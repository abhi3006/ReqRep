package com.vz.mybiz.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.mybiz.entity.ServiceRequestEntity;


import java.util.List;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SRDataListResponse {
	
	private Long totalElements;
	private Integer pageSize;
	private Integer totalPages;
	private Integer currentPageNo;
	private List<ServiceRequestEntity> data;
	
	public List<ServiceRequestEntity> getData() {
		return data;
	}
	public void setData(List<ServiceRequestEntity> data) {
		this.data = data;
	}
	public Long getTotalElements() {
		return totalElements;
	}
	public void setTotalElements(Long total) {
		this.totalElements = total;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}
	public Integer getCurrentPageNo() {
		return currentPageNo;
	}
	public void setCurrentPageNo(Integer currentPageNo) {
		this.currentPageNo = currentPageNo;
	}
	

}
