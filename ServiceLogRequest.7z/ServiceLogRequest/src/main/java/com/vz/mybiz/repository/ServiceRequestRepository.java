package com.vz.mybiz.repository;

import com.vz.mybiz.entity.ServiceRequestEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

@Repository
public interface ServiceRequestRepository
        extends CrudRepository<ServiceRequestEntity, BigInteger>,
        PagingAndSortingRepository<ServiceRequestEntity, BigInteger>,
        JpaSpecificationExecutor<ServiceRequestEntity> {
    @Query("select e from ServiceRequestEntity e where e.ecpdId= :ecpdId")
    Page<ServiceRequestEntity> findByEcpdId(@Param("ecpdId") Long ecpdId, Pageable pageable);
}
