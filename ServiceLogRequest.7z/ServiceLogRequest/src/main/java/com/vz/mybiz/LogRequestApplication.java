package com.vz.mybiz;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class LogRequestApplication {
	public static void main(String[] args) {
		SpringApplication.run(LogRequestApplication.class, args);
    }       
}            