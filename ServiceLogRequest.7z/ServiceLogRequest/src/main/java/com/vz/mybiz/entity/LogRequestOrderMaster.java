package com.vz.mybiz.entity;

public class LogRequestOrderMaster {
    ORDER_NBR
            POS_ORDER_NR
    NETACE_LOCATION
}
