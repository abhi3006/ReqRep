package com.vz.mybiz.controller;


import com.vz.mybiz.LogRequestApplication;
import com.vz.mybiz.service.IServiceRequestService;
import com.vz.mybiz.util.SRDataListResponse;
import com.vz.mybiz.util.ServiceRegistryPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Optional;

@Controller
@CrossOrigin
@RequestMapping("log")
public class ServiceRequestController {
	@Autowired
	private IServiceRequestService iServiceRequestService;
	@GetMapping("ecpid/{id}")
	public ResponseEntity<SRDataListResponse> getServiceRegistry (@PathVariable("id") Long id, @RequestBody(required = false) ServiceRegistryPage request) {
		if (request==null) {
			request= new ServiceRegistryPage();
			request.setPageNo(0);
			request.setPageSize(10);
		}
		return iServiceRequestService.getServiceRegistryEcpdIdList(request, id);
	}

	@PostMapping("logrequest")
	public ResponseEntity<SRDataListResponse> getServiceRegistry (@PathVariable("id") Long id, @RequestBody(required = false) ServiceRegistryPage request) {
		if (request==null) {
			request= new ServiceRegistryPage();
			request.setPageNo(0);
			request.setPageSize(10);
		}
		return iServiceRequestService.getServiceRegistryEcpdIdList(request, id);
	}
}