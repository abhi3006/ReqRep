package com.vz.mybiz.service;

import com.vz.mybiz.entity.ServiceRequestEntity;
import com.vz.mybiz.util.ServiceRegistryPage;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
public interface IServiceRequestService {
     ResponseEntity getServiceRegistryEcpdIdList(ServiceRegistryPage request, Long id);

}
