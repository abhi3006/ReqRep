package com.vz.vm.service;

import com.vz.vm.entity.ServiceRequestEntity;
import com.vz.vm.repository.ServiceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;

@Service
public class ServiceRequestService implements IServiceRequestService {
	@Autowired
	private ServiceRequestRepository requestRepository;

	@Override
	public List<ServiceRequestEntity> findByEcpdId(BigInteger ecpdId) {
		List<ServiceRequestEntity> list = requestRepository.findByEcpdId(ecpdId);
		return list;

	}
}
