package com.vz.vm.service;

import com.vz.vm.entity.ServiceRequestEntity;
import com.vz.vm.repository.ServiceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Optional;

@Service
public class ServiceRequestService implements IServiceRequestService {
	@Autowired
	private ServiceRequestRepository requestRepository;

	@Override
	public ServiceRequestEntity findByEcpdId(BigInteger ecpdId) {
		Optional<ServiceRequestEntity> client = Optional.ofNullable(requestRepository.findByEcpdId(ecpdId));
		return client.isPresent() ?  client.get() : null;

	}

}
