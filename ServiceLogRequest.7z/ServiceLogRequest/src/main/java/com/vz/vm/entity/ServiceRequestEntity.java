package com.vz.vm.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;


@Entity
@Table(name = "COMM_REQ_RESP_LOG")
public class ServiceRequestEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private BigInteger Id;
	@Column(name = "LOG_TYPE")
	private String logType;
	@Column(name = "SERVICE")
	private String service;
	@Column(name = "URI")
	private String uri;
	@Column(name = "TRACE")
	private String trace;
	@Column(name = "SPAN")
	private String span;
	@Column(name = "CORRELATION_ID")
	private String correlationId;
	@Column(name = "TRANSACTION_ID")
	private String transactionId;
	@Column(name = "RESPONSE_CD")
	private String responseCd;
	@Column(name = "MESSAGE_DESCRIPTION")
	private String messageDesc;
	@Column(name = "ENV")
	private String env;
	@Column(name = "ECPD_ID")
	private BigInteger ecpdId;
	@Column(name = "TIME_TAKEN")
	private BigInteger timeTaken;
	@Lob
	@Column(name = "REQ_PAYLOAD")
	private String reqPayload;
	@Lob
	@Column(name = "RESP_PAYLOAD")
	private String respPayload;
	@Column (name = "USER_NAME")
	private String userName;

	@Column(name = "SESSION_ID")
	private String sessionId;
	@Column(name = "EXTERNAL_SYSTEM")
	private String externalSys;
	@Column (name = "EXTERNAL_SUB_SERVICE")
	private String externalSubSer;
	@Column (name = "API_CREATE_DATE")
	private LocalDateTime apiCreateDt;
	@Column (name = "AUDIT_CREATE_DATE")
	private LocalDateTime auditCreateDt;


	/**
	 * @return the id
	 */
	public BigInteger getId() {
		return Id;
	}



	/**
	 * @param id the id to set
	 */
	public void setId(BigInteger id) {
		Id = id;
	}



	/**
	 * @return the logType
	 */
	public String getLogType() {
		return logType;
	}



	/**
	 * @param logType the logType to set
	 */
	public void setLogType(String logType) {
		this.logType = logType;
	}



	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}



	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}



	/**
	 * @return the uri
	 */
	public String getUri() {
		return uri;
	}



	/**
	 * @param uri the uri to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}



	/**
	 * @return the trace
	 */
	public String getTrace() {
		return trace;
	}



	/**
	 * @param trace the trace to set
	 */
	public void setTrace(String trace) {
		this.trace = trace;
	}



	/**
	 * @return the span
	 */
	public String getSpan() {
		return span;
	}



	/**
	 * @param span the span to set
	 */
	public void setSpan(String span) {
		this.span = span;
	}



	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}



	/**
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}



	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}



	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}



	/**
	 * @return the responseCd
	 */
	public String getResponseCd() {
		return responseCd;
	}



	/**
	 * @param responseCd the responseCd to set
	 */
	public void setResponseCd(String responseCd) {
		this.responseCd = responseCd;
	}



	/**
	 * @return the messageDesc
	 */
	public String getMessageDesc() {
		return messageDesc;
	}



	/**
	 * @param messageDesc the messageDesc to set
	 */
	public void setMessageDesc(String messageDesc) {
		this.messageDesc = messageDesc;
	}



	/**
	 * @return the env
	 */
	public String getEnv() {
		return env;
	}



	/**
	 * @param env the env to set
	 */
	public void setEnv(String env) {
		this.env = env;
	}



	/**
	 * @return the ecpdId
	 */
	public BigInteger getEcpdId() {
		return ecpdId;
	}



	/**
	 * @param ecpdId the ecpdId to set
	 */
	public void setEcpdId(BigInteger ecpdId) {
		this.ecpdId = ecpdId;
	}



	/**
	 * @return the timeTaken
	 */
	public BigInteger getTimeTaken() {
		return timeTaken;
	}



	/**
	 * @param timeTaken the timeTaken to set
	 */
	public void setTimeTaken(BigInteger timeTaken) {
		this.timeTaken = timeTaken;
	}



	/**
	 * @return the reqPayload
	 */
	public String getReqPayload() {
		return reqPayload;
	}



	/**
	 * @param reqPayload the reqPayload to set
	 */
	public void setReqPayload(String reqPayload) {
		this.reqPayload = reqPayload;
	}



	/**
	 * @return the respPayload
	 */
	public String getRespPayload() {
		return respPayload;
	}



	/**
	 * @param respPayload the respPayload to set
	 */
	public void setRespPayload(String respPayload) {
		this.respPayload = respPayload;
	}



	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}



	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}



	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}



	/**
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}



	/**
	 * @return the externalSys
	 */
	public String getExternalSys() {
		return externalSys;
	}



	/**
	 * @param externalSys the externalSys to set
	 */
	public void setExternalSys(String externalSys) {
		this.externalSys = externalSys;
	}



	/**
	 * @return the externalSubSer
	 */
	public String getExternalSubSer() {
		return externalSubSer;
	}



	/**
	 * @param externalSubSer the externalSubSer to set
	 */
	public void setExternalSubSer(String externalSubSer) {
		this.externalSubSer = externalSubSer;
	}



	/**
	 * @return the apiCreateDt
	 */
	public LocalDateTime getApiCreateDt() {
		return apiCreateDt;
	}



	/**
	 * @param apiCreateDt the apiCreateDt to set
	 */
	public void setApiCreateDt(LocalDateTime apiCreateDt) {
		this.apiCreateDt = apiCreateDt;
	}



	/**
	 * @return the auditCreateDt
	 */
	public LocalDateTime getAuditCreateDt() {
		return auditCreateDt;
	}



	/**
	 * @param auditCreateDt the auditCreateDt to set
	 */
	public void setAuditCreateDt(LocalDateTime auditCreateDt) {
		this.auditCreateDt = auditCreateDt;
	}


	public ServiceRequestEntity(){

	}

	@Override
	public String toString() {
		return "ServiceRequestEntity [Id=" + Id + ", logType=" + logType + ", service=" + service + ", uri=" + uri
				+ ", trace=" + trace + ", span=" + span + ", correlationId=" + correlationId + ", transactionId="
				+ transactionId + ", responseCd=" + responseCd + ", messageDesc=" + messageDesc + ", env=" + env
				+ ", ecpdId=" + ecpdId + ", timeTaken=" + timeTaken + ", reqPayload=" + reqPayload + ", respPayload="
				+ respPayload + ", userName=" + userName + ", sessionId=" + sessionId + ", externalSys=" + externalSys
				+ ", externalSubSer=" + externalSubSer + ", apiCreateDt=" + apiCreateDt + ", auditCreateDt="
				+ auditCreateDt + "]";
	}


}
