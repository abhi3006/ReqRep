package com.vz.vm.repository;

import com.vz.vm.entity.ServiceRequestEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;

@Repository
public interface ServiceRequestRepository extends CrudRepository<ServiceRequestEntity, BigInteger> {
    ServiceRequestEntity findByEcpdId(BigInteger ecpdId);
}
