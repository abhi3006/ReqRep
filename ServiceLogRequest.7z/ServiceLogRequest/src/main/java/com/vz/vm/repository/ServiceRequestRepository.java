package com.vz.vm.repository;

import com.vz.vm.entity.ServiceRequestEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Repository
public interface ServiceRequestRepository extends CrudRepository<ServiceRequestEntity, BigInteger> {
    @Query("select e from ServiceRequestEntity e where e.ecpdId= :ecpdId")
    List<ServiceRequestEntity> findByEcpdId(@Param("ecpdId") BigInteger ecpdId);
}
