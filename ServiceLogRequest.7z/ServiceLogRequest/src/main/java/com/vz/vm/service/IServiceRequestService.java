package com.vz.vm.service;

import com.vz.vm.entity.ServiceRequestEntity;

import java.math.BigInteger;

public interface IServiceRequestService {
     ServiceRequestEntity findByEcpdId(BigInteger ecpdId);

}
