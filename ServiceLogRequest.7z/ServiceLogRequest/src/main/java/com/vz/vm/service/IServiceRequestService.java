package com.vz.vm.service;

import com.vz.vm.entity.ServiceRequestEntity;

import java.math.BigInteger;
import java.util.List;

public interface IServiceRequestService {
     List<ServiceRequestEntity> findByEcpdId(BigInteger ecpdId);

}
