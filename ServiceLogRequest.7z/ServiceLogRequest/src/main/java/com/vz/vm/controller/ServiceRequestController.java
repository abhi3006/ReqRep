package com.vz.vm.controller;

import com.vz.vm.entity.ServiceRequestEntity;
import com.vz.vm.service.IServiceRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;


@Controller
@RequestMapping("log")
public class ServiceRequestController {

	@Autowired
	private IServiceRequestService iServiceRequestService;
	@GetMapping("ecpid/{id}")
	public ResponseEntity<List<ServiceRequestEntity>> getServiceRequestById(@PathVariable("id") BigInteger id) {
		List<ServiceRequestEntity> requestEntity = iServiceRequestService.findByEcpdId(id);
		return new ResponseEntity<List<ServiceRequestEntity>>(requestEntity, HttpStatus.OK);
	}
}