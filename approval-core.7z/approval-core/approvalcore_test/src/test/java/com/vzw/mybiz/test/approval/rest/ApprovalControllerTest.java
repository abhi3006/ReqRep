package com.vzw.mybiz.test.approval.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.rest.ApprovalController;
import com.vzw.mybiz.approval.service.ManagerService;




@RunWith(SpringRunner.class)
public class ApprovalControllerTest {

	@Spy
	@InjectMocks
	ApprovalController approvalController;

	private MockMvc mockMvc;

	@MockBean
	ManagerService managerService;

	Gson gson = new Gson();

	ManagerApprovalInfo managerApprovalServiceRes;
	
	ManagerApprovalResponse maResponse;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(approvalController).build();
		managerApprovalServiceRes = new ManagerApprovalInfo();
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		managerApprovalServiceRes.setServiceStatus(serviceStatus);
		managerApprovalServiceRes.setReadonly(false);
		managerApprovalServiceRes.setRequired(true);
		managerApprovalServiceRes.setUserInputType("Input Text");
		managerApprovalServiceRes.setPrePopulateEmailID("someone@some.com");
		
	    maResponse=new ManagerApprovalResponse();
		maResponse.setServiceStatus(serviceStatus);

	}
	

	@Test
	public void test_approvalLanding() throws Exception {

	}

	public MvcResult getMvcResult(String url,ManagerApprovalRequest approvalReq) {
		try {
			return mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.accept(MediaType.APPLICATION_JSON_VALUE).content(gson.toJson(approvalReq)))
					.andExpect(status().isOk()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Test
	public void getManagerApprovalInfo() throws Exception {
		Mockito.when(managerService.getManagerApprovalInfo(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(managerApprovalServiceRes);

		ManagerApprovalRequest getApprovalReq = new ManagerApprovalRequest();
		getApprovalReq.setEcpdId("9782");
		getApprovalReq.setUserId("9782QA123");
		getApprovalReq.setZipCode("30007");
		MvcResult mvcResult = getMvcResult("/mbt/approval/getMAInformation",getApprovalReq);

		ManagerApprovalInfo managerApprovalOrderResponse1 = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalInfo.class);
		assertNotNull(managerApprovalOrderResponse1);
		assertThat(managerApprovalOrderResponse1.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void getManagerApprovalMissingParams() throws Exception{
		Mockito.when(managerService.getManagerApprovalInfo(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(managerApprovalServiceRes);
		ManagerApprovalRequest getApprovalReq = new ManagerApprovalRequest();
		getApprovalReq.setEcpdId("");
		getApprovalReq.setUserId("9782QA123");

		MvcResult mvcResult = getMvcResult("/mbt/approval/getMAInformation",getApprovalReq);
		ManagerApprovalInfo managerApprovalOrderResponse1 = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalInfo.class);
		assertNotNull(managerApprovalOrderResponse1);
		assertThat(managerApprovalOrderResponse1.getServiceStatus().getStatusCode()).isEqualTo("99");
	}
	
	@Test
	public void test_saveManagerApprovalInfo() throws Exception {
		ManagerApprovalData managerApprovalData=new ManagerApprovalData();
		managerApprovalData.setEcpdId("TEST1234");
		Mockito.when(managerService.saveManagerApprovalDetails(Mockito.isA(ManagerApprovalData.class)))
		.thenReturn(maResponse);
		
		MvcResult mvc=
				 mockMvc.perform(post("/mbt/approval/saveMAInformation").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
							.content(gson.toJson(managerApprovalData)))				
							.andExpect(status().isOk())
							.andReturn();
		
		ManagerApprovalResponse maResp= gson.fromJson(mvc.getResponse().getContentAsString(),ManagerApprovalResponse.class);
		assertNotNull(maResp);
		assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);
		
	}
	
}
