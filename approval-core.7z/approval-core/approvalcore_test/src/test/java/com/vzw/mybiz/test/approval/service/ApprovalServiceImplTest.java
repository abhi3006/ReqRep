package com.vzw.mybiz.test.approval.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.CartCore;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AccessoryPackage;
import com.vzw.mybiz.approval.domain.Cart;
import com.vzw.mybiz.approval.domain.CartResponse;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.DgfFieldShortLookup;
import com.vzw.mybiz.approval.domain.DomainList;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.Equipment;
import com.vzw.mybiz.approval.domain.ManageApprovalMiscDto;
import com.vzw.mybiz.approval.domain.ManageApprovalOrderDto;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.entity.ManagerApprovalUrl;
import com.vzw.mybiz.approval.repo.MaTrackerRepo;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.impl.ManagerServiceImpl;
import com.vzw.mybiz.caching.services.cache.CacheService;

@RunWith(SpringRunner.class)
@SuppressWarnings("deprecation")
public class ApprovalServiceImplTest {

	@Spy
	@InjectMocks
	ManagerServiceImpl managerService;

	private MockMvc mockMvc;

	@MockBean
	private CustomizationClient customizationClient;

	@MockBean
	private CompanyClient companyClient;

	@MockBean
	CacheService<ManagerApprovalInfo> managerApprovalSession;

	@MockBean
	private CartCore cartCore;

	Gson gson = new Gson();
	@Autowired
	
	@MockBean
	private ManagerApprovalRepo managerApprovalRepo;
	
	@MockBean
	private MaTrackerRepo maTrackerRepo;

	ManagerApprovalInfo managerApprovalServiceRes;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(managerService).build();

		managerApprovalServiceRes = new ManagerApprovalInfo();
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		managerApprovalServiceRes.setServiceStatus(serviceStatus);
		managerApprovalServiceRes.setReadonly(false);
		managerApprovalServiceRes.setRequired(true);
		managerApprovalServiceRes.setUserInputType("Input Text");
		managerApprovalServiceRes.setPrePopulateEmailID("someone@some.com");
	}

	public EcpdProfileInfo getEcpdInfo() {
		EcpdProfileInfo ecpdInfo = new EcpdProfileInfo();
		ecpdInfo.setApproverEmail1("Emailid1.com");
		ecpdInfo.setApproverEmail2("Emailid2.com");
		ecpdInfo.setApproverEmail3("Emailid3.com");
		ecpdInfo.setOption(1);
		return ecpdInfo;
	}

	public String[] getDomainList() {
		return new String[] { "verizon.com" };
	}

	public CompanyCoreResponse getCompanyCoreRes(boolean isDomain) {
		CompanyCoreResponse companyCoreResponse = new CompanyCoreResponse();
		companyCoreResponse.setBusinessZip("30007");
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		companyCoreResponse.setServiceStatus(serviceStatus);
		OrderDataManagerApproval managerApproval = new OrderDataManagerApproval();
		managerApproval.setCommerceInfo(getEcpdInfo());
		if(isDomain) {
			managerApproval.setDomainEntry(getDomainList());
		}
		companyCoreResponse.setManagerApproval(managerApproval);
		return companyCoreResponse;
	}

	public DgfFieldShort getFieldDomain() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.EMAIL_DOMAIN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("nirupama@verizon.com");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	public DgfFieldShort getFieldDropdown() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.DROPDOWN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("");
		field.setReadonly(false);
		field.setRequired(true);
		DgfFieldShortLookup lookup = new DgfFieldShortLookup();
		lookup.setDefaultFlag("Y");
		lookup.setDisplayName("test@gmai.com");
		lookup.setValue("test");
		DgfFieldShortLookup lookup1 = new DgfFieldShortLookup();
		lookup1.setDefaultFlag("N");
		lookup1.setDisplayName("new@gmai.com");
		lookup1.setValue("new");
		List<DgfFieldShortLookup> listLookup = new ArrayList<DgfFieldShortLookup>();
		listLookup.add(lookup);
		listLookup.add(lookup1);
		field.setLookUp(listLookup);
		return field;
	}

	public DgfFieldShort getFieldText() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.INPUT_TEXT);
		field.setLookUp(null);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("Ramya.Shivakumar@verizoniwireless.com");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	
	public ManageApprovalOrderDto getManagerApprovalOrder(String type, boolean isOrderType, boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if(isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if(isOrderThreshold) {
			orderDto.setOt(getFieldText());	
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(1);
		orderDto.setQuantityThresholdValueNAO("Greater Than/Equal To");
		orderDto.setQuanttityThresholdNAO(true);
		orderDto.setOrderThresholdRule("Less Than/Equal To");
		orderDto.setOrderThresholdValue(29);
		return orderDto;
	}
	
	public ManageApprovalOrderDto getManagerApprovalOrder1(String type, boolean isOrderType, boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if(isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if(isOrderThreshold) {
			orderDto.setOt(getFieldText());	
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(4);
		orderDto.setQuantityThresholdValueNAO("Less Than/Equal To");
		orderDto.setQuanttityThresholdNAO(true);
		orderDto.setOrderThresholdRule("Greater Than/Equal To");
		orderDto.setOrderThresholdValue(25);
		return orderDto;
	}
	
	public ManageApprovalOrderDto getManagerApprovalOrderMissingQuantity(String type, boolean isOrderType, boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if(isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if(isOrderThreshold) {
			orderDto.setOt(getFieldText());	
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(1);
		orderDto.setQuantityThresholdValueNAO("Less Than/Equal To");
		orderDto.setQuanttityThresholdNAO(false);
		orderDto.setOrderThresholdRule("Greater Than/Equal To");
		orderDto.setOrderThresholdValue(27);
		return orderDto;
	}
	
	public CustomizationEcpdProfileDto getCustomicationEcpdProfile(int urlStatus) {
		CustomizationEcpdProfileDto profileDto = new CustomizationEcpdProfileDto();
		profileDto.setManagerApprovalState(urlStatus);
		profileDto.setManagerApprovalVariable(1);
		profileDto.setUrlStatus(urlStatus);
		return profileDto;
	}

	public DgfDto getDgfDto(String type,int urlStatus, 
			boolean isManageAllOrders, boolean isOrderType, boolean isOrderThreshold) {
		DgfDto dgfDto = new DgfDto();
		ManageApprovalMiscDto miscDto = new ManageApprovalMiscDto();
		miscDto.setManageAllOrders(isManageAllOrders);
		dgfDto.setManageApprovalMiscDto(miscDto);
		if(urlStatus == 1)
			dgfDto.setManageApprovalOrder(getManagerApprovalOrder1(type,isOrderType,isOrderThreshold));
		else if(urlStatus == 0)
			dgfDto.setManageApprovalOrder(getManagerApprovalOrder(type,isOrderType,isOrderThreshold));
		dgfDto.setEcpdProfile(getCustomicationEcpdProfile(urlStatus));
		return dgfDto;
	}

	public CheckoutCustomization getCustomizationResponse(String type,int urlStatus, boolean isManageAllOrders,
			boolean isOrderType, boolean isOrderThreshold) {
		CheckoutCustomization checkoutRes = new CheckoutCustomization();
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		checkoutRes.setServiceStatus(serviceStatus);
		checkoutRes.setDgf(getDgfDto(type,urlStatus,isManageAllOrders,isOrderType,isOrderThreshold));
		return checkoutRes;
	}

	public DgfDto getDgfDtoMissingQty(String type,int urlStatus, 
			boolean isManageAllOrders, boolean isOrderType, boolean isOrderThreshold) {
		DgfDto dgfDto = new DgfDto();
		ManageApprovalMiscDto miscDto = new ManageApprovalMiscDto();
		miscDto.setManageAllOrders(isManageAllOrders);
		dgfDto.setManageApprovalMiscDto(miscDto);
		dgfDto.setManageApprovalOrder(getManagerApprovalOrderMissingQuantity(type,isOrderType,isOrderThreshold));
		dgfDto.setEcpdProfile(getCustomicationEcpdProfile(urlStatus));
		return dgfDto;
	}
	
	public CheckoutCustomization getCustomizationResponseMisingQty(String type,int urlStatus, boolean isManageAllOrders,
			boolean isOrderType, boolean isOrderThreshold) {
		CheckoutCustomization checkoutRes = new CheckoutCustomization();
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		checkoutRes.setServiceStatus(serviceStatus);
		checkoutRes.setDgf(getDgfDtoMissingQty(type,urlStatus,isManageAllOrders,isOrderType,isOrderThreshold));
		return checkoutRes;
	}
	
	private Equipment getCartAccessory() {
		Equipment equipment = new Equipment();
		equipment.setProductCode("VPC48BLK");
		equipment.setQuantity(3);
		return equipment;
	}

	public CartResponse getCartResponse() {
		CartResponse cartRes = new CartResponse();
		Cart cart = new Cart();
		cart.setCartId("Cart_c1dd38ca-63d8-45d7-9634-c5fc6fe01039");
		AccessoryPackage accessoryPackage = new AccessoryPackage();
		List<Equipment> equipmentList = new ArrayList();
		equipmentList.add(getCartAccessory());
		accessoryPackage.setEquipmentList(equipmentList);
		accessoryPackage.setTotalDueNow(24.32);
		cart.setAccessoryPackage(accessoryPackage);
		cartRes.setCart(cart);
		return cartRes;
	}

	@Test
	public void getManagerApprovalInfoCache() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(managerApprovalServiceRes);
		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");
		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void getManagerApprovalNotCached_TextType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",1,true,false,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void getManagerApproval_CatchBlock() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",1,true,false,false));
		//Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());
		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void getManagerApprovalNotCached_DomainType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(true));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("Domain",1,true,false,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.getEmailDomainList().size()).isGreaterThan(0);
	}

	@Test
	public void getManagerApprovalNotCached_DropdownType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("Dropdown",1,true,false,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.getLookUp().size()).isGreaterThan(0);
	}
	
	@Test
	public void getManagerApprovalNotCached_EcpdProfile_url() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",0,true,false,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.isManagerApprovalEnabled()).isEqualTo(true);
	}
	
	@Test
	public void getManagerApprovalNotCached_orderTypeNao() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",1,false,true,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
	}
	
	@Test
	public void getManagerApprovalNotCached_orderTypeNaoEvaluate() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",0,false,true,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void getManagerApprovalNotCached_orderThresholdRules() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponse("",0,false,false,true));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void getManagerApprovalNotCached_quantityThresholdMissing() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.anyObject())).thenReturn(getCompanyCoreRes(false));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.anyObject()))
				.thenReturn(getCustomizationResponseMisingQty("",2,false,true,false));
		Mockito.when(cartCore.retrieveCart(Mockito.anyObject())).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo("9782", "9782QA123","30007");

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void saveManagerApprovalDetails_Test() {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject()))
		.thenReturn(managerApprovalServiceRes);
		
		ManagerApprovalData maReq=new ManagerApprovalData();
		maReq.setEcpdId("9789");
		maReq.setLevel("1");
		maReq.setMaApprovalUrl("https://b2b.verizonwireless.com/b2b/commerce/webflow/lowerfunnel/checkout-manager");
		maReq.setOrderNumber("MB7000000349830");
		
		Mockito.when(managerApprovalRepo.save(Mockito.isA(ManagerApprovalTracker.class))).thenReturn(new ManagerApprovalTracker());
		Mockito.when(maTrackerRepo.save(Mockito.isA(ManagerApprovalUrl.class))).thenReturn(new ManagerApprovalUrl());
		
		
		ManagerApprovalResponse maResp=managerService.saveManagerApprovalDetails(maReq);
		assertNotNull(maResp);
		assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);
		
		
		
	}
}
