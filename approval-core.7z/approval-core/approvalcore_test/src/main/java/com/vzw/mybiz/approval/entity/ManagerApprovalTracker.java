package com.vzw.mybiz.approval.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "EPS_MGR_APPROVAL_TXN", schema = "COMMB2B")
public class ManagerApprovalTracker implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tx_generator")
	@SequenceGenerator(name = "tx_generator", sequenceName = "EPS_MGR_APPROVAL_TXN_SEQ", schema = "COMMB2B", allocationSize = 1)
	@Column(name = "MA_TRANSACTION_ID", updatable = false, nullable = false)
	private Long id;

	@Column(name = "MA_APP_TRANS_ID", nullable = false)
	private String orderNumber;

	@Column(name = "MA_MANAGER_APPROVAL_LEVEL")
	private Integer level;

	@Column(name = "MA_APPROVAL_URLS_L1")
	private String levelApproveUrl1;

	@Column(name = "MA_APPROVAL_URLS_L2")
	private String levelApproveUrl2;

	@Column(name = "MA_APPROVAL_URLS_L3")
	private String levelApproveUrl3;

	@Column(name = "MA_RECORD_TYPE")
	private String recordType;

	@Column(name = "MA_TRANSACTION_STATUS")
	private String status;

	@Column(name = "ECPD_ID")
	private String ecpdId;

	@Column(name = "MA_REASON_CODE")
	private String reasonCode;

	@Column(name = "MA_APP_ID")
	private String appId;

	@Column(name = "MA_TRANSACTION_TYPE")
	private String transactionType;

	@Column(name = "MA_APPROVED_BY_EMAIL_L1")
	private String approvedByEmail1;

	@Column(name = "MA_APPROVED_BY_EMAIL_L2")
	private String approvedByEmail2;

	@Column(name = "MA_APPROVED_BY_EMAIL_L3")
	private String approvedByEmail3;

	@Column(name = "MA_APPROVER_EMAILS_L1")
	private String email1;

	@Column(name = "MA_APPROVER_EMAILS_L2")
	private String email2;

	@Column(name = "MA_APPROVER_EMAILS_L3")
	private String email3;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getLevelApproveUrl1() {
		return levelApproveUrl1;
	}

	public void setLevelApproveUrl1(String levelApproveUrl1) {
		this.levelApproveUrl1 = levelApproveUrl1;
	}

	public String getLevelApproveUrl2() {
		return levelApproveUrl2;
	}

	public void setLevelApproveUrl2(String levelApproveUrl2) {
		this.levelApproveUrl2 = levelApproveUrl2;
	}

	public String getLevelApproveUrl3() {
		return levelApproveUrl3;
	}

	public void setLevelApproveUrl3(String levelApproveUrl3) {
		this.levelApproveUrl3 = levelApproveUrl3;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getApprovedByEmail1() {
		return approvedByEmail1;
	}

	public void setApprovedByEmail1(String approvedByEmail1) {
		this.approvedByEmail1 = approvedByEmail1;
	}

	public String getApprovedByEmail2() {
		return approvedByEmail2;
	}

	public void setApprovedByEmail2(String approvedByEmail2) {
		this.approvedByEmail2 = approvedByEmail2;
	}

	public String getApprovedByEmail3() {
		return approvedByEmail3;
	}

	public void setApprovedByEmail3(String approvedByEmail3) {
		this.approvedByEmail3 = approvedByEmail3;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public String getEmail3() {
		return email3;
	}

	public void setEmail3(String email3) {
		this.email3 = email3;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
