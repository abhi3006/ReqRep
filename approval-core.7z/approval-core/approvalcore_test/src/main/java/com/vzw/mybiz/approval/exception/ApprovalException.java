package com.vzw.mybiz.approval.exception;

public class ApprovalException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public ApprovalException(Exception exception) {
		super(exception);
	}
	
	public ApprovalException(String errorCode,String errorMessage) {
	// Generate the response from	
	}
}
