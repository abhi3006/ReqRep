package com.vzw.mybiz.approval.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vzw.mybiz.approval.client.CartCore;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AccessoryPackage;
import com.vzw.mybiz.approval.domain.Cart;
import com.vzw.mybiz.approval.domain.CartResponse;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.DomainList;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.Equipment;
import com.vzw.mybiz.approval.domain.ManageApprovalMiscDto;
import com.vzw.mybiz.approval.domain.ManageApprovalOrderDto;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.OrderTypeDetails;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.entity.ManagerApprovalUrl;
import com.vzw.mybiz.approval.repo.MaTrackerRepo;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.ManagerService;
import com.vzw.mybiz.caching.services.cache.CacheService;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	CacheService<ManagerApprovalInfo> managerApprovalCache;

	@Autowired
	private CustomizationClient customizationClient;

	@Autowired
	private CompanyClient companyClient;

	@Autowired
	private CartCore cartCore;

	@Autowired
	private ManagerApprovalRepo managerApprovalRepo;

	@Autowired
	private MaTrackerRepo maTrackerRepo;

	public static final String MA_INFO_KEY = "CACHE_MA_";

	@Override
	public ManagerApprovalInfo getManagerApprovalInfo(String ecpdId, String userId,String zipCode) {
		ManagerApprovalInfo serviceRes = new ManagerApprovalInfo();
		try {
			ManagerApprovalInfo managerResfromCache = managerApprovalCache.getFromSession(MA_INFO_KEY + ecpdId,
					ManagerApprovalInfo.class);
			if (managerResfromCache != null) {
				return managerResfromCache;
			}
			CommonRequest companyCoreReq = new CommonRequest();
			companyCoreReq.setEcpdId(ecpdId);
			companyCoreReq.setUserId(userId);
			companyCoreReq.setZipCode(zipCode);
			CompanyCoreResponse companyCoreResponse = companyClient.getCompanyOrderData(companyCoreReq);
			CheckoutCustomization customizationInfo = customizationClient.getCustomizationInfo(companyCoreReq);
			managerApprovalForOrder(companyCoreResponse.getManagerApproval(), customizationInfo, companyCoreReq,
					serviceRes);
			serviceRes.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			managerApprovalCache.setToSession(MA_INFO_KEY+ecpdId, serviceRes);
		} catch (Exception e) {
			serviceRes.setServiceStatus(getServiceStatus(Constants.EXCEPTION_CODE, Constants.EXCEPTION_MSG));
		}
		return serviceRes;

	}

	private ManagerApprovalInfo managerApprovalForOrder(OrderDataManagerApproval managerApproval,
			CheckoutCustomization customizationInfo, CommonRequest companyCoreReq, ManagerApprovalInfo res) {
		EcpdProfileInfo ecpdProfileInfo = managerApproval.getCommerceInfo();

		ManageApprovalOrderDto manageApprovalOrderDto = null;

		String[] domainList = managerApproval.getDomainEntry();
		if (customizationInfo != null && customizationInfo.getDgf() != null
				&& customizationInfo.getDgf().getManageApprovalOrder() != null) {
			manageApprovalOrderDto = customizationInfo.getDgf().getManageApprovalOrder();
		}

		boolean showManagerApproval = showManagerApproval(ecpdProfileInfo, customizationInfo.getDgf());
		res.setManagerApprovalEnabled(showManagerApproval);
		if (showManagerApproval && manageApprovalOrderDto != null) {
			CartResponse cartResponse = cartCore.retrieveCart(companyCoreReq);
			DgfFieldShort fieldData = setManagerApproverDetails(res, ecpdProfileInfo, customizationInfo, cartResponse);
			setManagerApprovalFields(fieldData, res);
			setManagerApprovalLevelEmail(res, ecpdProfileInfo);
			if (fieldData.getDgfDataType().equalsIgnoreCase(Constants.EMAIL_DOMAIN)) {
				setDomainList(res, domainList);
			}
		}
		return res;
	}

	public void setDomainList(ManagerApprovalInfo managerApprovalRes, String[] domainList) {
		if (domainList != null && CollectionUtils.isNotEmpty(Arrays.asList(domainList))) {
			List<String> emailDomainList = new ArrayList<>();
			for (String domain : domainList) {
				emailDomainList.add(domain);
			}
			managerApprovalRes.setEmailDomainList(emailDomainList);
		}
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		return serviceStatus;
	}

	private DgfFieldShort manageNaoType(ManageApprovalOrderDto manageApprovalOrder, OrderTypeDetails orderTypeDetails) {
		DgfFieldShort nao = manageApprovalOrder.getNao();
		Boolean naoEnabled = manageApprovalOrder.getNaoEnable();
		if (naoEnabled != null && naoEnabled && orderTypeDetails.getNaoCount() > 0) {
			if (manageApprovalOrder.isQuanttityThresholdNAO()
					&& StringUtils.isNotEmpty(manageApprovalOrder.getQuantityThresholdValueNAO())) {
				if (evaluateThresholdRules(manageApprovalOrder.getQuantityNAO(),
						manageApprovalOrder.getQuantityThresholdValueNAO(), orderTypeDetails.getNaoCount())) {
					return nao;
				}
			} else {
				return nao;
			}
		}
		return null;
	}

	private boolean evaluateThresholdRules(long thresholdValue, String thresholdRule, long value) {
		boolean threshHoldRetVal = false;
		if (thresholdRule.equals("Greater Than/Equal To")) {
			if (value >= thresholdValue) {
				threshHoldRetVal = true;
			}
		} else if (thresholdRule.equals("Less Than/Equal To")) {
			if (value <= thresholdValue) {
				threshHoldRetVal = true;
			}
		}
		return threshHoldRetVal;
	}

	private boolean showManagerApproval(EcpdProfileInfo ecpdProfileInfo, DgfDto dgfDto) {
		boolean retVal = false;
		if (ecpdProfileInfo != null && ecpdProfileInfo.getOption() != 0) {
			CustomizationEcpdProfileDto ecpdProfile = dgfDto.getEcpdProfile();
			if (ecpdProfile.getUrlStatus() == 1) {
				final int ecpdState = ecpdProfile.getManagerApprovalState();
				if (ecpdState == 0 || ecpdState == 2 || ecpdState == 1) {
					retVal = true;
				}
			} else {
				retVal = true;
			}
		}
		return retVal;
	}

	public DgfFieldShort setManagerApproverDetails(ManagerApprovalInfo managerApprovalRes,
			EcpdProfileInfo commerApprovalInfo, CheckoutCustomization customizationInfo, CartResponse cartResponse) {

		DgfFieldShort dataField = null;
		ManageApprovalOrderDto manageApprovalOrder = customizationInfo.getDgf().getManageApprovalOrder();
		DgfDto dgf = customizationInfo.getDgf();
		if (manageApprovalOrder != null && manageApprovalOrder.getManagerApprovalSuppress() != null
				&& manageApprovalOrder.getManagerApprovalSuppress()) {
			managerApprovalRes.setManagerApprovalSuppress(true);
		}

		ManageApprovalMiscDto manageApprovalMisc = dgf.getManageApprovalMiscDto();
		DgfFieldShort managerApproval = null;
		if (manageApprovalOrder != null) {
			managerApproval = manageApprovalOrder.getManagerApproval();
		}
		if (manageApprovalMisc != null && manageApprovalMisc.isManageAllOrders()) {
			dataField = managerApproval;
		} else if (manageApprovalOrder != null && manageApprovalOrder.isOrderType()) {
			OrderTypeDetails orderTypeDetails = this.populateOrderTypeDetails(cartResponse);
			dataField = manageNaoType(manageApprovalOrder, orderTypeDetails);
		} else if (manageApprovalOrder != null && manageApprovalOrder.isOrderThreshold()) {
			double totalDue = cartResponse.getCart().getAccessoryPackage().getTotalDueNow();
			if (StringUtils.isNotBlank(manageApprovalOrder.getOrderThresholdRule())
					&& manageApprovalOrder.getOrderThresholdValue() > 0) {
				if ((manageApprovalOrder.getOrderThresholdRule().equals(Constants.GREATERTHNEQUALTO)
						&& totalDue >= manageApprovalOrder.getOrderThresholdValue())
						|| (manageApprovalOrder.getOrderThresholdRule().equals(Constants.LESSTHNEQUALTO)
								&& totalDue <= manageApprovalOrder.getOrderThresholdValue())) {
					dataField = manageApprovalOrder.getOt();
				}
			}
		}
		return dataField;
	}

	private OrderTypeDetails populateOrderTypeDetails(CartResponse cartResponse) {
		OrderTypeDetails orderTypeDetails = new OrderTypeDetails();
		Cart cart = cartResponse.getCart();
		int naoCount = 0;
		if (cart != null) {
			AccessoryPackage accessoryPackage = cart.getAccessoryPackage();
			if (CollectionUtils.isNotEmpty(accessoryPackage.getEquipmentList())) {
				for (Equipment equipment : accessoryPackage.getEquipmentList()) {
					naoCount += equipment.getQuantity();
				}
			}
		}
		orderTypeDetails.setNaoCount(naoCount);
		return orderTypeDetails;

	}

	private void setManagerApprovalFields(DgfFieldShort fieldData, ManagerApprovalInfo res) {
		res.setReadonly(fieldData.isReadonly());
		res.setRequired(fieldData.isRequired());
		res.setUserInputType(fieldData.getDgfDataType());
		res.setPrePopulateEmailID(fieldData.getPrePopulatedValue());
		if (fieldData.getDgfDataType().equalsIgnoreCase(Constants.DROPDOWN)) {
			res.setLookUp(fieldData.getLookUp());
		}
		if (fieldData.getDgfDataType().equalsIgnoreCase(Constants.INPUT_TEXT)
				|| fieldData.getDgfDataType().equalsIgnoreCase(Constants.EMAIL_DOMAIN)) {
			res.setPrePopulateEmailID(fieldData.getPrePopulatedValue());
		}
	}

	public void setManagerApprovalLevelEmail(ManagerApprovalInfo managerApprovalRes,
			EcpdProfileInfo commerApprovalInfo) {
		Set<String> levelOneApproval = new HashSet<>();
		if (commerApprovalInfo != null && commerApprovalInfo.getOption() == 1) {
			if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail1())) {
				levelOneApproval.add(commerApprovalInfo.getApproverEmail1());
			}
			if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail2())) {
				levelOneApproval.add(commerApprovalInfo.getApproverEmail2());
			}
			if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail3())) {
				levelOneApproval.add(commerApprovalInfo.getApproverEmail3());
			}

			managerApprovalRes.setApproverEmails(levelOneApproval);
		}
	}
	@Override
	public ManagerApprovalResponse saveManagerApprovalDetails(ManagerApprovalData maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			ManagerApprovalInfo managerResfromCache = managerApprovalCache
					.getFromSession(MA_INFO_KEY + maRequest.getEcpdId(), ManagerApprovalInfo.class);
			ManagerApprovalTracker maTracker = new ManagerApprovalTracker();
			maTracker.setEcpdId(maRequest.getEcpdId());
			maTracker.setLevel(Integer.valueOf(maRequest.getLevel()));
			maTracker.setApprovedByEmail1(
					managerResfromCache.getPrePopulateEmailID() + "," + maRequest.getApproverEmailIds());
			maTracker.setLevelApproveUrl1(maRequest.getMaApprovalUrl());
			maTracker.setAppId("MYBUSS");
			maTracker.setStatus("L1PENDING");
			maTracker.setTransactionType("ORDERS");
			maTracker.setRecordType("ORDERS");
			maTracker.setCreatedDate(new Date());
			maTracker.setOrderNumber(maRequest.getOrderNumber());
			maTracker = managerApprovalRepo.save(maTracker);
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			saveManagerApprovalUrl(maRequest);
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}

	private ManagerApprovalResponse saveManagerApprovalUrl(ManagerApprovalData maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			ManagerApprovalUrl maUrl = new ManagerApprovalUrl();
			maUrl.setEcpdId(Long.valueOf(maRequest.getEcpdId()));
			maUrl.setUrl(maRequest.getMaApprovalUrl());
			maUrl.setCreateDate(new Date());
			maUrl.setMaxAccessed(0);
			maUrl.setUserName(maRequest.getUserId());
			maUrl = maTrackerRepo.save(maUrl);
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}
}
