package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class CheckoutCustomization implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6515946445910611057L;

	private String errorCode;
	private String errorMessage;
	private ServiceStatus serviceStatus;
	
	private DgfDto dgf;

	public DgfDto getDgf() {
		return dgf;
	}

	public void setDgf(DgfDto dgf) {
		this.dgf = dgf;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

}
