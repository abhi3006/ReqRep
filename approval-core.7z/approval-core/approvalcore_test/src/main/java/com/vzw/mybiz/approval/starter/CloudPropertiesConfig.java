package com.vzw.mybiz.approval.starter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import com.vzw.mybiz.transformation.security.helpers.EncryptionHelper;

@RefreshScope
@Configuration
public class CloudPropertiesConfig {

	private static final Log LOGGER = LogFactory.getLog(CloudPropertiesConfig.class);
	
	@Value("${external.interfacing.system.vip.url}")
	private String vipUrl;

	@Value("${external.interfacing.system.vip.userId}")
	private String userId;

	@Value("${external.interfacing.system.vip.password}")
	private String password;

	@Value("${global.feign.connectTimeout:2000}")
	private int feignConnectTimeout;

	@Value("${global.feign.readTimeout:60000}")
	private int feignReadTimeout;

	@Autowired
	EncryptionHelper encryptionHelper;

	public String getVipUrl() {
		return vipUrl;
	}

	public void setVipUrl(String vipUrl) {
		this.vipUrl = vipUrl;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		String decryptedPassword = new String();
		try {
			LOGGER.debug("Decrypting started.");
			decryptedPassword = "OAS123";//encryptionHelper.voltageDecrypt(password);
			LOGGER.debug("Decrypting ended.");
		} catch (Exception e) {
			LOGGER.error("Unable to decrypt the password from cloud config", e);
		}
		return decryptedPassword;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setFeignConnectTimeout(int feignConnectTimeout)
	{
		this.feignConnectTimeout = feignConnectTimeout;
	}

	public int getFeignConnectTimeout()
	{
		return feignConnectTimeout;
	}

	public void setFeignReadTimeout(int feignReadTimeout)
	{
		this.feignReadTimeout = feignReadTimeout;
	}

	public int getFeignReadTimeout()
	{
		return feignReadTimeout;
	}

}