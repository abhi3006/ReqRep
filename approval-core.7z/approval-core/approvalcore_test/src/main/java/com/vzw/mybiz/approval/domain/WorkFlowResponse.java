package com.vzw.mybiz.approval.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkFlowResponse {

	
	private static final long serialVersionUID = -2890724563818904642L;
	
	private ServiceStatus serviceStatus;
	private String workFlowResponse;
	
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getWorkFlowResponse() {
		return workFlowResponse;
	}
	public void setWorkFlowResponse(String workFlowResponse) {
		this.workFlowResponse = workFlowResponse;
	}
}
