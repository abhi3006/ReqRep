package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceHeader implements Serializable {
	private static final long serialVersionUID = 1L;

	private String clientId;

	private String loggedInUserType;

	private String transactionId;

	private String profileId;

	private String impersonatedUser;

	private String loggedInUserId;

	private String errorCode;

	private String errorMessage;

	private String referenceId;
	private String serviceId;

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getImpersonatedUser() {
		return impersonatedUser;
	}

	public void setImpersonatedUser(String impersonatedUser) {
		this.impersonatedUser = impersonatedUser;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getLoggedInUserType() {
		return loggedInUserType;
	}

	public void setLoggedInUserType(String loggedInUserType) {
		this.loggedInUserType = loggedInUserType;
	}

	@Override
	public String toString() {
		return "ClassPojo [errorMessage = " + errorMessage
				+ ", transactionId = " + transactionId + ", profileId = "
				+ profileId + ", impersonatedUser = " + impersonatedUser
				+ ", errorCode = " + errorCode + ", loggedInUserId = "
				+ loggedInUserId + ", referenceId = " + referenceId
				+ ", clientId = " + clientId + ", loggedInUserType = "
				+ loggedInUserType + "]";
	}
}
