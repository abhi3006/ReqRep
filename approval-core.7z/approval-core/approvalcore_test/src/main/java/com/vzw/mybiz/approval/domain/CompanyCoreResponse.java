/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * @author kab82bq
 *
 */

@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyCoreResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ServiceStatus serviceStatus;
	private String businessZip;
	OrderDataManagerApproval managerApproval;
	
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getBusinessZip() {
		return businessZip;
	}
	public void setBusinessZip(String businessZip) {
		this.businessZip = businessZip;
	}
	public OrderDataManagerApproval getManagerApproval() {
		return managerApproval;
	}
	public void setManagerApproval(OrderDataManagerApproval managerApproval) {
		this.managerApproval = managerApproval;
	}

	
}
