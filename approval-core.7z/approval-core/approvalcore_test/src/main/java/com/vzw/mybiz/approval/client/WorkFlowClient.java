package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.WorkFlowResponse;

@FeignClient(name = "workflowmgtservice", configuration = CommonFeignConfiguration.class)
public interface WorkFlowClient {

	@PostMapping("/mbt/workflowmgt/optOrderTracking")
	public WorkFlowResponse updateOptTracking(OrderTrackingRequest orderTrackingRequest);
	
	@GetMapping("/mbt/workflowmgt/getOrderJson/{orderNumber}")
	public String getOrderJson(String orderNumber);
	
	@PostMapping("/mbt/workflowmgt/updateOrderMaster")
	public WorkFlowResponse updateOrderMaster(OrderMaster orderMaster);
}
