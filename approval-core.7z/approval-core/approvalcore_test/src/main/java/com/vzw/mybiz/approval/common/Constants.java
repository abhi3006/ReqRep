package com.vzw.mybiz.approval.common;

public interface Constants {

	public static final String SUCCESS_MSG = "SUCCESS";

	public static final String SUCCESS_CODE = "200";

	public static final String URL_EXPIRY_CODE = "202";

	public static final String URL_EXPIRY_MSG = "Manager Approval url expired";

	public static final String FAILURE_CODE = "99";

	public static final String EXCEPTION_CODE = "102";

	public static final String EXCEPTION_MSG = "Unexpected system failure";

	public static final String MANDATORY_MSG_ORDER_NUM = "Order Number is mandatory";

	public static final String FAIL_STATUS = "FAILURE";

	public static final String COMPLETED = "COMPLETED";

	public static final String CANCELLED = "CANCELLED";

	public static final String CREDS_MISSING = "Order information is mandatory";

	public static final String MISSING_MANDATORY_FIELDS = "Mandatory information is missing";

	public static final String 	MANAGER_APPROVER_IN_SESSION ="managerApproverinSession";
	
	public static final String TRUE =	"TRUE";
	
	public static final String ACCESSORY_ONLY = "accessoryOnly";
	public static final String COMMERCE_TYPE_ACCESSORIES = "ACC";
	public static final String NAO ="NAO";     
	public static final String INPUT_TEXT = "Input Text";
	public static final String RADIO_BUTTON = "Radio Button";
	public static final String CHECKBOX = "Checkbox";
	public static final String EMAIL_DOMAIN = "Email w/ Domain";
	public static final String DROPDOWN = "Dropdown";
	public static final String SUB_DROPDOWN = "Sub Dropdown";
	public static final String NONE = "None";
	public static final String ALPHANUMERIC = "AlphaNumeric";
	public static final String NUMERIC_ONLY = "Numeric Only";
	public static final String EMAIL = "Email";
	public static final String DATE = "Date (mm/dd/yyyy)";
	public static final String GREATERTHNEQUALTO = "Greater Than/Equal To";
	public static final String LESSTHNEQUALTO =	"Less Than/Equal To";

	public static final String APPROVAL_CORE = "APPROVAL_CORE";

	public static final String MA_ORDER_SUBMISSION_SUCCESS_MSG = "Order submission to POS initiated from approval core";
	public static final String MA_ORDER_SUBMISSION_FAILURE_MSG = "Failure while submitting order to POS from approval core";

	public static final String L1_APPROVED = "L1APPROVED";
	public static final String APPROVAL_MSG = "Order has been approved";
	public static final String REJECTION_MSG = "Order has been rejected";

	public static final String MA_ORDER_SUBMISSION_REJECTED_MSG = "Order has been rejected by the manager";

	public static final String L1_REJECTED = "L1REJECTED";

	public static final String ORDER_MASTER_STATUS_APPROVED = "MANAGER_APPROVED";
	public static final String ORDER_MASTER_STATUS_REJECTED = "REJECTED";
}
