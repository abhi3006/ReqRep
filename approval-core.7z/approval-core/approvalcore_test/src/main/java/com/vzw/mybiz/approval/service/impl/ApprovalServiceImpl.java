package com.vzw.mybiz.approval.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vzw.mybiz.approval.client.SubmitClient;
import com.vzw.mybiz.approval.client.WfmCoreClient;
import com.vzw.mybiz.approval.client.WorkFlowClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.FailOverWfmRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.SubmitCoreResponse;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.ApprovalService;

@Service
public class ApprovalServiceImpl implements ApprovalService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApprovalServiceImpl.class);

	@Autowired
	private WorkFlowClient workFlowClient;

	@Autowired
	private SubmitClient submitClient;

	@Autowired
	private WfmCoreClient wfmClient;

	@Autowired
	private ManagerApprovalRepo managerApprovalRepo;

	@Override
	public ManagerApprovalResponse getOrderInformation(ManagerApprovalRequest maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			Map<String, String> infoMap = decryptCreds(maRequest.getCreds());
			if (isURLExpired(infoMap)) {
				String orderJson = retriveOrderJson(infoMap.get("ORDER_NUMBER"));
				updateUrlAccessedCounter();
				response.setOrderJson(orderJson);
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			} else {
				processOrderCancellation(infoMap.get("ORDER_NUMBER"));
				response.setServiceStatus(getServiceStatus(Constants.URL_EXPIRY_CODE, Constants.URL_EXPIRY_MSG));
			}

		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}

		return response;
	}

	@Override
	public ManagerApprovalResponse makeApprovalCall(ManagerApprovalRequest maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			SubmitCoreResponse submitCoreResponse = submitClient.submitOrderToPos(maRequest.getOrderNumber());
			if (submitCoreResponse.getServiceStatus().getStatusCode().equalsIgnoreCase(Constants.SUCCESS_CODE)) {
				updateMAStatus(Constants.L1_APPROVED, maRequest.getOrderNumber());
				workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.SUCCESS_MSG, "",
						Constants.SUCCESS_CODE, Constants.MA_ORDER_SUBMISSION_SUCCESS_MSG));
				updateOrderMaster(maRequest.getOrderNumber(), Constants.ORDER_MASTER_STATUS_APPROVED);
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.APPROVAL_MSG));
			} else {
				workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.FAIL_STATUS, "",
						Constants.FAILURE_CODE, Constants.MA_ORDER_SUBMISSION_FAILURE_MSG));
			}
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}

	private OrderTrackingRequest buildOPTRequest(String orderNumber, String status, String transactionId, String stepId,
			String message) {
		OrderTrackingRequest request = new OrderTrackingRequest();
		request.setSource(Constants.APPROVAL_CORE);
		request.setOrderNbr(orderNumber);
		request.setOptStatus(status);
		request.setOptTransactionId(transactionId);
		request.setOptStepId(stepId);
		request.setOptMessage(message);
		request.setServerInstance(Constants.APPROVAL_CORE);
		return request;

	}

	private FailOverWfmRequest buildFailToWfm(String orderNumber, String posStatus, String transactionId,
			String locationCode, String orderStatusReason, String orderStatus) {
		FailOverWfmRequest failoverRequest = new FailOverWfmRequest();
		failoverRequest.setGroupOrderNumber(transactionId);
		failoverRequest.setCustomerReferenceNumber(orderNumber);
		failoverRequest.setLocationCode(locationCode);
		failoverRequest.setAceOrder("0000");
		failoverRequest.setOrderStatus(orderStatus);
		failoverRequest.setOrderStatusReason(orderStatusReason);
		failoverRequest.setOrderSource(Constants.APPROVAL_CORE);
		failoverRequest.setOrderMessage(posStatus);
		return failoverRequest;
	}

	@Override
	public ManagerApprovalResponse makeRejectionCall(ManagerApprovalRequest maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.REJECTION_MSG));
			workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.SUCCESS_MSG, "",
					Constants.SUCCESS_CODE, Constants.MA_ORDER_SUBMISSION_REJECTED_MSG));
			updateMAStatus(Constants.L1_REJECTED, maRequest.getOrderNumber());
			updateOrderMaster(maRequest.getOrderNumber(), Constants.ORDER_MASTER_STATUS_REJECTED);
			wfmClient.updateOrderConfirmationToWFM(
					buildFailToWfm(maRequest.getOrderNumber(), Constants.MA_ORDER_SUBMISSION_REJECTED_MSG, "00", null,
							Constants.MA_ORDER_SUBMISSION_REJECTED_MSG, Constants.L1_REJECTED));
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}

	private void updateOrderMaster(String orderNumber, String orderStatus) {
		LOGGER.info("::: Update to order master on approval/rejection cases");
		OrderMaster orderMasterData = new OrderMaster();
		orderMasterData.setOrderNbr(orderNumber);
		orderMasterData.setModifiedBy(Constants.APPROVAL_CORE);
		orderMasterData.setModifiedDt(new Date());
		orderMasterData.setOrderStatus(orderStatus);
		workFlowClient.updateOrderMaster(orderMasterData);
	}

	private void processOrderCancellation(String string) {
		// TODO Need to write logic for URL expiry for order cancellation
		// process
		// order master
		// wfm update
		// OPT table
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		return serviceStatus;
	}

	private void updateUrlAccessedCounter() {
		// TODO Increment number of times URL accessed on DB

	}

	private boolean isURLExpired(Map<String, String> infoMap) {
		// TODO Verify whether URL is expired with the created date (url expires
		// from 7
		// days after creation)
		return false;
	}

	private String retriveOrderJson(String orderNumber) {
		// TODO need to write endpoint for orderJson in work flow micro
		return workFlowClient.getOrderJson(orderNumber);
	}

	private Map<String, String> decryptCreds(String creds) {
		// TODO decryption with Voltage
		Map<String, String> infoMap = new HashMap<String, String>();
		infoMap.put("ORDER_NUMBER", "");

		return infoMap;
	}

	private void updateMAStatus(String status, String orderNumber) {
		managerApprovalRepo.updateMAStatus(status, orderNumber);
	}

}