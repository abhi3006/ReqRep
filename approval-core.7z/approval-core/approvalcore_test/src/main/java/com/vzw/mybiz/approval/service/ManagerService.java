package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;

public interface ManagerService {

	public ManagerApprovalInfo getManagerApprovalInfo(String ecpdId, String userId, String zipCode);
	
    public ManagerApprovalResponse saveManagerApprovalDetails(ManagerApprovalData maRequest);
}
