package com.vzw.mybiz.approval.rest;

import java.io.Serializable;

public class ManagerApprovalDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
