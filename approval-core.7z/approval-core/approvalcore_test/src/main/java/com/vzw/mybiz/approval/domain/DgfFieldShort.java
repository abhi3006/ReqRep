package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;

public class DgfFieldShort  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dgfDataType;
	private String dgfDataFormat;
	private boolean isRequired;
	private boolean isReadonly;
	private String prePopulatedValue;
	private List<DgfFieldShortLookup> lookUp;
	
	public DgfFieldShort() {
	}

	public List<DgfFieldShortLookup> getLookUp() {
		return lookUp;
	}

	public void setLookUp(List<DgfFieldShortLookup> lookUp) {
		this.lookUp = lookUp;
	}

	public String getDgfDataType() {
		return dgfDataType;
	}

	public void setDgfDataType(String dgfDataType) {
		this.dgfDataType = dgfDataType;
	}

	public String getDgfDataFormat() {
		return dgfDataFormat;
	}

	public void setDgfDataFormat(String dgfDataFormat) {
		this.dgfDataFormat = dgfDataFormat;
	}

	public boolean isRequired() {
		return isRequired;
	}

	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}

	public boolean isReadonly() {
		return isReadonly;
	}

	public void setReadonly(boolean isReadonly) {
		this.isReadonly = isReadonly;
	}

	public String getPrePopulatedValue() {
		return prePopulatedValue;
	}

	public void setPrePopulatedValue(String prePopulatedValue) {
		this.prePopulatedValue = prePopulatedValue;
	}
}
