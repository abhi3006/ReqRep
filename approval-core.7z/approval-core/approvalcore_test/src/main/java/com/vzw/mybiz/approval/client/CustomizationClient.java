package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name="customization-core", configuration = CommonFeignConfiguration.class)
public interface CustomizationClient {

	@PostMapping("/mbt/getCustomization")
	public CheckoutCustomization getCustomizationInfo(CommonRequest request);
}
