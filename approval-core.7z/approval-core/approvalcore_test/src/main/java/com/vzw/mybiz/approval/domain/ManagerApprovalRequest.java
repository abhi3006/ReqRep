package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class ManagerApprovalRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String ecpdId;
	private String creds;
	private String transactionType;
	private String orderNumber;
	private String zipCode;
	//IF TRUE APPROVE OR IF FALSE REJECT
	private boolean approvalStatus; 
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEcpdId() {
		return ecpdId;
	}
	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}
	public String getCreds() {
		return creds;
	}
	public void setCreds(String creds) {
		this.creds = creds;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public boolean isApprovalStatus() {
		return approvalStatus;
	}
	public void setApprovalStatus(boolean approvalStatus) {
		this.approvalStatus = approvalStatus;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
}
