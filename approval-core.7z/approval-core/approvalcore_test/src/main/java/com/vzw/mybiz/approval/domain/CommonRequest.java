package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

/**
 * @author w553190
 *
 */
public class CommonRequest implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String ecpdId;
	private String userId;
	private String zipCode;
	private String shoppingPath;
	
	public String getEcpdId() {
		return ecpdId;
	}
	public CommonRequest setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
		return this;
	}
	public String getUserId() {
		return userId;
	}
	public CommonRequest setUserId(String userId) {
		this.userId = userId;
		return this;
	}
	
	public String getZipCode() {
		return zipCode;
	}	
	public CommonRequest setZipCode(String zipCode) {
		this.zipCode = zipCode;
		return this;
	}
	public String getShoppingPath() {
		return shoppingPath;
	}
	public void setShoppingPath(String shoppingPath) {
		this.shoppingPath = shoppingPath;
	}
	
}
