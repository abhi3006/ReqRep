package com.vzw.mybiz.approval.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name = "MANAGER_APPROVAL_URL", schema = "COMMB2B")
public class ManagerApprovalUrl implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6695105843984992669L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "url_generator")
	@SequenceGenerator(name = "url_generator", sequenceName = "MANAGER_APPROVAL_URL_SEQ", schema = "COMMB2B", allocationSize = 1)
	@Column(name = "ID", updatable = false, nullable = false)
	private Long id;
	@Column(name = "ECPD_ID")
	private Long ecpdId;
	@Column(name = "MANAGER_APPROVAL_URL")
	private String url;
	@Column(name = "NUM_ACCESSED")
	private Integer maxAccessed;
	@Column(name = "CREATED_DT")
	private Date createDate;
	@Column(name = "CREATE_USER")
	private String userName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(Long ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getMaxAccessed() {
		return maxAccessed;
	}

	public void setMaxAccessed(Integer maxAccessed) {
		this.maxAccessed = maxAccessed;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
