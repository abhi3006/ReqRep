package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class DgfFieldShortLookup  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1225761540027579830L;
	private String value;
    private String displayName;
    private String defaultFlag;
    
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public void setDefaultFlag(String defaultFlag) {
		this.defaultFlag = defaultFlag;
	}
	public String getDefaultFlag() {
		return defaultFlag;
	}	
}
