package com.vzw.mybiz.approval.domain;

public class OrderTypeDetails {
	private int naoCount;

	public int getNaoCount() {
		return naoCount;
	}

	public void setNaoCount(int naoCount) {
		this.naoCount = naoCount;
	}
	
}
