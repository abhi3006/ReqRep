package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

public class OrderMaster implements Serializable {

	private static final long serialVersionUID = 1234567L;

	private Long id;

	private String orderNbr;

	private String groupOrderNbr;

	private String orderType;

	private String orderStatus;

	private Integer orderCount;

	private String posOrderNr;

	private String netaceLocation;

	private BigInteger ecpdId;

	private String opCenter;

	private String isMgrApproval;

	private String orderChannel;

	private String orderRequest;

	private String orderResponse;

	private Long preOrderNbr;

	private Long creditAppNbr;

	private String multiLineSeqNbr;

	private String newPoNbr;

	private String ipAddress;

	private String serverInstance;

	private String createdBy;

	private Date createdDt;

	private String modifiedBy;

	private Date modifiedDt;

	public OrderMaster() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNbr() {
		return orderNbr;
	}

	public void setOrderNbr(String orderNbr) {
		this.orderNbr = orderNbr;
	}

	public String getOpCenter() {
		return opCenter;
	}

	public void setOpCenter(String opCenter) {
		this.opCenter = opCenter;
	}

	public String getServerInstance() {
		return serverInstance;
	}

	public void setServerInstance(String serverInstance) {
		this.serverInstance = serverInstance;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public Date getModifiedDt() {
		return modifiedDt;
	}

	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}

	public String getGroupOrderNbr() {
		return groupOrderNbr;
	}

	public void setGroupOrderNbr(String groupOrderNbr) {
		this.groupOrderNbr = groupOrderNbr;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Integer getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(Integer i) {
		this.orderCount = i;
	}

	public String getPosOrderNr() {
		return posOrderNr;
	}

	public void setPosOrderNr(String posOrderNr) {
		this.posOrderNr = posOrderNr;
	}

	public String getNetaceLocation() {
		return netaceLocation;
	}

	public void setNetaceLocation(String netaceLocation) {
		this.netaceLocation = netaceLocation;
	}

	public BigInteger getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(BigInteger ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getIsMgrApproval() {
		return isMgrApproval;
	}

	public void setIsMgrApproval(String isMgrApproval) {
		this.isMgrApproval = isMgrApproval;
	}

	public String getOrderChannel() {
		return orderChannel;
	}

	public void setOrderChannel(String orderChannel) {
		this.orderChannel = orderChannel;
	}

	public String getOrderRequest() {
		return orderRequest;
	}

	public void setOrderRequest(String orderRequest) {
		this.orderRequest = orderRequest;
	}

	public String getOrderResponse() {
		return orderResponse;
	}

	public void setOrderResponse(String orderResponse) {
		this.orderResponse = orderResponse;
	}

	public Long getPreOrderNbr() {
		return preOrderNbr;
	}

	public void setPreOrderNbr(Long preOrderNbr) {
		this.preOrderNbr = preOrderNbr;
	}

	public Long getCreditAppNbr() {
		return creditAppNbr;
	}

	public void setCreditAppNbr(Long creditAppNbr) {
		this.creditAppNbr = creditAppNbr;
	}

	public String getMultiLineSeqNbr() {
		return multiLineSeqNbr;
	}

	public void setMultiLineSeqNbr(String multiLineSeqNbr) {
		this.multiLineSeqNbr = multiLineSeqNbr;
	}

	public String getNewPoNbr() {
		return newPoNbr;
	}

	public void setNewPoNbr(String newPoNbr) {
		this.newPoNbr = newPoNbr;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
}
