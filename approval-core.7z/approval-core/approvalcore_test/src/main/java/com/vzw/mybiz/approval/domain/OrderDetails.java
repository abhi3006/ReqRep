package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.Date;

public class OrderDetails implements Serializable {

	private static final long serialVersionUID = 1234567L;

	private Long id;

	private String orderNbr;

	private String orderProcessDetailsType;

	private String orderPrecessNbr;

	private String orderProcessDetails;

	private String orderProcessStage;

	private String orderProcessStatus;

	private String opCenter;

	private String serverInstance;

	private String createdBy;

	private Date createdDt;

	private String modifiedBy;

	private Date modifiedDt;

	public OrderDetails() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNbr() {
		return orderNbr;
	}

	public void setOrderNbr(String orderNbr) {
		this.orderNbr = orderNbr;
	}

	public String getOrderProcessDetailsType() {
		return orderProcessDetailsType;
	}

	public void setOrderProcessDetailsType(String orderProcessDetailsType) {
		this.orderProcessDetailsType = orderProcessDetailsType;
	}

	public String getOrderPrecessNbr() {
		return orderPrecessNbr;
	}

	public void setOrderPrecessNbr(String orderPrecessNbr) {
		this.orderPrecessNbr = orderPrecessNbr;
	}

	public String getOrderProcessDetails() {
		return orderProcessDetails;
	}

	public void setOrderProcessDetails(String orderProcessDetails) {
		this.orderProcessDetails = orderProcessDetails;
	}

	public String getOrderProcessStage() {
		return orderProcessStage;
	}

	public void setOrderProcessStage(String orderProcessStage) {
		this.orderProcessStage = orderProcessStage;
	}

	public String getOrderProcessStatus() {
		return orderProcessStatus;
	}

	public void setOrderProcessStatus(String orderProcessStatus) {
		this.orderProcessStatus = orderProcessStatus;
	}

	public String getOpCenter() {
		return opCenter;
	}

	public void setOpCenter(String opCenter) {
		this.opCenter = opCenter;
	}

	public String getServerInstance() {
		return serverInstance;
	}

	public void setServerInstance(String serverInstance) {
		this.serverInstance = serverInstance;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public Date getModifiedDt() {
		return modifiedDt;
	}

	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}
}
