package com.vzw.mybiz.approval.rest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.exception.ApprovalException;
import com.vzw.mybiz.approval.service.ApprovalService;
import com.vzw.mybiz.approval.service.ManagerService;


@RestController
@RequestMapping("/mbt/approval")
public class ApprovalController {
	
	@Autowired
	private ApprovalService approvalService;
	
	@Autowired
	private ManagerService managerService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ApprovalController.class);

	@PostMapping(value = "/approvalLanding", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse getManagerApprovalLandingInfo(@RequestBody ManagerApprovalRequest maRequest) throws ApprovalException {
		LOGGER.info("Calling Manager approval landing page");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		if(StringUtils.isNotBlank(maRequest.getCreds())){
			response = approvalService.getOrderInformation(maRequest);
		}else{
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.CREDS_MISSING);
			response.setServiceStatus(serviceStatus);
		}
		return response;
	}
	
	@PostMapping(value = "/approvalProcess", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse approve(@RequestBody ManagerApprovalRequest maRequest) throws ApprovalException {
		LOGGER.info("Initiating approval flow page");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		if(maRequest.isApprovalStatus()){
			response = approvalService.makeApprovalCall(maRequest);
		}else{
			response = approvalService.makeRejectionCall(maRequest);
		}
		return response;
	}
	
	@PostMapping(value = "/getMAInformation", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalInfo getManagerApprovalInfo(@RequestBody ManagerApprovalRequest maRequest) throws ApprovalException {
		LOGGER.info("Retrive ManagerApproval Information");
		ManagerApprovalInfo approvalInfo = new ManagerApprovalInfo();
		if(StringUtils.isNotBlank(maRequest.getEcpdId()) && StringUtils.isNotBlank(maRequest.getUserId()) 
				&& StringUtils.isNotBlank(maRequest.getZipCode())){
			approvalInfo = managerService.getManagerApprovalInfo(maRequest.getEcpdId(), maRequest.getUserId(),maRequest.getZipCode());
		}else{
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			approvalInfo.setServiceStatus(serviceStatus);
		}
		return approvalInfo;
	}
	
	@PostMapping(value = "/saveMAInformation", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse saveManagerApprovalInfo(@RequestBody ManagerApprovalData managerApprovalData)
			throws ApprovalException {
		LOGGER.info("Save ManagerApproval Information and URL");
		ManagerApprovalResponse approvalInfo = new ManagerApprovalResponse();
		if (StringUtils.isNotBlank(managerApprovalData.getEcpdId())) {
			approvalInfo = managerService.saveManagerApprovalDetails(managerApprovalData);
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			approvalInfo.setServiceStatus(serviceStatus);
		}
		return approvalInfo;
	}

}