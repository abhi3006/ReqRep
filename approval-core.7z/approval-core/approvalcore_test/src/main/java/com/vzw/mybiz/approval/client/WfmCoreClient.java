package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.FailOverWfmRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name="wfm-core", configuration = CommonFeignConfiguration.class)
public interface WfmCoreClient {

	@PostMapping("/mbt/wfm/updateWfmOrderStatus")
	public String updateOrderConfirmationToWFM(FailOverWfmRequest failOverWfmRequest);
	
}
