package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import org.springframework.lang.NonNull;

public class OrderTrackingRequest implements Serializable {

	private static final long serialVersionUID = -6879466023141813891L;

	private Long id;
	private String orderNbr;
	private String optTransactionId;
	private String optStepId;
	private String optStatus;
	private String optMessage;
	private String source;
	private String serverInstance;

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNbr() {
		return orderNbr;
	}

	public void setOrderNbr(String orderNbr) {
		this.orderNbr = orderNbr;
	}

	public String getOptStatus() {
		return optStatus;
	}

	public void setOptStatus(String optStatus) {
		this.optStatus = optStatus;
	}

	public String getOptMessage() {
		return optMessage;
	}

	public void setOptMessage(String optMessage) {
		this.optMessage = optMessage;
	}

	@NonNull
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getOptTransactionId() {
		return optTransactionId;
	}

	public void setOptTransactionId(String optTransactionId) {
		this.optTransactionId = optTransactionId;
	}

	public String getOptStepId() {
		return optStepId;
	}

	public void setOptStepId(String optStepId) {
		this.optStepId = optStepId;
	}

	public String getServerInstance() {
		return serverInstance;
	}

	public void setServerInstance(String serverInstance) {
		this.serverInstance = serverInstance;
	}

}
