package com.vzw.mybiz.approval.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;


public interface ManagerApprovalRepo extends CrudRepository<ManagerApprovalTracker, Long>{

	@Query("UPDATE ManagerApprovalTracker a SET a.status = :status where a.orderNumber =:orderNumber")
	public void updateMAStatus(@Param("status") String status, @Param("orderNumber") String orderNumber);
	
	@Query("UPDATE ManagerApprovalTracker a SET a.status = :status, a.approvedByEmail1 = :approverEmail where a.orderNumber =:orderNumber")
	public void updateMAStatusAndEmail(@Param("status") String status, @Param("approverEmail") String approverEmail, @Param("orderNumber") String orderNumber);
}
