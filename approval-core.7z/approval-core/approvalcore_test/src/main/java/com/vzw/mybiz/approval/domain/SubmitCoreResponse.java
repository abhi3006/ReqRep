package com.vzw.mybiz.approval.domain;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitCoreResponse {

	
	private static final long serialVersionUID = -2890724563818804642L;
	
	private ServiceStatus serviceStatus;
	private String submitCoreResponse;
	
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public String getSubmitCoreResponse() {
		return submitCoreResponse;
	}
	public void setSubmitCoreResponse(String submitCoreResponse) {
		this.submitCoreResponse = submitCoreResponse;
	}
	
}
