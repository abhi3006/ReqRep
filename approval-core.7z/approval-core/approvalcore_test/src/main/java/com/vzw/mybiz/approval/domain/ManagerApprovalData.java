package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class ManagerApprovalData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ecpdId;
	private String maApprovalUrl;
	private String level;
	private String approverEmailIds;
	private String orderNumber;
	private String userId;

	

	public String getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getMaApprovalUrl() {
		return maApprovalUrl;
	}

	public void setMaApprovalUrl(String maApprovalUrl) {
		this.maApprovalUrl = maApprovalUrl;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getApproverEmailIds() {
		return approverEmailIds;
	}

	public void setApproverEmailIds(String approverEmailIds) {
		this.approverEmailIds = approverEmailIds;
	}
	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
