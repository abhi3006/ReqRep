package com.vzw.mybiz.approval.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.session.SessionAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

@SpringBootApplication(exclude = {SecurityAutoConfiguration.class, SessionAutoConfiguration.class })
@EnableFeignClients(basePackages= {"com.vzw.mybiz.approval.client"})
@ComponentScan(basePackages= {"com.vzw.mybiz.approval.*", "com.vzw.mybiz.caching.*",
		"com.vzw.mybiz.utilities.*", "com.vzw.mybiz.transformation", "com.vzw.mybiz.security.overrides"})
@PropertySource(value = { "classpath:build-info.properties" })
@EnableDiscoveryClient
public class ApprovalCoreApp {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ApprovalCoreApp.class, args);
	}
	
}
