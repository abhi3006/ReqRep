/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author kab82bq
 *
 */
@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class AccessoryPackage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<Equipment> equipmentList;
	
	private String accountNumber;
	private String existingPhoneNumber;
	private double dueMonthly;
	private double dueNow;
	private double totalDueNow;
	private String fipsCode;
	private String taxExemptTypes;

	private List<String> appliedPromoCodes;
	
	/**
	 * @return the equipmentList
	 */
	public List<Equipment> getEquipmentList() {
		return equipmentList;
	}
	/**
	 * @param equipmentList the equipmentList to set
	 */
	public void setEquipmentList(List<Equipment> equipmentList) {
		this.equipmentList = equipmentList;
	}
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the existingPhoneNumber
	 */
	public String getExistingPhoneNumber() {
		return existingPhoneNumber;
	}
	/**
	 * @param existingPhoneNumber the existingPhoneNumber to set
	 */
	public void setExistingPhoneNumber(String existingPhoneNumber) {
		this.existingPhoneNumber = existingPhoneNumber;
	}
	/**
	 * @return the dueMonthly
	 */
	public double getDueMonthly() {
		return dueMonthly;
	}
	/**
	 * @param dueMonthly the dueMonthly to set
	 */
	public void setDueMonthly(double dueMonthly) {
		this.dueMonthly = dueMonthly;
	}
	/**
	 * @return the dueNow
	 */
	public double getDueNow() {
		return dueNow;
	}
	/**
	 * @param dueNow the dueNow to set
	 */
	public void setDueNow(double dueNow) {
		this.dueNow = dueNow;
	}
	
	/**
	 * @return the appliedPromoCodes
	 */
	public List<String> getAppliedPromoCodes() {
		return appliedPromoCodes;
	}
	/**
	 * @param appliedPromoCodes the appliedPromoCodes to set
	 */
	public void setAppliedPromoCodes(List<String> appliedPromoCodes) {
		this.appliedPromoCodes = appliedPromoCodes;
	}
	/**
	 * @return the totalDueNow
	 */
	public double getTotalDueNow() {
		return totalDueNow;
	}
	/**
	 * @param totalDueNow the totalDueNow to set
	 */
	public void setTotalDueNow(double totalDueNow) {
		this.totalDueNow = totalDueNow;
	}
	/**
	 * @return the fipsCode
	 */
	public String getFipsCode() {
		return fipsCode;
	}
	/**
	 * @param fipsCode the fipsCode to set
	 */
	public void setFipsCode(String fipsCode) {
		this.fipsCode = fipsCode;
	}
	public String getTaxExemptTypes() {
		return taxExemptTypes;
	}
	public void setTaxExemptTypes(String taxExemptTypes) {
		this.taxExemptTypes = taxExemptTypes;
	}

	
}
