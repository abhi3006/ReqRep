package com.vzw.mybiz.approval.domain;

public class EcpdProfileInfo {
	private int option;
	private String approverEmail1;
	private String approverEmail2;
	private String approverEmail3;

	public int getOption() {
		return option;
	}

	public void setOption(int option) {
		this.option = option;
	}

	public String getApproverEmail1() {
		return approverEmail1;
	}

	public void setApproverEmail1(String approverEmail1) {
		this.approverEmail1 = approverEmail1;
	}

	public String getApproverEmail2() {
		return approverEmail2;
	}

	public void setApproverEmail2(String approverEmail2) {
		this.approverEmail2 = approverEmail2;
	}

	public String getApproverEmail3() {
		return approverEmail3;
	}

	public void setApproverEmail3(String approverEmail3) {
		this.approverEmail3 = approverEmail3;
	}

}
