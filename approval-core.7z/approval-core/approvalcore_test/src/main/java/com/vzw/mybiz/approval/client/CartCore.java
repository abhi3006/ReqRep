package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.CartResponse;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;


/*
 * @author kab82bq
 * 
 */

@FeignClient(name="cart-core", configuration=CommonFeignConfiguration.class)
public interface CartCore {

	@PostMapping("/mbt/cart/fetchcart")
	public CartResponse retrieveCart(CommonRequest request);
	
}
