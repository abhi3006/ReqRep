/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author kab82bq
 *
 */
@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class Cart implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String cartId;
	
	private String purchasePath;

	private AccessoryPackage accessoryPackage;
	
	public AccessoryPackage getAccessoryPackage() {
		return accessoryPackage;
	}

	public void setAccessoryPackage(AccessoryPackage accessoryPackage) {
		this.accessoryPackage = accessoryPackage;
	}

	/**
	 * @return the cartId
	 */
	public String getCartId() {
		return cartId;
	}

	/**
	 * @param cartId the cartId to set
	 */
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}

	/**
	 * @return the purchasePath
	 */
	public String getPurchasePath() {
		return purchasePath;
	}

	/**
	 * @param purchasePath the purchasePath to set
	 */
	public void setPurchasePath(String purchasePath) {
		this.purchasePath = purchasePath;
	}
	
}
