package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class ManageApprovalOrderDto  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean orderType;
	private boolean orderThreshold;
	private double orderThresholdValue;
	private String orderThresholdRule; 
	private String multiOrderEmailForOrder; 
	private Boolean managerApprovalSuppress;
	private DgfFieldShort managerApproval;
	private Boolean otEnable;
	private Boolean nseEnable;
	private Boolean nsoEnable;
	private Boolean piaEnable;
	private Boolean eupEnable;
	private Boolean naoEnable;
	private Boolean bsoEnable;
	private Boolean ndoEnable;
	
	private DgfFieldShort ot;
	private DgfFieldShort nse;
	private DgfFieldShort nso;
	private DgfFieldShort pia;
	private DgfFieldShort eup;
	private DgfFieldShort nao;
	private DgfFieldShort bso;
	private DgfFieldShort ndo;
	private long quantityNSE;  
	private boolean quantityThresholdNSE; 
	private String quantityThresholdValueNSE;  
	private long quantityNSO;
	private boolean quanttityThresholdNSO;
	private String quantityThresholdValueNSO;  
	private long quantityPIA; 
	private boolean quanttityThresholdPIA;
	private String quantityThresholdValuePIA;  
	private long quantityEUP; 
	private boolean quanttityThresholdEUP;
	private String quantityThresholdValueEUP;  
	private long quantityNAO;  
	private boolean quanttityThresholdNAO;
	private String quantityThresholdValueNAO;  
	private long quantityBSO;
	private boolean quanttityThresholdBSO;
	private String quantityThresholdValueBSO;
	private long quantityNDO;
	private boolean quantityThresholdNDO;
	private String quantityThresholdValueNDO;
	
	public boolean isOrderType() {
		return orderType;
	}
	public void setOrderType(boolean orderType) {
		this.orderType = orderType;
	}
	public boolean isOrderThreshold() {
		return orderThreshold;
	}
	public void setOrderThreshold(boolean orderThreshold) {
		this.orderThreshold = orderThreshold;
	}
	public double getOrderThresholdValue() {
		return orderThresholdValue;
	}
	public void setOrderThresholdValue(double orderThresholdValue) {
		this.orderThresholdValue = orderThresholdValue;
	}
	public String getOrderThresholdRule() {
		return orderThresholdRule;
	}
	public void setOrderThresholdRule(String orderThresholdRule) {
		this.orderThresholdRule = orderThresholdRule;
	}
	public String getMultiOrderEmailForOrder() {
		return multiOrderEmailForOrder;
	}
	public void setMultiOrderEmailForOrder(String multiOrderEmailForOrder) {
		this.multiOrderEmailForOrder = multiOrderEmailForOrder;
	}
	public long getQuantityNSE() {
		return quantityNSE;
	}
	public void setQuantityNSE(long quantityNSE) {
		this.quantityNSE = quantityNSE;
	}
	public boolean isQuantityThresholdNSE() {
		return quantityThresholdNSE;
	}
	public void setQuantityThresholdNSE(boolean quantityThresholdNSE) {
		this.quantityThresholdNSE = quantityThresholdNSE;
	}
	public String getQuantityThresholdValueNSE() {
		return quantityThresholdValueNSE;
	}
	public void setQuantityThresholdValueNSE(String quantityThresholdValueNSE) {
		this.quantityThresholdValueNSE = quantityThresholdValueNSE;
	}
	public long getQuantityNSO() {
		return quantityNSO;
	}
	public void setQuantityNSO(long quantityNSO) {
		this.quantityNSO = quantityNSO;
	}
	public boolean isQuanttityThresholdNSO() {
		return quanttityThresholdNSO;
	}
	public void setQuanttityThresholdNSO(boolean quanttityThresholdNSO) {
		this.quanttityThresholdNSO = quanttityThresholdNSO;
	}
	public String getQuantityThresholdValueNSO() {
		return quantityThresholdValueNSO;
	}
	public void setQuantityThresholdValueNSO(String quantityThresholdValueNSO) {
		this.quantityThresholdValueNSO = quantityThresholdValueNSO;
	}
	public long getQuantityPIA() {
		return quantityPIA;
	}
	public void setQuantityPIA(long quantityPIA) {
		this.quantityPIA = quantityPIA;
	}
	public boolean isQuanttityThresholdPIA() {
		return quanttityThresholdPIA;
	}
	public void setQuanttityThresholdPIA(boolean quanttityThresholdPIA) {
		this.quanttityThresholdPIA = quanttityThresholdPIA;
	}
	public String getQuantityThresholdValuePIA() {
		return quantityThresholdValuePIA;
	}
	public void setQuantityThresholdValuePIA(String quantityThresholdValuePIA) {
		this.quantityThresholdValuePIA = quantityThresholdValuePIA;
	}
	public long getQuantityEUP() {
		return quantityEUP;
	}
	public void setQuantityEUP(long quantityEUP) {
		this.quantityEUP = quantityEUP;
	}
	public boolean isQuanttityThresholdEUP() {
		return quanttityThresholdEUP;
	}
	public void setQuanttityThresholdEUP(boolean quanttityThresholdEUP) {
		this.quanttityThresholdEUP = quanttityThresholdEUP;
	}
	public String getQuantityThresholdValueEUP() {
		return quantityThresholdValueEUP;
	}
	public void setQuantityThresholdValueEUP(String quantityThresholdValueEUP) {
		this.quantityThresholdValueEUP = quantityThresholdValueEUP;
	}
	public long getQuantityNAO() {
		return quantityNAO;
	}
	public void setQuantityNAO(long quantityNAO) {
		this.quantityNAO = quantityNAO;
	}
	public boolean isQuanttityThresholdNAO() {
		return quanttityThresholdNAO;
	}
	public void setQuanttityThresholdNAO(boolean quanttityThresholdNAO) {
		this.quanttityThresholdNAO = quanttityThresholdNAO;
	}
	public String getQuantityThresholdValueNAO() {
		return quantityThresholdValueNAO;
	}
	public void setQuantityThresholdValueNAO(String quantityThresholdValueNAO) {
		this.quantityThresholdValueNAO = quantityThresholdValueNAO;
	}
	public long getQuantityBSO() {
		return quantityBSO;
	}
	public void setQuantityBSO(long quantityBSO) {
		this.quantityBSO = quantityBSO;
	}
	public boolean isQuanttityThresholdBSO() {
		return quanttityThresholdBSO;
	}
	public void setQuanttityThresholdBSO(boolean quanttityThresholdBSO) {
		this.quanttityThresholdBSO = quanttityThresholdBSO;
	}
	public String getQuantityThresholdValueBSO() {
		return quantityThresholdValueBSO;
	}
	public void setQuantityThresholdValueBSO(String quantityThresholdValueBSO) {
		this.quantityThresholdValueBSO = quantityThresholdValueBSO;
	}
	public long getQuantityNDO() {
		return quantityNDO;
	}
	public void setQuantityNDO(long quantityNDO) {
		this.quantityNDO = quantityNDO;
	}
	public boolean isQuantityThresholdNDO() {
		return quantityThresholdNDO;
	}
	public void setQuantityThresholdNDO(boolean quantityThresholdNDO) {
		this.quantityThresholdNDO = quantityThresholdNDO;
	}
	public String getQuantityThresholdValueNDO() {
		return quantityThresholdValueNDO;
	}
	public void setQuantityThresholdValueNDO(String quantityThresholdValueNDO) {
		this.quantityThresholdValueNDO = quantityThresholdValueNDO;
	}
	public DgfFieldShort getNse() {
		return nse;
	}
	public void setNse(DgfFieldShort nse) {
		this.nse = nse;
	}
	public DgfFieldShort getNso() {
		return nso;
	}
	public void setNso(DgfFieldShort nso) {
		this.nso = nso;
	}
	public DgfFieldShort getPia() {
		return pia;
	}
	public void setPia(DgfFieldShort pia) {
		this.pia = pia;
	}
	public DgfFieldShort getEup() {
		return eup;
	}
	public void setEup(DgfFieldShort eup) {
		this.eup = eup;
	}
	public DgfFieldShort getNao() {
		return nao;
	}
	public void setNao(DgfFieldShort nao) {
		this.nao = nao;
	}
	public DgfFieldShort getBso() {
		return bso;
	}
	public void setBso(DgfFieldShort bso) {
		this.bso = bso;
	}
	public DgfFieldShort getNdo() {
		return ndo;
	}
	public void setNdo(DgfFieldShort ndo) {
		this.ndo = ndo;
	}
	public DgfFieldShort getOt() {
		return ot;
	}
	public void setOt(DgfFieldShort ot) {
		this.ot = ot;
	} 
	public DgfFieldShort getManagerApproval() {
		return managerApproval;
	}
	public void setManagerApproval(DgfFieldShort managerApproval) {
		this.managerApproval = managerApproval;
	}
	public Boolean getManagerApprovalSuppress() {
		return managerApprovalSuppress;
	}
	public void setManagerApprovalSuppress(Boolean managerApprovalSuppress) {
		this.managerApprovalSuppress = managerApprovalSuppress;
	}
	public Boolean getOtEnable() {
		return otEnable;
	}
	public void setOtEnable(Boolean otEnable) {
		this.otEnable = otEnable;
	}
	public Boolean getNseEnable() {
		return nseEnable;
	}
	public void setNseEnable(Boolean nseEnable) {
		this.nseEnable = nseEnable;
	}
	public Boolean getNsoEnable() {
		return nsoEnable;
	}
	public void setNsoEnable(Boolean nsoEnable) {
		this.nsoEnable = nsoEnable;
	}
	public Boolean getPiaEnable() {
		return piaEnable;
	}
	public void setPiaEnable(Boolean piaEnable) {
		this.piaEnable = piaEnable;
	}
	public Boolean getEupEnable() {
		return eupEnable;
	}
	public void setEupEnable(Boolean eupEnable) {
		this.eupEnable = eupEnable;
	}
	public Boolean getNaoEnable() {
		return naoEnable;
	}
	public void setNaoEnable(Boolean naoEnable) {
		this.naoEnable = naoEnable;
	}
	public Boolean getBsoEnable() {
		return bsoEnable;
	}
	public void setBsoEnable(Boolean bsoEnable) {
		this.bsoEnable = bsoEnable;
	}
	public Boolean getNdoEnable() {
		return ndoEnable;
	}
	public void setNdoEnable(Boolean ndoEnable) {
		this.ndoEnable = ndoEnable;
	}
	


}
