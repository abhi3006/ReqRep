package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class CustomizationEcpdProfileDto  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int level;
	private String emailAddress1;
	private String emailAddress2;
	private String emailAddress3;
	private int managerApprovalState;
	private int urlStatus;
	private int managerApprovalVariable;
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getEmailAddress1() {
		return emailAddress1;
	}
	public void setEmailAddress1(String emailAddress1) {
		this.emailAddress1 = emailAddress1;
	}
	public String getEmailAddress2() {
		return emailAddress2;
	}
	public void setEmailAddress2(String emailAddress2) {
		this.emailAddress2 = emailAddress2;
	}
	public String getEmailAddress3() {
		return emailAddress3;
	}
	public void setEmailAddress3(String emailAddress3) {
		this.emailAddress3 = emailAddress3;
	}
	public int getManagerApprovalState() {
		return managerApprovalState;
	}
	public void setManagerApprovalState(int managerApprovalState) {
		this.managerApprovalState = managerApprovalState;
	}
	public int getUrlStatus() {
		return urlStatus;
	}
	public void setUrlStatus(int urlStatus) {
		this.urlStatus = urlStatus;
	}
	public int getManagerApprovalVariable() {
		return managerApprovalVariable;
	}
	public void setManagerApprovalVariable(int managerApprovalVariable) {
		this.managerApprovalVariable = managerApprovalVariable;
	}
	
}
