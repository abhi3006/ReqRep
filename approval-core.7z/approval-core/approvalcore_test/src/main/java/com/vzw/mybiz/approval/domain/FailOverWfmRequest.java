package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FailOverWfmRequest  implements Serializable {

	private static final long serialVersionUID = -6879466023141813891L;
    private String groupOrderNumber;
	private String customerReferenceNumber;
	private String locationCode;
	private String aceOrder;
	private String orderStatus;
	private String orderStatusReason;
	private String orderSource;
	private String orderMessage;
	
	private ServiceInformation serviceinformation;

	public String getGroupOrderNumber() {
		return groupOrderNumber;
	}

	public void setGroupOrderNumber(String groupOrderNumber) {
		this.groupOrderNumber = groupOrderNumber;
	}

	public String getCustomerReferenceNumber() {
		return customerReferenceNumber;
	}

	public void setCustomerReferenceNumber(String customerReferenceNumber) {
		this.customerReferenceNumber = customerReferenceNumber;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public String getAceOrder() {
		return aceOrder;
	}

	public void setAceOrder(String aceOrder) {
		this.aceOrder = aceOrder;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderStatusReason() {
		return orderStatusReason;
	}

	public void setOrderStatusReason(String orderStatusReason) {
		this.orderStatusReason = orderStatusReason;
	}

	public ServiceInformation getServiceinformation() {
		return serviceinformation;
	}

	public void setServiceinformation(ServiceInformation serviceinformation) {
		this.serviceinformation = serviceinformation;
	}

	public String getOrderSource() {
		return orderSource;
	}

	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}

	public String getOrderMessage() {
		return orderMessage;
	}

	public void setOrderMessage(String orderMessage) {
		this.orderMessage = orderMessage;
	}	
}