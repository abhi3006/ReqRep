package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;

public interface ApprovalService {

	public ManagerApprovalResponse getOrderInformation(ManagerApprovalRequest maRequest);

	public ManagerApprovalResponse makeApprovalCall(ManagerApprovalRequest maRequest);

	public ManagerApprovalResponse makeRejectionCall(ManagerApprovalRequest maRequest);

	
}