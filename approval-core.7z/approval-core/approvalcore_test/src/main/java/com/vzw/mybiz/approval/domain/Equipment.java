/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author w615250
 *
 */
@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class Equipment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String productCode;//SKU
    private String discountAmount;
    private String productName;    
    private String productType;
    private String color;
    private String subClassCode;
    private double taxAmout;
    private String taxDescription;
    private double unitTaxBasedPrice;
    private String taxBasedPriceFlag;
    private String make;
    private String model;
        
    /**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the unitTaxBasedPrice
	 */
	public double getUnitTaxBasedPrice() {
		return unitTaxBasedPrice;
	}

	/**
	 * @param unitTaxBasedPrice the unitTaxBasedPrice to set
	 */
	public void setUnitTaxBasedPrice(double unitTaxBasedPrice) {
		this.unitTaxBasedPrice = unitTaxBasedPrice;
	}

	/**
	 * @return the taxBasedPriceFlag
	 */
	public String getTaxBasedPriceFlag() {
		return taxBasedPriceFlag;
	}

	/**
	 * @param taxBasedPriceFlag the taxBasedPriceFlag to set
	 */
	public void setTaxBasedPriceFlag(String taxBasedPriceFlag) {
		this.taxBasedPriceFlag = taxBasedPriceFlag;
	}

	/**
	 * @return the taxAmout
	 */
	public double getTaxAmout() {
		return taxAmout;
	}

	/**
	 * @param taxAmout the taxAmout to set
	 */
	public void setTaxAmout(double taxAmout) {
		this.taxAmout = taxAmout;
	}

	/**
	 * @return the taxDescription
	 */
	public String getTaxDescription() {
		return taxDescription;
	}

	/**
	 * @param taxDescription the taxDescription to set
	 */
	public void setTaxDescription(String taxDescription) {
		this.taxDescription = taxDescription;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	private int quantity;
    
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the discountAmount
	 */
	public String getDiscountAmount() {
		return discountAmount;
	}

	/**
	 * @param discountAmount the discountAmount to set
	 */
	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the subClassCode
	 */
	public String getSubClassCode() {
		return subClassCode;
	}

	/**
	 * @param subClassCode the subClassCode to set
	 */
	public void setSubClassCode(String subClassCode) {
		this.subClassCode = subClassCode;
	}	
    
}
