package com.vzw.mybiz.approval.client;

import com.vzw.mybiz.approval.domain.SubmitCoreResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name="submit-core", configuration = CommonFeignConfiguration.class)
public interface SubmitClient {

	
	@PostMapping("/mbt/submit/submitToPos")
	public SubmitCoreResponse submitOrderToPos(String orderNumber);

}
