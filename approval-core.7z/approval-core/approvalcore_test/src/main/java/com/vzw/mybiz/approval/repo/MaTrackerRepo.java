package com.vzw.mybiz.approval.repo;

import org.springframework.data.repository.CrudRepository;

import com.vzw.mybiz.approval.entity.ManagerApprovalUrl;


public interface MaTrackerRepo extends CrudRepository<ManagerApprovalUrl, Long>{

}
