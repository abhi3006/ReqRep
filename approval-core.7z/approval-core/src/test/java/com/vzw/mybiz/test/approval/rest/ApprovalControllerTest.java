package com.vzw.mybiz.test.approval.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AutoNotificationRequest;
import com.vzw.mybiz.approval.domain.AutoNotificationResponse;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.accessory.AccessoryGridwallResponse;
import com.vzw.mybiz.approval.domain.devices.DeviceDetails;
import com.vzw.mybiz.approval.domain.devices.DeviceGridwallResponse;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsRequest;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMInfo;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.approval.rest.ApprovalController;
import com.vzw.mybiz.approval.service.ApprovalService;
import com.vzw.mybiz.approval.service.ApprovalServiceSM;
import com.vzw.mybiz.approval.service.BatchService;
import com.vzw.mybiz.approval.service.ManagerService;
import com.vzw.mybiz.approval.service.ManagerServiceSM;
import com.vzw.mybiz.approval.service.SmCpcService;
import com.vzw.mybiz.approval.service.impl.DeviceServiceImpl;


@RunWith(SpringRunner.class)
public class ApprovalControllerTest {

	@Spy
	@InjectMocks
	ApprovalController approvalController;

	private MockMvc mockMvc;

	@MockBean
	ManagerService managerService;
	
	@Mock
	DeviceServiceImpl deviceService;

	@Mock
	private ApprovalService approvalService;
	
	@MockBean
	ManagerServiceSM managerServiceSM;

	@Mock
	private ApprovalServiceSM approvalServiceSM;
	
	@MockBean
	BatchService batchService;
	
	@Mock
	SmCpcService smCpcService;

	Gson gson = new Gson();

	ManagerApprovalInfo managerApprovalServiceRes;

	ManagerApprovalResponse maResponse;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(approvalController).build();
		managerApprovalServiceRes = new ManagerApprovalInfo();
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		managerApprovalServiceRes.setServiceStatus(serviceStatus);
		managerApprovalServiceRes.setReadonly(false);
		managerApprovalServiceRes.setRequired(true);
		managerApprovalServiceRes.setUserInputType("Input Text");
		managerApprovalServiceRes.setPrePopulateEmailID("someone@some.com");
		maResponse = new ManagerApprovalResponse();
		maResponse.setServiceStatus(serviceStatus);

	}

	public MvcResult getMvcResult(String url, ManagerApprovalRequest approvalReq) {
		try {
			return mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON_VALUE).content(gson.toJson(approvalReq)))
					.andExpect(status().isOk()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Test
	public void test_ManagerApprovalInfo() throws Exception {
		Mockito.when(
				managerService.getManagerApprovalInfo(Mockito.isA(ManagerApprovalRequest.class)))
				.thenReturn(managerApprovalServiceRes);

		ManagerApprovalRequest getApprovalReq = new ManagerApprovalRequest();
		getApprovalReq.setEcpdId("9782");
		getApprovalReq.setUserId("9782QA123");
		getApprovalReq.setZipCode("30007");
		MvcResult mvcResult = getMvcResult("/mbt/approval/getMAInformation", getApprovalReq);

		ManagerApprovalInfo managerApprovalOrderResponse1 = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalInfo.class);
		assertNotNull(managerApprovalOrderResponse1);
		assertThat(managerApprovalOrderResponse1.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	
	@Test
	public void test_ManagerApprovalMissingEcpdParam() throws Exception {
		Mockito.when(
				managerService.getManagerApprovalInfo(Mockito.isA(ManagerApprovalRequest.class)))
				.thenReturn(managerApprovalServiceRes);
		ManagerApprovalRequest getApprovalReq = new ManagerApprovalRequest();
		getApprovalReq.setEcpdId("");
		getApprovalReq.setUserId("9782QA123");
		getApprovalReq.setZipCode("30007");

		MvcResult mvcResult = getMvcResult("/mbt/approval/getMAInformation", getApprovalReq);
		ManagerApprovalInfo managerApprovalOrderResponse1 = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalInfo.class);
		assertNotNull(managerApprovalOrderResponse1);
		assertThat(managerApprovalOrderResponse1.getServiceStatus().getStatusCode()).isEqualTo("99");
	}


	@Test
	public void test_ManagerApprovalMissingUserIdParam() throws Exception {
		Mockito.when(
				managerService.getManagerApprovalInfo(Mockito.isA(ManagerApprovalRequest.class)))
				.thenReturn(managerApprovalServiceRes);
		ManagerApprovalRequest getApprovalReq = new ManagerApprovalRequest();
		getApprovalReq.setEcpdId("677");
		getApprovalReq.setUserId("");
		getApprovalReq.setZipCode("30007");

		MvcResult mvcResult = getMvcResult("/mbt/approval/getMAInformation", getApprovalReq);
		ManagerApprovalInfo managerApprovalOrderResponse1 = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalInfo.class);
		assertNotNull(managerApprovalOrderResponse1);
		assertThat(managerApprovalOrderResponse1.getServiceStatus().getStatusCode()).isEqualTo("99");
	}

	
	@Test
	public void test_saveManagerApprovalInfo() throws Exception {
		ManagerApprovalData managerApprovalData = new ManagerApprovalData();
		managerApprovalData.setEcpdId("TEST1234");
		Mockito.when(managerService.saveManagerApprovalDetails(Mockito.isA(ManagerApprovalData.class)))
				.thenReturn(maResponse);

		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/saveMAInformation").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(gson.toJson(managerApprovalData)))
				.andExpect(status().isOk()).andReturn();

		ManagerApprovalResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertNotNull(maResp);
		assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);

	}
	 @Test
	public void test_saveManagerApprovalInfoMissingFields() throws Exception {
		ManagerApprovalData managerApprovalData = new ManagerApprovalData();
		managerApprovalData.setApproverEmailIds("");
		managerApprovalData.setEcpdId("");
		managerApprovalData.setLevel("");
		managerApprovalData.setMaApprovalUrl("");
		managerApprovalData.setOrderNumber("");
		managerApprovalData.setUserId("");		
		Mockito.when(managerService.saveManagerApprovalDetails(Mockito.isA(ManagerApprovalData.class)))
				.thenReturn(maResponse);

		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/saveMAInformation").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(gson.toJson(managerApprovalData)))
				.andExpect(status().isOk()).andReturn();

		ManagerApprovalResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertNotNull(maResp);
		assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.FAILURE_CODE);

	}

	@Test
	public void test_approvalLanding_success() throws Exception {
		ManagerApprovalRequest maRequest = new ManagerApprovalRequest();
		maRequest.setEcpdId("6778");
		maRequest.setUserId("6778ADMBT");
		maRequest.setZipCode("30007");
		maRequest.setCreds("00000000000000000000000000000000000000");
		Mockito.when(approvalService.getOrderInformation(Mockito.any(ManagerApprovalRequest.class)))
				.thenReturn(getManagerApprovalResponse(true));
		MvcResult mvcResult = getMvcResult("/mbt/approval/approvalLanding", maRequest);
		ManagerApprovalResponse managerApprovalResponse = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertNotNull(managerApprovalResponse.getOrderJson());

	}

	@Test
	public void test_approvalLanding_missingParams() throws Exception {
		ManagerApprovalRequest maRequest = new ManagerApprovalRequest();
		maRequest.setEcpdId("6778");
		maRequest.setUserId("6778ADMBT");
		maRequest.setZipCode("30007");
		MvcResult mvcResult = getMvcResult("/mbt/approval/approvalLanding", maRequest);
		ManagerApprovalResponse managerApprovalResponse = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertTrue(managerApprovalResponse.getServiceStatus().getStatusCode(),
				managerApprovalResponse.getServiceStatus().getStatusCode().equalsIgnoreCase(Constants.FAILURE_CODE));
	}

	@Test
	public void approve_test() throws Exception {
		ManagerApprovalRequest maRequest = new ManagerApprovalRequest();
		maRequest.setEcpdId("6778");
		maRequest.setUserId("6778ADMBT");
		maRequest.setZipCode("30007");
		maRequest.setApprovalStatus(true);
		Mockito.when(approvalService.makeApprovalCall(Mockito.any(ManagerApprovalRequest.class)))
				.thenReturn(getManagerApprovalResponse(false));
		MvcResult mvcResult = getMvcResult("/mbt/approval/approvalProcess", maRequest);
		ManagerApprovalResponse managerApprovalResponse = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertTrue(managerApprovalResponse.getServiceStatus().getStatusCode(),
				managerApprovalResponse.getServiceStatus().getStatusCode().equalsIgnoreCase(Constants.SUCCESS_CODE));
	}

	@Test
	public void reject_test() throws Exception {
		ManagerApprovalRequest maRequest = new ManagerApprovalRequest();
		maRequest.setEcpdId("6778");
		maRequest.setUserId("6778ADMBT");
		maRequest.setZipCode("30007");
		maRequest.setApprovalStatus(false);
		Mockito.when(approvalService.makeRejectionCall(Mockito.any(ManagerApprovalRequest.class)))
				.thenReturn(getManagerApprovalResponse(false));
		MvcResult mvcResult = getMvcResult("/mbt/approval/approvalProcess", maRequest);
		ManagerApprovalResponse managerApprovalResponse = gson.fromJson(mvcResult.getResponse().getContentAsString(),
				ManagerApprovalResponse.class);
		assertTrue(managerApprovalResponse.getServiceStatus().getStatusCode(),
				managerApprovalResponse.getServiceStatus().getStatusCode().equalsIgnoreCase(Constants.SUCCESS_CODE));
	}

	private ManagerApprovalResponse getManagerApprovalResponse(boolean managerApprovalLandingInfo) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		if (managerApprovalLandingInfo) {
			response.setOrderJson(getOrderJson());
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
			serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
			response.setServiceStatus(serviceStatus);
		}
		return response;
	}
	
	@Test
	public void test_updateManagerInfoFailure() throws Exception {
		ServiceStatus serviceStatus=new ServiceStatus();	
		serviceStatus.setStatusCode(Constants.FAILURE_CODE);
		serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
		
		ManagerApprovalRequest request = new ManagerApprovalRequest();
		request.setEcpdId("");
		request.setApproverEmailIds("");
		request.setLevel("");
		Mockito.when(managerService.updateManagerApprovalInfo(Mockito.isA(ManagerApprovalRequest.class))).thenReturn(serviceStatus);
		
		MvcResult mvc=mockMvc.perform(post("/mbt/approval/updateManagerInfo")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request)))
				.andExpect(status().isOk()).andReturn();
		ManagerApprovalResponse  outputResp= gson.fromJson(mvc.getResponse().getContentAsString(),ManagerApprovalResponse .class);
		
	    assertNotNull(outputResp);
	    assertThat(outputResp.getServiceStatus().getStatusCode().equals(Constants.FAILURE_CODE));
						
	}
	@Test
	public void test_updateManagerInfo() throws Exception {
		ServiceStatus serviceStatus=new ServiceStatus();	
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		
		ManagerApprovalRequest request = new ManagerApprovalRequest();
		request.setEcpdId("582760");
		request.setApproverEmailIds("girish@verizon.com");
		request.setLevel("1");
		Mockito.when(managerService.updateManagerApprovalInfo(Mockito.isA(ManagerApprovalRequest.class))).thenReturn(serviceStatus);
		
		MvcResult mvc=mockMvc.perform(post("/mbt/approval/updateManagerInfo")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request)))
				.andExpect(status().isOk()).andReturn();
		ManagerApprovalResponse  outputResp= gson.fromJson(mvc.getResponse().getContentAsString(),ManagerApprovalResponse .class);
		
	    assertNotNull(outputResp);
	    assertThat(outputResp.getServiceStatus().getStatusCode().equals(Constants.SUCCESS_CODE));
						
	}

	@Test
	public void test_getManagerApprovalSm() throws Exception {
		
		
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setEcpdId("9782");
		request.setUserId("9782QA123");
		Mockito.when(managerServiceSM.getManagerApprovalSMInfo(Mockito.isA(ManagerApprovalSMRequest.class))).thenReturn(getManagerApprovalSmInfo());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/getMAInformationSM")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMInfo returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMInfo.class);		
		
		assertNotNull(returnInfo);
		assertTrue(returnInfo.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getManagerApprovalSmMissingMandFields() throws Exception {
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setEcpdId("");
		request.setUserId("");
		Mockito.when(managerServiceSM.getManagerApprovalSMInfo(Mockito.isA(ManagerApprovalSMRequest.class))).thenReturn(getManagerApprovalSmInfo());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/getMAInformationSM")
				.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMInfo returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMInfo.class);		
		
		assertNotNull(returnInfo);
		assertFalse(returnInfo.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_approvalLandingSm() throws Exception {
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setCreds("ssdlkfhuydsfyuhsd87fysd78hyufsd6ftyusdhbfgyu7s6dtfsdhf");
		Mockito.when(approvalServiceSM.getSMInformation(Mockito.isA(ManagerApprovalSMRequest.class))).thenReturn(getManagerApprovalSMResponse());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/approvalLandingSM")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMResponse returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMResponse.class);
		
		assertNotNull(returnInfo);
		assertTrue(returnInfo.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_approvalLandingSmMisingCreds() throws Exception {
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setCreds("");
		Mockito.when(approvalServiceSM.getSMInformation(Mockito.isA(ManagerApprovalSMRequest.class))).thenReturn(getManagerApprovalSMResponse());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/approvalLandingSM")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMResponse returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMResponse.class);
		
		assertNotNull(returnInfo);
		assertFalse(returnInfo.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_approvedProcessingSm() throws Exception {
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setApprovalStatus(true);		
		Mockito.when(approvalServiceSM.makeApprovalCall(Mockito.isA(ManagerApprovalSMRequest.class))).thenReturn(getManagerApprovalSMResponse());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/approvalProcessingSM")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMResponse returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMResponse.class);
		
		assertNotNull(returnInfo);
		assertTrue(returnInfo.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_rejectionProcessingSm() throws Exception {
		ManagerApprovalSMRequest request = new ManagerApprovalSMRequest();
		request.setApprovalStatus(false);		
		Mockito.when(approvalServiceSM.makeRejectionCall(Mockito.isA(ManagerApprovalSMRequest.class),Mockito.anyBoolean())).thenReturn(getManagerApprovalSMResponse());
		MvcResult mvc = mockMvc.perform(post("/mbt/approval/approvalProcessingSM")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.content(gson.toJson(request))).andExpect(status().isOk()).andReturn();
		
		ManagerApprovalSMResponse returnInfo = gson.fromJson(mvc.getResponse().getContentAsString(), ManagerApprovalSMResponse.class);
		
		assertNotNull(returnInfo);
		assertTrue(returnInfo.getServiceStatus().isSuccess());
	}


	@Test
	public void test_MaAutoExpireNotification() throws Exception {

		AutoNotificationResponse response = new AutoNotificationResponse();
		AutoNotificationRequest maRequest = new AutoNotificationRequest();
		Mockito.when(batchService.initialReminder(Mockito.isA(AutoNotificationRequest.class)))
				.thenReturn(response);

		Mockito.when(batchService.finalReminder(Mockito.isA(AutoNotificationRequest.class)))
				.thenReturn(response);
		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/MaAutoExpireNotification").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(gson.toJson(response)))
				.andExpect(status().isOk()).andReturn();

		AutoNotificationResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(),
				AutoNotificationResponse.class);
		//assertNotNull(maResp);
		//assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);

	}
	
	@Test
	public void test_MAReminderNotification() throws Exception {
		// AutoNotificationResponse
		// reminderNotificationOne(AutoNotificationRequest maRequest)

		AutoNotificationResponse response = new AutoNotificationResponse();
		AutoNotificationRequest maRequest = new AutoNotificationRequest();
		Mockito.when(batchService.initialReminder(Mockito.isA(AutoNotificationRequest.class)))
				.thenReturn(response);

		Mockito.when(batchService.finalReminder(Mockito.isA(AutoNotificationRequest.class)))
				.thenReturn(response);

		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/MaReminderNotification").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(gson.toJson(response)))
				.andExpect(status().isOk()).andReturn();

		AutoNotificationResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(),
				AutoNotificationResponse.class);
		assertNotNull(maResp);
		//assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);

	}

	@Test
	public void test_getProspectDevices() throws Exception {
		Mockito.when(deviceService.getDeviceInformation()).thenReturn(getDeviceList());
		
		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/prospect/getDevices").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON)
						.content(gson.toJson("")))
				.andExpect(status().isOk()).andReturn();

		DeviceGridwallResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(), DeviceGridwallResponse.class);
		
		assertNotNull(maResp);

	}

	@Test
	public void test_getProspectAccessories() throws Exception {
		try {
		Mockito.when(deviceService.getAccessoryInformation()).thenReturn(new AccessoryGridwallResponse());
		
		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/prospect/getAccessories").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON)
						.content(gson.toJson("")))
				.andExpect(status().isOk()).andReturn();

		AccessoryGridwallResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(), AccessoryGridwallResponse.class);
		
		assertNotNull(maResp);
		} catch (Exception e){
			
		}

	}
	
	@Test
	public void test_getProspectAccessory_Exception() throws Exception {
		Mockito.when(deviceService.getAccessoryInformation()).thenThrow(new RuntimeException());
		
		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/prospect/getAccessories").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON)
						.content(gson.toJson("")))
				.andExpect(status().isOk()).andReturn();

		AccessoryGridwallResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(), AccessoryGridwallResponse.class);
		
		assertNotNull(maResp);

	}
	
	@Test
	public void test_getProspectDevices_Exception() throws Exception {
		Mockito.when(deviceService.getDeviceInformation()).thenThrow(new RuntimeException());
		
		MvcResult mvc = mockMvc
				.perform(post("/mbt/approval/prospect/getDevices").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON)
						.content(gson.toJson("")))
				.andExpect(status().isOk()).andReturn();

		DeviceGridwallResponse maResp = gson.fromJson(mvc.getResponse().getContentAsString(), DeviceGridwallResponse.class);
		
		assertNotNull(maResp);

	}
	
	private com.vzw.mybiz.utilities.audit.domain.ServiceStatus getServiceStatus(String statusCode, String statusMessage, boolean isSuccess) {
		com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setSuccess(isSuccess);
		return serviceStatus;
	}
	private ManagerApprovalSMInfo getManagerApprovalSmInfo() {
		ManagerApprovalSMInfo info =new ManagerApprovalSMInfo();
		info.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG,true));
		return info;
	}
	
	private ManagerApprovalSMResponse getManagerApprovalSMResponse() {
		ManagerApprovalSMResponse res = new ManagerApprovalSMResponse();
		res.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG,true));
		return res;
	}
	
	private List<DeviceDetails> getDeviceList() throws IOException {
		String deviceData = IOUtils.toString(getClass().getClassLoader().getResource("deviceList.json"));
		DeviceGridwallResponse resposne = gson.fromJson(deviceData, DeviceGridwallResponse.class);
		return resposne.getDeviceList(); 
	}
	
	private String getOrderJson() {

		String orderJson = "{\"order\":{\"orderTimeStamp\":\"2018-11-08T15:23:09.791\",\"timeZone\":\"EST\",\"credential\":{\"existingPhoneNumber\":\"8102781776\",\"accountNumber\":\"481044994-1\"},\"corporateInfo\":{\"ecpdId\":6778,\"corporateName\":\"UAT3TEST - 6778\",\"corporateCustCareNumber\":\"BGCO SMB NC MKT\",\"corporateTaxId\":\"AHJMS4734\",\"corporateTaxExempt\":\"N\",\"corporateManagerApproval\":\"NO\",\"corporateSuppressCredit\":\"NO\",\"corporateEmailTemplateId\":\"25\",\"liabilityType\":\"C\"},\"orderApproval\":[{\"level\":\"1\",\"approver\":[{\"approvalEmail\":\"pradeep.rajendiran@verizon.com\",\"approvalUrl\":\"mbqa1.sdc.vzwcorp.com\"}]}],\"maApprovalUrl\":\"mbqa1.sdc.vzwcorp.com\",\"maApproverEmailId\":\"pradeep.rajendiran@verizon.com\",\"confirmationAndShipNotification\":{\"email\":\"\"},\"billingAddress\":{\"type\":\"RD\",\"addressType\":\"B\",\"streetName\":\"HIGHLAND\",\"zipCode\":\"48353\",\"zipCode4\":\"2711\",\"city\":\"HARTLAND\",\"state\":\"MI\",\"addressLine1\":\"11590 HIGHLAND RD # M59\",\"addressLine2\":\"M59\",\"country\":\"USA\",\"streetNum\":\"11590\"},\"subscriberShippingInformation\":{\"carrierCode\":\"SHP002\",\"shippingDescription\":\"2 DAY SHIP BY 8PM\",\"serviceType\":\"STANDARD SHIPPING\",\"shCharges\":0,\"shippingAddress\":{\"type\":\"RD\",\"attn\":\"Jake\",\"addressType\":\"Business\",\"streetName\":\"TALL OAK\",\"zipCode\":\"08837\",\"zipCode4\":\"2072\",\"city\":\"EDISON\",\"state\":\"NJ\",\"addressLine1\":\"291 Tall Oak Road\",\"businessName\":\"Walmart\",\"shippingCBRNumber\":\"7692454875\",\"streetNum\":\"291\"}},\"creditWriteRequestInfo\":{\"locationCode\":\"P166701\"},\"originatingIpAddress\":\"10.169.250.162\",\"revenueInfo\":{\"dueToday\":7.99,\"orderAmount\":7.49,\"taxAmount\":0.5,\"taxDetails\":[{\"subTotal\":\"0.5\",\"item\":[{\"amount\":0.5,\"description\":[{\"value\":\"NJ State Sales Tax\"}]}],\"type\":\"TBA\"}],\"paymentType\":\"BILLTOACCT\"},\"subOrder\":[{\"retailAccessory\":{\"fipsCode\":\"3402300000\",\"systemData\":{\"marketCode\":\"Georgia\",\"regionCode\":\"Georgia/Alabama\",\"areaName\":\"South\",\"fulfillment\":\"VISION_B2B\",\"databaseID\":\"GA\",\"serviceZipCode\":\"30004\",\"serviceCity\":\"Alpharetta\",\"serviceState\":\"GA\"},\"salesRepId\":\"ESQ43\",\"equipment\":[{\"name\":\"4.8A Vehicle Charger with Dual Output\",\"productType\":\"ACCESSORY\",\"taxDetailsList\":[{\"taxDetail\":[{\"taxType\":\"NJ State Sales Tax\",\"taxAmount\":\"0.5\",\"taxDescription\":\"NJ State Sales Tax\"}],\"count\":\"1.0\"}],\"amount\":\"7.49\",\"retailPrice\":\"9.98\",\"listPrice\":\"7.49\",\"quantity\":1,\"productCode\":\"VPC48BLK\",\"taxAmount\":0.5,\"taxDescription\":\"\"},{\"name\":\"2 DAY SHIP BY 8PM\",\"productType\":\"SHIP\",\"taxDetailsList\":[],\"amount\":\"0.0\",\"retailPrice\":\"0.0\",\"listPrice\":\"0.0\",\"quantity\":1,\"productCode\":\"SHP002\",\"taxAmount\":0}],\"feature\":[],\"subscriber\":{\"subscriberName\":{\"firstName\":\"DON\",\"lastName\":\"HENDERSON\"},\"contact\":{\"email\":\"WHKVIL@VZW.COM\"},\"subscriberServiceAddress\":{\"zipCode\":\"48353\",\"city\":\"HARTLAND\",\"state\":\"MI\",\"addressLine1\":\"11590 HIGHLAND RD # M59\",\"zip10\":\"48353\"}},\"customerUniqueCode\":[]}}]},\"clientId\":\"MBT\",\"groupOrderNumber\":\"MB3000008482754\",\"loggedInUserId\":\"6778ADMBT\",\"profileId\":\"6778\",\"confirmationNumber\":\"MB3000008482755\",\"orderType\":\"EPBNAO\",\"tokenizationFlag\":\"ON\"}";
		return orderJson;
	}
	

	@Test
	public void test_generateOrderPdfonSuccess() throws Exception {
		OrderPdfRequest request = new OrderPdfRequest();
		OrderPDFResponse res = new OrderPDFResponse();

		request.setConfirmationNumber("504738589");
		Mockito.when(smCpcService.generateOrderPdfLineLevel(Mockito.isA(OrderPdfRequest.class))).thenReturn(res);
		MvcResult result = mockMvc
				.perform(post("/mbt/approval/generateOrderPdf").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(gson.toJson(request)))
				.andExpect(status().isOk()).andReturn();
		OrderPDFResponse response = gson.fromJson(result.getResponse().getContentAsString(),
				OrderPDFResponse.class);
		Assert.assertNotNull(response);
	}
	
	
}
