package com.vzw.mybiz.test.approval.service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.junit4.SpringRunner;

import com.vzw.mybiz.approval.exception.VipFeignException;
import com.vzw.mybiz.approval.service.impl.VipRestServiceImpl;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.prospect.domain.pos.ObjectFactory;
import com.vzw.mybiz.prospect.domain.pos.POSServices;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.FeignException;
import feign.RequestTemplate;
import feign.Response;
import feign.Body;
import feign.codec.DecodeException;

@RunWith(SpringRunner.class)
public class VipRestServiceImplTest {
	
	@Spy
	@InjectMocks
	private VipRestServiceImpl vipService;
	
	@Mock
	private CloudPropertiesConfig cloudPropertiesConfig;
	
	@Mock
	private AuditService auditService;
	
	//@Mock
	private Response response;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		Mockito.when(cloudPropertiesConfig.getVipUrl()).thenReturn("https://vip-sqa3.vzwcorp.com");	
		Mockito.doNothing().when(auditService).beginTransaction(new POSServices(), new ExternalSys("POS", "https://vip-sqa3.vzwcorp.com"));
		//vipService.init();
	}
	
	//@Test
//	public void test_submitOrder_success(){
//		//Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
//		//Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
//		Mockito.when(cloudPropertiesConfig.getFeignConnectTimeout()).thenReturn(0);
//		Mockito.when(cloudPropertiesConfig.getFeignReadTimeout()).thenReturn(0);
//		Mockito.when(cloudPropertiesConfig.getPassword()).thenReturn("");
//		Mockito.when(cloudPropertiesConfig.getUserId()).thenReturn("");
//		//Mockito.when(cloudPropertiesConfig.getVipUrl()).thenReturn("");
//		
//		//Mockito.doNothing().when(auditService.endTransaction(Mockito.any(POSServices.class), Mockito.any(ResponseDetails.class)));
//		
//		try {
//			vipService.submitProspectOrder(buildPOSRequest(null));
//		} catch (VipFeignException e) {
//			e.printStackTrace();
//		}
//	}
	
	//@Test
	public void test_decode() {
		try {
			Map<String, Collection<String>> map = new HashMap<String, Collection<String>>();
			//response = Response.create(200, "Success", map , "0".getBytes());
			
//			Mockito.when(response.status()).thenReturn(200);
//			Mockito.when(response.body()).thenReturn(null);
			vipService.getCustomDecoder(null).decode(response, POSServices.class);
		} catch (DecodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FeignException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	@Test
	public void test_encode() {
		vipService.getCustomEncoder(buildPOSRequest(null)).encode(null, POSServices.class, new RequestTemplate());
	}
	
	@Test
	public void test_customDecoder() {
		Response.Builder builder = Response.builder().status(404).request(feign.Request.create("POST", "", new HashMap<String, Collection<String>>(), "0".getBytes(), Charset.defaultCharset()));
		builder.headers(new HashMap<String, Collection<String>>());
		Response response = builder.build();
		Object expectedValue = null;
		try {
			expectedValue = vipService.getCustomDecoder(null).decode(response, POSServices.class);
		} catch (FeignException | IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void test_customDecoder1() {
		Response.Builder builder = Response.builder().status(200).request(feign.Request.create("POST", "", new HashMap<String, Collection<String>>(), "0".getBytes(), Charset.defaultCharset()));
		builder.headers(new HashMap<String, Collection<String>>());
		builder.body("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><POSServices xmlns=\"http://pos.odc.vzwcorp.com\">    <ServiceHeader>        <userName>OAS</userName>        <password>*********</password>        <clientAppName>MYBUSINESS</clientAppName>        <clientAppUserName>PROSPECT-USER</clientAppUserName>        <serviceName>cartMicroService</serviceName>        <serviceAction>saveCommonCart</serviceAction>        <applicationResponseCode>99000</applicationResponseCode>        <applicationResponseClass>SUCCESS</applicationResponseClass>        <applicationResponseMessage>[10-119-11-235.EBIZ.VERIZON.COM:onevz-vip-conductor02:10.119.11.235]Transaction processed successfully.</applicationResponseMessage>        <applicationResponseDetails></applicationResponseDetails>        <timeStamp>2020-04-06T16:13:40.356-04:00</timeStamp>        <encryptionIndicator>T</encryptionIndicator>        <loggingId>634cac18e789d4f7</loggingId>    </ServiceHeader>    <ServiceBody>        <saveCommonCartMS>            <response>                <cartId>10816657</cartId>                <resultCode>1</resultCode>            </response>        </saveCommonCartMS>    </ServiceBody></POSServices>", StandardCharsets.UTF_8);
		Response response = builder.build();
		Object expectedValue = null;
		try {
			expectedValue = vipService.getCustomDecoder(com.vzw.mybiz.prospect.domain.sed.vip.POSServices.class).decode(response, POSServices.class);
		} catch (FeignException | IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void test_customDecoder2() {
		Response.Builder builder = Response.builder().status(200).request(feign.Request.create("POST", "", new HashMap<String, Collection<String>>(), "0".getBytes(), Charset.defaultCharset()));
		builder.headers(new HashMap<String, Collection<String>>());
		builder.body("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><POSServices xmlns=\"http://pos.odc.vzwcorp.com\">    <ServiceHeader>        <userName>OAS</userName>        <password>*********</password>        <clientAppName>MYBUSINESS</clientAppName>        <clientAppUserName>PROSPECT-USER</clientAppUserName>        <serviceName>cartMicroService</serviceName>        <serviceAction>saveCommonCart</serviceAction>        <applicationResponseCode>99000</applicationResponseCode>        <applicationResponseClass>SUCCESS</applicationResponseClass>        <applicationResponseMessage>[10-119-11-235.EBIZ.VERIZON.COM:onevz-vip-conductor02:10.119.11.235]Transaction processed successfully.</applicationResponseMessage>        <applicationResponseDetails></applicationResponseDetails>        <timeStamp>2020-04-06T16:13:40.356-04:00</timeStamp>        <encryptionIndicator>T</encryptionIndicator>        <loggingId>634cac18e789d4f7</loggingId>    </ServiceHeader>    <ServiceBody>        <saveCommonCartMS>            <response>                <cartId>10816657</cartId>                <resultCode>1</resultCode>            </response>        </saveCommonCartMS>    </ServiceBody></POSServices>", StandardCharsets.UTF_8);
		Response response = builder.build();
		Object expectedValue = null;
		try {
			expectedValue = vipService.getCustomDecoder(null).decode(response, POSServices.class);
		} catch (FeignException | IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	
	@Test
	public void test_customDecoder_nullResponse() {
		Response.Builder builder = Response.builder().status(200).request(feign.Request.create("POST", "", new HashMap<String, Collection<String>>(), "0".getBytes(), Charset.defaultCharset()));
		builder.headers(new HashMap<String, Collection<String>>());
		Response response = builder.build();
		Object expectedValue = null;
		try {
			expectedValue = vipService.getCustomDecoder(null).decode(response, POSServices.class);
		} catch (FeignException | IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Test
	public void test_customDecoder_DecodeException() {
		Response.Builder builder = Response.builder().status(200).request(feign.Request.create("POST", "", new HashMap<String, Collection<String>>(), "0".getBytes(), Charset.defaultCharset()));
		builder.headers(new HashMap<String, Collection<String>>());
		builder.body("test".getBytes());
		Response response = builder.build();
		boolean decodeException = false;
		try {
			vipService.getCustomDecoder(null).decode(response, String.class);
		} catch (FeignException | IOException e) {
			decodeException = true;
		}
		
		
	}

	
	private POSServices buildPOSRequest(String base64Order) {
		
		ObjectFactory posObjectFactory = new ObjectFactory();
		POSServices service = posObjectFactory.createPOSServices();
		POSServices.ServiceHeader serviceHeader = posObjectFactory.createPOSServicesServiceHeader();
		POSServices.ServiceHeader.OrderKeyInfo serviceHeaderOrderKeyInfo = posObjectFactory.createPOSServicesServiceHeaderOrderKeyInfo();
		
		POSServices.ServiceBody serviceBody = posObjectFactory.createPOSServicesServiceBody();
		
		POSServices.ServiceBody.SaveCommonCartMS saveCommonCartMS = posObjectFactory.createPOSServicesServiceBodySaveCommonCartMS();
		POSServices.ServiceBody.SaveCommonCartMS.Request saveCommonCartMSRequest =  posObjectFactory.createPOSServicesServiceBodySaveCommonCartMSRequest();
		
		saveCommonCartMSRequest.setStatus("A");
		saveCommonCartMSRequest.setCartInfo(base64Order);
		
		saveCommonCartMS.setRequest(saveCommonCartMSRequest);
		serviceBody.setSaveCommonCartMS(saveCommonCartMS);
		
		serviceHeader.setClientAppName("MYBUSINESS");
		serviceHeader.setClientAppUserName("PROSPECT-USER");
		serviceHeader.setEncryptionIndicator("T");
		serviceHeader.setOrderKeyInfo(serviceHeaderOrderKeyInfo);
		serviceHeader.setServiceAction("saveCommonCart");
		serviceHeader.setServiceName("cartMicroService");
		serviceHeader.setSessionID("");
		//serviceHeader.setTimeStamp("");
		serviceHeader.setTransactionId("");
		
		service.setServiceHeader(serviceHeader);
		service.setServiceBody(serviceBody);
		
		
		return service;
	}

}
