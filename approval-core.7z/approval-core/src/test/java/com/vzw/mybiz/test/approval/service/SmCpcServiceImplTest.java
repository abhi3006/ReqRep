package com.vzw.mybiz.test.approval.service;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;

import com.vzw.mybiz.approval.client.SmCpcClient;
import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.approval.exception.ApprovalException;
import com.vzw.mybiz.approval.service.impl.SmCpcServiceImpl;
import com.vzw.mybiz.utilities.audit.services.AuditService;



public class SmCpcServiceImplTest {
	
	@InjectMocks
	@Spy
	private SmCpcServiceImpl smCpcServiceImpl;

	@Mock
	SmCpcClient smCpcClient;

	@Mock
	AuditService auditService;
	
	@Mock
    private HttpServletRequest httpServletRequest;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test_generateOrderPdfLineLevel_success() throws ApprovalException {
		OrderPdfRequest request = new OrderPdfRequest();
		request.setConfirmationNumber("504744556");
		String loninUserId = "48242ALEXQA1";
		String ecpdId = "48242";
		String csrid = "CSRID";
		OrderPDFResponse response = mockCurrentPlanResponse();
		Mockito.when(httpServletRequest.getHeader(Constant.ECPD_ID)).thenReturn(ecpdId);
		Mockito.when(httpServletRequest.getHeader(Constant.LOGIN_USER_ID)).thenReturn(loninUserId);

		Mockito.when(smCpcClient.generateOrderPdf(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(OrderPdfRequest.class))).thenReturn(response);
		smCpcServiceImpl.generateOrderPdfLineLevel(request);		

	}
	
	
	@Test(expected = ApprovalException.class)
	public void test_generateOrderPdfLineLevel_Exception() throws ApprovalException {
		OrderPdfRequest request = new OrderPdfRequest();
		request.setConfirmationNumber("504744556");
		String loninUserId = "48242ALEXQA1";
		String ecpdId = "48242";
		String csrid = "CSRID";
		OrderPDFResponse response = mockCurrentPlanFailureResponse();
		Mockito.when(httpServletRequest.getHeader(Constant.ECPD_ID)).thenReturn(ecpdId);
		Mockito.when(httpServletRequest.getHeader(Constant.LOGIN_USER_ID)).thenReturn(loninUserId);

		Mockito.when(smCpcClient.generateOrderPdf(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(OrderPdfRequest.class))).thenReturn(response);
		smCpcServiceImpl.generateOrderPdfLineLevel(request);		

	}
	
	@Test(expected = ApprovalException.class)
	public void test_generateOrderPdfLineLevel_failure() throws ApprovalException {
		OrderPdfRequest request = new OrderPdfRequest();
		request.setConfirmationNumber("504744556");
		String loninUserId = "48242ALEXQA1";
		String ecpdId = "48242";
		String csrid = "CSRID";		
		Mockito.when(httpServletRequest.getHeader(Constant.ECPD_ID)).thenReturn(ecpdId);
		Mockito.when(httpServletRequest.getHeader(Constant.LOGIN_USER_ID)).thenReturn(loninUserId);

		Mockito.when(smCpcClient.generateOrderPdf(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(OrderPdfRequest.class))).thenReturn(null);
		smCpcServiceImpl.generateOrderPdfLineLevel(request);		

	}
	
	
	@Test(expected = ApprovalException.class)
	public void test_generateOrderPdfLineLevel_null() throws ApprovalException {
		OrderPDFResponse response = mockCurrentPlanResponse();
		response.setServiceStatus(null);
		OrderPdfRequest request = new OrderPdfRequest();
		String loninUserId = "48242ALEXQA1";
		String ecpdId = "48242";
		String csrid = "CSRID";
		Mockito.when(httpServletRequest.getHeader(Constant.ECPD_ID)).thenReturn(ecpdId);
		Mockito.when(httpServletRequest.getHeader(Constant.LOGIN_USER_ID)).thenReturn(loninUserId);
		Mockito.when(smCpcClient.generateOrderPdf(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(OrderPdfRequest.class))).thenReturn(response);
		smCpcServiceImpl.generateOrderPdfLineLevel(request);		
	}

	@Test(expected = ApprovalException.class)
	public void test_getCurrentPlan_exception() throws ApprovalException {
		OrderPdfRequest request = new OrderPdfRequest();
		Mockito.when(smCpcClient.generateOrderPdf(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.isA(OrderPdfRequest.class))).thenThrow(NullPointerException.class);
		smCpcServiceImpl.generateOrderPdfLineLevel(request);
		
	}
	
	private OrderPDFResponse mockCurrentPlanResponse()
	{
		OrderPDFResponse response = new OrderPDFResponse();		
		ServiceStatus svcStatus = new ServiceStatus();
		svcStatus.setStatusMessage("00");
		response.setServiceStatus(svcStatus);
		return response;
	}
	
	private OrderPDFResponse mockCurrentPlanFailureResponse()
	{
		OrderPDFResponse response = new OrderPDFResponse();		
		ServiceStatus svcStatus = new ServiceStatus();
		svcStatus.setStatusMessage("");
		response.setServiceStatus(svcStatus);
		return response;
	}



}
