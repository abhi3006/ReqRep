package com.vzw.mybiz.test.approval.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.NotificationClient;
import com.vzw.mybiz.approval.client.SMTransactionSubmitClient;
import com.vzw.mybiz.approval.client.TransHistoryCoreClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.Credentials;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalAccountLevelResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMResponse;
import com.vzw.mybiz.approval.domain.sm.onemessage.ManagerRequest;
import com.vzw.mybiz.approval.domain.sm.onemessage.NotificationResponse;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsRequest;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;
import com.vzw.mybiz.approval.entity.ManagerApprovalSMTracker;
import com.vzw.mybiz.approval.repo.ManagerApprovalSMRepo;
import com.vzw.mybiz.approval.service.impl.ApprovalServiceSMImpl;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

public class ApprovalServiceSMImplTest {
	
	@Spy
	@InjectMocks
	private ApprovalServiceSMImpl approvalService;

	@Mock
  	private ManagerApprovalSMRepo managerApprovalSMRepo;
	
	@Mock
	private TransHistoryCoreClient transHistoryCoreClient;
	
	@Mock
	private Credentials credentials;
	
	@Mock
	private SMTransactionSubmitClient smTransactionSubmitClient;
	
	@Mock
	private NotificationClient oneMsgClient;
	
	@Mock
	CloudPropertiesConfig cloudPropertiesConfig;

	Gson gson = new Gson();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		approvalService.init();
	}
	
	@Test
	public void test_getOrderInformationSMAccountLevel_success(){
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getAccountLevelOrderData());
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFACCOUNTLEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMAccountLevel_success_empty_orderList(){
		OrderDetailsResponse orderDetail = getAccountLevelOrderData();
		orderDetail.setOrderDetailsList(null);
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(orderDetail);
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFACCOUNTLEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}

	
	@Test
	public void test_getOrderInformation_Exception(){
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenThrow(new RuntimeException("This is for testing"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFACCOUNTLEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMLineLevel_success(){
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMLineLevel_success_empty_orderList(){
		OrderDetailsResponse order = getLineLevelOrderData();
		order.setOrderDetailsList(null);
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(order);
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMCCC_success(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequest(true);
		 managerApprovalRequest.setTransactionType("changeCostCenter");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForCCC(true));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=changeCostCenter");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.doReturn(true).when(approvalService).checkForCommonTransaction(Mockito.anyString());
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMCCC_nullOrderDetails(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequest(true);
		 managerApprovalRequest.setTransactionType("changeCostCenter");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForCCC(false));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=changeCostCenter");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMCWUI_success() throws Exception {
		ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequest(true);
		managerApprovalRequest.setTransactionType("ChangeUserInformation");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class)))
				.thenReturn(getOrderDataForCWUI(true));
		Mockito.when(credentials.getDecryptedText())
				.thenReturn("orderId=1007290134&ecpdId=5598&level=1&transactionType=ChangeUserInformation");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString()))
				.thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.doReturn(true).when(approvalService).checkForCommonTransaction(Mockito.anyString());
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);

		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}

	@Test
	public void test_getOrderInformationSMCWUI_emptyOrderDetails() throws Exception {
		ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequest(true);
		managerApprovalRequest.setTransactionType("ChangeUserInformation");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class)))
				.thenReturn(getOrderDataForCWUI(false));
		Mockito.when(credentials.getDecryptedText())
				.thenReturn("orderId=1007290134&ecpdId=5598&level=1&transactionType=ChangeUserInformation");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString()))
				.thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);

		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationUrlExpired() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("13-JUL-19"));
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
		assertEquals(smRes.getServiceStatus().getStatusMessage(),(Constants.URL_EXPIRY_MSG));
	}
	
	@Test
	public void test_getOrderInformationRejected() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1REJECTED");
		tracker.setCreatedDate(new Date());
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
		assertEquals(smRes.getServiceStatus().getStatusMessage(),(Constants.ORDER_REJECTED_MSG));
	}
	
	@Test
	public void test_getOrderInformationApproved() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L2APPROVED");
		tracker.setCreatedDate(new Date());
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
		assertEquals(smRes.getServiceStatus().getStatusMessage(),(Constants.ORDER_APPROVED_MSG));
	}
	
	@Test
	public void test_makeL1RejectionCall() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		ManagerApprovalSMResponse smRes = approvalService.makeRejectionCall(request,true);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
		assertEquals(Constants.L1_REJECTED,smRes.getLevel());
	}
	
	@Test
	public void test_makeL2RejectionCall() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("2");
		ManagerApprovalSMResponse smRes = approvalService.makeRejectionCall(request,true);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
		assertEquals(Constants.L2_REJECTED,smRes.getLevel());
	}
	
	@Test
	public void test_makeL2RejectionCall_Exception() throws Exception {
		
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenThrow(new RuntimeException("This is for testing"));
		
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("2");
		request.setApprovalStatus(false);
		ManagerApprovalSMResponse smRes = approvalService.makeRejectionCall(request,true);
		 ServiceStatus serviceStatus= new ServiceStatus();
		 
		smRes.setServiceStatus(serviceStatus);
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
		assertEquals(Constants.L2_REJECTED,smRes.getLevel());
	}
	
	@Test
	public void test_makeL1ApprovalCall() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setApproverEmail2("");
		tracker.setOrderNumber("MB00000000");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"MB00000000"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	@Test
	public void test_makeL1ApprovalCallCommonTran() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=changeCostCenter");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setOrderNumber("MB00000000");
		tracker.setTransactionType("changeCostCenter");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("changeCostCenter");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"MB00000000"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
	}
	
	@Test
	public void test_makeL2ApprovalCallCommonTran() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=changeCostCenter");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(2);
		tracker.setApproverEmail2("xyz@mail.com");
		tracker.setOrderNumber("MB00000000");
		tracker.setTransactionType("changeCostCenter");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("changeCostCenter");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"MB00000000"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	@Test
	public void test_makeL1ApprovalCallFailed() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setApproverEmail2(null);
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(false,""));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
	}
	@Test
	public void test_makeL1ApprovalCallFailed1() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L2PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setApproverEmail2(null);
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(false,""));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());		
	}
	
	@Test
	public void test_makeL2ApprovalCall() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderData());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L2PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(2);
		tracker.setApproverEmail2("test@verizon.com");
		tracker.setMaAmTransactionJson("{\"clientId\":\"MBT\",\"ecpdId\":\"6778\",\"loginUserId\":\"6778QA3DATA\",\"tranType\":\"ARFLINELEVEL\",\"refNbr\":\"c82d9ff0-7819-494d-82c4-912c5e165a9c2hWUwqDJKuERSNLEwesGKk0-FTD5mmx1LHPt81xMhLQ2VnSzss7o!-1245414049!loghost!5027!-1!1552978976969\",\"mgrApprovalEmail\":[\"VZW.MB.AUTOMATION.DEV.TEAM@ONE.VERIZON.COM\"],\"mgrApprovalLevel\":2,\"confirmEmail\":[\"MVB.MOBILE.DEV@VERIZONWIRELESS.COM\",\"renuka.raja@verizon.com\"],\"numberOfAcc\":1,\"firstName\":\"SWATHI\",\"lastName\":\"DATLA\",\"userName\":\"SWATHI DATLA\",\"accountList\":[{\"accountNbr\":\"803277415-00001\",\"mtnList\":[{\"mtn\":\"7022794778\",\"validatedFeaturesList\":[{\"billingCode\":\"48526\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"Text Messaging Pay Per Message\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"48553\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Streamlined Billing\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"54307\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"A\",\"statIind\":\"S\",\"limitTypeCode\":\"A\",\"name\":\"Block Messaging\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"ADD\"},{\"billingCode\":\"66332\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Decline Equipment Protection\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"68869\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Caller ID\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"68871\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Conference Calling\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"68872\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"CALL DELIVERY\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"68873\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Call Waiting\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"73733\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Decline Voice Mail\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"73884\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Call \\u0026 Messaging Block\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"75706\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"D\",\"statIind\":\"T\",\"limitTypeCode\":\"A\",\"name\":\"Pay Per Message\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"AUTODELETE\"},{\"billingCode\":\"75802\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Dynamic-Private IP\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"75836\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"4G Internet Access\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"75837\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"4G Application Access\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"76019\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Block Roaming of 4G Devices\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"76152\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"D\",\"statIind\":\"T\",\"limitTypeCode\":\"A\",\"name\":\"Picture Message Provisioning\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"AUTODELETE\"},{\"billingCode\":\"77249\",\"billingCodeType\":\"DATASFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"Mobile Hotspot Trigger\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"77552\",\"billingCodeType\":\"DATASFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Block Mobile Hotspot/Pre-Provisioned Mobile Hotspot\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"77556\",\"billingCodeType\":\"DATASFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"4G PROVISIONING\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"77568\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"EMAIL ACCESS\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"77581\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"EMAIL TRIGGER ALP\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"77583\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"DATA PROVISION ALP\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"80148\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"International Messages While in US\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"82419\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Access Wi-fi Calling\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"83856\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"CDMA-LESS DEVICE PROVISIONING\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"84071\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"Carryover Data\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"84076\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"VERIZON PLAN ENTITLEMENT\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"84077\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"B\",\"limitTypeCode\":\"M\",\"name\":\"RTR/UC TRIGGER VP 2.0\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"84094\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"INTL SERVICES ENABLED LITE\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"84215\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"4G Voice\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"85464\",\"billingCodeType\":\"SFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"ENTITLEMENT\",\"price\":0.0,\"finalPrice\":0.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"},{\"billingCode\":\"85617\",\"billingCodeType\":\"DATASFO\",\"actionIndicator\":\"Z\",\"statIind\":\"O\",\"limitTypeCode\":\"A\",\"name\":\"NumberShare - Line Access\",\"price\":10.0,\"finalPrice\":10.0,\"mutuallyExclusive\":false,\"suppressed\":false,\"globalFeature\":false,\"ipV6\":false,\"actionType\":\"Z\"}],\"sharePlanInfoList\":[{\"oldSharePlanId\":\"96328\",\"newSharePlanId\":\"96328\",\"componentType\":\"VD\"}],\"productCorrelationId\":\"0\",\"userName\":\"Dick Beltran\",\"effectiveDate\":\"12/04/2019\",\"curMtnDetails\":{\"mtn\":\"7022794778\",\"min\":\"7022865093\",\"mtnEffectiveDate\":\"07/09/2019\"},\"curDeviceDetails\":{\"deviceId\":\"89148000005270943855\",\"deviceIdType\":\"ICC\",\"equipmentMfgName\":\"APL\",\"imei\":\"358648090070222\",\"phoneProductId\":\"42516\",\"phoneTypeCode\":\"P\"},\"curPricePlanDetails\":{\"pricePlanId\":\"99999\",\"bgsaID\":\"978\",\"meaCode\":\"NLG\"},\"newMtnDetails\":{\"mtn\":\"7022794778\",\"min\":\"7022865093\",\"mtnEffectiveDate\":\"07/09/2019\"},\"newDeviceDetails\":{\"deviceId\":\"89148000005270943855\",\"deviceIdType\":\"ICC\",\"equipmentMfgName\":\"APL\",\"imei\":\"358648090070222\",\"phoneProductId\":\"42516\",\"phoneTypeCode\":\"P\"},\"newPricePlanDetails\":{\"pricePlanId\":\"99999\",\"bgsaID\":\"978\",\"meaCode\":\"NLG\"},\"zipCode\":\"89117\",\"isParticipatingMtn\":false}],\"numberOfLine\":1}],\"hasManagerApproved\":false,\"userManagerApprovalEmail\":\"renuka.raja@one.verizon.com\"}");
		tracker.setOrderNumber("MB00000000");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("2");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"MB00000000"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	
	@Test
	public void test_getOrderInformationSMLineLevel_successDuplicateFeature(){
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getLineLevelOrderDataDupFeature());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778&level=1&transactionType=ARFLINELEVEL");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	// CPC Manager Approval Testing
	
	@Test
	public void test_getOrderInformationSM_success(){		
	//	Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderSharedPlandeatils());
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderdeatilsind());
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504864821&ecpdId=48242&level=1&transactionType=CPCLINELEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	} 
	
	
	@Test
	public void test_getOrderInformationSM_shared_success(){		
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderSharedPlandeatils());
	//	Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderdeatilsind());
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504774807&ecpdId=5598&level=1&transactionType=CPCLINELEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	} 
	@Test
	public void test_getOrderInformationSM_Exception(){
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenThrow(new RuntimeException("This is for testing"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504864821&ecpdId=5598&level=1&transactionType=CPCLINELEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertFalse(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSM_empty_orderList(){
		OrderDetailsResponse orderDetail = getAccountLevelOrderData();
		orderDetail.setOrderDetailsList(null);
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(orderDetail);
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504864821&ecpdId=5598&level=1&transactionType=CPCLINELEVEL");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(getManagerApprovalRequest(true));
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_makeApprovalCallForL1() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderdeatilsind());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504864821&ecpdId=5598&level=1&transactionType=CPCLINELEVEL");
		Mockito.when(cloudPropertiesConfig.getCpcmanagerApprovalUrl()).thenReturn("www.samplehost/managerAPprovalPath/");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("19-Feb-20"));
		tracker.setLevel(1);
		tracker.setApproverEmail2("Test@test.com");
		tracker.setOrderNumber("504864821");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		ManagerApprovalSMRequest request =getManagerApprovalRequestForCPC(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"MB00000000"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	@Test
	public void test_getOrderInformationSMSuspend_nullOrderDetails(){
	ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequestForSuspend(true);
	Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForSuspend(false));
	Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=suspend");
	Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
	ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
	assertNotNull(smRes);
	assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMSuspend_success(){
	ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequestForSuspend(true);
	Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForSuspend(true));
	Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=suspend");
	Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
	Mockito.doReturn(true).when(approvalService).checkForCommonTransaction(Mockito.anyString());
	ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
	assertNotNull(smRes);
	assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_makeL1ApprovalCallCommonTranSus() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForSuspend());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=suspendService");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setOrderNumber("504657574");
		tracker.setTransactionType("suspendService");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("suspendService");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"504657574"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
	}
	
	@Test
	public void test_makeL2ApprovalCallCommonTranSus() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForSuspend());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=suspendService");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(2);
		tracker.setApproverEmail2("xyz@mail.com");
		tracker.setOrderNumber("504657574");
		tracker.setTransactionType("suspendService");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("suspendService");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"504657574"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	@Test
	public void test_makeL1ApprovalCallCommonTranRes() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForRES());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=resumeService");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(1);
		tracker.setOrderNumber("504657574");
		tracker.setTransactionType("resumeService");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("resumeService");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"504657574"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
	}
	
	@Test
	public void test_makeL2ApprovalCallCommonTranRes() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForRES());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=resumeService");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date("18-JUL-19"));
		tracker.setLevel(2);
		tracker.setApproverEmail2("xyz@mail.com");
		tracker.setOrderNumber("504657574");
		tracker.setTransactionType("resumeService");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("resumeService");
		Mockito.when(cloudPropertiesConfig.getCommonTranManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("1");
		Mockito.when(smTransactionSubmitClient.submitTransactionARF(Mockito.isA(TransactionSubmitRequest.class))).thenReturn(getSubmitRes(true,"504657574"));
		Mockito.when(oneMsgClient.sendMailToManger(Mockito.any(ManagerRequest.class))).thenReturn(new NotificationResponse(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());		
	}
	
	
	
	private ManagerApprovalSMRequest getManagerApprovalRequestForCPC(boolean approvalStatus) {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("48242ALEXQA1");
		approvalRequest.setEcpdId("48242");
		approvalRequest.setTransactionType("callingPlanChg");
		approvalRequest.setOrderNumber("504864821");
		approvalRequest.setApproverEmailIds("test@verizon.com");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
	
	private OrderDetailsResponse getOrderSharedPlandeatils() {
		OrderDetailsResponse response = new OrderDetailsResponse();
		response.setConfirmationEmail("mallikarjun.eedupuganti@verizonwireless.com");
		response.setConfirmationNumber("504774807");		
		response.setEcpdId("48242");
		response.setTransType("callingPlanChange");
		response.setSubTxnType("CPCLINELEVEL");
		response.setStatus("COMPLETED");
		response.setEffectiveDate("10/01/2019");
		response.setLoggedInUserId("48242ALEXQA1");	
		
		List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
	
		SystemTxnInfo addInfo = new SystemTxnInfo();
		addInfo.setAccountNumber("581039799-00010");
	
		addInfo.setServiceNumber("740-334-9849");		
		addInfo.setSubTxnType("CPCLINELEVEL");
		addInfo.setStatus("COMPLETED");
		addInfo.setUserId("48242ALEXQA1");
		addInfo.setTxnType("callingPlanChg");
		addInfo.setAction("ADD");
		addInfo.setFinalPrice("20.00");
		addInfo.setListPrice("20.00");
		addInfo.setPhoneType("smart phone");
		addInfo.setSubscriberName("KENNY JETER");
		addInfo.setDetailType("Calling Plan");
		addInfo.setItemType("ALP");
		addInfo.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfo.setTransactionId(0);		
		addInfo.setPlanType("share plan");	
		addInfo.setPlanGroup("monthly access fee");
		addInfo.setBillingCode("90428");		
		
		SystemTxnInfo currmdn1 = new SystemTxnInfo();
		currmdn1.setAccountNumber("581039799-00010");
	
		currmdn1.setServiceNumber("740-334-9849");		
		currmdn1.setSubTxnType("CPCLINELEVEL");
		currmdn1.setStatus("FAILED");
		currmdn1.setUserId("48242ALEXQA1");
		currmdn1.setTxnType("callingPlanChg");
		currmdn1.setAction("DELETE");
		currmdn1.setFinalPrice("20.00");
		currmdn1.setListPrice("20.00");
		currmdn1.setPhoneType("smart phone");
		currmdn1.setSubscriberName("KENNY JETER");
		currmdn1.setDetailType("Calling Plan");
		currmdn1.setItemType("Data change");
		currmdn1.setItemName(" Business Unlimited Talk & Text 80GB");
		currmdn1.setTransactionId(0);		
		currmdn1.setPlanType("share plan");	
		currmdn1.setPlanGroup("monthly access fee");
		currmdn1.setBillingCode("90428");
		
		SystemTxnInfo addInfoarf = new SystemTxnInfo();
		addInfoarf.setAccountNumber("581039799-00010");
	
		addInfoarf.setServiceNumber("740-334-9849");		
		addInfoarf.setSubTxnType("CPCLINELEVEL");
		addInfoarf.setStatus("FAILED");
		addInfoarf.setUserId("48242ALEXQA1");
		addInfoarf.setTxnType("callingPlanChg");
		addInfoarf.setAction("AUTOADD");
		addInfoarf.setFinalPrice("0.00");
		addInfoarf.setListPrice("0.00");
		addInfoarf.setPhoneType("smart phone");
		addInfoarf.setSubscriberName("KENNY JETER");
		addInfoarf.setDetailType("Calling Plan");
		addInfoarf.setItemType("ALP");
		addInfoarf.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfoarf.setTransactionId(0);		
		addInfoarf.setPlanType("share plan");	
	//	addInfoarf.setPlanGroup("monthly access fee");
		addInfoarf.setPlanGroup("Monthly Access|$69.99--Monthly Home Airtime (in minutes)|Unlimited--Additional Peak Minutes|$0.25");
		addInfoarf.setBillingCode("90428");		
		
		
		SystemTxnInfo addInfo1 = new SystemTxnInfo();
		addInfo1.setAccountNumber("581039799-00010");
	
		addInfo1.setServiceNumber("740-334-9850");		
		addInfo1.setSubTxnType("CPCLINELEVEL");
		addInfo1.setStatus("FAILED");
		addInfo1.setUserId("48242ALEXQA1");
		addInfo1.setTxnType("callingPlanChg");
		addInfo1.setAction("ADD");
		addInfo1.setFinalPrice("20.00");
		addInfo1.setListPrice("20.00");
		addInfo1.setPhoneType("smart phone");
		addInfo1.setSubscriberName("KENNY CLEMENS");
		addInfo1.setDetailType("Calling Plan");
		addInfo1.setItemType("ALP");
		addInfo1.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfo1.setTransactionId(0);		
		addInfo1.setPlanType("share plan");	
		addInfo1.setPlanGroup("monthly access fee");
		addInfo1.setBillingCode("90428");		
		
		SystemTxnInfo addInfo1arf = new SystemTxnInfo();
		addInfo1arf.setAccountNumber("581039799-00010");
	
		addInfo1arf.setServiceNumber("740-334-9850");		
		addInfo1arf.setSubTxnType("CPCLINELEVEL");
		addInfo1arf.setStatus("FAILED");
		addInfo1arf.setUserId("48242ALEXQA1");
		addInfo1arf.setTxnType("callingPlanChg");
		addInfo1arf.setAction("AUTOADD");
		addInfo1arf.setFinalPrice("20.00");
		addInfo1arf.setListPrice("20.00");
		addInfo1arf.setPhoneType("smart phone");
		addInfo1arf.setSubscriberName("KENNY CLEMENS");
		addInfo1arf.setDetailType("Calling Plan");
		addInfo1arf.setItemType("ALP");
		addInfo1arf.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfo1arf.setTransactionId(0);		
		addInfo1arf.setPlanType("share plan");	
		addInfo1arf.setPlanGroup("monthly access fee");
		addInfo1arf.setBillingCode("90428");		
		
		SystemTxnInfo addInfo2 = new SystemTxnInfo();
		addInfo2.setAccountNumber("581039799-00010");
	
		addInfo2.setServiceNumber("740-334-9849");		
		addInfo2.setSubTxnType("CPCLINELEVEL");
		addInfo2.setStatus("FAILED");
		addInfo2.setUserId("48242ALEXQA1");
		addInfo2.setTxnType("callingPlanChg");
		addInfo2.setAction("ADD");
		addInfo2.setFinalPrice("60.00");
		addInfo2.setListPrice("60.00");
		addInfo2.setPhoneType("smart phone");
		addInfo2.setSubscriberName("RYAN HENDERSON");
		addInfo2.setDetailType("Calling Plan");
		addInfo2.setItemType("ALP");
		addInfo2.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfo2.setTransactionId(0);		
		addInfo2.setPlanType("share plan");
		addInfo2.setPlanGroup("monthly access fee");
		addInfo2.setBillingCode("90428");
		
		SystemTxnInfo addInfo3 = new SystemTxnInfo();
		addInfo3.setAccountNumber("581039799-00010");
	
		addInfo3.setServiceNumber("740-334-9849");		
		addInfo3.setSubTxnType("CPCLINELEVEL");
		addInfo3.setStatus("FAILED");
		addInfo3.setUserId("48242ALEXQA1");
		addInfo3.setTxnType("callingPlanChg");
		addInfo3.setAction("AUTODELETE");
		addInfo3.setFinalPrice("10.00");
		addInfo3.setListPrice("10.00");
		addInfo3.setPhoneType("smart phone");
		addInfo3.setSubscriberName("KENNY CLEMENS");
		addInfo3.setDetailType("Calling Plan");
		addInfo3.setItemType("ALP");
		addInfo3.setItemName("The new Verizon Plan Unlimited");
		addInfo3.setTransactionId(0);		
		addInfo3.setPlanType("share plan");
		addInfo3.setPlanGroup("monthly access fee");
		addInfo3.setBillingCode("98127");		
		
		
		SystemTxnInfo addInfo4 = new SystemTxnInfo();
		addInfo4.setAccountNumber("581039799-00010");
	
		addInfo4.setServiceNumber("740-334-9000");		
		addInfo4.setSubTxnType("CPCLINELEVEL");
		addInfo4.setStatus("FAILED");
		addInfo4.setUserId("48242ALEXQA1");
		addInfo4.setTxnType("callingPlanChg");
		addInfo4.setAction("ADD");
		addInfo4.setFinalPrice("15.00");
		addInfo4.setListPrice("15.00");
		addInfo4.setPhoneType("tablet");
		addInfo4.setSubscriberName("KENNY NICKS");
		addInfo4.setDetailType("Calling Plan");
		addInfo4.setItemType("ALP");
		addInfo4.setItemName("Small Business Unlimited Talk & Text 80GB");
		addInfo4.setTransactionId(0);		
		addInfo4.setPlanType("share plan");	
		addInfo4.setPlanGroup("monthly access fee");
		addInfo4.setBillingCode("90428");
		
		SystemTxnInfo addInfofeature = new SystemTxnInfo();
		addInfofeature.setAccountNumber("581039799-00010");
	
		addInfofeature.setServiceNumber("740-334-9001");		
		addInfofeature.setSubTxnType("CPCLINELEVEL");
		addInfofeature.setStatus("FAILED");
		addInfofeature.setUserId("48242ALEXQA1");
		addInfofeature.setTxnType("callingPlanChg");
		addInfofeature.setAction("ADD");
		addInfofeature.setFinalPrice("18.00");
		addInfofeature.setListPrice("18.00");
		addInfofeature.setPhoneType("smart phone");
		addInfofeature.setSubscriberName("KENNY JETER");
		addInfofeature.setDetailType("Features");
		addInfofeature.setItemType("ALP");
		addInfofeature.setItemName("HD VIDEO OPTIMIZATION");
		addInfofeature.setTransactionId(0);		
		addInfofeature.setPlanType("share plan");	
		addInfofeature.setPlanGroup("monthly access fee");
		addInfofeature.setBillingCode("90428");	
		
		SystemTxnInfo addInfo5 = new SystemTxnInfo();
		addInfo5.setAccountNumber("581039799-00010");
	
		addInfo5.setServiceNumber("740-334-9002");		
		addInfo5.setSubTxnType("CPCLINELEVEL");
		addInfo5.setStatus("FAILED");
		addInfo5.setUserId("48242ALEXQA1");
		addInfo5.setTxnType("callingPlanChg");
		addInfo5.setAction("ADD");
		addInfo5.setFinalPrice("15.00");
		addInfo5.setListPrice("15.00");
		addInfo5.setPhoneType("tablet");
		addInfo5.setSubscriberName("KENNY NICKS");
		addInfo5.setDetailType("Features");
		addInfo5.setItemType("ALP");
		addInfo5.setItemName("HD VIDEO OPTIMIZATION");
		addInfo5.setTransactionId(0);		
		addInfo5.setPlanType("share plan");	
		addInfo5.setPlanGroup("monthly access fee");
		addInfo5.setBillingCode("90428");
		
		SystemTxnInfo addInfo6 = new SystemTxnInfo();
		addInfo6.setAccountNumber("581039799-00010");
	
		addInfo6.setServiceNumber("740-334-9003");		
		addInfo6.setSubTxnType("CPCLINELEVEL");
		addInfo6.setStatus("FAILED");
		addInfo6.setUserId("48242ALEXQA1");
		addInfo6.setTxnType("callingPlanChg");
		addInfo6.setAction("AUTOADD");
		addInfo6.setFinalPrice("15.00");
		addInfo6.setListPrice("15.00");
		addInfo6.setPhoneType("tablet");
		addInfo6.setSubscriberName("KENNY NICKS");
		addInfo6.setDetailType("Features");
		addInfo6.setItemType("ALP");
		addInfo6.setItemName("DATA ROAM USA/CANADA B2B");
		addInfo6.setTransactionId(0);		
		addInfo6.setPlanType("share plan");	
		addInfo6.setPlanGroup("monthly access fee");
		addInfo6.setBillingCode("90428");
		
		SystemTxnInfo addInfo7 = new SystemTxnInfo();
		addInfo7.setAccountNumber("581039799-00010");
	
		addInfo7.setServiceNumber("740-334-9004");		
		addInfo7.setSubTxnType("CPCLINELEVEL");
		addInfo7.setStatus("FAILED");
		addInfo7.setUserId("48242ALEXQA1");
		addInfo7.setTxnType("callingPlanChg");
		addInfo7.setAction("DELETE");
		addInfo7.setFinalPrice("60.00");
		addInfo7.setListPrice("60.00");
		addInfo7.setPhoneType("tablet");
		addInfo7.setSubscriberName("KENNY NICKS");
		addInfo7.setDetailType("Features");
		addInfo7.setItemType("Data change");
		addInfo7.setItemName("DATA ROAM USA/CANADA B2B");
		addInfo7.setTransactionId(0);		
		addInfo7.setPlanType("share plan");	
		addInfo7.setPlanGroup("monthly access fee");
		addInfo7.setBillingCode("90428");

		orderDetailsList.add(addInfo);
		orderDetailsList.add(addInfo1);
		orderDetailsList.add(addInfo2);
		orderDetailsList.add(addInfo3);	
		orderDetailsList.add(addInfo4);			
		orderDetailsList.add(addInfo5);
		orderDetailsList.add(addInfo6);
		orderDetailsList.add(addInfo7);
		orderDetailsList.add(addInfoarf);
		orderDetailsList.add(addInfofeature);
		orderDetailsList.add(currmdn1);	
		
		response.setOrderDetailsList(orderDetailsList);
		return response;
}	
	
	
    private OrderDetailsResponse getOrderdeatilsind()	
	{		
		OrderDetailsResponse response = new OrderDetailsResponse();
		response.setConfirmationEmail("mallikarjun.eedupuganti@verizonwireless.com");
		response.setConfirmationNumber("504864821");		
		response.setEcpdId("5598");
		response.setTransType("callingPlanChange");
		response.setSubTxnType("CPCLINELEVEL");
		response.setStatus("COMPLETED");
		response.setEffectiveDate("02/10/2020");
		response.setLoggedInUserId("5598SELE28QA1");	
		
		List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
		SystemTxnInfo addInfo = new SystemTxnInfo();    	    
    	addInfo.setServiceNumber("985-966-6744");
    	addInfo.setItemName("4G Data Transport");
    	addInfo.setAccountNumber("542314782-00001");
    	addInfo.setStatus("COMPLETED");
		addInfo.setSubTxnType("CPCLINELEVEL");
		addInfo.setTxnType("callingPlanChg");
		addInfo.setAction("AUTOADD");
		addInfo.setListPrice("0.00");
		addInfo.setFinalPrice("0.00");
		addInfo.setSubscriberName("ETHAN WRIGHT");
		addInfo.setDetailType("Features");
		addInfo.setItemType("SFO");
		addInfo.setTransactionId(0);		
	    addInfo.setPhoneType("PDA/SmartPhones");
		addInfo.setBillingCode("75622");      
		
		SystemTxnInfo addInfo1 = new SystemTxnInfo();    	    
    	addInfo1.setServiceNumber("985-966-6744");
    	addInfo1.setItemName("4G Mobile Hotspot Provisioning");
    	addInfo1.setAccountNumber("542314782-00001");
    	addInfo1.setTransactionId(0);
    	addInfo1.setStatus("COMPLETED");
		addInfo1.setSubTxnType("CPCLINELEVEL");
		addInfo1.setTxnType("callingPlanChg");
		addInfo1.setAction("AUTODELETE");
		addInfo1.setFinalPrice("0.00");
		addInfo1.setListPrice("0.00");		
		addInfo1.setSubscriberName("ETHAN WRIGHT");
		addInfo1.setDetailType("Features");
		addInfo1.setItemType("SFO");    			   		
	    addInfo1.setPhoneType("PDA/SmartPhones");
		addInfo1.setBillingCode("76404"); 		
		
		SystemTxnInfo addInfo2 = new SystemTxnInfo();    	    
		addInfo2.setServiceNumber("985-966-6744");
		addInfo2.setItemName("4g Provisioning");
		addInfo2.setAccountNumber("542314782-00001");
		addInfo2.setTransactionId(0);
		addInfo2.setStatus("COMPLETED");
		addInfo2.setSubTxnType("CPCLINELEVEL");
		addInfo2.setUserId("5598SELE28QA1");
		addInfo2.setTxnType("callingPlanChg");
		addInfo2.setAction("AUTODELETE");
		addInfo2.setFinalPrice("0.00");
		addInfo2.setListPrice("0.00");		
		addInfo2.setSubscriberName("ETHAN WRIGHT");
		addInfo2.setDetailType("Features");
		addInfo2.setItemType("SFO");
		addInfo2.setPhoneType("PDA/SmartPhones");
		addInfo2.setBillingCode("77556"); 		
		
		SystemTxnInfo addInfo3 = new SystemTxnInfo();    	    
		addInfo3.setServiceNumber("985-966-6744");
		addInfo3.setItemName("Corporate Email");
		addInfo3.setAccountNumber("542314782-00001");    			
		addInfo3.setSubTxnType("CPCLINELEVEL");
		addInfo3.setUserId("5598SELE28QA1");
		addInfo3.setTxnType("callingPlanChg");
		addInfo3.setAction("AUTOADD");
		addInfo3.setFinalPrice("0.00");
		addInfo3.setListPrice("0.00");		
		addInfo3.setSubscriberName("ETHAN WRIGHT");
		addInfo3.setDetailType("Features");
		addInfo3.setItemType("SFO");    			   			
		addInfo3.setPhoneType("PDA/SmartPhones");
		addInfo3.setBillingCode("76285"); 
			
		SystemTxnInfo addInfo4 = new SystemTxnInfo();    	    
		addInfo4.setServiceNumber("985-966-6744");
		addInfo4.setItemName("Data Provision Alp");
		addInfo4.setAccountNumber("542314782-00001");    			
		addInfo4.setSubTxnType("CPCLINELEVEL");
		addInfo4.setUserId("5598SELE28QA1");
		addInfo4.setTxnType("callingPlanChg");
		addInfo4.setAction("AUTODELETE");
		addInfo4.setFinalPrice("0.00");
		addInfo4.setListPrice("0.00");
		addInfo4.setSubscriberName("ETHAN WRIGHT");
		addInfo4.setDetailType("Features");
		addInfo4.setItemType("SFO");
		addInfo4.setPhoneType("PDA/SmartPhones");
		addInfo4.setBillingCode("77583");
    
		SystemTxnInfo addInfo5 = new SystemTxnInfo();    	    
		addInfo5.setServiceNumber("985-966-6744");
		addInfo5.setItemName("Data Roaming USA & Canada B2B");
		addInfo5.setAccountNumber("542314782-00001");    			
		addInfo5.setSubTxnType("CPCLINELEVEL");
		addInfo5.setUserId("5598SELE28QA1");
		addInfo5.setTxnType("callingPlanChg");
		addInfo5.setAction("AUTOADD");
		addInfo5.setFinalPrice("0.00");
		addInfo5.setListPrice("0.00");
		addInfo5.setSubscriberName("ETHAN WRIGHT");
		addInfo5.setDetailType("Features");
		addInfo5.setItemType("SFO");
		addInfo5.setPhoneType("PDA/SmartPhones");
		addInfo5.setBillingCode("78927");		
		
		SystemTxnInfo addInfo6 = new SystemTxnInfo();    	    
		addInfo6.setServiceNumber("985-966-6744");
		addInfo6.setItemName("Email Access");
		addInfo6.setAccountNumber("542314782-00001");    			
		addInfo6.setSubTxnType("CPCLINELEVEL");
		addInfo6.setUserId("5598SELE28QA1");
		addInfo6.setTxnType("callingPlanChg");
		addInfo6.setAction("AUTODELETE");
		addInfo6.setFinalPrice("0.0");
		addInfo6.setListPrice("0.0");
		addInfo6.setSubscriberName("ETHAN WRIGHT");    			
		addInfo6.setItemType("SFO");
		addInfo6.setDetailType("Features");
		addInfo6.setPhoneType("PDA/SmartPhones");
		addInfo6.setBillingCode("77568"); 		
		
		SystemTxnInfo addInfo7 = new SystemTxnInfo();    	    
		addInfo7.setServiceNumber("985-966-6744");
		addInfo7.setItemName("Email Trigger Alp");
		addInfo7.setAccountNumber("542314782-00001");    			
		addInfo7.setSubTxnType("CPCLINELEVEL");
		addInfo7.setUserId("5598SELE28QA1");
		addInfo7.setTxnType("callingPlanChg");
		addInfo7.setAction("AUTODELETE");
		addInfo7.setFinalPrice("0.00");
		addInfo7.setListPrice("0.00");
		addInfo7.setPhoneType("smart phone");
		addInfo7.setSubscriberName("ETHAN WRIGHT");
		addInfo7.setDetailType("Features");
		addInfo7.setItemType("SFO");
		addInfo7.setPhoneType("PDA/SmartPhones");
		addInfo7.setBillingCode("77581");
		
		SystemTxnInfo addInfo8 = new SystemTxnInfo();    	    
		addInfo8.setServiceNumber("985-966-6744");
		addInfo8.setItemName("Include Mexico & Canada in your domestic plan");
		addInfo8.setAccountNumber("542314782-00001");    			
		addInfo8.setSubTxnType("CPCLINELEVEL");
		addInfo8.setUserId("5598SELE28QA1");
		addInfo8.setTxnType("callingPlanChg");
		addInfo8.setAction("AUTODELETE");
		addInfo8.setFinalPrice("0.00");
		addInfo8.setListPrice("0.00");
		addInfo8.setSubscriberName("ETHAN WRIGHT");
		addInfo8.setDetailType("Features");
		addInfo8.setItemType("SFO");
		addInfo8.setPhoneType("PDA/SmartPhones");
		addInfo8.setBillingCode("84876"); 	

		SystemTxnInfo addInfo9 = new SystemTxnInfo();    	    
		addInfo9.setServiceNumber("985-966-6744");
		addInfo9.setItemName("Nationwide Talk");
		addInfo9.setAccountNumber("542314782-00001");    			
		addInfo9.setSubTxnType("CPCLINELEVEL");
		addInfo9.setUserId("5598SELE28QA1");
		addInfo9.setTxnType("callingPlanChg");
		addInfo9.setAction("ADD");
		addInfo9.setFinalPrice("0.00");
		addInfo9.setListPrice("0.00");
		addInfo9.setSubscriberName("ETHAN WRIGHT");
		addInfo9.setDetailType("Details");
		addInfo9.setPhoneType("PDA/SmartPhones");
		addInfo9.setBillingCode("84876");
		addInfo9.setPlanGroup("Monthly Access|$69.99--Monthly Home Airtime (in minutes)|Unlimited--Additional Peak Minutes|$0.25");
		
		SystemTxnInfo addInfo10 = new SystemTxnInfo();    	    
		addInfo10.setServiceNumber("985-966-6744");
		addInfo10.setItemName("Nationwide Talk - Unlimited");
		addInfo10.setAccountNumber("542314782-00001");    			
		addInfo10.setSubTxnType("CPCLINELEVEL");
		addInfo10.setUserId("5598SELE28QA1");
		addInfo10.setTxnType("callingPlanChg");
		addInfo10.setAction("ADD");
		addInfo10.setFinalPrice("69.99");
		addInfo10.setListPrice("69.99");
		addInfo10.setSubscriberName("ETHAN WRIGHT");
		addInfo10.setDetailType("Calling Plan");
		addInfo10.setItemType("LLP");
		addInfo10.setPhoneType("PDA/SmartPhones");
		addInfo10.setBillingCode("83233");
		addInfo10.setPlanGroup("Individual");		

		SystemTxnInfo addInfo11 = new SystemTxnInfo();    	    
		addInfo11.setServiceNumber("985-966-6744");
		addInfo11.setItemName("The new Verizon Plan");
		addInfo11.setAccountNumber("542314782-00001");    			
		addInfo11.setSubTxnType("CPCLINELEVEL");
		addInfo11.setUserId("5598SELE28QA1");
		addInfo11.setTxnType("callingPlanChg");
		addInfo11.setAction("DELETE");
		addInfo11.setFinalPrice("0.00");
		addInfo11.setListPrice("0.00");
		addInfo11.setSubscriberName("ETHAN WRIGHT");
		addInfo11.setDetailType("Details");
		addInfo11.setItemType("LLP");
		addInfo11.setPhoneType("PDA/SmartPhones");		
		addInfo11.setPlanGroup("Monthly Access|$20.0--Monthly Home Airtime (in minutes)|Unlimited Talk, Text & Data--Additional Peak Minutes|$0.25");
		
		SystemTxnInfo addInfo12 = new SystemTxnInfo();    	    
		addInfo12.setServiceNumber("985-966-6744");
		addInfo12.setItemName("The new Verizon Plan Unlimited");
		addInfo12.setAccountNumber("542314782-00001");    			
		addInfo12.setSubTxnType("CPCLINELEVEL");
		addInfo12.setUserId("5598SELE28QA1");
		addInfo12.setTxnType("callingPlanChg");
		addInfo12.setAction("DELETE");
		addInfo12.setFinalPrice("0.00");
		addInfo12.setListPrice("0.00");
		addInfo12.setSubscriberName("ETHAN WRIGHT");
		addInfo12.setDetailType("Calling Plan");
		addInfo12.setItemType("ALP");
		addInfo12.setPhoneType("PDA/SmartPhones");		
		addInfo12.setPlanGroup("Shared");
		addInfo12.setBillingCode("98127");
		
		SystemTxnInfo addInfo13 = new SystemTxnInfo();    	    
		addInfo13.setServiceNumber("985-966-6744");
		addInfo13.setItemName("International Messages While in US");
		addInfo13.setAccountNumber("542314782-00001");    			
		addInfo13.setSubTxnType("CPCLINELEVEL");
		addInfo13.setUserId("5598SELE28QA1");
		addInfo13.setTxnType("callingPlanChg");
		addInfo13.setAction("AUTODELETE");
		addInfo13.setFinalPrice("0.00");
		addInfo13.setListPrice("0.00");
		addInfo13.setSubscriberName("ETHAN WRIGHT");
		addInfo13.setDetailType("Features");
		addInfo13.setItemType("SFO");
		addInfo13.setPhoneType("PDA/SmartPhones");
		addInfo13.setBillingCode("80148"); 
		
		SystemTxnInfo addInfo14 = new SystemTxnInfo();    	    
		addInfo14.setServiceNumber("985-966-6744");
		addInfo14.setItemName("Intl Travel Voice & Data Paygo");
		addInfo14.setAccountNumber("542314782-00001");    			
		addInfo14.setSubTxnType("CPCLINELEVEL");
		addInfo14.setUserId("5598SELE28QA1");
		addInfo14.setTxnType("callingPlanChg");
		addInfo14.setAction("AUTODELETE");
		addInfo14.setFinalPrice("0.00");
		addInfo14.setListPrice("0.00");
		addInfo14.setSubscriberName("ETHAN WRIGHT");
		addInfo14.setDetailType("Features");
		addInfo14.setItemType("SPO");
		addInfo14.setPhoneType("PDA/SmartPhones");
		addInfo14.setBillingCode("384"); 
		
		SystemTxnInfo addInfo15 = new SystemTxnInfo();    	    
		addInfo15.setServiceNumber("985-966-6744");
		addInfo15.setItemName("Mobile Hotspot Trigger");
		addInfo15.setAccountNumber("542314782-00001");    			
		addInfo15.setSubTxnType("CPCLINELEVEL");
		addInfo15.setUserId("5598SELE28QA1");
		addInfo15.setTxnType("callingPlanChg");
		addInfo15.setAction("AUTODELETE");
		addInfo15.setFinalPrice("0.00");
		addInfo15.setListPrice("0.00");
		addInfo15.setSubscriberName("ETHAN WRIGHT");
		addInfo15.setDetailType("Features");
		addInfo15.setItemType("SFO");
		addInfo15.setPhoneType("PDA/SmartPhones");
		addInfo15.setBillingCode("77249"); 
		
		SystemTxnInfo addInfo16 = new SystemTxnInfo();    	    
		addInfo16.setServiceNumber("985-966-6744");
		addInfo16.setItemName("Nights & Weekends");
		addInfo16.setAccountNumber("542314782-00001");    			
		addInfo16.setSubTxnType("CPCLINELEVEL");
		addInfo16.setUserId("5598SELE28QA1");
		addInfo16.setTxnType("callingPlanChg");
		addInfo16.setAction("AUTOADD");
		addInfo16.setFinalPrice("0.00");
		addInfo16.setListPrice("0.00");
		addInfo16.setSubscriberName("ETHAN WRIGHT");
		addInfo16.setDetailType("Features");
		addInfo16.setItemType("SFO");
		addInfo16.setPhoneType("PDA/SmartPhones");
		addInfo16.setBillingCode("72709"); 
		
		orderDetailsList.add(addInfo);
		orderDetailsList.add(addInfo1);
		orderDetailsList.add(addInfo2);	
		orderDetailsList.add(addInfo3);
		orderDetailsList.add(addInfo4);
		orderDetailsList.add(addInfo5);
		orderDetailsList.add(addInfo6);
		orderDetailsList.add(addInfo7);
		orderDetailsList.add(addInfo8);
		orderDetailsList.add(addInfo9);
		orderDetailsList.add(addInfo10);
		orderDetailsList.add(addInfo11);
		orderDetailsList.add(addInfo12);
		orderDetailsList.add(addInfo13);
		orderDetailsList.add(addInfo14);
		orderDetailsList.add(addInfo15);
		orderDetailsList.add(addInfo16);

		response.setOrderDetailsList(orderDetailsList);
		return response; 
		
	} 
   

	private TransactionSubmitResponse getSubmitRes(boolean success,String confirmNo) {
		TransactionSubmitResponse res = new TransactionSubmitResponse();
		res.setConfirmNbr(confirmNo);
		res.setNeedEmailTrigger("N");
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setSuccess(success);
		res.setServiceStatus(serviceStatus);
		return res;
	}
	private ManagerApprovalSMRequest getManagerApprovalRequest(boolean approvalStatus) {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("6778ADMBT");
		approvalRequest.setEcpdId("6778");
		approvalRequest.setTransactionType("EPBNAO");
		approvalRequest.setOrderNumber("MB00000000");
		approvalRequest.setApproverEmailIds("test@verizon.com");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
	
	private OrderDetailsResponse getLineLevelOrderDataDupFeature() {
		String s = "{\"orderDetailsList\":[{\"serviceNumber\":\"630-280-4531\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-280-8929\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-716-1265\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-716-1267\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-716-1424\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-716-1434\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-878-2269\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-878-8053\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-878-9422\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"},{\"serviceNumber\":\"630-888-8580\",\"itemName\":\"Data Boost\",\"transactionId\":0,\"accountNumber\":\"886003269-00001\",\"status\":\"COMPLETED\",\"finalPrice\":\"15.00\",\"txnType\":\"addRemoveFeature\",\"billingCode\":\"681\",\"userId\":\"1034669TMPQA1\",\"listPrice\":\"15.00\",\"ecpdId\":\"1034669\",\"itemType\":\"SPO\",\"effectiveDate\":\"05/05/2020\",\"detailType\":\"Features\",\"action\":\"ADD\",\"subTxnType\":\"ARFACCOUNTLEVEL\"}],\"confirmationEmail\":\"nirupama.krishnaiah@verizonwireless.com,sindhu.atluri@verizonwireless.com\",\"transType\":\"addRemoveFeature\",\"status\":\"COMPLETED\",\"subTxnType\":\"ARFACCOUNTLEVEL\",\"effectiveDate\":\"05/05/2020\",\"loggedInUserId\":\"1034669TMPQA1\",\"ecpdId\":\"1034669\",\"confirmationNumber\":\"504957329\"}";
		OrderDetailsResponse response = new Gson().fromJson(s, OrderDetailsResponse.class);
		return response;
	}
	
	private OrderDetailsResponse getLineLevelOrderData() {
		OrderDetailsResponse response = new OrderDetailsResponse();
		response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
		response.setConfirmationNumber("MB00000000");
		response.setConfirmEmailStatus("COMPLETED");
		response.setEcpdId("5598");
		response.setTransType("addORRemoveFeatures");
		response.setSubTxnType("ARFLINELEVEL");
		response.setStatus("COMPLETED");
		response.setEffectiveDate("12/9/2020");
		List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
		
		SystemTxnInfo addInfo = new SystemTxnInfo();
		addInfo.setAccountNumber("724738686");
		addInfo.setItemName("IPHONE");
		addInfo.setSubTxnType("ARFACCOUNTLEVEL");
		addInfo.setStatus("FAILED");
		addInfo.setUserId("5598AD");
		addInfo.setTxnType("ARF");
		addInfo.setAction("ADD");
		addInfo.setFinalPrice("12.0");
		addInfo.setListPrice("0.0");
		
		SystemTxnInfo addInfo1 = new SystemTxnInfo();
		addInfo1.setAccountNumber("724738686");
		addInfo1.setItemName("VZ Navigator\\u003csup\\u003esm\\u003c/sup\\u003e with Real\\u0026ndash;Time Traffic");
		addInfo1.setSubTxnType("ARFACCOUNTLEVEL");
		addInfo1.setStatus("FAILED");
		addInfo1.setUserId("5598AD");
		addInfo1.setTxnType("ARF");
		addInfo1.setAction("ADD");
		addInfo1.setFinalPrice("12.0");
		addInfo1.setListPrice("0.0");
		
		SystemTxnInfo autoaddInfo = new SystemTxnInfo();
		autoaddInfo.setAccountNumber("724738686");
		autoaddInfo.setItemName("IPHONE");
		autoaddInfo.setSubTxnType("ARFACCOUNTLEVEL");
		autoaddInfo.setStatus("FAILED");
		autoaddInfo.setUserId("5598AD");
		autoaddInfo.setTxnType("ARF");
		autoaddInfo.setAction("AUTOADD");
		autoaddInfo.setFinalPrice("700.0");
		autoaddInfo.setListPrice("692.0");
		
		SystemTxnInfo removedInfo = new SystemTxnInfo();
		removedInfo.setAccountNumber("724738686");
		removedInfo.setItemName("IPHONE");
		removedInfo.setSubTxnType("ARFACCOUNTLEVEL");
		removedInfo.setStatus("FAILED");
		removedInfo.setUserId("5598AD");
		removedInfo.setTxnType("ARF");
		removedInfo.setAction("DELETE");
		removedInfo.setFinalPrice("12.0");
		removedInfo.setListPrice("0.0");
		
		SystemTxnInfo removedInfo1 = new SystemTxnInfo();
		removedInfo1.setAccountNumber("724738686");
		removedInfo1.setItemName("International Travel 100 talk, text &Data-Expires after 1 month");
		removedInfo1.setSubTxnType("ARFACCOUNTLEVEL");
		removedInfo1.setStatus("FAILED");
		removedInfo1.setUserId("5598AD");
		removedInfo1.setTxnType("ARF");
		removedInfo1.setAction("DELETE");
		removedInfo1.setFinalPrice("12.0");
		removedInfo1.setListPrice("0.0");
		
		SystemTxnInfo autodelete = new SystemTxnInfo();
		autodelete.setAccountNumber("724738686");
		autodelete.setItemName("IPHONE");
		autodelete.setSubTxnType("ARFACCOUNTLEVEL");
		autodelete.setStatus("FAILED");
		autodelete.setUserId("5598AD");
		autodelete.setTxnType("ARF");
		autodelete.setAction("AUTODELETE");
		autodelete.setFinalPrice("700.0");
		autodelete.setListPrice("692.0");
		
		orderDetailsList.add(autodelete);
		orderDetailsList.add(addInfo1);
		orderDetailsList.add(autoaddInfo);
		orderDetailsList.add(addInfo);
		orderDetailsList.add(removedInfo);
		orderDetailsList.add(removedInfo1);
		
		response.setOrderDetailsList(orderDetailsList );
		return response;
	}
	
	private OrderDetailsResponse getAccountLevelOrderData() {
		OrderDetailsResponse response = new OrderDetailsResponse();
		response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
		response.setConfirmationNumber("MB00000000");
		response.setConfirmEmailStatus("COMPLETED");
		response.setEcpdId("5598");
		response.setTransType("addORRemoveFeatures");
		response.setSubTxnType("ARFLINELEVEL");
		response.setStatus("COMPLETED");
		response.setEffectiveDate("12/9/2020");
		List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
		
		SystemTxnInfo addInfo = new SystemTxnInfo();
		addInfo.setAccountNumber("724738686");
		addInfo.setItemName("IPHONE");
		addInfo.setSubTxnType("ARFACCOUNTLEVEL");
		addInfo.setStatus("FAILED");
		addInfo.setUserId("5598AD");
		addInfo.setTxnType("ARF");
		addInfo.setItemType("SPO");
		addInfo.setAction("ADD");
		addInfo.setFinalPrice("12.0");
		addInfo.setListPrice("0.0");
		
		SystemTxnInfo autoaddInfo = new SystemTxnInfo();
		autoaddInfo.setAccountNumber("724738686");
		autoaddInfo.setItemName("IPHONE");
		autoaddInfo.setSubTxnType("ARFACCOUNTLEVEL");
		autoaddInfo.setStatus("FAILED");
		autoaddInfo.setUserId("5598AD");
		autoaddInfo.setTxnType("ARF");
		autoaddInfo.setItemType("SPO");
		autoaddInfo.setAction("AUTOADD");
		autoaddInfo.setFinalPrice("700.0");
		autoaddInfo.setListPrice("692.0");
		
		SystemTxnInfo removedInfo = new SystemTxnInfo();
		removedInfo.setAccountNumber("724738686");
		removedInfo.setItemName("IPHONE");
		removedInfo.setSubTxnType("ARFACCOUNTLEVEL");
		removedInfo.setStatus("FAILED");
		removedInfo.setUserId("5598AD");
		removedInfo.setTxnType("ARF");
		removedInfo.setAction("DELETE");
		removedInfo.setFinalPrice("12.0");
		removedInfo.setItemType("SPO");
		removedInfo.setListPrice("0.0");
		
		SystemTxnInfo autodelete = new SystemTxnInfo();
		autodelete.setAccountNumber("724738686");
		autodelete.setItemName("IPHONE");
		autodelete.setSubTxnType("ARFACCOUNTLEVEL");
		autodelete.setStatus("FAILED");
		autodelete.setUserId("5598AD");
		autodelete.setTxnType("ARF");
		autodelete.setAction("AUTODELETE");
		autodelete.setFinalPrice("700.0");
		autodelete.setItemType("SPO");
		autodelete.setListPrice("692.0");
		
		orderDetailsList.add(autodelete);
		orderDetailsList.add(autoaddInfo);
		orderDetailsList.add(addInfo);
		orderDetailsList.add(removedInfo);
		
		response.setOrderDetailsList(orderDetailsList );
		return response;
	}
	
	private OrderDetailsResponse getOrderDataForCWUI(boolean isDataPresent) throws IOException {
		OrderDetailsResponse response = new OrderDetailsResponse();
		if (isDataPresent) {
			String orderDetails = IOUtils.toString(getClass().getClassLoader().getResource("orderDetailsCWUI.json"));
			response = gson.fromJson(orderDetails, OrderDetailsResponse.class);
		} else {
			List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
			response.setOrderDetailsList(orderDetailsList);
		}
		return response;
	}
	
	private OrderDetailsResponse getOrderDataForCCC(boolean orderDetail) {
		OrderDetailsResponse response = new OrderDetailsResponse();

		if(orderDetail) {
		response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
		response.setConfirmationNumber("MB00000000");
		response.setConfirmEmailStatus("COMPLETED");
		response.setEcpdId("5598");
		response.setTransType("changeCostCenter");
		response.setSubTxnType("CCC");
		response.setStatus("COMPLETED");
		response.setEffectiveDate("12/9/2020");
		List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
		
		SystemTxnInfo addInfo = new SystemTxnInfo();
		addInfo.setAccountNumber("724738686");
		addInfo.setServiceNumber("9999999999");
		addInfo.setItemName("IPHONE");
		addInfo.setSubscriberName("John");
		addInfo.setSubTxnType("CCC");
		addInfo.setStatus("COMPLETED");
		addInfo.setUserId("5598AD");
		addInfo.setTxnType("changeCostCenter");
		addInfo.setAction("ADD");
		addInfo.setFinalPrice("0.0");
		addInfo.setListPrice("0.0");
		
		SystemTxnInfo autodelete = new SystemTxnInfo();
		autodelete.setAccountNumber("724738686");
		autodelete.setServiceNumber("9999999999");
		autodelete.setItemName("IPHONE");
		autodelete.setSubTxnType("CCC");
		autodelete.setStatus("COMPLETED");
		autodelete.setUserId("5598AD");
		autodelete.setTxnType("changeCostCenter");
		autodelete.setAction("AUTODELETE");
		autodelete.setFinalPrice("0.0");
		autodelete.setListPrice("0.0");
		
		
		orderDetailsList.add(autodelete);
		orderDetailsList.add(addInfo);
		
		response.setOrderDetailsList(orderDetailsList );
	
		} else {
			response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
			response.setConfirmationNumber("MB00000000");
			response.setConfirmEmailStatus("COMPLETED");
			response.setEcpdId("5598");
			response.setTransType("changeCostCenter");
			response.setSubTxnType("CCC");
			response.setStatus("COMPLETED");
			response.setEffectiveDate("12/9/2020");
			List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
			
			SystemTxnInfo addInfo = new SystemTxnInfo();
			addInfo.setAccountNumber(null);
			response.setOrderDetailsList(orderDetailsList);
		}
		return response;
	}
	
	@SuppressWarnings("deprecation")
	private ManagerApprovalSMTracker getManagerApprovalTracker(String status) {
		ManagerApprovalSMTracker approvalTracker = new ManagerApprovalSMTracker();
		approvalTracker.setCreatedDate(new Date());
		approvalTracker.setStatus(status);
		return approvalTracker;
	}
	

	@Test
	public void test_getOrderInformationSMRES_success(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		 managerApprovalRequest.setTransactionType("resume");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForRES(true));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=resume");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.doReturn(true).when(approvalService).checkForCommonTransaction(Mockito.anyString());
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMRES_nullOrderDetails(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		 managerApprovalRequest.setTransactionType("resume");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForRES(false));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=resume");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformation_disconnect_OrderDetails(){
		ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		managerApprovalRequest.setTransactionType("disconnect");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getDisconnectRes());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=disconnect");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.when(cloudPropertiesConfig.getMbtCommonTransactions()).thenReturn("disconnect");
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	private ManagerApprovalSMRequest getManagerApprovalRequesForRESt(boolean approvalStatus) {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("6778ADMBT");
		approvalRequest.setEcpdId("6778");
		approvalRequest.setTransactionType("resume");
		approvalRequest.setOrderNumber("504657574");
		approvalRequest.setApproverEmailIds("test@verizon.com");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
	
	private OrderDetailsResponse getOrderDataForRES(boolean orderDetail) {
		OrderDetailsResponse response = new OrderDetailsResponse();

		if(orderDetail) {
			String s =  "{\"orderDetailsList\":[{\"serviceNumber\":\"2014148644\",\"itemName\":\"08/12/2020\",\"transactionId\":\"0\",\"accountNumber\":\"471627157-00001\","
					+ "\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":"
					+ "\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":\"null null\",\"planGroup\":"
					+ "\"08/12/2020\",\"subTxnType\":\"suspend\"},"
					+ "{\"serviceNumber\":\"2014148644\",\"itemName\":\"Business Contract\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reason\",\"subscriberName\":\"null null\","
					+ "\"planGroup\":\"Business Contract\",\"subTxnType\":\"suspend\"},"
					+ "{\"serviceNumber\":\"2014148644\",\"itemName\":\"With billing\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Billing\",\"subscriberName\":"
					+ "\"null null\",\"planGroup\":\"With billing\",\"subTxnType\":\"suspend\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"09/02/2020\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":"
					+ "\"Sri ram\",\"planGroup\":\"08/12/2020\",\"subTxnType\":\"suspend\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"Business Contract\",\"detailType\":\"Reason\",\"accountNumber\":"
					+ "\"471627157-00001\",\"subscriberName\":\"Sri ram\",\"status\":\"PENDING\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"With billing\",\"detailType\":\"Billing\",\"accountNumber\":\"471627157-00001\",\"subscriberName\":\"Sri ram\"}],"
					+ "\"confirmationEmail\":\"steve.jensen@verizonwireless.com\",\"effectiveDate\":\"09/12/2020\",\"status\":\"PENDING\",\"subTxnType\":\"suspend\","
					+ "\"loggedInUserId\":\"5598ABI\",\"ecpdId\":\"5598\",\"confirmationNumber\":\"504657387\"}";
			Gson gson = new Gson();
			return gson.fromJson(s, OrderDetailsResponse.class);
	
		} else {
			response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
			response.setConfirmationNumber("MB00000000");
			response.setConfirmEmailStatus("COMPLETED");
			response.setEcpdId("5598");
			response.setTransType("resume");
			response.setSubTxnType("RES");
			response.setStatus("COMPLETED");
			response.setEffectiveDate("12/9/2020");
			List<SystemTxnInfo> orderDetailsList = new ArrayList<>();
			
			SystemTxnInfo addInfo = new SystemTxnInfo();
			addInfo.setAccountNumber(null);
			response.setOrderDetailsList(orderDetailsList);
		}
		return response;
	}
	
	private OrderDetailsResponse getOrderDataForRES() {
		OrderDetailsResponse response = new OrderDetailsResponse();

			String s =  "{\"orderDetailsList\":[{\"serviceNumber\":\"2014148644\",\"itemName\":\"08/12/2020\",\"transactionId\":\"0\",\"accountNumber\":\"471627157-00001\","
					+ "\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":\"5598ABI\",\"listPrice\":"
					+ "\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":\"null null\",\"planGroup\":"
					+ "\"08/12/2020\",\"subTxnType\":\"suspendService\"},"
					+ "{\"serviceNumber\":\"2014148644\",\"itemName\":\"Business Contract\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reason\",\"subscriberName\":\"null null\","
					+ "\"planGroup\":\"Business Contract\",\"subTxnType\":\"suspendService\"},"
					+ "{\"serviceNumber\":\"2014148644\",\"itemName\":\"With billing\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Billing\",\"subscriberName\":"
					+ "\"null null\",\"planGroup\":\"With billing\",\"subTxnType\":\"suspendService\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"09/02/2020\",\"transactionId\":\"0\",\"accountNumber\":"
					+ "\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":"
					+ "\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":"
					+ "\"Sri ram\",\"planGroup\":\"08/12/2020\",\"subTxnType\":\"suspendService\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"Business Contract\",\"detailType\":\"Reason\",\"accountNumber\":"
					+ "\"471627157-00001\",\"subscriberName\":\"Sri ram\",\"status\":\"PENDING\"},"
					+ "{\"serviceNumber\":\"2014148645\",\"itemName\":\"With billing\",\"detailType\":\"Billing\",\"accountNumber\":\"471627157-00001\",\"subscriberName\":\"Sri ram\"}],"
					+ "\"confirmationEmail\":\"steve.jensen@verizonwireless.com\",\"effectiveDate\":\"09/12/2020\",\"status\":\"PENDING\",\"subTxnType\":\"suspendService\","
					+ "\"loggedInUserId\":\"5598ABI\",\"ecpdId\":\"5598\",\"confirmationNumber\":\"504657387\"}";
			Gson gson = new Gson();
			//return gson.fromJson(s, OrderDetailsResponse.class);
			response = gson.fromJson(s, OrderDetailsResponse.class);
		return response;
	}

	private ManagerApprovalSMRequest getManagerApprovalRequestForSuspend(boolean approvalStatus) {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("48242ALEXQA1");
		approvalRequest.setEcpdId("48242");
		approvalRequest.setTransactionType("suspend");
		approvalRequest.setOrderNumber("504864821");
		approvalRequest.setApproverEmailIds("test@verizon.com");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
	
	
	
	private OrderDetailsResponse getOrderDataForSuspend(boolean orderDetail) {
		OrderDetailsResponse response = new OrderDetailsResponse();
		if(orderDetail) {
			String s ="{\"orderDetailsList\":[{\"serviceNumber\":\"2014148644\",\"itemName\":\"08/12/2020\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":\"null null\",\"planGroup\":\"08/12/2020\",\"subTxnType\":\"suspend\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"Business Contract\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reason\",\"subscriberName\":\"null null\",\"planGroup\":\"Business Contract\",\"subTxnType\":\"suspend\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"With billing\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Billing\",\"subscriberName\":\"null null\",\"planGroup\":\"With billing\",\"subTxnType\":\"suspend\"}],\"confirmationEmail\":\"steve.jensen@verizonwireless.com\",\"transType\":\"suspend\",\"status\":\"PENDING\",\"subTxnType\":\"suspend\",\"loggedInUserId\":\"5598ABI\",\"ecpdId\":\"5598\",\"confirmationNumber\":\"504657387\"}";
			response = gson.fromJson(s, OrderDetailsResponse.class);
		} else {
			response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
			response.setConfirmationNumber("MB00000000");
			response.setConfirmEmailStatus("COMPLETED");
			response.setEcpdId("5598");
			response.setTransType("suspend");
			response.setSubTxnType("suspend");
			response.setStatus("COMPLETED");
			response.setEffectiveDate("12/9/2020");
			List<SystemTxnInfo> orderDetailsList = new ArrayList<>();		
			SystemTxnInfo addInfo = new SystemTxnInfo();
			addInfo.setAccountNumber(null);
			response.setOrderDetailsList(orderDetailsList);
		}
		return response;
	}
	
	private OrderDetailsResponse getOrderDataForSuspend() {
		OrderDetailsResponse response = new OrderDetailsResponse();
		
			String s ="{\"orderDetailsList\":[{\"serviceNumber\":\"2014148644\",\"itemName\":\"08/12/2020\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":\"null null\",\"planGroup\":\"08/12/2020\",\"subTxnType\":\"suspendService\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"Business Contract\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reason\",\"subscriberName\":\"null null\",\"planGroup\":\"Business Contract\",\"subTxnType\":\"suspendService\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"With billing\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspendService\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Billing\",\"subscriberName\":\"null null\",\"planGroup\":\"With billing\",\"subTxnType\":\"suspendService\"}],\"confirmationEmail\":\"steve.jensen@verizonwireless.com\",\"transType\":\"suspendService\",\"status\":\"PENDING\",\"subTxnType\":\"suspendService\",\"loggedInUserId\":\"5598ABI\",\"ecpdId\":\"5598\",\"confirmationNumber\":\"504657387\"}";
			response = gson.fromJson(s, OrderDetailsResponse.class);		
		return response;
	}
	
	@Test
	public void test_getOrderInformationSMCMB_success(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForCMB(true);
		 managerApprovalRequest.setTransactionType("callMessageBlocking");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForCMB(true));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=callMessageBlocking");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		Mockito.doReturn(true).when(approvalService).checkForCommonTransaction(Mockito.anyString());
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformationSMCMB_nullOrderDetails(){
		 ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		 managerApprovalRequest.setTransactionType("callMessageBlocking");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getOrderDataForCMB(false));
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=504657574&ecpdId=6778&level=1&transactionType=callMessageBlocking");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalSMResponse smRes = approvalService.getSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	private ManagerApprovalSMRequest getManagerApprovalRequesForCMB(boolean approvalStatus) {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("6778ADMBT");
		approvalRequest.setEcpdId("6778");
		approvalRequest.setTransactionType("callMessageBlocking");
		approvalRequest.setOrderNumber("504657574");
		approvalRequest.setApproverEmailIds("test@verizon.com");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
	
	private OrderDetailsResponse getOrderDataForCMB(boolean orderDetail) {
		OrderDetailsResponse response = new OrderDetailsResponse();
		if(orderDetail) {
			String s ="{\"orderDetailsList\":[{\"serviceNumber\":\"2014148644\",\"itemName\":\"08/12/2020\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"addRemoveFeature\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reconnect Date\",\"subscriberName\":\"null null\",\"planGroup\":\"1234567890||||\",\"subTxnType\":\"suspend\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"Business Contract\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Reason\",\"subscriberName\":\"null null\",\"planGroup\":\"Business Contract\",\"subTxnType\":\"suspend\"},{\"serviceNumber\":\"2014148644\",\"itemName\":\"With billing\",\"transactionId\":0,\"accountNumber\":\"471627157-00001\",\"status\":\"PENDING\",\"finalPrice\":\"0.00\",\"txnType\":\"suspend\",\"userId\":\"5598ABI\",\"listPrice\":\"0.00\",\"ecpdId\":\"5598\",\"detailType\":\"Billing\",\"subscriberName\":\"null null\",\"planGroup\":\"With billing\",\"subTxnType\":\"suspend\"}],\"confirmationEmail\":\"steve.jensen@verizonwireless.com\",\"transType\":\"suspend\",\"status\":\"PENDING\",\"subTxnType\":\"suspend\",\"loggedInUserId\":\"5598ABI\",\"ecpdId\":\"5598\",\"confirmationNumber\":\"504657387\"}";
			response = gson.fromJson(s, OrderDetailsResponse.class);
		} else {
			response.setConfirmationEmail("a@b.verizon.com,b@gfc.verizon.com");
			response.setConfirmationNumber("MB00000000");
			response.setConfirmEmailStatus("COMPLETED");
			response.setEcpdId("5598");
			response.setTransType("callMessageBlocking");
			response.setSubTxnType("callMessageBlocking");
			response.setStatus("COMPLETED");
			response.setEffectiveDate("12/9/2020");
			List<SystemTxnInfo> orderDetailsList = new ArrayList<>();		
			SystemTxnInfo addInfo = new SystemTxnInfo();
			addInfo.setAccountNumber(null);
			response.setOrderDetailsList(orderDetailsList);
		}
		return response;
	}
	
	private OrderDetailsResponse getDisconnectRes() {
		String s = "{\"orderDetailsList\":[{\"serviceNumber\":\"248-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Status\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"Deactivated\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"248-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Deactivation Date\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"billing date\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"248-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Reason For Deactivation\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"discontinue\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"348-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Status\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"Deactivated\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"348-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Deactivation Date\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"billing date\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"348-867-5348\",\"itemName\":\"2488675348\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Reason For Deactivation\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"discontinue\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"348-867-5348\",\"itemName\":\"10/15/5020\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Contract End Date\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"discontinue\",\"subTxnType\":\"disconnect\"},{\"serviceNumber\":\"348-867-5348\",\"itemName\":\"$1205\",\"transactionId\":0,\"accountNumber\":\"586006658-00001\",\"status\":\"FAILED\",\"finalPrice\":\"0.00\",\"txnType\":\"disconnect\",\"userId\":\"21232VMDEADMINQA2\",\"listPrice\":\"0.00\",\"ecpdId\":\"2132\",\"effectiveDate\":\"09/07/2020\",\"detailType\":\"Etf Fee\",\"action\":\"Add\",\"subscriberName\":\"RAVI WRIGHT\",\"planGroup\":\"discontinue\",\"subTxnType\":\"disconnect\"}],\"confirmationEmail\":\"devesh.tyagi@verizon.com;\",\"transType\":\"disconnect\",\"status\":\"FAILED\",\"subTxnType\":\"disconnect\",\"effectiveDate\":\"09/07/2020\",\"loggedInUserId\":\"21232VMDEADMINQA2\",\"ecpdId\":\"2132\",\"confirmationNumber\":\"1007081536\"}";
		return gson.fromJson(s, OrderDetailsResponse.class);
	}
	
	@Test
	public void test_getOrderInformation_CBA_OrderDetails_success(){
		ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		managerApprovalRequest.setTransactionType("chgBillingAddress");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getCBAResponse());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=1007210544&ecpdId=30992&level=1&transactionType=chgBillingAddress");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1PENDING"));
		ManagerApprovalAccountLevelResponse smRes = approvalService.getAccountLevelSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(smRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_getOrderInformation_CBA_OrderDetails_failure(){
		ManagerApprovalSMRequest managerApprovalRequest = getManagerApprovalRequesForRESt(true);
		managerApprovalRequest.setTransactionType("chgBillingAddress");
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getCBAResponse());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=1007210544&ecpdId=30992&level=1&transactionType=chgBillingAddress");
		Mockito.when(managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker("L1REJECTED"));
		ManagerApprovalAccountLevelResponse smRes = approvalService.getAccountLevelSMInformation(managerApprovalRequest);
		
		assertNotNull(smRes);
		assertTrue(!smRes.getServiceStatus().isSuccess());
	}
	
	private OrderDetailsResponse getCBAResponse() {
		String s = "{ \"orderDetailsList\": [{\"itemName\": \"08817\",\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Zip Code\",	\"action\": \"Add\",	\"planGroup\": \"07407\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"24P\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Attention Line\",	\"action\": \"Add\",	\"planGroup\": \"24P\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"24P READING RD\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Address 1\",	\"action\": \"Add\",	\"planGroup\": \"76 HAMILTON AVE\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"919-112-7078\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Contact 1\",	\"action\": \"Add\",	\"planGroup\": \"919-112-7078\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"919-112-7079\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Contact 2\",	\"action\": \"Add\",	\"planGroup\": \"919-112-7079\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"Business\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Location\",	\"action\": \"Add\",	\"planGroup\": \"Business\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"EDISON\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"City\",	\"action\": \"Add\",	\"planGroup\": \"ELMWOOD PARK\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"NJ\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"State\",	\"action\": \"Add\",	\"planGroup\": \"NJ\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"itemName\": \"OFF\",	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Paperless Billing\",	\"action\": \"Add\",	\"planGroup\": \"ON\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Address 2\",	\"action\": \"Add\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Ext 1\",	\"action\": \"Add\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Ext 2\",	\"action\": \"Add\",	\"subTxnType\": \"chgBillingAddress\" 	}, 	{	\"transactionId\": 0,	\"accountNumber\": \"208763421-00001\",	\"status\": \"COMPLETED\",	\"finalPrice\": \"0.00\",	\"txnType\": \"chgBillingAddress\",	\"userId\": \"30992QA2TEST\",	\"listPrice\": \"0.00\",	\"ecpdId\": \"30992\",	\"effectiveDate\": \"12/11/2020\",	\"detailType\": \"Country Code\",	\"action\": \"Add\",	\"subTxnType\": \"chgBillingAddress\" 	}], 	\"confirmationEmail\": \"sonal.gulani@verizon.com;\", 	\"transType\": \"chgBillingAddress\", 	\"status\": \"COMPLETED\", 	\"subTxnType\": \"chgBillingAddress\", 	\"effectiveDate\": \"12/11/2020\", 	\"loggedInUserId\": \"30992QA2TEST\", 	\"ecpdId\": \"30992\", 	\"confirmationNumber\": \"1007294794\" }";
		return gson.fromJson(s, OrderDetailsResponse.class);
	}

	@Test
	public void test_makeL2ApprovalCall_CBA() throws Exception {
		Mockito.when(transHistoryCoreClient.retrieveOrderDetails(Mockito.isA(OrderDetailsRequest.class))).thenReturn(getCBAResponse());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=1007210544&ecpdId=30992&level=1&transactionType=chgBillingAddress");

		ManagerApprovalSMTracker tracker =getManagerApprovalTracker("L1PENDING");
		tracker.setCreatedDate(new Date());
		tracker.setLevel(2);
		tracker.setOrderNumber("MB00000000");
		tracker.setTransactionType("chgBillingAddress");
		tracker.setApproverEmail2("test@verizon.com");
		Mockito.when( managerApprovalSMRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(tracker);
		Mockito.when(cloudPropertiesConfig.getCbaManagerApprovalUrl()).thenReturn("/test");
		ManagerApprovalSMRequest request =getManagerApprovalRequest(true);
		request.setLevel("2");
		ManagerApprovalSMResponse smRes = approvalService.makeApprovalCall(request);
		
		assertNotNull(smRes);
	}
}
