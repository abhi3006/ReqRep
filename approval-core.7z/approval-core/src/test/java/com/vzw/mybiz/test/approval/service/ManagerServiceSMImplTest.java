package com.vzw.mybiz.test.approval.service;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.DgfFieldShortLookup;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.ManageApprovalAMDto;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.ViewOnlyDto;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMInfo;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.service.impl.ManagerServiceSMImpl;
import com.vzw.mybiz.caching.services.cache.CacheService;

@RunWith(SpringRunner.class)
public class ManagerServiceSMImplTest {

	@Spy
	@InjectMocks
	ManagerServiceSMImpl managerServiceSM;

	private MockMvc mockMvc;

	@MockBean
	private CustomizationClient customizationClient;

	@MockBean
	private CompanyClient companyClient;

	@MockBean
	CacheService<ManagerApprovalSMInfo> managerApprovalSession;

	Gson gson = new Gson();

	ManagerApprovalSMInfo managerApprovalSMInfo;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(managerServiceSM).build();
		
		managerApprovalSMInfo = new ManagerApprovalSMInfo();
		managerApprovalSMInfo.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG,true));
		managerApprovalSMInfo.setReadonly(false);
		managerApprovalSMInfo.setRequired(true);
		managerApprovalSMInfo.setUserInputType("Input Text");
		managerApprovalSMInfo.setPrePopulateEmailID("someone@some.com");
		
	}

	public EcpdProfileInfo getEcpdInfo1() {
		EcpdProfileInfo ecpdInfo = new EcpdProfileInfo();
		ecpdInfo.setApproverEmail1("Emailid1.com");
		ecpdInfo.setApproverEmail2("Emailid2.com");
		ecpdInfo.setApproverEmail3("Emailid3.com");
		ecpdInfo.setOption(1);
		return ecpdInfo;
	}
	
	public EcpdProfileInfo getEcpdInfo2() {
		EcpdProfileInfo ecpdInfo = new EcpdProfileInfo();
		ecpdInfo.setApproverEmail1("Emailid1.com");
		ecpdInfo.setApproverEmail2("");
		ecpdInfo.setApproverEmail3("");
		ecpdInfo.setOption(2);
		return ecpdInfo;
	}
	
	public String[] getDomainList() {
		return new String[] { "verizon.com" };
	}
	
	
	public CompanyCoreResponse getCompanyCoreRes(boolean isDomain, int email) {
		CompanyCoreResponse companyCoreResponse = new CompanyCoreResponse();
		companyCoreResponse.setBusinessZip("30007");
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		companyCoreResponse.setServiceStatus(serviceStatus);
		OrderDataManagerApproval managerApproval = new OrderDataManagerApproval();
		switch (email) {
		case 1:
			managerApproval.setAccountMaintenanceInfo(getEcpdInfo1());
			break;
		default:
			managerApproval.setAccountMaintenanceInfo(getEcpdInfo2());
		}
		if (isDomain) {
			managerApproval.setDomainEntry(getDomainList());
		}
		companyCoreResponse.setManagerApproval(managerApproval);
		return companyCoreResponse;
	}
	
	public DgfFieldShort getFieldDomain() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.EMAIL_DOMAIN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("nirupama");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	public DgfFieldShort getFieldDropdown() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.DROPDOWN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("");
		field.setReadonly(false);
		field.setRequired(true);
		DgfFieldShortLookup lookup = new DgfFieldShortLookup();
		lookup.setDefaultFlag("Y");
		lookup.setDisplayName("test@gmai.com");
		lookup.setValue("test");
		DgfFieldShortLookup lookup1 = new DgfFieldShortLookup();
		lookup1.setDefaultFlag("N");
		lookup1.setDisplayName("new@gmai.com");
		lookup1.setValue("new");
		List<DgfFieldShortLookup> listLookup = new ArrayList<DgfFieldShortLookup>();
		listLookup.add(lookup);
		listLookup.add(lookup1);
		field.setLookUp(listLookup);
		return field;
	}

	public DgfFieldShort getFieldText() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.INPUT_TEXT);
		field.setLookUp(null);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("Ramya.Shivakumar@verizoniwireless.com");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	public CustomizationEcpdProfileDto getCustomicationEcpdProfile(int urlState) {
		CustomizationEcpdProfileDto profileDto = new CustomizationEcpdProfileDto();
		profileDto.setManagerApprovalState(1);
		profileDto.setManagerApprovalVariable(1);
		profileDto.setUrlStatus(urlState);
		return profileDto;
	}
	
	private ManageApprovalAMDto getManageApprovalSM(boolean isArfEnabled,String type) {
		ManageApprovalAMDto manageApprovalAMDto = new ManageApprovalAMDto();
		manageApprovalAMDto.setAddRemoveFeatures(isArfEnabled);
		if(isArfEnabled) {
			if (type == "Dropdown") {
				manageApprovalAMDto.setArf(getFieldDropdown());
			} else if (type == "Domain") {
				manageApprovalAMDto.setArf(getFieldDomain());
			} else {
				manageApprovalAMDto.setArf(getFieldText());
			}
		}
		return manageApprovalAMDto;
	}

	public DgfDto getDgfDto(boolean isArfEnabled, String type) {
		DgfDto dgfDto = new DgfDto();
		if(type.equals("Dropdown")) {
			dgfDto.setEcpdProfile(getCustomicationEcpdProfile(0));			
		} else {
			dgfDto.setEcpdProfile(getCustomicationEcpdProfile(1));	
		}
		dgfDto.setViewOnly(new ViewOnlyDto());
		dgfDto.setManageApprovalAM(getManageApprovalSM(isArfEnabled,type));
		return dgfDto;
	}
	
	public CheckoutCustomization getCustomizationResponse(String type,boolean isArfEnabled) {
		CheckoutCustomization checkoutRes = new CheckoutCustomization();
		ServiceStatus serviceStatus = new ServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
		checkoutRes.setServiceStatus(serviceStatus);
		checkoutRes.setDgf(getDgfDto(isArfEnabled,type));
		return checkoutRes;
	}

	@Test
	public void test_ManagerApprovalInfoCache() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(managerApprovalSMInfo);
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
	}
	
	@Test
	public void test_ManagerApprovalDisabledMBA() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false, 1));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("text", false));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalDisabledECPD() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 1);
		companyCoreResponse.getManagerApproval().getAccountMaintenanceInfo().setOption(0);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("text", false));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalInfoL2withMBA() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 2);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("text", true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalInfoL2NullEcpd() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 1);
		companyCoreResponse.getManagerApproval().setAccountMaintenanceInfo(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("text", true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalInfoL2NullCustomization() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 1);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(null);

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}

	@Test
	public void test_ManagerApprovalInfoL2NullDgf() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 1);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		CheckoutCustomization custRes = getCustomizationResponse("text", true);
		custRes.setDgf(null);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(custRes);

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalInfoL2NullAM() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 1);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		CheckoutCustomization custRes = getCustomizationResponse("text", true);
		custRes.getDgf().setManageApprovalAM(null);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(custRes);

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	@Test
	public void test_ManagerApprovalInfoL2withoutMBA() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false, 2);
		companyCoreResponse.getManagerApproval().getAccountMaintenanceInfo().setApproverEmail2("Email2FromEcpd.com");
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("text", true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCustomizationResponse("text",true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}

	
	@Test
	public void test_ManagerApprovalL1Cpc() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setCcp(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setChangingCallPlan(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("callingPlanChg");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1Suspend() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setSs(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setSuspendService(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("suspend");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1Resume() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setRs(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setResumeService(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("resume");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1CCC() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setCcc(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setChangeCostCenter(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("changeCostCenter");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalNoMatch() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setSs(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setSuspendService(false);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertFalse(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL2DrpDown() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false, 2));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("Dropdown", true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1Domain() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(true, 1));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("Domain", true));

		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}

	@Test
	public void test_ManagerApproval_CatchBlock() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class)).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(true, 1));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenThrow(new RuntimeException("testing catch block"));
		// .thenReturn(getCustomizationResponse("", 1, true, false, false));
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertFalse(serviceRes.getServiceStatus().isSuccess());
//		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("102");
	}

	@Test
	public void test_ManagerApprovalL1Disconnect() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setDs(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setDeactivateService(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("disconnect");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1ChangeBillingAddress() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setCbta(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setChangeBillToAddress(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("CBA");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	@Test
	public void test_ManagerApprovalL1ChangeUserInformation() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession("CACHE_MA_SM582760",ManagerApprovalSMInfo.class))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization response = getCustomizationResponse("text",true);
		response.getDgf().getManageApprovalAM().setCui(response.getDgf().getManageApprovalAM().getArf());
		response.getDgf().getManageApprovalAM().setChangeUserInformation(true);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(response);
		ManagerApprovalSMRequest request = getManagerApprovalRequest();
		request.setTransactionType("CWUI");
		ManagerApprovalSMInfo serviceRes = managerServiceSM.getManagerApprovalSMInfo(request);
		assertNotNull(serviceRes);
		assertTrue(serviceRes.getServiceStatus().isSuccess());
		assertTrue(serviceRes.isManagerApprovalEnabled());
	}
	
	private com.vzw.mybiz.utilities.audit.domain.ServiceStatus getServiceStatus(String statusCode, String statusMessage, boolean isSuccess) {
		com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setSuccess(isSuccess);
		return serviceStatus;
	}
	
	private ManagerApprovalSMRequest getManagerApprovalRequest() {
		ManagerApprovalSMRequest approvalRequest = new ManagerApprovalSMRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("582760MBTQA1");
		approvalRequest.setEcpdId("582760");
		approvalRequest.setTransactionType("ARF");
		approvalRequest.setZipCode("30004");
		return approvalRequest;
	}
}
