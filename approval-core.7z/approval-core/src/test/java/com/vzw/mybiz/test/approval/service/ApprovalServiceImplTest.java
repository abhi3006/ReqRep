package com.vzw.mybiz.test.approval.service;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.vzw.mybiz.approval.client.AccessoryClient;
import com.vzw.mybiz.approval.client.SubmitClient;
import com.vzw.mybiz.approval.client.WfmCoreClient;
import com.vzw.mybiz.approval.client.WorkFlowClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.Credentials;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.RecommendationRequest;
import com.vzw.mybiz.approval.domain.RecommendationResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.SubmitCoreResponse;
import com.vzw.mybiz.approval.domain.UpdateRequest;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.impl.ApprovalServiceImpl;

public class ApprovalServiceImplTest {
	
	@Spy
	@InjectMocks
	private ApprovalServiceImpl approvalService;

	@Mock
	private WorkFlowClient workFlowClient;

	@Mock
	private SubmitClient submitClient;

	@Mock
	private WfmCoreClient wfmClient;

	@Mock
	private ManagerApprovalRepo managerApprovalRepo;
	
	@Mock
	private Credentials credentials;
	
	@Mock
	private AccessoryClient accessoryClient;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		approvalService.init();
	}
	@Test
	public void test_getOrderInformation_success(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	@Test
	public void test_getOrderInformation_Exception(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenThrow(new RuntimeException("This is for testing"));
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	
	@Test
	public void test_getOrderInformation_Approved(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker(Constants.L1_APPROVED));
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	
	@Test
	public void test_getOrderInformation_ManagerApproval_Null(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(null);
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(null);
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	
	
	@Test
	public void test_getOrderInformation_Rejected(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker(Constants.L1_REJECTED));
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	
	@Test
	public void test_getOrderInformation_URL_Expiry(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker(Constants.URL_EXPIRED));
		approvalService.getOrderInformation(getManagerApprovalRequest(false));
	}
	@Test
	public void test_getOrderInformation_URL_Non_Expiry(){
		Mockito.when(workFlowClient.getOrderJson("MB00000000")).thenReturn(getOrderJson());
		Mockito.when(credentials.getDecryptedText()).thenReturn("orderId=MB00000000&ecpdId=6778");
		Mockito.when(managerApprovalRepo.findOneByOrderNumber(Mockito.anyString())).thenReturn(getManagerApprovalTracker(Constants.L1_PENDING));
		approvalService.getOrderInformation(getManagerApprovalRequest(true));
	}
	
	private ManagerApprovalTracker getManagerApprovalTracker(String status) {
		ManagerApprovalTracker approvalTracker = new ManagerApprovalTracker();
		if(Constants.URL_EXPIRED.equalsIgnoreCase(status)){
			approvalTracker.setStatus("L1PENDING");
			approvalTracker.setCreatedDate(new Date("1/16/2019 5:10:30 AM"));
		}else{
			approvalTracker.setStatus(status);
			approvalTracker.setCreatedDate(new Date());
		}
		
		return approvalTracker;
	}
	private ServiceStatus getServiceStatus(String statusCode){
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		return serviceStatus;
	}
	@Test
	public void test_makeApprovalCall_success(){
		SubmitCoreResponse submitResponse = new SubmitCoreResponse();
		submitResponse.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE));
		Mockito.when(submitClient.submitOrderToPos(Mockito.anyString())).thenReturn(submitResponse);
		doNothing().when(managerApprovalRepo).updateMAStatus(Mockito.anyString(), Mockito.anyString());
		Mockito.when(accessoryClient.getRecommendations(Mockito.any(RecommendationRequest.class))).thenReturn(new RecommendationResponse());
		approvalService.makeApprovalCall(getManagerApprovalRequest(true));
		
		verify(workFlowClient, times(1)).updateOrderMaster(Mockito.any(OrderMaster.class));
		verify(workFlowClient, times(1)).updateOptTracking(Mockito.any(OrderTrackingRequest.class));
	}
	@Test
	public void test_makeApprovalCall_failure(){
		SubmitCoreResponse submitResponse = new SubmitCoreResponse();
		submitResponse.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE));
		Mockito.when(submitClient.submitOrderToPos(Mockito.anyString())).thenReturn(submitResponse);
		Mockito.when(accessoryClient.getRecommendations(Mockito.any(RecommendationRequest.class))).thenReturn(new RecommendationResponse());
		approvalService.makeApprovalCall(getManagerApprovalRequest(true));
		verify(workFlowClient, times(1)).updateOptTracking(Mockito.any(OrderTrackingRequest.class));
	}
	@Test
	public void test_makeApprovalCall_exception(){
		SubmitCoreResponse submitResponse = new SubmitCoreResponse();
		submitResponse.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE));
		Mockito.when(submitClient.submitOrderToPos(Mockito.anyString())).thenThrow(new RuntimeException("This is for testing"));
		Mockito.when(accessoryClient.getRecommendations(Mockito.any(RecommendationRequest.class))).thenReturn(new RecommendationResponse());
		approvalService.makeApprovalCall(getManagerApprovalRequest(true));
	}
	
	@Test
	public void test_makeRejectionCall_success(){
		doNothing().when(managerApprovalRepo).updateMAStatus(Mockito.anyString(), Mockito.anyString());
		Mockito.when(accessoryClient.getRecommendations(Mockito.any(RecommendationRequest.class))).thenReturn(new RecommendationResponse());
		approvalService.makeRejectionCall(getManagerApprovalRequest(false));
		
		verify(workFlowClient, times(1)).updateOrderMaster(Mockito.any(OrderMaster.class));
		verify(workFlowClient, times(1)).updateOptTracking(Mockito.any(OrderTrackingRequest.class));
		verify(wfmClient, times(1)).updateOrderConfirmationToWFM(Mockito.any(UpdateRequest.class));
	}
	@Test
	public void test_makeRejectionCall_exception(){
		Mockito.when(workFlowClient.updateOptTracking(Mockito.any(OrderTrackingRequest.class))).thenThrow(new RuntimeException("This is for testing"));
		Mockito.when(accessoryClient.getRecommendations(Mockito.any(RecommendationRequest.class))).thenReturn(new RecommendationResponse());
		approvalService.makeRejectionCall(getManagerApprovalRequest(false));
	}
	
	
	private String getOrderJson() {
		
		String orderJson = "{\"order\":{\"orderTimeStamp\":\"2018-11-08T15:23:09.791\",\"timeZone\":\"EST\",\"credential\":{\"existingPhoneNumber\":\"8102781776\",\"accountNumber\":\"481044994-1\"},\"corporateInfo\":{\"ecpdId\":6778,\"corporateName\":\"UAT3TEST - 6778\",\"corporateCustCareNumber\":\"BGCO SMB NC MKT\",\"corporateTaxId\":\"AHJMS4734\",\"corporateTaxExempt\":\"N\",\"corporateManagerApproval\":\"NO\",\"corporateSuppressCredit\":\"NO\",\"corporateEmailTemplateId\":\"25\",\"liabilityType\":\"C\"},\"orderApproval\":[{\"level\":\"1\",\"approver\":[{\"approvalEmail\":\"pradeep.rajendiran@verizon.com\",\"approvalUrl\":\"mbqa1.sdc.vzwcorp.com\"}]}],\"maApprovalUrl\":\"mbqa1.sdc.vzwcorp.com\",\"maApproverEmailId\":\"pradeep.rajendiran@verizon.com\",\"confirmationAndShipNotification\":{\"email\":\"\"},\"billingAddress\":{\"type\":\"RD\",\"addressType\":\"B\",\"streetName\":\"HIGHLAND\",\"zipCode\":\"48353\",\"zipCode4\":\"2711\",\"city\":\"HARTLAND\",\"state\":\"MI\",\"addressLine1\":\"11590 HIGHLAND RD # M59\",\"addressLine2\":\"M59\",\"country\":\"USA\",\"streetNum\":\"11590\"},\"subscriberShippingInformation\":{\"carrierCode\":\"SHP002\",\"shippingDescription\":\"2 DAY SHIP BY 8PM\",\"serviceType\":\"STANDARD SHIPPING\",\"shCharges\":0,\"shippingAddress\":{\"type\":\"RD\",\"attn\":\"Jake\",\"addressType\":\"Business\",\"streetName\":\"TALL OAK\",\"zipCode\":\"08837\",\"zipCode4\":\"2072\",\"city\":\"EDISON\",\"state\":\"NJ\",\"addressLine1\":\"291 Tall Oak Road\",\"businessName\":\"Walmart\",\"shippingCBRNumber\":\"7692454875\",\"streetNum\":\"291\"}},\"creditWriteRequestInfo\":{\"locationCode\":\"P166701\"},\"originatingIpAddress\":\"10.169.250.162\",\"revenueInfo\":{\"dueToday\":7.99,\"orderAmount\":7.49,\"taxAmount\":0.5,\"taxDetails\":[{\"subTotal\":\"0.5\",\"item\":[{\"amount\":0.5,\"description\":[{\"value\":\"NJ State Sales Tax\"}]}],\"type\":\"TBA\"}],\"paymentType\":\"BILLTOACCT\"},\"subOrder\":[{\"retailAccessory\":{\"fipsCode\":\"3402300000\",\"systemData\":{\"marketCode\":\"Georgia\",\"regionCode\":\"Georgia/Alabama\",\"areaName\":\"South\",\"fulfillment\":\"VISION_B2B\",\"databaseID\":\"GA\",\"serviceZipCode\":\"30004\",\"serviceCity\":\"Alpharetta\",\"serviceState\":\"GA\"},\"salesRepId\":\"ESQ43\",\"equipment\":[{\"name\":\"4.8A Vehicle Charger with Dual Output\",\"productType\":\"ACCESSORY\",\"taxDetailsList\":[{\"taxDetail\":[{\"taxType\":\"NJ State Sales Tax\",\"taxAmount\":\"0.5\",\"taxDescription\":\"NJ State Sales Tax\"}],\"count\":\"1.0\"}],\"amount\":\"7.49\",\"retailPrice\":\"9.98\",\"listPrice\":\"7.49\",\"quantity\":1,\"productCode\":\"VPC48BLK\",\"taxAmount\":0.5,\"taxDescription\":\"\"},{\"name\":\"2 DAY SHIP BY 8PM\",\"productType\":\"SHIP\",\"taxDetailsList\":[],\"amount\":\"0.0\",\"retailPrice\":\"0.0\",\"listPrice\":\"0.0\",\"quantity\":1,\"productCode\":\"SHP002\",\"taxAmount\":0}],\"feature\":[],\"subscriber\":{\"subscriberName\":{\"firstName\":\"DON\",\"lastName\":\"HENDERSON\"},\"contact\":{\"email\":\"WHKVIL@VZW.COM\"},\"subscriberServiceAddress\":{\"zipCode\":\"48353\",\"city\":\"HARTLAND\",\"state\":\"MI\",\"addressLine1\":\"11590 HIGHLAND RD # M59\",\"zip10\":\"48353\"}},\"customerUniqueCode\":[]}}]},\"clientId\":\"MBT\",\"groupOrderNumber\":\"MB3000008482754\",\"loggedInUserId\":\"6778ADMBT\",\"profileId\":\"6778\",\"confirmationNumber\":\"MB3000008482755\",\"orderType\":\"EPBNAO\",\"tokenizationFlag\":\"ON\"}";
		return orderJson;
	}
	private ManagerApprovalRequest getManagerApprovalRequest(boolean approvalStatus) {
		ManagerApprovalRequest approvalRequest = new ManagerApprovalRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("6778ADMBT");
		approvalRequest.setEcpdId("6778");
		approvalRequest.setTransactionType("EPBNAO");
		approvalRequest.setOrderNumber("MB00000000");
		approvalRequest.setApprovalStatus(approvalStatus);
		return approvalRequest;
	}
}
