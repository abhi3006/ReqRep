package com.vzw.mybiz.test.approval.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.data.bcc.entity.PlanMasterDetails;
import com.vzw.mybiz.approval.data.bcc.repo.PlanMasterDetailsRepo;
import com.vzw.mybiz.approval.service.impl.PlanServiceImpl;
import com.vzw.mybiz.prospect.domain.Address;
import com.vzw.mybiz.prospect.domain.plan.PlanRequest;

public class PlanServiceImplTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PlanServiceImplTest.class);

	
	@Spy
	@InjectMocks
	private PlanServiceImpl planServiceImpl;
	
	@Mock
	PlanMasterDetailsRepo planRepo;
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);		
	}
	
	
	@Test
	public void testPlan() {
		
		PlanRequest planReq = new PlanRequest();
		planReq.setAddress(new Address());
		planReq.getAddress().setZipCode("07407");
		Mockito.when(
				planRepo.fetchMarket(Mockito.isA(String.class)))
				.thenReturn("153");
		
		List<String> billingCds = new ArrayList<String>();
		for (int cnt=0; cnt< 1000; cnt++) {
			billingCds.add(cnt+"");
		}
		
		
		
		Mockito.when(
				planRepo.fetchBillingCds(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class)))
				.thenReturn(new ArrayList<String>(1000));
		
		Mockito.when(
				planRepo.fetchCompatiblePlans(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class)))
				.thenReturn(new ArrayList<PlanMasterDetails>());
		
		try{
			planServiceImpl.fetchDeviceCompatiblePlans(planReq);
			} catch(Exception e) {
				
			}
	}
	
	@Test
	public void testPlan1() {
		
		PlanRequest planReq = new PlanRequest();
		planReq.setPlanCatagoryType("AccountSharePlan");
		planReq.setAddress(new Address());
		planReq.getAddress().setZipCode("07407");
		Mockito.when(
				planRepo.fetchMarket(Mockito.isA(String.class)))
				.thenReturn("153");
		
		List<String> billingCds = new ArrayList<String>();
		for (int cnt=0; cnt< 1000; cnt++) {
			billingCds.add(cnt+"");
		}
		
		
		
		Mockito.when(
				planRepo.fetchBillingCds(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class)))
				.thenReturn(new ArrayList<String>(1000));
		
		Mockito.when(
				planRepo.fetchCompatiblePlans(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class), Mockito.isA(List.class)))
				.thenReturn(new ArrayList<PlanMasterDetails>());
		
		try{
		planServiceImpl.fetchDeviceCompatiblePlans(planReq);
		} catch(Exception e) {
			
		}
	}
	
	
	@Test
	public void testSplitPlan() {
		List<String> billingCds = new ArrayList<String>();
		for (int cnt=0; cnt< 1000; cnt++) {
			billingCds.add(cnt+"");
		}
		planServiceImpl.splitList(0,10,billingCds);
	}
	
	
	@Test
	public void testOrganizePlan() {
		Gson gson = new Gson();
		String data = "{                \"planId\": \"3360296\",                \"planScope\": \"MBU\",                \"category_id\": \"3400085\",                \"monthlyMins\": \"1MB\",                \"monthlyFee\": \"0.6\",                \"displayName\": \"4G Machine to Machine SharePlan On-Net - 1MB\",                \"billingCode\": \"25587\",                \"componentType\": null,                \"addRateInfo\": \"$0.60/MB\",                \"shortDesc\": null,                \"b2bShortDesc\": null,                \"b2bLongDesv\": \"Verizon Wireless Machine to Machine plans enable your business to send and receive datatransmissions between your office-based systems and remote devices and applications. Collect,monitor and store information gathered from meter readings, ATMs, kiosks, point-of-sales systems,back-end data collection and transaction systems.\",                \"bgsa\": \"666\",                \"b2bDisplayName\": \"4G Machine to Machine SharePlan On-Net\",                \"planCatType\": \"BCCData\",                \"type\": \"INTERNET/DATA\",                \"segmentCd\": \"15\",                \"categoryCode\": \"28\",                \"planStatus\": \"UNSUPPRESSED\",                \"primarySecondaryId\": null            }";
		PlanMasterDetails planMasterDtls = gson.fromJson(data, PlanMasterDetails.class);
		List<PlanMasterDetails> plnMstLst = new ArrayList<PlanMasterDetails>();
		plnMstLst.add(planMasterDtls);
		Map<String, List<PlanMasterDetails>> x = new HashMap<String, List<PlanMasterDetails>>();
		planServiceImpl.organizeCompatiblePlans(x, plnMstLst);
	}
	
	
	@Test
	public void testPlanError() {
		
		PlanRequest planReq = null;
		planServiceImpl.fetchDeviceCompatiblePlans(planReq);
	}
	
	
}
