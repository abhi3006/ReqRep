package com.vzw.mybiz.test.approval.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.vzw.mybiz.approval.data.bcc.entity.PhoneMasterDetails;
import com.vzw.mybiz.approval.data.bcc.repo.PhoneMasterDetailsRepo;
import com.vzw.mybiz.approval.domain.devices.DeviceDetails;
import com.vzw.mybiz.approval.service.impl.DeviceServiceImpl;

public class DeviceServiceImplTest {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DeviceServiceImplTest.class);

	
	@Spy
	@InjectMocks
	private DeviceServiceImpl deviceServiceImpl;
	
	@Mock
	private PhoneMasterDetailsRepo repo;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);		
	}
	
	@Test
	public void test_getDeviceInformation() {
		Mockito.when(repo.getPhoneMasterDetails()).thenReturn(getPhoneMasterDate());
		List<DeviceDetails> result = deviceServiceImpl.getDeviceInformation();
		assertNotNull(result);
		assertTrue(result.size() > 0);
	}
	
	@Test
	public void test_getDeviceInformation_Empty() {
		Mockito.when(repo.getPhoneMasterDetails()).thenReturn(Collections.emptyList());
		List<DeviceDetails> result = deviceServiceImpl.getDeviceInformation();
		assertNotNull(result);
		assertTrue(result.size() == 0);
	}

	
	@Test
	public void test_getDeviceInformation_PrimitiveNull() {
		
		List<PhoneMasterDetails> details = getPhoneMasterDate();
		details.stream().forEach(d -> {
			d.setCriticalInventoryLevel(null);
			d.setRetailPrice(null);
		});
		
		Mockito.when(repo.getPhoneMasterDetails()).thenReturn(details);
		List<DeviceDetails> result = deviceServiceImpl.getDeviceInformation();
		assertNotNull(result);
		assertTrue(result.size() > 0);
	}
	
	public List<PhoneMasterDetails> getPhoneMasterDate() {
		
		Map<String, String> mapping = new HashMap<String, String>();
		mapping.put("PHONE_ID", "phoneId");
		mapping.put("MAKE", "brandName");
		mapping.put("CATEGORY", "category");
		mapping.put("MODEL", "model");
		mapping.put("IMAGE_NAME", "filePath");
		mapping.put("DISPLAY_PROD_NAME", "displayProductName");
		mapping.put("PROD_NAME", "productName");
		mapping.put("DISPLAY_NAME_SKU", "displayName");
		mapping.put("DEVICE_MASTER_ID", "deviceId");
		mapping.put("SKU", "sku");
		mapping.put("IMAGESET", "imageSet");
		mapping.put("COLOR_ATTRIB_NAME", "color");
		mapping.put("COLOR_HEX_NAME", "cssColor");
		mapping.put("CRITICAL_INVENTORY_LEVEL", "criticalInventoryLevel");
		mapping.put("USRP_PRICE", "retailPrice");
		mapping.put("SIM_SKU", "simSku");
		mapping.put("CAPACITY", "capacity");
		
		HeaderColumnNameTranslateMappingStrategy<PhoneMasterDetails> strategy = new HeaderColumnNameTranslateMappingStrategy<PhoneMasterDetails>();
		strategy.setType(PhoneMasterDetails.class);
		strategy.setColumnMapping(mapping);
		
		CSVReader csvReader = null;
		try {
			String dbData = IOUtils.toString(getClass().getClassLoader().getResource("phonemaster.csv"));
			Reader targetReader = new StringReader(dbData);
			csvReader = new CSVReader(targetReader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("Error during devices retrieval", e);
		}
		CsvToBean<PhoneMasterDetails> csvToBean = new CsvToBean<PhoneMasterDetails>();
		List<PhoneMasterDetails> list = csvToBean.parse(strategy, csvReader);
		
		return list;
	}
	
}
