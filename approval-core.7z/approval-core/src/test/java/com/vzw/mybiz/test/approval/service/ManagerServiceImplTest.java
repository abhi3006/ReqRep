package com.vzw.mybiz.test.approval.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.CartCore;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AccessoryPackage;
import com.vzw.mybiz.approval.domain.Cart;
import com.vzw.mybiz.approval.domain.CartResponse;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.DgfFieldShortLookup;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.Equipment;
import com.vzw.mybiz.approval.domain.ManageApprovalMiscDto;
import com.vzw.mybiz.approval.domain.ManageApprovalOrderDto;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.ViewOnlyDto;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.entity.ManagerApprovalUrl;
import com.vzw.mybiz.approval.repo.MaTrackerRepo;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.impl.ManagerServiceImpl;
import com.vzw.mybiz.caching.services.cache.CacheService;

@RunWith(SpringRunner.class)
@SuppressWarnings("deprecation")
public class ManagerServiceImplTest {

	@Spy
	@InjectMocks
	ManagerServiceImpl managerService;

	private MockMvc mockMvc;

	@MockBean
	private CustomizationClient customizationClient;

	@MockBean
	private CompanyClient companyClient;

	@MockBean
	CacheService<ManagerApprovalInfo> managerApprovalSession;

	@MockBean
	private CartCore cartCore;

	Gson gson = new Gson();
	@Autowired

	@MockBean
	private ManagerApprovalRepo managerApprovalRepo;

	@MockBean
	private MaTrackerRepo maTrackerRepo;

	ManagerApprovalInfo managerApprovalServiceRes;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(managerService).build();

		managerApprovalServiceRes = new ManagerApprovalInfo();
		ServiceStatus serviceStatus = new ServiceStatus( );
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		managerApprovalServiceRes.setServiceStatus(serviceStatus);
		managerApprovalServiceRes.setReadonly(false);
		managerApprovalServiceRes.setRequired(true);
		managerApprovalServiceRes.setUserInputType("Input Text");
		managerApprovalServiceRes.setPrePopulateEmailID("someone@some.com");
	}

	public EcpdProfileInfo getEcpdInfo() {
		EcpdProfileInfo ecpdInfo = new EcpdProfileInfo();
		ecpdInfo.setApproverEmail1("Emailid1.com");
		ecpdInfo.setApproverEmail2("Emailid2.com");
		ecpdInfo.setApproverEmail3("Emailid3.com");
		ecpdInfo.setOption(1);
		return ecpdInfo;
	}
	
	public EcpdProfileInfo getEcpdInfo1() {
		EcpdProfileInfo ecpdInfo = new EcpdProfileInfo();
		ecpdInfo.setApproverEmail1("");
		ecpdInfo.setApproverEmail2("");
		ecpdInfo.setApproverEmail3("");
		ecpdInfo.setOption(1);
		return ecpdInfo;
	}
	
	public String[] getDomainList() {
		return new String[] { "verizon.com" };
	}
	
	
	public CompanyCoreResponse getCompanyCoreRes(boolean isDomain, int email) {
		CompanyCoreResponse companyCoreResponse = new CompanyCoreResponse();
		companyCoreResponse.setBusinessZip("30007");
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		companyCoreResponse.setServiceStatus(serviceStatus);
		OrderDataManagerApproval managerApproval = new OrderDataManagerApproval();
		switch(email) {
		case 1:
			managerApproval.setCommerceInfo(getEcpdInfo1());
			break;
		default:
			managerApproval.setCommerceInfo(getEcpdInfo());
		}
		
		if (isDomain) {
			managerApproval.setDomainEntry(getDomainList());
		}
		companyCoreResponse.setManagerApproval(managerApproval);
		return companyCoreResponse;
	}
	
	public DgfFieldShort getFieldDomain() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.EMAIL_DOMAIN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("nirupama@verizon.com");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	public DgfFieldShort getFieldDropdown() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.DROPDOWN);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("");
		field.setReadonly(false);
		field.setRequired(true);
		DgfFieldShortLookup lookup = new DgfFieldShortLookup();
		lookup.setDefaultFlag("Y");
		lookup.setDisplayName("test@gmai.com");
		lookup.setValue("test");
		DgfFieldShortLookup lookup1 = new DgfFieldShortLookup();
		lookup1.setDefaultFlag("N");
		lookup1.setDisplayName("new@gmai.com");
		lookup1.setValue("new");
		List<DgfFieldShortLookup> listLookup = new ArrayList<DgfFieldShortLookup>();
		listLookup.add(lookup);
		listLookup.add(lookup1);
		field.setLookUp(listLookup);
		return field;
	}

	public DgfFieldShort getFieldText() {
		DgfFieldShort field = new DgfFieldShort();
		field.setDgfDataType(Constants.INPUT_TEXT);
		field.setLookUp(null);
		field.setDgfDataFormat(Constants.EMAIL);
		field.setPrePopulatedValue("Ramya.Shivakumar@verizoniwireless.com");
		field.setReadonly(false);
		field.setRequired(true);
		return field;
	}

	public ManageApprovalOrderDto getManagerApprovalOrder(String type, boolean isOrderType, boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if (isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if (isOrderThreshold) {
			orderDto.setOt(getFieldText());
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(1);
		orderDto.setQuantityThresholdValueNAO("Greater Than/Equal To");
		orderDto.setQuanttityThresholdNAO(true);
		orderDto.setOrderThresholdRule("Less Than/Equal To");
		orderDto.setOrderThresholdValue(29);
		return orderDto;
	}

	public ManageApprovalOrderDto getManagerApprovalOrder1(String type, boolean isOrderType, boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if (isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if (isOrderThreshold) {
			orderDto.setOt(getFieldText());
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(4);
		orderDto.setQuantityThresholdValueNAO("Less Than/Equal To");
		orderDto.setQuanttityThresholdNAO(true);
		orderDto.setOrderThresholdRule("Greater Than/Equal To");
		orderDto.setOrderThresholdValue(25);
		return orderDto;
	}

	public ManageApprovalOrderDto getManagerApprovalOrderMissingQuantity(String type, boolean isOrderType,
			boolean isOrderThreshold) {
		ManageApprovalOrderDto orderDto = new ManageApprovalOrderDto();
		orderDto.setOrderType(isOrderType);
		orderDto.setOrderThreshold(isOrderThreshold);
		orderDto.setManagerApprovalSuppress(true);
		if (type == "Dropdown") {
			orderDto.setManagerApproval(getFieldDropdown());
		} else if (type == "Domain") {
			orderDto.setManagerApproval(getFieldDomain());
		} else {
			orderDto.setManagerApproval(getFieldText());
		}

		if (isOrderType) {
			orderDto.setNao(getFieldText());
		}
		if (isOrderThreshold) {
			orderDto.setOt(getFieldText());
		}
		orderDto.setNaoEnable(true);
		orderDto.setQuantityNAO(1);
		orderDto.setQuantityThresholdValueNAO("Less Than/Equal To");
		orderDto.setQuanttityThresholdNAO(false);
		orderDto.setOrderThresholdRule("Greater Than/Equal To");
		orderDto.setOrderThresholdValue(27);
		return orderDto;
	}

	public CustomizationEcpdProfileDto getCustomicationEcpdProfile(int urlStatus) {
		CustomizationEcpdProfileDto profileDto = new CustomizationEcpdProfileDto();
		profileDto.setManagerApprovalState(urlStatus);
		profileDto.setManagerApprovalVariable(1);
		profileDto.setUrlStatus(urlStatus);
		return profileDto;
	}

	public DgfDto getDgfDto(String type, int urlStatus, boolean isManageAllOrders, boolean isOrderType,
			boolean isOrderThreshold) {
		DgfDto dgfDto = new DgfDto();
		ManageApprovalMiscDto miscDto = new ManageApprovalMiscDto();
		miscDto.setManageAllOrders(isManageAllOrders);
		dgfDto.setManageApprovalMiscDto(miscDto);
		if (urlStatus == 1)
			dgfDto.setManageApprovalOrder(getManagerApprovalOrder1(type, isOrderType, isOrderThreshold));
		else if (urlStatus == 0)
			dgfDto.setManageApprovalOrder(getManagerApprovalOrder(type, isOrderType, isOrderThreshold));
		dgfDto.setEcpdProfile(getCustomicationEcpdProfile(urlStatus));
		dgfDto.setViewOnly(new ViewOnlyDto());
		return dgfDto;
	}

	public CheckoutCustomization getCustomizationResponse(String type, int urlStatus, boolean isManageAllOrders,
			boolean isOrderType, boolean isOrderThreshold) {
		CheckoutCustomization checkoutRes = new CheckoutCustomization();
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		checkoutRes.setServiceStatus(serviceStatus);
		checkoutRes.setDgf(getDgfDto(type, urlStatus, isManageAllOrders, isOrderType, isOrderThreshold));
		return checkoutRes;
	}

	public DgfDto getDgfDtoMissingQty(String type, int urlStatus, boolean isManageAllOrders, boolean isOrderType,
			boolean isOrderThreshold) {
		DgfDto dgfDto = new DgfDto();
		ManageApprovalMiscDto miscDto = new ManageApprovalMiscDto();
		miscDto.setManageAllOrders(isManageAllOrders);
		dgfDto.setManageApprovalMiscDto(miscDto);
		dgfDto.setManageApprovalOrder(getManagerApprovalOrderMissingQuantity(type, isOrderType, isOrderThreshold));
		dgfDto.setEcpdProfile(getCustomicationEcpdProfile(urlStatus));
		dgfDto.setViewOnly(new ViewOnlyDto());
		return dgfDto;
	}

	public CheckoutCustomization getCustomizationResponseMisingQty(String type, int urlStatus,
			boolean isManageAllOrders, boolean isOrderType, boolean isOrderThreshold) {
		CheckoutCustomization checkoutRes = new CheckoutCustomization();
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
		serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		checkoutRes.setServiceStatus(serviceStatus);
		checkoutRes.setDgf(getDgfDtoMissingQty(type, urlStatus, isManageAllOrders, isOrderType, isOrderThreshold));
		return checkoutRes;
	}

	private Equipment getCartAccessory() {
		Equipment equipment = new Equipment();
		equipment.setProductCode("VPC48BLK");
		equipment.setQuantity(3);
		return equipment;
	}

	public CartResponse getCartResponse() {
		CartResponse cartRes = new CartResponse();
		Cart cart = new Cart();
		cart.setCartId("Cart_c1dd38ca-63d8-45d7-9634-c5fc6fe01039");
		AccessoryPackage accessoryPackage = new AccessoryPackage();
		List<Equipment> equipmentList = new ArrayList();
		equipmentList.add(getCartAccessory());
		accessoryPackage.setEquipmentList(equipmentList);
		accessoryPackage.setTotalDueNow(24.32);
		cart.setAccessoryPackage(accessoryPackage);
		cartRes.setCart(cart);
		return cartRes;
	}

	@Test
	public void test_ManagerApprovalInfoCache() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(managerApprovalServiceRes);
		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalInfo() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCompanyOrderData());
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCustomizationResponse());
		
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getFetchCartResponse());


		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());
		assertNotNull(serviceRes);
	}

	private CartResponse getFetchCartResponse() {
		String cartResponse = "{\"serviceStatus\":{\"success\":true,\"message\":\"Fetched Cart Successfully\",\"statusCode\":\"0\",\"statusMessage\":\"Fetched Cart Successfully\"},\"cartDetails\":{\"totalQuantity\":1,\"dueNow\":154.99,\"dueMonthly\":0,\"cartItems\":[{\"bestPrice\":154.99,\"retailPrice\":154.99,\"color\":\"Sand Leather\",\"name\":\"Q Accomplice Hybrid Smartwatch\",\"quantity\":1,\"discountPercent\":0,\"discountAmount\":0,\"sku\":\"FSLQACCOMPLICE\"}],\"shippingOption\":{\"shipper\":\"DEFAULT\",\"shippingCode\":\"SHP002\",\"shippingDescription\":\"2 DAY SHIP BY 8PM\",\"shippingType\":\"STANDARD SHIPPING\",\"shippingCost\":0},\"taxAmount\":10.27,\"totalDueNow\":165.26,\"groundShippingRequired\":false,\"taxCity\":\"BASKING RIDGE\",\"taxState\":\"NJ\",\"taxZipcode\":\"07920\"}}";
		return gson.fromJson(cartResponse, CartResponse.class);
	}

	private CheckoutCustomization getCustomizationResponse() {
		String customiZationResponse = "{\"errorCode\":\"0\",\"errorMessage\":\"Successful\",\"serviceStatus\":{\"message\":\"Successful\",\"success\":true,\"statusCode\":\"0\",\"statusMessage\":\"Successful\"},\"sessionReady\":true,\"dgf\":{\"errorCode\":\"0\",\"errorMessage\":\"Successful\",\"dgfId\":1008172997,\"active\":false,\"entityAfflLvl\":null,\"costCenter\":{\"displayName\":\"Cost Center\",\"value\":[],\"fieldName\":\"CU_COST_CENTER\",\"dgfDataType\":\"Input Text\",\"dgfDataFormat\":\"AlphaNumeric\",\"minLength\":0,\"maxLength\":15,\"displaySize\":15,\"displayOrder\":1,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":true,\"uploadON\":null,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":0,\"subDgfFieldId\":{},\"subDropDowns\":null},\"userId\":{\"displayName\":\"User ID\",\"value\":[],\"fieldName\":\"CU_USER_ID\",\"dgfDataType\":\"Input Text\",\"dgfDataFormat\":\"AlphaNumeric\",\"minLength\":0,\"maxLength\":40,\"displaySize\":40,\"displayOrder\":2,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":true,\"uploadON\":null,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":0,\"subDgfFieldId\":{},\"subDropDowns\":null},\"ecpdProfile\":{\"level\":\"0\",\"emailAddress1\":null,\"emailAddress2\":null,\"emailAddress3\":null,\"managerApprovalState\":\"0\",\"urlStatus\":\"1\",\"managerApprovalVariable\":\"0\"},\"couponSuppression\":false,\"defaultPaymentOption\":\"Bill To Account\",\"defaultCreditCard\":null,\"viewOnly\":{\"viewOnlyOn\":false,\"state\":\"Both\",\"defaultMessage\":\"Use this site to browse calling plans and phone offers from Verizon Wireless.  It reflects your company's qualifying discount. You will not be able to submit orders from this site rather it is a browse-only site.  Please contact your company's authorized wireless administrator if you would like to place orders.\",\"customOverrideMessage\":null},\"userInformation\":[{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field1\",\"dgfDataType\":\"Input Text\",\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173100,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field2\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173101,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field3\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173102,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field4\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173103,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field5\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173104,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field6\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173105,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field7\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173106,\"subDgfFieldId\":{},\"subDropDowns\":null},{\"displayName\":null,\"value\":[],\"fieldName\":\"UI_Field8\",\"dgfDataType\":null,\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":null,\"uploadON\":0,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173107,\"subDgfFieldId\":{},\"subDropDowns\":null}],\"subDropDown\":[{\"displayName\":null,\"value\":[],\"fieldName\":\"SubDropdown_1234472936_1234473051\",\"dgfDataType\":\"Dropdown\",\"dgfDataFormat\":null,\"minLength\":0,\"maxLength\":5,\"displaySize\":5,\"displayOrder\":null,\"defaultValue\":null,\"stringValue\":null,\"isRequired\":false,\"isReadonly\":false,\"isHidden\":false,\"enabled\":false,\"uploadON\":null,\"toolTip\":\"N\",\"requiredToolTip\":\"N\",\"parentId\":null,\"dgfFieldId\":1008173099,\"subDgfFieldId\":{},\"subDropDowns\":null}],\"paymentOptions\":{\"billToAccount\":true,\"billToPOEquipment\":true,\"billToCreditCard\":true,\"billToPOService\":false,\"billToPOSoftware\":true},\"fpoBillOptions\":{\"fpoBillToAcctOpt\":[\"GTOET\",\"GT\",\"LTOET\",\"LT\",\"ET\"],\"fpoBillToAcctSelected\":null,\"fpoBillToCreditOpt\":[\"GTOET\",\"GT\",\"LTOET\",\"LT\",\"ET\"],\"fpoBillToCreditSelected\":null,\"fpoBillToPOOpt\":[\"GTOET\",\"GT\",\"LTOET\",\"LT\",\"ET\"],\"fpoBillToPOSelected\":null},\"enableBillTo\":{\"enableBillToAccountFPO\":false,\"enableBillToCreditFPO\":false,\"enableBillToPOFPO\":false},\"billToAmt\":{\"billToAccountFPOAmt\":null,\"billToCreditFPOAmt\":null,\"billToPOFPOAmt\":null},\"creditCard\":{\"mastercard\":true,\"masterCardPF1\":null,\"masterCardPF2\":null,\"masterCardPF3\":null,\"masterCardPF4\":null,\"masterCardPF5\":null,\"visa\":true,\"visaPF1\":null,\"visaPF2\":null,\"visaPF3\":null,\"visaPF4\":null,\"visaPF5\":null,\"discover\":true,\"discoverPF1\":null,\"discoverPF2\":null,\"discoverPF3\":null,\"discoverPF4\":null,\"discoverPF5\":null,\"amex\":true,\"amexPF1\":null,\"amexPF2\":null,\"amexPF3\":null,\"amexPF4\":null,\"amexPF5\":null},\"manageApprovalOrder\":{\"orderType\":false,\"orderThreshold\":false,\"orderThresholdValue\":0,\"orderThresholdRule\":\"Less Than/Equal To\",\"multiOrderEmailForOrder\":null,\"managerApprovalSuppress\":false,\"managerApproval\":{\"dgfDataType\":null,\"dgfDataFormat\":\"Email\",\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"otEnable\":null,\"nseEnable\":true,\"nsoEnable\":true,\"piaEnable\":true,\"eupEnable\":true,\"naoEnable\":true,\"bsoEnable\":true,\"ndoEnable\":true,\"ot\":{\"dgfDataType\":\"Radio Button\",\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"nse\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"nso\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"pia\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"eup\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"nao\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"bso\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"ndo\":{\"dgfDataType\":null,\"dgfDataFormat\":null,\"prePopulatedValue\":null,\"lookUp\":[],\"readonly\":false,\"required\":false},\"quantityNSE\":0,\"quantityThresholdNSE\":true,\"quantityThresholdValueNSE\":\"\",\"quantityNSO\":0,\"quanttityThresholdNSO\":true,\"quantityThresholdValueNSO\":\"\",\"quantityPIA\":0,\"quanttityThresholdPIA\":true,\"quantityThresholdValuePIA\":\"\",\"quantityEUP\":0,\"quanttityThresholdEUP\":true,\"quantityThresholdValueEUP\":\"\",\"quantityNAO\":0,\"quanttityThresholdNAO\":true,\"quantityThresholdValueNAO\":\"\",\"quantityBSO\":0,\"quanttityThresholdBSO\":true,\"quantityThresholdValueBSO\":\"\",\"quantityNDO\":0,\"quantityThresholdNDO\":true,\"quantityThresholdValueNDO\":\"\"},\"recurringPaymentCheckoutOptions\":{\"enableEnrollment\":true,\"enrollmentRequired\":false,\"enableAddCreditCard\":true,\"enableAddBankAccount\":true,\"masterCard\":true,\"masterCardPF\":null,\"visa\":true,\"visaPF\":null,\"discover\":true,\"discoverPF\":null,\"amex\":true,\"amexPF\":null},\"manageApprovalAM\":{\"changeUserInformation\":false,\"cui\":null,\"activationEquipment\":false,\"ae\":null,\"changeCostCenter\":false,\"ccc\":null,\"callMessageBlocking\":false,\"cmb\":null,\"suspendService\":false,\"ss\":null,\"resumeService\":false,\"rs\":null,\"changingCallPlan\":false,\"ccp\":null,\"addRemoveFeatures\":false,\"arf\":null,\"changeVoiceMailPassword\":false,\"cvmp\":null,\"changeWirelessNumber\":false,\"cwn\":null,\"changeBillToAddress\":false,\"cbta\":null,\"deactivateService\":false,\"ds\":null,\"changeBillingResponsibility\":false,\"cbr\":null},\"manageApprovalMisc\":{\"manageAllOrders\":true,\"manageDeviceType\":false,\"manageAccessoryCategory\":false,\"manageDeviceTypeSub\":[{\"deviceTypeSubstring\":\"BlackBerry Devices\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"deviceTypeSubstring\":\"Phones\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"deviceTypeSubstring\":\"Push To Talk\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"deviceTypeSubstring\":\"Broadband Access Devices\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"deviceTypeSubstring\":\"PDA/SmartPhones\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"deviceTypeSubstring\":\"Connected Devices\",\"defaultValue\":false,\"dgfDataType\":\"Input Text\",\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false}],\"manageAccessoryCategorySub\":[{\"accessoryCategorySubstring\":\"Accessory Bundles\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"accessoryCategorySubstring\":\"Battery\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false},{\"accessoryCategorySubstring\":\"Belt Clips & Cases\",\"defaultValue\":true,\"dgfDataType\":null,\"dgfDataFormat\":null,\"lookUp\":[],\"prePolulatedValue\":null,\"readonly\":false,\"required\":false}],\"multiOrderEmailAccessory\":\"\"}},\"savedAddresses\":[{\"id\":1006044,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"PT\",\"address1\":\"200 centennial Ave\",\"address2\":null,\"city\":\"Piscataway\",\"state\":\"NJ\",\"zipCode\":\"08854\",\"firstName\":null,\"lastName\":null,\"companyName\":\"PT\",\"attention\":null,\"phone\":\"425-603-8318\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"Y\",\"createdDate\":\"2019-01-16T18:45:01.000+0000\",\"modifiedDate\":null},{\"id\":1006045,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Small Business\",\"address1\":\"1500 Broadway\",\"address2\":null,\"city\":\"New York\",\"state\":\"NY\",\"zipCode\":\"10036\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Small Business\",\"attention\":null,\"phone\":\"212-944-6789\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T18:51:00.000+0000\",\"modifiedDate\":null},{\"id\":1006042,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Glass\",\"address1\":\"200 White Birch Road\",\"address2\":null,\"city\":\"edison\",\"state\":\"NJ\",\"zipCode\":\"08837\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Glass\",\"attention\":null,\"phone\":\"647-506-5076\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T18:29:28.000+0000\",\"modifiedDate\":null},{\"id\":1006041,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Vz\",\"address1\":\"201 Centennial Ave\",\"address2\":null,\"city\":\"Piscataway\",\"state\":\"NJ\",\"zipCode\":\"08854\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Vz\",\"attention\":null,\"phone\":\"425-603-8318\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T18:12:00.000+0000\",\"modifiedDate\":null},{\"id\":1006021,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Seth\",\"address1\":\"200 Tall Oak Road\",\"address2\":null,\"city\":\"edison\",\"state\":\"NJ\",\"zipCode\":\"08837\",\"firstName\":\"Seth\",\"lastName\":\"Meyers\",\"companyName\":null,\"attention\":null,\"phone\":\"473-425-7045\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"R\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T17:34:06.000+0000\",\"modifiedDate\":null},{\"id\":1006006,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Jack\",\"address1\":\"250 Tall Oak road\",\"address2\":null,\"city\":\"EDISON\",\"state\":\"NJ\",\"zipCode\":\"08837\",\"firstName\":\"Jack\",\"lastName\":\"Straw\",\"companyName\":null,\"attention\":null,\"phone\":\"874-649-8570\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"R\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T17:24:28.000+0000\",\"modifiedDate\":null},{\"id\":1006005,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Business\",\"address1\":\"105 Parsonage Road\",\"address2\":\"floor 1\",\"city\":\"EDISON\",\"state\":\"NJ\",\"zipCode\":\"08837\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Business\",\"attention\":\"Jack\",\"phone\":\"647-570-4685\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T17:12:33.000+0000\",\"modifiedDate\":null},{\"id\":1005694,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Target\",\"address1\":\"700 Keeaumoku St\",\"address2\":null,\"city\":\"Honolulu\",\"state\":\"HI\",\"zipCode\":\"96814\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Target\",\"attention\":null,\"phone\":\"543-536-5647\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-10T18:30:21.000+0000\",\"modifiedDate\":\"2019-01-16T16:08:42.000+0000\"},{\"id\":1005963,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"Test1\",\"address1\":\"909 Knollwood Drive\",\"address2\":null,\"city\":\"Middletown\",\"state\":\"NJ\",\"zipCode\":\"07748\",\"firstName\":null,\"lastName\":null,\"companyName\":\"Test1\",\"attention\":null,\"phone\":\"111-111-1111\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-16T16:00:59.000+0000\",\"modifiedDate\":null},{\"id\":1005721,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"3350 161ST AVE SE\",\"address1\":\"3350 161ST AVE SE\",\"address2\":null,\"city\":\"BELLEVUE\",\"state\":\"WA\",\"zipCode\":\"98008\",\"firstName\":null,\"lastName\":null,\"companyName\":\"UAT2TEST - 5598\",\"attention\":null,\"phone\":\"665-647-5675\",\"email\":\"WestAreaIT-Test@nw.verizonwireless.com\",\"addType\":\"B\",\"ecpdId\":5598,\"alpEnabled\":null,\"defaultShipAddr\":\"N\",\"createdDate\":\"2019-01-11T04:30:38.000+0000\",\"modifiedDate\":\"2019-01-11T13:54:53.000+0000\"},{\"id\":1006201,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"201 centenial ave\",\"address1\":\"201 centenial ave\",\"address2\":null,\"city\":\"piscataway\",\"state\":\"NJ\",\"zipCode\":\"08854\",\"firstName\":null,\"lastName\":null,\"companyName\":null,\"attention\":null,\"phone\":null,\"email\":null,\"addType\":\"A\",\"ecpdId\":null,\"alpEnabled\":null,\"defaultShipAddr\":null,\"createdDate\":\"2019-01-22T08:05:58.000+0000\",\"modifiedDate\":null},{\"id\":1005701,\"userId\":\"5598SELE1061QA2\",\"addrNickName\":\"75 Hamilton Avenue\",\"address1\":\"75 Hamilton Avenue\",\"address2\":\"64 Hamilton Avenue\",\"city\":\"Elmwood Park\",\"state\":\"NJ\",\"zipCode\":\"07407\",\"firstName\":null,\"lastName\":null,\"companyName\":null,\"attention\":null,\"phone\":null,\"email\":null,\"addType\":\"A\",\"ecpdId\":null,\"alpEnabled\":null,\"defaultShipAddr\":null,\"createdDate\":\"2019-01-10T22:13:06.000+0000\",\"modifiedDate\":null}],\"prepopulatedInfo\":{\"companyAddressList\":[],\"savedCreditList\":[],\"savedAccountList\":[],\"savedPOInfos\":[]},\"shippingCustomizer\":{\"errorCode\":\"5025\",\"errorMessage\":\"Shipping Customizer Info not available\",\"shippingVerbiage1\":null,\"suppress1\":false,\"shippingVerbiage2\":null,\"suppress2\":false,\"shippingVerbiage3\":null,\"suppress3\":false,\"address2Label\":null,\"address2LabelRequired\":false,\"shippingAddressSuppress\":false},\"shoppingPathPtmOptionList\":{\"errorCode\":\"0\",\"errorMessage\":\"Successful\",\"isKynChecked\":false,\"shoppingPathPtmOptionList\":[{\"trType\":\"AA\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"EUP\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"HG\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"NAO\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"NDO\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"NSE\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"NSO\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"OTT\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false},{\"trType\":\"PurchSoft\",\"billCcChecked\":false,\"billPoChecked\":false,\"billPoSChecked\":false,\"billPoSoftwareChecked\":false,\"billAcctChecked\":false,\"suppPmtOptChecked\":false}]},\"mbaConfiguration\":{\"opinionLabEnabled\":true,\"webchatEnabled\":false}}";
		return gson.fromJson(customiZationResponse, CheckoutCustomization.class);
	}

	private CompanyCoreResponse getCompanyOrderData() {
	String companyCoreResponse = "{\"serviceStatus\":{\"message\":\"SUCCESS\",\"success\":true,\"statusCode\":\"0\",\"statusMessage\":\"SUCCESS\"},\"businessZip\":\"07920\",\"corporateInfo\":{\"ecpdId\":5598,\"corporateName\":\"UAT2TEST - 5598\",\"corporateCustCareNumber\":\"BGCO LIAISON SUPPORTED ACCOUNTS NC MKT\",\"corporateTaxId\":\"WYEBU8014\",\"corporateTaxExempt\":\"N\",\"corporateManagerApproval\":\"NO\",\"corporateSuppressCredit\":\"NO\",\"corporateEmailTemplateId\":\"25\",\"companyStructureIndicator\":null,\"liabilityType\":\"C\",\"corporateConsolidationCode\":null,\"corporateBillingType\":null},\"myBizCommerceEmails\":{\"orderConfirmationEmail\":[]},\"creditWriteRequestInfo\":{\"locationCode\":\"D771101\"},\"systemData\":{\"marketCode\":\"New York Metro\",\"regionCode\":\"New York Metro\",\"areaName\":\"Northeast\",\"fulfillment\":\"VISION_B2B\",\"databaseID\":\"NY\",\"serviceZipCode\":\"07920\",\"serviceCity\":\"Basking Ridge\",\"serviceState\":\"NJ\"},\"taxInfo\":{\"ecpdProfileId\":5598,\"liabilityType\":\"C\",\"ecpdSegmentProfileType\":\"NATIONAL ACCT CORPORATE\",\"customerTypeVision\":\"NA\",\"taxExemptFlag\":\"N\",\"salesTaxExemptFlag\":\"N\"},\"managerApproval\":{\"commerceInfo\":{\"option\":1,\"approverEmail1\":\"PRADEEP.RAJENDIRAN@VERIZON.COM\",\"approverEmail2\":\"VALLIYAPPAN.SARAVANAN@VERIZONWIRELESS.COM\",\"approverEmail3\":\"\"},\"accountMaintenanceInfo\":{\"option\":0,\"approverEmail1\":\"\",\"approverEmail2\":\"\",\"approverEmail3\":\"\"},\"domainEntry\":[\"verizon.com\"]}}";
		return gson.fromJson(companyCoreResponse, CompanyCoreResponse.class);
	}

	@Test
	public void test_ManagerApprovalNotCached_TextType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 1, true, false, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalNoDgfDto() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization = getCustomizationResponse("", 1, true, false, false);
		checkoutCustomization.setDgf(null);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);

		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalNoManagerApprovalOrder() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization = getCustomizationResponse("", 1, true, false, false);
		checkoutCustomization.getDgf().setManageApprovalOrder(null);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);

		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalDisabled() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false,5);
		companyCoreResponse.getManagerApproval().getCommerceInfo().setOption(0);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 1, true, false, false));

		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalMissingEmails() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false,1);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 1, true, false, false));

		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApproval_CatchBlock() throws Exception {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenThrow(new RuntimeException("testing catch block"));
		// .thenReturn(getCustomizationResponse("", 1, true, false, false));
		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("102");
	}

	@Test
	public void test_ManagerApprovalNotCached_DomainType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(true,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("Domain", 1, true, false, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.getEmailDomainList().size()).isGreaterThan(0);
	}

	@Test
	public void test_ManagerApprovalNotCached_DropdownType() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization	=getCustomizationResponse("Dropdown", 1, true, false, false);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.getLookUp().size()).isGreaterThan(0);
	}

	@Test
	public void test_ManagerApprovalNotCached_EcpdProfile_url() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 0, true, false, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
		assertThat(serviceRes.isManagerApprovalEnabled()).isEqualTo(true);
	}

	@Test
	public void test_ManagerApprovalNotCached_orderTypeNao() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization	=getCustomizationResponse("", 1, false, true, false);
		checkoutCustomization.getDgf().setManageApprovalMiscDto(null);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
	}

	@Test
	public void test_ManagerApprovalNotCached_orderTypeNaoEvaluateOrderThLesser() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 0, false, false, true));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_orderTypeNaoEvaluateOrderThGreater() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("",1, false, false, true));
		CartResponse cartResponse=getCartResponse();
		cartResponse.getCart().getAccessoryPackage().setTotalDueNow(30);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(cartResponse);
		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalNotCached_orderThresholdRulesGreater() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponse("", 0, false, true, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_orderThresholdRulesGreaterFailed() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization =getCustomizationResponse("", 0, false, true, false);
		checkoutCustomization.getDgf().getManageApprovalOrder().setQuantityNAO(5);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalNotCached_orderThresholdRulesLesser() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization =getCustomizationResponse("", 1, false, true, false);
		checkoutCustomization.getDgf().getManageApprovalOrder().setQuantityNAO(5);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_orderThresholdRulesLessFailed() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization =getCustomizationResponse("", 1, false, true, false);
		checkoutCustomization.getDgf().getManageApprovalOrder().setQuantityNAO(1);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	@Test
	public void test_ManagerApprovalNotCached_quantityThresholdMissing() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCustomizationResponseMisingQty("", 2, false, true, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}

	@Test
	public void test_ManagerApprovalNotCached_MissingNao() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);

		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,5));
		CheckoutCustomization checkoutCustomization = getCustomizationResponseMisingQty("", 1, false, true, false);
		checkoutCustomization.getDgf().getManageApprovalOrder().setNaoEnable(false);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_MissingEcpdProfile() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false,1);
		companyCoreResponse.getManagerApproval().setCommerceInfo(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		CheckoutCustomization checkoutCustomization = getCustomizationResponseMisingQty("", 1, false, true, false);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_ecpdState() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization checkoutCustomization = getCustomizationResponseMisingQty("", 1, false, true, false);
		checkoutCustomization.getDgf().getEcpdProfile().setManagerApprovalState(1);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	
	@Test
	public void test_ManagerApprovalNotCached_emptyDomainList() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);
		CompanyCoreResponse companyCoreResponse = getCompanyCoreRes(false,1);
		companyCoreResponse.getManagerApproval().setDomainEntry(new String[0]);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(companyCoreResponse);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
		.thenReturn(getCustomizationResponse("Domain", 1, true, false, false));
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	@Test
	public void test_ManagerApprovalNotCached_ecpdState2() throws Exception {

		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(null);
		Mockito.when(companyClient.getCompanyOrderData(Mockito.isA(CommonRequest.class)))
				.thenReturn(getCompanyCoreRes(false,1));
		CheckoutCustomization checkoutCustomization = getCustomizationResponseMisingQty("", 1, false, true, false);
		checkoutCustomization.getDgf().getEcpdProfile().setManagerApprovalState(2);
		Mockito.when(customizationClient.getCustomizationInfo(Mockito.isA(CommonRequest.class)))
				.thenReturn(checkoutCustomization);
		Mockito.when(cartCore.retrieveCart(Mockito.isA(CommonRequest.class))).thenReturn(getCartResponse());

		ManagerApprovalInfo serviceRes = managerService.getManagerApprovalInfo(getManagerApprovalRequest());

		assertNotNull(serviceRes);
		assertThat(serviceRes.getServiceStatus().getStatusCode()).isEqualTo("200");
	}
	@Test
	public void saveManagerApprovalDetails_Test() {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject()))
				.thenReturn(managerApprovalServiceRes);

		ManagerApprovalData maReq = new ManagerApprovalData();
		maReq.setEcpdId("9789");
		maReq.setLevel("1");
		maReq.setMaApprovalUrl("https://b2b.verizonwireless.com/b2b/commerce/webflow/lowerfunnel/checkout-manager");
		maReq.setOrderNumber("MB7000000349830");

		Mockito.when(managerApprovalRepo.save(Mockito.isA(ManagerApprovalTracker.class)))
				.thenReturn(new ManagerApprovalTracker());
		Mockito.when(maTrackerRepo.save(Mockito.isA(ManagerApprovalUrl.class))).thenReturn(new ManagerApprovalUrl());

		ManagerApprovalResponse maResp = managerService.saveManagerApprovalDetails(maReq);
		assertNotNull(maResp);
		assertThat(maResp.getServiceStatus().getStatusCode()).isEqualTo(Constants.SUCCESS_CODE);

	}
	
	private ManagerApprovalRequest getManagerApprovalRequest() {
		ManagerApprovalRequest approvalRequest = new ManagerApprovalRequest();
		approvalRequest.setCreds("test");
		approvalRequest.setUserId("582760MBTQA1");
		approvalRequest.setEcpdId("582760");
		approvalRequest.setTransactionType("EPBNAO");
		approvalRequest.setZipCode("30004");
		return approvalRequest;
	}
	
	@Test
	public void test_updateManagerApprovalInfo() {
		Mockito.when(managerApprovalSession.getFromSession(Mockito.anyString(), Mockito.anyObject())).thenReturn(managerApprovalServiceRes);
		ManagerApprovalRequest request = getManagerApprovalRequest();
		request.setApproverEmailIds("girish@verizon.com");
		request.setLevel("1");
		managerService.updateManagerApprovalInfo(request);
	}
}
