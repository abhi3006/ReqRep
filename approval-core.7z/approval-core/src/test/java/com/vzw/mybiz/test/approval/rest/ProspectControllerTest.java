package com.vzw.mybiz.test.approval.rest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferReq;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferUiRes;
import com.vzw.mybiz.approval.rest.ProspectController;
import com.vzw.mybiz.approval.service.PlanService;
import com.vzw.mybiz.approval.service.VipRestService;
import com.vzw.mybiz.prospect.domain.CartHeader;
import com.vzw.mybiz.prospect.domain.ECPDInfo;
import com.vzw.mybiz.prospect.domain.LineDetails;
import com.vzw.mybiz.prospect.domain.LineInfo;
import com.vzw.mybiz.prospect.domain.Root;
import com.vzw.mybiz.prospect.domain.ServiceInfo;
import com.vzw.mybiz.prospect.domain.plan.PlanRequest;
import com.vzw.mybiz.prospect.domain.pos.POSServices;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

@RunWith(SpringRunner.class)
public class ProspectControllerTest {
	
	private MockMvc mockMvc;
	private Gson gson = new Gson();
	@Spy
	@InjectMocks
	ProspectController prospectController;
	
	@Mock
	private VipRestService posService;
	
	@Mock
	private PlanService planService;
	
	public MvcResult getMvcResult(String url, Root cartObject) {
		try {
			return mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON_VALUE).content(gson.toJson(cartObject)))
					.andExpect(status().isOk()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public MvcResult getMvcResult(String url, String cartObject) {
		try {
			return mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON_VALUE).content(cartObject))
					.andExpect(status().isOk()).andReturn();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(prospectController).build();
	}
	
	@Test
	public void test_prospectOrder() throws Exception {
		
		String json = "{\"cartHeader\":{\"sourceSystem\":\"MYBIZ\",\"fullAccountNumber\":\"\",\"mtn\":\"\",\"status\":\"A\",\"lockStatus\":\"\",\"lockingSystem\":\"MYBIZ\",\"lastAccessSystem\":\"MYBIZ\",\"originatingSalesRep\":\"\",\"lastAccessSalesRep\":\"\",\"businessName\":\"HIJ CORP\",\"ecpdInfo\":{\"ecpdID\":\"\"},\"userId\":\"MYBIZ\",\"systemId\":\"MYBIZ\"},\"orderDetails\":{\"customerType\":\"N\",\"accountType\":null,\"locationCode\":null,\"homeLocation\":null,\"storeLocation\":null,\"orderType\":null,\"totalTaxAmount\":0,\"taxPrices\":null,\"spocs\":null,\"totalDueToday\":0.0,\"totalDueMonthly\":0,\"isAttachmentCompleted\":false,\"effectiveDate\":null,\"barCodes\":null},\"lineDetails\":{\"cartId\":null,\"cartLineMap\":null,\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":0,\"lineActivityType\":\"NEW\",\"saleType\":null,\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"RAVI\",\"lastName\":\"WRIGHT\",\"address\":{\"aptNum\":\"N\",\"streetNum\":\"314\",\"streetName\":\"S HIGHWAY 62 65\",\"type\":null,\"city\":\"NEWYORK\",\"state\":\"AK\",\"zipCode\":\"ksdfjksdfhjk\",\"country\":\"USA\"},\"isValidAddress\":false},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":null,\"min\":null,\"mea\":null,\"oldPricePlanId\":null,\"newPricePlanId\":null,\"contractTermId\":null,\"activateDeviceOnDsdsImei\":null,\"pricePlanInfo\":{\"pricePlanCategory\":\"N\",\"ratePlanType\":null,\"accessFeeRange\":null,\"contractRange\":null,\"contractDuration\":0,\"pricePlanCode\":null,\"pricePlanDesc\":null,\"contractTermId\":null},\"selectedFeaturesList\":{\"visFeature\":null},\"selectedALPShareList\":null,\"correlationID\":null,\"currentDevice\":null,\"orderDevice\":null,\"planDetails\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"itemsInfo\":[{\"depletionType\":null,\"upgradeInd\":null,\"attention\":null,\"addrType\":null,\"shipping\":null,\"fipsCode\":null,\"taxExemptionTypes\":null,\"itemCount\":2,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"dev6400127\",\"sorId\":\"dev6400127\",\"cartItemType\":\"device\",\"description\":\"trade\",\"qty\":1,\"itemPrice\":null,\"taxAmount\":0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"discounts\":null,\"availableReasonCode\":null,\"depletionType\":null,\"unitTaxBasedPrice\":0,\"itemCost\":0,\"itemNrpPrice\":0,\"itemPriceType\":null},{\"itemCode\":\"dev6400128\",\"sorId\":\"dev6400128\",\"cartItemType\":\"device\",\"description\":\"trade\",\"qty\":1,\"itemPrice\":null,\"taxAmount\":0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"discounts\":null,\"availableReasonCode\":null,\"depletionType\":null,\"unitTaxBasedPrice\":0,\"itemCost\":0,\"itemNrpPrice\":0,\"itemPriceType\":null}]},\"mtnLevelEmail\":\"MANISHA.GANDHI@VERIZON.COM\"}],\"totalDueToday\":0.0,\"totalDueTodayWithoutTax\":0.0,\"totalDueMonthly\":0,\"mobileNumber\":\"8703656322\",\"validationMessages\":null,\"impactedLine\":false,\"assignMTNIndicator\":null,\"salesRepId\":null,\"preOrBackOrder\":false,\"panelPricing\":null,\"taxPrices\":null,\"installmentContractDetail\":null,\"ispuItem\":false}],\"validationMessages\":null,\"payments\":null,\"lineSeq\":0,\"fivegOrderind\":false,\"humDeviceinOrder\":false}}";
		
		Root cartRoot = new Root();
		Mockito.when(
				posService.submitProspectOrder(Mockito.isA(String.class), Mockito.isA(Root.class)))
				.thenReturn(new ServiceStatus());
		
		
		
		MvcResult mvcResult = getMvcResult("/mbt/prospect/submit", json);
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch(Exception e) {
			e.getStackTrace();
		}
	}
	
	@Test
	public void test_computeSedOffer() throws Exception {
		
		String json = "{\"ServiceHeader\":{\"userName\":\"OAS\",\"password\":\"*********\",\"clientAppName\":\"MYBUSINESS\",\"clientAppUserName\":\"loginUser\",\"serviceName\":\"offerManagement\",\"serviceAction\":\"retrieveOffers\",\"applicationResponseCode\":\"99000\",\"applicationResponseClass\":\"SUCCESS\",\"applicationResponseMessage\":\"[ESQA1pos:vipsvcs01:01]Transaction processed successfully.\",\"applicationResponseDetails\":null,\"timeStamp\":\"2020-04-21T14:16:37.993-04:00\",\"responseFormat\":\"XML\",\"loggingId\":\"ddfadfe5fb6c3795\"},\"ServiceBody\":{\"computeOffer\":{\"response\":{\"subsetResponse\":{\"subsetId\":\"Upgrade\",\"lineInfoOffer\":{\"lineNum\":\"1\",\"orderMtn\":\"9016264932\",\"itemOffer\":[{\"itemSeqNum\":\"1\",\"itemCode\":\"S6371LL/BUS\",\"productType\":\"ACCESSORY\",\"priceOption\":[{\"itemPriceType\":\"R\",\"itemPrice\":\"199.97\",\"itemNetPrice\":\"199.97\",\"bestPriceInd\":\"Y\"},{\"itemPriceType\":\"E\",\"itemPrice\":\"199.97\",\"itemNetPrice\":\"199.97\",\"bestPriceInd\":\"N\"}]},{\"itemSeqNum\":\"2\",\"itemCode\":\"MTAH2LL/A\",\"productType\":\"PHONE\",\"priceOption\":{\"itemPriceType\":\"R\",\"itemPrice\":\"549.99\",\"itemNetPrice\":\"549.99\",\"bestPriceInd\":\"Y\"}},{\"itemSeqNum\":\"3\",\"itemCode\":\"SHP002\",\"productType\":\"SHP\",\"priceOption\":{\"itemPriceType\":\"R\",\"itemPrice\":\"0\",\"itemNetPrice\":\"0.00\",\"bestPriceInd\":\"Y\"}}]}}}}}}";
		
		Mockito.when(
				posService.computeOffer(Mockito.isA(ComputeOfferReq.class)))
				.thenReturn(new ComputeOfferUiRes());
		
		
		
		MvcResult mvcResult = getMvcResult("/mbt/prospect/computeSedOffer", json);
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch(Exception e) {
			e.getStackTrace();
		}
	}
	
	@Test
	public void test_prospectOrde_errr() throws Exception {
		
		Root cartRoot = new Root();
		cartRoot.setCartHeader(new CartHeader());
		cartRoot.getCartHeader().setEcpdInfo(new ECPDInfo());
		cartRoot.setLineDetails(new LineDetails());
		List<LineInfo> lInfoLst = new ArrayList<LineInfo>();
		lInfoLst.add(new LineInfo());
		cartRoot.getLineDetails().setLineInfo(lInfoLst);
		cartRoot.getLineDetails().getLineInfo().get(0).setServiceInfo(new ServiceInfo());
//		Mockito.when(
//				posService.submitProspectOrder(Mockito.isA(POSServices.class)))
//				.thenReturn(null);
		
		
		
		MvcResult mvcResult = getMvcResult("/mbt/prospect/submit", cartRoot);
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch (Exception e){}
	}
	
	@Test
	public void test_prospectOrde_errr1() throws Exception {
		
		Root cartRoot = new Root();
		cartRoot.setCartHeader(new CartHeader());
		cartRoot.setLineDetails(new LineDetails());
		List<LineInfo> lInfoLst = new ArrayList<LineInfo>();
		lInfoLst.add(new LineInfo());
		cartRoot.getLineDetails().setLineInfo(lInfoLst);
		cartRoot.getLineDetails().getLineInfo().get(0).setServiceInfo(new ServiceInfo());
//		Mockito.when(
//				posService.submitProspectOrder(Mockito.isA(POSServices.class)))
//				.thenReturn(null);
		
		
	//	posService = null;
		
		Mockito.when(
				posService.submitProspectOrder(Mockito.isA(String.class), Mockito.isA(Root.class)))
				.thenReturn(null);
		MvcResult mvcResult = getMvcResult("/mbt/prospect/submit", cartRoot);
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch (Exception e) {
			
		}
	}
	
	@Test
	public void test_prospectError() throws Exception{
		prospectController.base64Encode(null);
	}
	
	@Test
	public void test_prospectCompress_errr() throws Exception {
		prospectController.compress(null);
	}
	
	@Test
	public void testPlansFetch() {
		
		String json = "{\"planCatagoryType\": \"\",\"deviceSku\": \"OCPO3APL6SP16RG\",\"simSku\": \"DFILLSIM4FF-A\",\"ecpd\":\"5507564\",\"address\":{\"zipCode\":\"07407\"}}";
		
		Mockito.when(
				planService.fetchDeviceCompatiblePlans(Mockito.isA(PlanRequest.class)))
				.thenReturn(new HashMap());
		
		MvcResult mvcResult = getMvcResult("/mbt/prospect/getDeviceCompatiblePlans", json);
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch(Exception e) {
			e.getStackTrace();
		}
		
	}
	
	@Test
	public void testPlanFetch_Error() {
		MvcResult mvcResult = getMvcResult("/mbt/prospect/getDeviceCompatiblePlans", "{}");
		try{
		gson.fromJson(mvcResult.getResponse().getContentAsString(),
				Object.class);
		} catch(Exception e) {
			e.getStackTrace();
		}
	}
	

}
