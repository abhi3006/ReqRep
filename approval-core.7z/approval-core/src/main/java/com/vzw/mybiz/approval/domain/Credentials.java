package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.annotation.Configuration;

import com.vzw.mybiz.transformation.security.helpers.EncryptionHelper;
@Configuration
public class Credentials implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2868334316519754505L;
	private static final Log LOGGER = LogFactory.getLog(Credentials.class);

	private String encryptedText;
	
	private String plainText;
	public String getPlainText() {
		return plainText;
	}

	public void setPlainText(String plainText) {
		this.plainText = plainText;
	}
	public void setEncryptedText(String encryptedText) {
		this.encryptedText = encryptedText;
	}

	public String getDecryptedText() {
		String decryptedText = new String();
		try {
			decryptedText = EncryptionHelper.decryptAes(this.encryptedText);
		} catch (Exception e) {
			LOGGER.error("Unable to decrypt the creds", e);
		}
		return decryptedText;
	}
	
	public String getEncryptedText() {

		String encrptedValue = new String();
		try {
			encrptedValue = EncryptionHelper.encryptAes(this.getPlainText());
		} catch (Exception e) {
			LOGGER.error("Unable to decrypt the creds", e);
		}
		return encrptedValue;
	}
}
