package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeatureInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String featureName;
	private int mtnCount = 0;
	private Set<MtnInfo> mtnList;
	/**
	 * @return the mtnList
	 */
	public final Set<MtnInfo> getMtnList() {
		return mtnList;
	}
	/**
	 * @param mtnList the mtnList to set
	 */
	public final void setMtnList(Set<MtnInfo> mtnList) {
		this.mtnList = mtnList;
	}
	/**
	 * @return the featureName
	 */
	public final String getFeatureName() {
		return featureName;
	}
	/**
	 * @param featureName the featureName to set
	 */
	public final void setFeatureName(String featureName) {
		this.featureName = featureName;
	}
	/**
	 * @return the mtnCount
	 */
	public final int getMtnCount() {
		if(mtnList!=null){
			mtnCount = mtnList.size();
		}
		return mtnCount;
	}
	/**
	 * @param mtnCount the mtnCount to set
	 */
	public final void setMtnCount(int mtnCount) {
		this.mtnCount = mtnCount;
	}
	/**
	 * @return the mtnList
	 *//*
	public final List<MtnInfo> getMtnList() {
		return mtnList;
	}
	*//**
	 * @param mtnList the mtnList to set
	 *//*
	public final void setMtnList(List<MtnInfo> mtnList) {
		this.mtnList = mtnList;
	}*/
	
	
	public void addToMtnList(MtnInfo mtnInfo){
		if(mtnList == null){
			mtnList = new HashSet<MtnInfo>();
		}
		mtnList.add(mtnInfo);
	}
}