package com.vzw.mybiz.approval.starter.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import com.vzw.mybiz.approval.client.DunsApiClient;
import com.vzw.mybiz.decrypt.util.DecryptionUtil;

import feign.Feign;
import feign.Logger.Level;
import feign.Request.Options;
import feign.auth.BasicAuthRequestInterceptor;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;

@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "duns")
public class DunsConfig {
	@Autowired
	private DecryptionUtil decryptionUtil;

	private String username;
	private String passwordEncrypted; // we have to decrypt it

	private String clientId;
	private String base_uri;
	private String addressmatch_endpoint;
	private String standardizedaddress_endpoint;
	private String connectTimeout;
	
	private String readTimeout;

	public String getUsername() {
		return username;
	}

	public String getClientId() {
		return clientId;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPasswordEncrypted() {
		return passwordEncrypted;
	}

	public void setPasswordEncrypted(String passwordEncrypted) {
		this.passwordEncrypted = passwordEncrypted;
	}
	/**
	 * @return the base_uri
	 */
	public String getBase_uri() {
		return base_uri;
	}

	/**
	 * @param base_uri the base_uri to set
	 */
	public void setBase_uri(String base_uri) {
		this.base_uri = base_uri;
	}

	/**
	 * @return the addressmatch_endpoint
	 */
	public String getAddressmatch_endpoint() {
		return addressmatch_endpoint;
	}

	/**
	 * @param addressmatch_endpoint the addressmatch_endpoint to set
	 */
	public void setAddressmatch_endpoint(String addressmatch_endpoint) {
		this.addressmatch_endpoint = addressmatch_endpoint;
	}

	/**
	 * @return the standardizedaddress_endpoint
	 */
	public String getStandardizedaddress_endpoint() {
		return standardizedaddress_endpoint;
	}

	/**
	 * @param standardizedaddress_endpoint the standardizedaddress_endpoint to set
	 */
	public void setStandardizedaddress_endpoint(String standardizedaddress_endpoint) {
		this.standardizedaddress_endpoint = standardizedaddress_endpoint;
	}

	public String getConnectTimeout() {
		return connectTimeout;
	}

	public void setConnectTimeout(String connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public String getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(String readTimeout) {
		this.readTimeout = readTimeout;
	}

	@Bean(name = "dunsApiClient")
	@RefreshScope
	@Lazy
	public DunsApiClient dunsApiClient() {
		return Feign.builder().client(new OkHttpClient())
				.requestInterceptor(new BasicAuthRequestInterceptor(this.getUsername(),
						decryptionUtil.voltageDecrypt(this.getPasswordEncrypted())))
				.options(new Options(Integer.parseInt(getConnectTimeout()), Integer.parseInt(getReadTimeout())))
				.logger(new Slf4jLogger(DunsApiClient.class)).logLevel(Level.BASIC)
				.target(DunsApiClient.class, this.getBase_uri());
	}
}
