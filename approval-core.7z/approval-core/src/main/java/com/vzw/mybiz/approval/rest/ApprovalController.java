	package com.vzw.mybiz.approval.rest;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AutoNotificationRequest;
import com.vzw.mybiz.approval.domain.AutoNotificationResponse;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.accessory.AccessoryGridwallResponse;
import com.vzw.mybiz.approval.domain.devices.BrowseFilterDetails;
import com.vzw.mybiz.approval.domain.devices.BrowseFilterDetails.FilterDetails;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferReq;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferUiRes;
import com.vzw.mybiz.approval.domain.devices.DeviceDetails;
import com.vzw.mybiz.approval.domain.devices.DeviceGridwallResponse;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsRequest;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalAccountLevelResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMInfo;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.approval.exception.ApprovalException;
import com.vzw.mybiz.approval.service.ApprovalService;
import com.vzw.mybiz.approval.service.ApprovalServiceSM;
import com.vzw.mybiz.approval.service.BatchService;
import com.vzw.mybiz.approval.service.SmCpcService;
import com.vzw.mybiz.approval.service.VipRestService;
import com.vzw.mybiz.approval.service.ManagerService;
import com.vzw.mybiz.approval.service.ManagerServiceSM;
import com.vzw.mybiz.approval.service.impl.DeviceServiceImpl;
import com.vzw.mybiz.domain.pos.retrieveorder.ReadOrder;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

@RestController
@RequestMapping("/mbt/approval")
public class ApprovalController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApprovalController.class);

	@Autowired
	private ApprovalService approvalService;

	@Autowired
	private ManagerService managerService;

	@Autowired
	private ApprovalServiceSM approvalServiceSM;

	@Autowired
	private ManagerServiceSM managerServiceSM;

	@Autowired
	private BatchService batchService;
	
	@Autowired
	DeviceServiceImpl deviceService;
	
	@Autowired
	SmCpcService smCpcService;
	
	@Autowired
	private VipRestService posService;

	@PostMapping(value = "/approvalLanding", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse getManagerApprovalLandingInfo(@RequestBody ManagerApprovalRequest maRequest)
			throws ApprovalException {
		LOGGER.info("Calling Manager approval landing page");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		if (StringUtils.isNotBlank(maRequest.getCreds())) {
			response = approvalService.getOrderInformation(maRequest);
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.CREDS_MISSING);
			response.setServiceStatus(serviceStatus);
		}
		return response;
	}

	@PostMapping(value = "/approvalProcess", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse approve(@RequestBody ManagerApprovalRequest maRequest) throws ApprovalException {
		LOGGER.info("Initiating approval flow page");
		ManagerApprovalResponse response ;
		if (maRequest.isApprovalStatus()) {
			response = approvalService.makeApprovalCall(maRequest);
		} else {
			response = approvalService.makeRejectionCall(maRequest);
		}
		return response;
	}

	@PostMapping(value = "/getMAInformation", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalInfo getManagerApprovalInfo(@RequestBody ManagerApprovalRequest maRequest)
			throws ApprovalException {
		LOGGER.info("Retrive ManagerApproval Information");
		ManagerApprovalInfo approvalInfo = new ManagerApprovalInfo();
		if (StringUtils.isNotBlank(maRequest.getEcpdId()) && StringUtils.isNotBlank(maRequest.getUserId())) {
			approvalInfo = managerService.getManagerApprovalInfo(maRequest);
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			approvalInfo.setServiceStatus(serviceStatus);
		}
		return approvalInfo;
	}

	@PostMapping(value = "/saveMAInformation", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse saveManagerApprovalInfo(@RequestBody ManagerApprovalData managerApprovalData)
			throws ApprovalException {
		LOGGER.info("Save ManagerApproval Information and URL");
		ManagerApprovalResponse approvalInfo = new ManagerApprovalResponse();
		if (StringUtils.isNotBlank(managerApprovalData.getEcpdId())) {
			approvalInfo = managerService.saveManagerApprovalDetails(managerApprovalData);
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			approvalInfo.setServiceStatus(serviceStatus);
		}
		return approvalInfo;
	}

	@PostMapping(value = "/updateManagerInfo", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalResponse updateManagerInfo(@RequestBody ManagerApprovalRequest maRequest) {
		LOGGER.info("Update user selected information to session ");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		if (StringUtils.isNotBlank(maRequest.getApproverEmailIds()) && StringUtils.isNotBlank(maRequest.getEcpdId())) {
			LOGGER.info("User Selected email Address : {} " , maRequest.getApproverEmailIds());
			ServiceStatus serviceStatus = managerService.updateManagerApprovalInfo(maRequest);
			response.setServiceStatus(serviceStatus);
		} else {
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			response.setServiceStatus(serviceStatus);
		}
		return response;
	}

	@PostMapping(value = "getMAInformationSM", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalSMInfo getMAInformationSM(@RequestBody ManagerApprovalSMRequest maAmRequest) {
		LOGGER.info("Calling ManagerApproval SM Information");
		ManagerApprovalSMInfo smManagerApprovalInfo = new ManagerApprovalSMInfo();
		if (StringUtils.isNotBlank(maAmRequest.getEcpdId()) && StringUtils.isNotBlank(maAmRequest.getUserId())) {
			smManagerApprovalInfo = managerServiceSM.getManagerApprovalSMInfo(maAmRequest);
		} else {
			com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			serviceStatus.setSuccess(false);
			smManagerApprovalInfo.setServiceStatus(serviceStatus);
		}
		LOGGER.info("Successfully retrieved ManagerApproval SM Information");
		return smManagerApprovalInfo;
	}
	

	@PostMapping(value = "/approvalLandingSM", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalSMResponse getMALandingSMInfo(@RequestBody ManagerApprovalSMRequest maRequest)
			throws ApprovalException {
		LOGGER.info("Calling Manager approval landing page SM");
		ManagerApprovalSMResponse response = new ManagerApprovalSMResponse();
		if (StringUtils.isNotBlank(maRequest.getCreds())) {
			response = approvalServiceSM.getSMInformation(maRequest);
		} else {
			com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.CREDS_MISSING);
			serviceStatus.setSuccess(false);
			response.setServiceStatus(serviceStatus);
		}
		LOGGER.info("Successfully retrieved Manager approval landing page SM");
		return response;
	}
	
	/**
	 * <p>
	 * This method is used to show transaction details on
	 * manager approval landing page for account level transactions
	 * </p>
	 * 
	 * @param ManagerApprovalSMRequest
	 * @return ManagerApprovalAccountLevelResponse
	 */
	@PostMapping(value = "/approvalLandingSMAccountLevel", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalAccountLevelResponse getMALandingAccountLevelInfo(@RequestBody ManagerApprovalSMRequest maRequest)
			throws ApprovalException {
		LOGGER.info("Calling Manager approval landing page SM");
		ManagerApprovalAccountLevelResponse response = new ManagerApprovalAccountLevelResponse();
		if (StringUtils.isNotBlank(maRequest.getCreds())) {
			response = approvalServiceSM.getAccountLevelSMInformation(maRequest);
		} else {
			com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.CREDS_MISSING);
			serviceStatus.setSuccess(false);
			response.setServiceStatus(serviceStatus);
		}
		LOGGER.info("Successfully retrieved Manager approval landing page SM");
		return response;
	}

	@PostMapping(value = "/approvalProcessingSM", produces = MediaType.APPLICATION_JSON_VALUE)
	public ManagerApprovalSMResponse approvalProcessingSM(@RequestBody ManagerApprovalSMRequest maRequest)
			throws ApprovalException {
		LOGGER.info("Initiating approval flow page");
		ManagerApprovalSMResponse response ;
		if (maRequest.isApprovalStatus()) {
			response = approvalServiceSM.makeApprovalCall(maRequest);
		} else {
			response = approvalServiceSM.makeRejectionCall(maRequest, true);
		}
		return response;
	}

	@PostMapping(value = "/MaAutoExpireNotification", produces = MediaType.APPLICATION_JSON_VALUE)
	public AutoNotificationResponse mAAutoCancellationNotification(@RequestBody AutoNotificationRequest request)
			throws ApprovalException {
		LOGGER.info("MaAutoExpireNotification ....");
		// Get the details from
		AutoNotificationResponse response ;
	    response = batchService.autoCancelNotification(request);
		return response;
	}

	@PostMapping(value = "/MaReminderNotification", produces = MediaType.APPLICATION_JSON_VALUE)
	public AutoNotificationResponse mAReminderNotification(@RequestBody AutoNotificationRequest request)
			throws ApprovalException {
		LOGGER.info("MaReminderNotification ...");
		AutoNotificationResponse response = new AutoNotificationResponse();
		if(request != null && Constants.TRAN_SUB_STATUS_REMINDER1.equals(request.getNotificationType())){
			response = batchService.initialReminder(request);
		} else if(request != null && Constants.TRAN_SUB_STATUS_REMINDER2.equals(request.getNotificationType())){
			response = batchService.finalReminder(request);
		}
		batchService.makeManagerApprovalTasks();
		
		
		return response;
	}
	
	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	@PostMapping(value = "/prospect/getDevices", produces = MediaType.APPLICATION_JSON_VALUE)
	public DeviceGridwallResponse getProspectDevices() {
		DeviceGridwallResponse response = new DeviceGridwallResponse();
		
		ServiceStatus serviceStatus = new ServiceStatus();
		try {
			
			List<DeviceDetails> details = deviceService.getDeviceInformation();
			
			if(CollectionUtils.isNotEmpty(details)) {
				List<FilterDetails> categories = details.stream()
						.filter(distinctByKey(DeviceDetails::getCategory))
						.map(d -> {
							FilterDetails filter = new FilterDetails();
							filter.setKey(d.getCategory());
							return filter;
						}).collect(Collectors.toList());
				
				List<FilterDetails> brands = details.stream()
						.filter(distinctByKey(DeviceDetails::getBrandName))
						.map(d -> {
							FilterDetails filter = new FilterDetails();
							filter.setKey(d.getBrandName());
							return filter;
						}).collect(Collectors.toList());
				
				BrowseFilterDetails filters = new BrowseFilterDetails();
				filters.setBrandList(brands);
				filters.setCategoryList(categories);
				response.setDeviceFilters(filters);
			}
			
			response.setDeviceList(details);
			serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
			serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		}catch (Exception e) {
			LOGGER.error("Error during devices retrieval", e);
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.EXCEPTION_MSG);
		}		
		
		response.setServiceStatus(serviceStatus);
		return response;
	}

	@PostMapping(value = "/prospect/getAccessories", produces = MediaType.APPLICATION_JSON_VALUE)
	public AccessoryGridwallResponse getProspectAccessories() {
		AccessoryGridwallResponse response = new AccessoryGridwallResponse();
		
		ServiceStatus serviceStatus = new ServiceStatus();
		try {
			response = deviceService.getAccessoryInformation();			
			serviceStatus.setStatusCode(Constants.SUCCESS_CODE);
			serviceStatus.setStatusMessage(Constants.SUCCESS_MSG);
		}catch (Exception e) {
			LOGGER.error("Error during devices retrieval : {}", e);
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.EXCEPTION_MSG);
		}		
		
		response.setServiceStatus(serviceStatus);
		return response;
	}
	
	
	@PostMapping(value = "/generateOrderPdf", produces = MediaType.APPLICATION_JSON_VALUE ,consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Am_ecpd_id", required = true, value = "48242",
				paramType = "header", dataType = "String"),
		@ApiImplicitParam(name = "AM_UID", required = true, value = "48242ALEXQA1",
				paramType = "header", dataType = "String")})
	public OrderPDFResponse generateOrderPdf(@RequestBody OrderPdfRequest request) throws ApprovalException {
		LOGGER.info("generate orderPDF");
		OrderPDFResponse response = null;
		response = smCpcService.generateOrderPdfLineLevel(request);
		return response;
	}
	
	
	@PostMapping(value = "/retrieveOrderDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public RetrieveOrderDetailsResponse retrieveOrderDetails(@RequestBody RetrieveOrderDetailsRequest request) {	
		LOGGER.info("In side ApprovalController.retrieveOrderDetails :: Request :: {}" , request);
		RetrieveOrderDetailsResponse response =  posService.retrieveOrderDetails(request);
		LOGGER.info("Exiting ApprovalController.retrieveOrderDetails :: Response :: {}" , response);
		return response;
	}
	
}