/**
 * 
 */
package com.vzw.mybiz.approval.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
@Entity
@Table(name = "EMAIL_AUDIT_SCH_DETAILED_LOG", schema = "COMMB2B")
public class EmailScheduleDetailsLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	@SequenceGenerator(name = "seq_generator", sequenceName = "EMAIL_AU_SCH_DET_LOG_SEQ", schema = "COMMB2B", allocationSize = 1)
	@Column(name = "SCH_DETAIL_ID", updatable = false, nullable = false)
	private Long id;
	
	@Column(name = "SCH_ID", updatable = false, nullable = false)
	private Long scheduleLogId;

	@Column(name = "SCH_STATUS", nullable = false)
	private String schStatus;
	// SCH_STATUS VARCHAR2 (15) NOT NULL,

	@Column(name = "MA_ORDER_NUMBER", nullable = false)
	private String orderNumber;
	// MA_ORDER_NUMBER VARCHAR2 (15) NOT NULL,

	@Column(name = "ECPD_ID", nullable = false)
	private String ecpdId;
	// ECPD_ID  			  NUMBER NOT NULL,
	
	@Column(name = "MA_EMAIL_LIST", nullable = false)
	private String approverEmailList;
	
	@Column(name = "MA_USER_EMAIL_LIST", nullable = false)
	private String userEmailList;
	
	//MA_EMAIL_LIST  		  VARCHAR2 (512) NOT NULL,

	@Column(name = "SCH_STATUS_MESSAGE", nullable = false)
	private String processStatusMessage;
	// SCH_STATUS_MESSAGE  		  VARCHAR2 (512) NOT NULL,

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;
	// CREATED_BY VARCHAR2 (50) NOT NULL,

	@Column(name = "CREATED_DT", nullable = false)
	private Date createdDate;
	// CREATED_DT TIMESTAMP (6)NOT NULL,

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;
	// MODIFIED_BY VARCHAR2 (50),

	@Column(name = "MODIFIED_DT", nullable = false)
	private Date modifiedDate;
	// MODIFIED_DT TIMESTAMP (6),
}
