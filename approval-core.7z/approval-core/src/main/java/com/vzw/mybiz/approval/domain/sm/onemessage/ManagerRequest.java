package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ManagerRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String confirmationNumber;
	private String status;
	private String tranType;
	private String approvalUrl;
	private List<String> approverEmailIds;
	private String approvalLevel;
	private boolean reminderFlag5Day;
	private boolean reminderFlag7Day;
	private String ecpdId;
	private String managerApprovalStatus;
	
	public String getManagerApprovalStatus() {
		return managerApprovalStatus;
	}

	public void setManagerApprovalStatus(String managerApprovalStatus) {
		this.managerApprovalStatus = managerApprovalStatus;
	}

	public String getApprovalUrl() {
		return approvalUrl;
	}

	public void setApprovalUrl(String approvalUrl) {
		this.approvalUrl = approvalUrl;
	}

	public boolean isReminderFlag5Day() {
		return reminderFlag5Day;
	}

	public void setReminderFlag5Day(boolean reminderFlag5Day) {
		this.reminderFlag5Day = reminderFlag5Day;
	}

	public boolean isReminderFlag7Day() {
		return reminderFlag7Day;
	}

	public void setReminderFlag7Day(boolean reminderFlag7Day) {
		this.reminderFlag7Day = reminderFlag7Day;
	}

	public String getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getApprovalLevel() {
		return approvalLevel;
	}

	public void setApprovalLevel(String approvalLevel) {
		this.approvalLevel = approvalLevel;
	}

	public List<String> getApproverEmailIds() {
		return approverEmailIds;
	}

	public void setApproverEmailIds(List<String> approverEmailIds) {
		this.approverEmailIds = approverEmailIds;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
}
