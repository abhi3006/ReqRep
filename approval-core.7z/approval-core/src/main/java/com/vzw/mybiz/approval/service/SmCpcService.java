package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.approval.exception.ApprovalException;

public interface SmCpcService {
	
	public OrderPDFResponse generateOrderPdfLineLevel(OrderPdfRequest request) throws ApprovalException ;

}


