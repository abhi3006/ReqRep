package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxRequet;
import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxResponse;

public interface NpaNxxService {
	
	public NpaNxxResponse fetchNPANXX(NpaNxxRequet request);

}
