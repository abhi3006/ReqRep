package com.vzw.mybiz.approval.service.impl;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.SalesForceAuthClient;
import com.vzw.mybiz.approval.client.SalesForceClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentDetail;
import com.vzw.mybiz.approval.domain.storeAppointment.Inp;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceAuthResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceRequest;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceResponse;
import com.vzw.mybiz.approval.service.SalesForceService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.Feign;
import feign.Logger.Level;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class SalesForceServiceImpl implements SalesForceService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SalesForceServiceImpl.class);
	
	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;
	
	@Autowired
	AuditService auditService;
	
	private SalesForceClient salesForceClient;
	
	private SalesForceAuthClient salesAuthClient;
	
	Gson gson = new Gson();
	
	@PostConstruct
	public void init() {
		LOGGER.info(" auth url==" + cloudPropertiesConfig.getSalesForceAuthUrl());
		LOGGER.info("url==" + cloudPropertiesConfig.getSalesForceUrl());
		
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(cloudPropertiesConfig.getHostProxy(), cloudPropertiesConfig.getPortProxy() )); 
		okhttp3.OkHttpClient okHttpClient = new okhttp3.OkHttpClient.Builder().proxy(proxy ).build();
		
		
		salesAuthClient = Feign.builder().client(new OkHttpClient(okHttpClient)).encoder(new GsonEncoder())
				.decoder(new GsonDecoder()).logger(new Slf4jLogger(SalesForceAuthClient.class)).logLevel(Level.FULL)
				.target(SalesForceAuthClient.class, cloudPropertiesConfig.getSalesForceAuthUrl());
		
		salesForceClient = Feign.builder().client(new OkHttpClient(okHttpClient)).encoder(new GsonEncoder())
				.decoder(new GsonDecoder()).logger(new Slf4jLogger(SalesForceClient.class)).logLevel(Level.FULL)
				.target(SalesForceClient.class, cloudPropertiesConfig.getSalesForceUrl());

	}

	@Override
	@Async("sfExecuter")
	public CompletableFuture<SalesForceResponse> initiateSfCall(AppointmentDetail appointmentDetail) {
		
		SalesForceRequest request = new SalesForceRequest();
		Inp inp = new Inp();
		
		
		try{
		    DateFormat df1 = new SimpleDateFormat("MMM dd, yyyy");
		    DateFormat df2 = new SimpleDateFormat("MM/dd/yyyy");
		   	Date d5 = df1.parse(appointmentDetail.getPurposeDetails().getAppointmentDate());
		    String tempDate =df2.format(d5);
		    inp.setAppointmentdate(tempDate);
		   }catch(Exception e){
		        System.out.println(e);
		   }
		
		inp.setAppointmenttime(appointmentDetail.getPurposeDetails().getSlotTime());
		inp.setBusname(appointmentDetail.getCustomerDetails().getBusinessName());
		inp.setComments(appointmentDetail.getPurposeDetails().getAdditionalComments());
		inp.setEmail(appointmentDetail.getCustomerDetails().getEmail());
		inp.setFirstname(appointmentDetail.getCustomerDetails().getFirstName());
		inp.setLastname(appointmentDetail.getCustomerDetails().getLastName());
		inp.setPhone(appointmentDetail.getCustomerDetails().getPhoneNumber());
		inp.setPurpose(appointmentDetail.getPurposeDetails().getPurpose());
		inp.setStoreid(appointmentDetail.getStoreDetails().getOutletId());
		inp.setNetaceid(appointmentDetail.getStoreDetails().getNetAceLocation());
		inp.setBusStreet(appointmentDetail.getCustomerDetails().getAddress1());
		inp.setBusCity(appointmentDetail.getCustomerDetails().getCity());
		inp.setBusState(appointmentDetail.getCustomerDetails().getState());
		inp.setBusZip(appointmentDetail.getCustomerDetails().getZip());
		
		request.setInp(inp);
		
		SalesForceResponse response = sendAppointmentToSalesForce(request);
		return CompletableFuture.completedFuture(response);
	}
	
	
	
	
	private SalesForceResponse sendAppointmentToSalesForce(SalesForceRequest salesForceRequest) {
		SalesForceResponse response = new SalesForceResponse();
		SalesForceAuthResponse authResponse = new SalesForceAuthResponse();
		LOGGER.info("salesForceRequest sendAppointmentToSalesForce" + salesForceRequest);
		try{
			auditService.beginTransaction(gson.toJson(salesForceRequest),
					new ExternalSys(Constants.SALES_FORCE_SYSTEM, cloudPropertiesConfig.getSalesForceAuthUrl()));
			
			authResponse = salesAuthClient.fetchSalesForceAuth("password",
					cloudPropertiesConfig.getSalesForeceClientId(), cloudPropertiesConfig.getSalesForeceClientSecret(),
					cloudPropertiesConfig.getSalesForeceAuthUserName(), cloudPropertiesConfig.getSalesForeceAuthPass());
			
			auditService.endTransaction(authResponse,
					new ResponseDetails(authResponse.getInstance_url(), authResponse.getIssued_at()));
		} catch(Exception e){
			LOGGER.error("Error Message For Failed SalesForce Auth Client" , e);
			auditService.endTransaction(authResponse,
					new ResponseDetails(e.getMessage(),"ERROR"));
		}
		
		
		try{
			if (authResponse != null && !StringUtils.isBlank(authResponse.getAccess_token())) {
				auditService.beginTransaction(gson.toJson(salesForceRequest),
						new ExternalSys(Constants.SALES_FORCE_SYSTEM, cloudPropertiesConfig.getSalesForceUrl()));
				
				//Header Map
				Map<String, Object> headerMap = new HashMap<>();  
				fetchHeaderMap(headerMap,authResponse);
				response = salesForceClient.sendDetailToSf(salesForceRequest,headerMap);
				auditService.endTransaction(response, new ResponseDetails(response.getMsg(),"SALESFORCE SAVE"));
			} else {
				LOGGER.error("error from auth call {} ", authResponse);
			}
			LOGGER.info("salesForceClient" + response);
		}catch(Exception e){
			LOGGER.error("Error Message For Failed SalesForce Client" , e);
			auditService.endTransaction(response,
					new ResponseDetails(e.getMessage(), "ERROR"));
		}
		return response;

	}
	private void fetchHeaderMap(Map<String, Object> headerMap,SalesForceAuthResponse authResponse) {
		headerMap.put("Authorization", "Bearer " + authResponse.getAccess_token());
		headerMap.put("Content-Type", "application/json");
	}
	
}
