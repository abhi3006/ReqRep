package com.vzw.mybiz.approval.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMInfo;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.service.ManagerServiceSM;
import com.vzw.mybiz.approval.util.ManagerApprovalUtil;
import com.vzw.mybiz.caching.services.cache.CacheService;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;


@Service
public class ManagerServiceSMImpl implements ManagerServiceSM {

	@Autowired
	CacheService<ManagerApprovalSMInfo> managerApprovalCache;

	@Autowired
	private CustomizationClient customizationClient;

	@Autowired
	private CompanyClient companyClient;

	public static final String MA_SM_INFO_KEY = "CACHE_MA_SM";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ManagerServiceSMImpl.class);

	@Override
	public ManagerApprovalSMInfo getManagerApprovalSMInfo(ManagerApprovalSMRequest maRequest) {
		ManagerApprovalSMInfo serviceRes = new ManagerApprovalSMInfo();
		LOGGER.info("Inside getManagerApprovalInfo Service");
		try {
			ManagerApprovalSMInfo managerResfromCache = managerApprovalCache.getFromSession(MA_SM_INFO_KEY+maRequest.getEcpdId(),
					ManagerApprovalSMInfo.class);
			if (managerResfromCache != null) {
				return managerResfromCache;
			}
			CommonRequest companyCoreReq = new CommonRequest();
			companyCoreReq.setEcpdId(maRequest.getEcpdId());
			companyCoreReq.setUserId(maRequest.getUserId());
			companyCoreReq.setZipCode(maRequest.getZipCode());
			companyCoreReq.setShoppingPath(maRequest.getTransactionType());
			CompanyCoreResponse companyCoreResponse = companyClient.getCompanyOrderData(companyCoreReq);
			CheckoutCustomization customizationInfo = customizationClient.getCustomizationInfo(companyCoreReq);
			managerApprovalForSM(companyCoreResponse.getManagerApproval(), customizationInfo, companyCoreReq,
					serviceRes,maRequest.getTransactionType());
			serviceRes.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG,true));
			managerApprovalCache.setToSession(MA_SM_INFO_KEY+maRequest.getEcpdId(), serviceRes);
		} catch (Exception e) {
			serviceRes.setServiceStatus(getServiceStatus(Constants.EXCEPTION_CODE, Constants.EXCEPTION_MSG,false));
			LOGGER.error("Error fetching Manager Approval Details:"+ e);
		}
		LOGGER.info("Ending getManagerApprovalInfo Service");
		return serviceRes;

	}

	private ManagerApprovalSMInfo managerApprovalForSM(OrderDataManagerApproval managerApproval,
			CheckoutCustomization customizationInfo, CommonRequest companyCoreReq, ManagerApprovalSMInfo res ,String transactionType) {
		LOGGER.info("Inside managerApprovalForAM");
		EcpdProfileInfo ecpdProfileInfo = managerApproval.getAccountMaintenanceInfo();

		boolean showManagerApproval = false;
		res.setManagerApprovalEnabled(false);
		String[] domainList = managerApproval.getDomainEntry();
		if (Optional.ofNullable(customizationInfo).isPresent()
				&& Optional.ofNullable(customizationInfo.getDgf()).isPresent()
				&& Optional.ofNullable(customizationInfo.getDgf().getManageApprovalAM()).isPresent()) {
			if (ManagerApprovalUtil.isMaCustomizationEnabled(transactionType,customizationInfo.getDgf().getManageApprovalAM())) {
				showManagerApproval = showManagerApprovalAM(ecpdProfileInfo, customizationInfo.getDgf());
				if (showManagerApproval) {
					res.setManagerApprovalEnabled(showManagerApproval);
					setECPDApprovalLevelEmail(res, ecpdProfileInfo);
					LOGGER.info("Populating Customization Info:"
							+ customizationInfo.getDgf().getManageApprovalAM().toString());
					DgfFieldShort fieldData = 
							ManagerApprovalUtil.getDfgFields(transactionType, customizationInfo.getDgf().getManageApprovalAM());
					setManagerApprovalFields(fieldData, res);
					if (Constants.EMAIL_DOMAIN.equalsIgnoreCase(fieldData.getDgfDataType())) {
						setDomainList(res, domainList);
					}
				}
			}
		}
		LOGGER.info("Ending managerApprovalForAM Service");
		return res;
	}

	public void setDomainList(ManagerApprovalSMInfo managerApprovalRes, String[] domainList) {
		managerApprovalRes.setEmailDomainList(Arrays.asList(domainList));
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage, boolean isSucces) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setSuccess(isSucces);
		return serviceStatus;
	}

	private boolean showManagerApprovalAM(EcpdProfileInfo ecpdProfileInfo, DgfDto dgfDto) {
		boolean retVal = false;
		if (ecpdProfileInfo != null && ecpdProfileInfo.getOption() != 0) {
			CustomizationEcpdProfileDto ecpdProfile = dgfDto.getEcpdProfile();
			if (ecpdProfile.getUrlStatus() == 1) {
				final int ecpdState = ecpdProfile.getManagerApprovalState();
				int[] ecpdArrState = new int[] {0,1,2};
				if(Arrays.binarySearch(ecpdArrState,ecpdState) != -1) {
					retVal = true;
				}
			} else {
				retVal = true;
			}
		}
		return retVal;
	}


	private void setManagerApprovalFields(DgfFieldShort fieldData, ManagerApprovalSMInfo res) {
		if(Constants.DROPDOWN.equalsIgnoreCase(fieldData.getDgfDataType())
				|| (Constants.INPUT_TEXT.equalsIgnoreCase(fieldData.getDgfDataType()) && org.apache.commons.lang3.StringUtils.isBlank(
						fieldData.getPrePopulatedValue()))) {
			res.setManagerApprovalSuppress(false);
		}
		res.setReadonly(fieldData.isReadonly()); 
		//BOVV-38342
//		if(Constants.INPUT_TEXT.equalsIgnoreCase(fieldData.getDgfDataType())) {
//			res.setReadonly(false);
//		}
		res.setRequired(fieldData.isRequired());
		//use this flag in UI for mandating the customization input as L2 needs two email
		if(res.getLevel().equals("2") &&  res.getApproverEmails().size() <= 1) {
			res.setRequired(true);
		}		
		res.setUserInputType(fieldData.getDgfDataType());
		res.setPrePopulateEmailID(fieldData.getPrePopulatedValue());
		if (Constants.DROPDOWN.equalsIgnoreCase(fieldData.getDgfDataType())) {
			res.setLookUp(fieldData.getLookUp());
		}
		
	}

	public void setECPDApprovalLevelEmail(ManagerApprovalSMInfo managerApprovalRes,
			EcpdProfileInfo accountMaintApprovalInfo) {
		List<String> approvalEmails = new ArrayList<String>();
		int option = accountMaintApprovalInfo.getOption();
		switch(option) {
			case 1:
				managerApprovalRes.setLevel(String.valueOf(accountMaintApprovalInfo.getOption()));
				approvalEmails.add(accountMaintApprovalInfo.getApproverEmail1());						
				approvalEmails.add(accountMaintApprovalInfo.getApproverEmail2());
				approvalEmails.add(accountMaintApprovalInfo.getApproverEmail3());
				managerApprovalRes.setVariableDisplayInUI(true);
				approvalEmails.removeIf(item -> StringUtils.isEmpty(item));
				break;
			case 2:
				managerApprovalRes.setLevel(String.valueOf(accountMaintApprovalInfo.getOption()));
				approvalEmails.add(accountMaintApprovalInfo.getApproverEmail1());						
				approvalEmails.add(accountMaintApprovalInfo.getApproverEmail2());
				approvalEmails.removeIf(item -> StringUtils.isEmpty(item));
				// if we have two emails in 2 level approval, then we dont have to put customization details in UI.
				// depend on the VariableDisplayInUI flag
				managerApprovalRes.setVariableDisplayInUI(true);
				if(approvalEmails.size() > 1) {
					managerApprovalRes.setVariableDisplayInUI(false);
				} 
				
				break;
		}
		managerApprovalRes.setApproverEmails(approvalEmails);
	}

}
