package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.AutoNotificationRequest;
import com.vzw.mybiz.approval.domain.AutoNotificationResponse;

public interface BatchService {

	public AutoNotificationResponse initialReminder(AutoNotificationRequest maRequest);
	
	public AutoNotificationResponse finalReminder(AutoNotificationRequest maRequest);

	public AutoNotificationResponse autoCancelNotification(AutoNotificationRequest maRequest);
	
	public void makeManagerApprovalTasks();
	
}