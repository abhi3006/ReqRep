package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;
import java.util.List;

import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
public class SAPInventoryResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private String ecpdId;
	private String userId;
	private String requestedSource;
	private boolean outofStockFlag;
	private boolean deviceOutofStockFlag;
	private boolean accessoryOutofStockFlag;
	private String locationCode;
	List<InventorySkuResponse> inventorySkuDetails;
	private ServiceStatus serviceStatus;

}
