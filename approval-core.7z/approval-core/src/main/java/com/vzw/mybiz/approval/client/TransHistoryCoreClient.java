package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsRequest;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.UpdateTransactionHistoryRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@Component
@FeignClient(name = "tranhistory-core", configuration = CommonFeignConfiguration.class )
public interface TransHistoryCoreClient {
	@RequestMapping(method = RequestMethod.POST, value = "mbt/transactionHistory/retrieveOrderDetailsWithConfirmationNumber", consumes = MediaType.APPLICATION_JSON_VALUE)
	public OrderDetailsResponse retrieveOrderDetails(OrderDetailsRequest request);
	
	@PostMapping(value = "mbt/transactionHistory/updateTransHistoryMAStatus", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateTransactionStatus(UpdateTransactionHistoryRequest request);
}