package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductMaster implements Serializable {

	private static final long serialVersionUID = 2390937460245801586L;
	private int productId;
	private String productName;
	private String category;
	private String brandname;
	private float overallRating;
	private int reviewCount;
	private String longdescription;

	private List<ProductSku> skulist;
	// Start : Accessories Bundle	
	private int bundleCriticalInventoryLevel;
	private String bundleFilePath;
	private double bundlePrice;
	private int skuSize;
	private double retailPrice;
	
	public int getBundleCriticalInventoryLevel() {
		return bundleCriticalInventoryLevel;
	}

	public void setBundleCriticalInventoryLevel(int bundleCriticalInventoryLevel) {
		this.bundleCriticalInventoryLevel = bundleCriticalInventoryLevel;
	}

	public String getBundleFilePath() {
		return bundleFilePath;
	}

	public void setBundleFilePath(String bundleFilePath) {
		this.bundleFilePath = bundleFilePath;
	}

	public double getBundlePrice() {
		return bundlePrice;
	}

	public void setBundlePrice(double bundlePrice) {
		this.bundlePrice = bundlePrice;
	}

	public int getSkuSize() {
		return skuSize;
	}

	public void setSkuSize(int skuSize) {
		this.skuSize = skuSize;
	}

	public double getRetailPrice() {
		return retailPrice;
	}

	public void setRetailPrice(double retailPrice) {
		this.retailPrice = retailPrice;
	}

	public List<ProductSku> getSkulist() {
		return skulist;
	}

	public void setSkulist(List<ProductSku> skulist) {
		this.skulist = skulist;
	}

	public void addSku(ProductSku accSku) {
		if (skulist == null) {
			skulist = new ArrayList<>();
		}
		skulist.add(accSku);
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBrandname() {
		return brandname;
	}

	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}



	public float getOverallRating() {
		return overallRating;
	}

	public void setOverallRating(float overallRating) {
		this.overallRating = overallRating;
	}

	public int getReviewCount() {
		return reviewCount;
	}

	public void setReviewCount(int reviewCount) {
		this.reviewCount = reviewCount;
	}

	public String getLongdescription() {
		return longdescription;
	}

	public void setLongdescription(String longdescription) {
		this.longdescription = longdescription;
	}

	@Override
	public String toString() {
		return "ProductMaster [accessoryprodid=" + getProductId() + ", longdescription=" + getLongdescription()
				+ ", accessoryprodname=" + getProductName() + ", category=" + getCategory() + ", brandname=" + getBrandname() + 
				", overallRating=" + getOverallRating() + ", reviewcount="
				+ getReviewCount() + ", skulist=" + getSkulist() 
				+ "]";
	}

}