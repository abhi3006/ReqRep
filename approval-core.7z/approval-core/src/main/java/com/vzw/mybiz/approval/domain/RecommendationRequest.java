package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecommendationRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ecpdId;
	private String userId;
	private int recommendedSize;
	private List<String> skuList;
	private List<String> cartList;

	public String getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getRecommendedSize() {
		return recommendedSize;
	}

	public void setRecommendedSize(int recommendationsSize) {
		this.recommendedSize = recommendationsSize;
	}

	public List<String> getSkuList() {
		return skuList;
	}

	public void setSkuList(List<String> skuList) {
		this.skuList = skuList;
	}

	public List<String> getCartList() {
		return cartList;
	}

	public void setCartList(List<String> cartList) {
		this.cartList = cartList;
	}

	@Override
	public String toString() {
		return "AccessoryRecommendRequest [ecpdId=" + ecpdId + ", userId=" + userId + ", recommendedSize="
				+ recommendedSize + ", skuList=" + skuList + ", cartList=" + cartList + "]";
	}
	
	
}
