package com.vzw.mybiz.approval.domain;

import java.util.List;
import java.util.Map;

import com.vzw.mybiz.approval.data.bcc.entity.PlanMasterDetails;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class PlanResponse {
	
	Map<String, List<PlanMasterDetails>> response;

}
