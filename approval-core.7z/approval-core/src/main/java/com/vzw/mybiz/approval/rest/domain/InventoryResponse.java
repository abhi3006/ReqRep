package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;
import java.util.Map;

import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;


public class InventoryResponse implements Serializable {

	private static final long serialVersionUID = 6893920277495880473L;
	
	private Map<String, InventoryDetail> skuInventoryDetail;
	
	private ServiceStatus serviceStatus;

	/**
	 * @return the serviceStatus
	 */
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	/**
	 * @param serviceStatus the serviceStatus to set
	 */
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	/**
	 * @return the skuInventoryDetail
	 */
	public Map<String, InventoryDetail> getSkuInventoryDetail() {
		return skuInventoryDetail;
	}

	/**
	 * @param skuInventoryDetail the skuInventoryDetail to set
	 */
	public void setSkuInventoryDetail(Map<String, InventoryDetail> skuInventoryDetail) {
		this.skuInventoryDetail = skuInventoryDetail;
	}

}
