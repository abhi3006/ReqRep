package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class InventoryRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6127149834580428255L;

	@NotEmpty(message = "SKU IDs code is mandatory and requires one atleast.")
	@Size(min = 1)
	private List<String> skuList;

	@NotEmpty(message = "NetAceLocation code is mandatory.")
	private String netAceLocation;

	public List<String> getSkuList() {
		return skuList;
	}

	public void setSkuList(List<String> skuList) {
		this.skuList = skuList;
	}

	public String getNetAceLocation() {
		return netAceLocation;
	}

	public void setNetAceLocation(String netAceLocation) {
		this.netAceLocation = netAceLocation;
	}

}
