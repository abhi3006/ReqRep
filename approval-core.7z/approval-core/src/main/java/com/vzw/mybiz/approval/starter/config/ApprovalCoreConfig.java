package com.vzw.mybiz.approval.starter.config;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.instrument.async.LazyTraceExecutor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import com.vzw.mybiz.security.overrides.ContextCopyDecorator;

/**
 * @author w553190
 *
 */
@Configuration
@EnableAsync
public class ApprovalCoreConfig {
	
	@Autowired
	private BeanFactory beanFactory;
	
	@Bean(name="approvalAsyncExecutor")
    public Executor asyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(new ContextCopyDecorator());
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(20);
        executor.setQueueCapacity(500);
        executor.setThreadNamePrefix("approvalAsyncExecutor-");
        executor.initialize();
        return new LazyTraceExecutor(beanFactory, executor);
    }
	
	@Bean(name = "sfExecuter")
	public Executor asyncExecutorSf() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(new ContextCopyDecorator());
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("sfExecuter-");
        executor.initialize();
        return new LazyTraceExecutor(beanFactory, executor);
	}
	
	@Bean(name="objectMapper")
	public ObjectMapper objectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JaxbAnnotationModule());
		return mapper;
	}
}