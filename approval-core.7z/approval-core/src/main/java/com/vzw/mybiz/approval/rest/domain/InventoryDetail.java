/**
 * 
 */
package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;

/**
 * @author nandbi6
 *
 */
public class InventoryDetail implements Serializable {
	
	private static final long serialVersionUID = -5585697077165827728L;
	
	private boolean outOfStock;
	
	private int criticalInventoryLevel;
	
	private boolean displayEvenOutOfStock;
	
	private LocationDetail[] locationDetails;

	/**
	 * @return the outOfStock
	 */
	public boolean isOutOfStock() {
		return outOfStock;
	}

	/**
	 * @param outOfStock the outOfStock to set
	 */
	public void setOutOfStock(boolean outOfStock) {
		this.outOfStock = outOfStock;
	}

	


	public int getCriticalInventoryLevel() {
		return criticalInventoryLevel;
	}

	public void setCriticalInventoryLevel(int criticalInventoryLevel) {
		this.criticalInventoryLevel = criticalInventoryLevel;
	}

	/**
	 * @return the locationDetails
	 */
	public LocationDetail[] getLocationDetails() {
		return locationDetails;
	}

	/**
	 * @param locationDetails the locationDetails to set
	 */
	public void setLocationDetails(LocationDetail[] locationDetails) {
		this.locationDetails = locationDetails;
	}

	public boolean isDisplayEvenOutOfStock() {
		return displayEvenOutOfStock;
	}

	public void setDisplayEvenOutOfStock(boolean displayEvenOutOfStock) {
		this.displayEvenOutOfStock = displayEvenOutOfStock;
	}


}
