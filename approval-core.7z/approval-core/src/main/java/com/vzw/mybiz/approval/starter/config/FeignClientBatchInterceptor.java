package com.vzw.mybiz.approval.starter.config;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.auth.token.FeignHeaderConfiguration;

import feign.RequestTemplate;

@Component
public class FeignClientBatchInterceptor extends FeignHeaderConfiguration {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FeignClientBatchInterceptor.class);
	
	public void apply(RequestTemplate template) {
		
		Map<String, Collection<String>> headers = template.headers();
		if(headers != null){
			Set<String> keys = headers.keySet();
		
			LOGGER.info("headers: " + keys);
			
			if(keys != null && !keys.isEmpty()){
				for(String key: keys){
					if(Constants.TRANSACTION_MODE_HEADER.equals(key)){

						//if the request is started from batch process, we need to add jwt token.
						Collection<String> values = headers.get(key);
						if(values != null && !values.isEmpty()){
							for(String value: values){
								if(Constants.TRANSACTION_MODE_BATCH.equals(value)){
									super.apply(template);
									break;
								}
							}
						}
						break;
					}
				}
			}
		}
	}

}
