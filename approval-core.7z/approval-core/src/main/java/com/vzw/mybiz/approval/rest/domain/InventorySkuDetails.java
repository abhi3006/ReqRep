package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
public class InventorySkuDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private String sku;
	private String skuName;
	private String skuType;
	private String deviceMasterId;
	private int requestedQuantity;
	private int criticalInventoryLevel;
}