package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class ProductSku implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String sku;	
	private int accessoryId;
	private String skuName;
	private String universalflag;
	private String color;
	private String colorCssStyle;
	private String filePath;
	private int criticalInventoryLevel;
	private int currentInventoryLevel;
	private double retailPrice;
	private double finalBestPrice;
	private double discountPercent;
	private Double discountAmount;
	private String offerType;
	private boolean outOfStock;
	private boolean displayEvenOutOfStock;

	@Override
	public String toString() {
		return "AccessorySku [sku=" + getSku() + ", accessoryId=" + getAccessoryId() + ", universalflag="
				+ getUniversalflag() + ", color=" + getColor() + ", colorCssStyle=" + getColorCssStyle() + ", filePath="
				+ getFilePath() + ", criticalInventoryLevel=" + getCriticalInventoryLevel() + ", currentInventoryLevel="
				+ getCurrentInventoryLevel() + ", retailPrice=" + getRetailPrice() + ", finalBestPrice="
				+ getFinalBestPrice() + ", discountPercent=" + getDiscountPercent() + ", offerType=" + getOfferType()
				+ ", outOfStock=" + getOutOfStock() + ", displayEvenOutOfStock=" + getDisplayEvenOutOfStock() + "]";
	}
	
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public int getAccessoryId() {
		return accessoryId;
	}
	public void setAccessoryId(int accessoryId) {
		this.accessoryId = accessoryId;
	}
	public String getSkuName() {
		return skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getUniversalflag() {
		return universalflag;
	}
	public void setUniversalflag(String universalflag) {
		this.universalflag = universalflag;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getColorCssStyle() {
		return colorCssStyle;
	}
	public void setColorCssStyle(String colorCssStyle) {
		this.colorCssStyle = colorCssStyle;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public int getCriticalInventoryLevel() {
		return criticalInventoryLevel;
	}
	public void setCriticalInventoryLevel(int criticalInventoryLevel) {
		this.criticalInventoryLevel = criticalInventoryLevel;
	}
	public int getCurrentInventoryLevel() {
		return currentInventoryLevel;
	}
	public void setCurrentInventoryLevel(int currentInventoryLevel) {
		this.currentInventoryLevel = currentInventoryLevel;
	}
	public double getRetailPrice() {
		return retailPrice;
	}
	public void setRetailPrice(double retailPrice) {
		this.retailPrice = retailPrice;
	}
	public double getFinalBestPrice() {
		return finalBestPrice;
	}
	public void setFinalBestPrice(double finalBestPrice) {
		this.finalBestPrice = finalBestPrice;
	}
	
	
	public double getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(double discountPercent) {
		this.discountPercent = discountPercent;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	/**
	 * @return the outOfStock
	 */
	public boolean getOutOfStock() {
		return outOfStock;
	}

	/**
	 * @return the displayEvenOutOfStock
	 */
	public boolean getDisplayEvenOutOfStock() {
		return displayEvenOutOfStock;
	}

	/**
	 * @param outOfStock the outOfStock to set
	 */
	public void setOutOfStock(boolean outOfStock) {
		this.outOfStock = outOfStock;
	}

	/**
	 * @param displayEvenOutOfStock the displayEvenOutOfStock to set
	 */
	public void setDisplayEvenOutOfStock(boolean displayEvenOutOfStock) {
		this.displayEvenOutOfStock = displayEvenOutOfStock;
	}

	public Double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(Double discountAmount) {
		this.discountAmount = discountAmount;
	}
	
	
}