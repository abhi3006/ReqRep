/**
 * 
 */
package com.vzw.mybiz.approval.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
@Entity
public class AccessoryMasterDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ACCESSORY_ID")
	private Long accessoryId;
	
	@Column(name = "MAKE")
	private String brandName;
	
	@Column(name = "MODEL")
	private String model;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "IMAGE_NAME")
	private String filePath;
	
	@Column(name = "DISPLAY_PROD_NAME")
	private String displayProductName;
	
	@Column(name = "PROD_NAME")
	private String productName;	
	
	@Column(name = "DISPLAY_NAME_SKU")
	private String displayName;
	
	@Column(name = "PHONE_ID")
	private String phoneId;
	
	@Column(name = "SKU")
	private String sku;
	
	@Column(name = "IMAGESET")
	private String imageSet;
	
	@Column(name = "COLOR_ATTRIB_NAME")
	private String color;
	
	@Column(name = "COLOR_HEX_NAME")
	private String cssColor;
	
	@Column(name = "CRITICAL_INVENTORY_LEVEL")
	private Integer criticalInventoryLevel;
	
	@Column(name = "USRP_PRICE")
	private Float retailPrice;
	
	@Column(name = "PHONE_SKU")
	private String phoneSku;
	
	@Column(name = "ACC_PROD_ID")
	private String accProdId;
	
}
