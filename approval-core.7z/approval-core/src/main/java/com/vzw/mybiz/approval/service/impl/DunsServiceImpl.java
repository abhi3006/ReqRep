package com.vzw.mybiz.approval.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.mybiz.approval.client.DunsApiClient;
import com.vzw.mybiz.approval.service.DunsService;
import com.vzw.mybiz.approval.starter.config.DunsConfig;
import com.vzw.mybiz.decrypt.util.DecryptionUtil;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceRequest;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceResponse;
import com.vzw.mybiz.prospect.domain.duns.StandardizedAddressServiceRequest;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.FeignException;

@Service
public class DunsServiceImpl implements DunsService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DunsServiceImpl.class);

	@Autowired
	private DunsConfig dunsConfig;
	
	@Autowired
	private AuditService auditService;
	
	//private DunsApiClient dunsApiClient;
	
	@Autowired
	DecryptionUtil decryptionUtil;
	
	@Autowired
	@Qualifier("dunsApiClient")
	private DunsApiClient dunsApiClient;
	
	ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
	@Override
	public AddressServiceResponse getAddressMatchService(AddressServiceRequest addMatchReq) {
		AddressServiceResponse response = new AddressServiceResponse();

		Map<String, String> dunsResponse = new HashMap<>();
		String dunsRespJson = "NA";
		int httpStatusCode = 200;
		String messageCode = "0";
		String messageDescription = "SUCCESS";
		try
		{
			Map<String, Object> headers = new HashMap<>();
			headers.put("CLIENT_ID", dunsConfig.getClientId());
			long time = System.currentTimeMillis();
			ExternalSys externalSys = new ExternalSys();
			externalSys.setEndpoint(dunsConfig.getBase_uri()+dunsConfig.getAddressmatch_endpoint());
			//externalSys.setSystem("SALESFORCE");
			externalSys.setService("addressmatch");
			String addressMatchReqString = objMapper.writeValueAsString(addMatchReq);
			auditService.beginTransaction(addressMatchReqString, externalSys);
			String addressmatchResString = dunsApiClient.getDunsAddressMatch(headers, addressMatchReqString);
			response = objMapper.readValue(addressmatchResString, AddressServiceResponse.class);
			LOGGER.info("Getting addressMatch from API calling took... = " + (System.currentTimeMillis() - time) + " ms");

		}
		catch(FeignException fex)
		{
			LOGGER.error("Get AddressMatch Error" + fex);
			messageCode = "5000";
			httpStatusCode = fex.status();
			messageDescription = fex.getMessage();
		}
		catch(Throwable ex)
		{
			httpStatusCode= 0;
			messageCode = "6000";
			LOGGER.error("Get AddressMatch Error" + ex);
		}
		finally
		{
			auditService.endTransaction(dunsRespJson, new ResponseDetails(httpStatusCode, messageCode, messageDescription));
			dunsResponse.put("MESSAGE_CODE", messageCode);
			dunsResponse.put("DUNS_JSON", dunsRespJson);
		}
		
		if(response==null || (response!=null && response.getMatchedAddressList()!=null && response.getMatchedAddressList().isEmpty())) {
			StandardizedAddressServiceRequest stndAddressReq = new StandardizedAddressServiceRequest();
			stndAddressReq.setAddressLine(addMatchReq.getAddressLine());
			stndAddressReq.setCity(addMatchReq.getCity());
			stndAddressReq.setState(addMatchReq.getState());
			stndAddressReq.setZip5(addMatchReq.getZip());
			
			response = getStandardizedAddressService(stndAddressReq);
		}
		
		return response;
	}

	@Override
	public AddressServiceResponse getStandardizedAddressService(StandardizedAddressServiceRequest stndAddressReq) {
		AddressServiceResponse response = new AddressServiceResponse();
		Map<String, String> dunsResponse = new HashMap<>();
		String dunsRespJson = "NA";
		int httpStatusCode = 200;
		String messageCode = "0";
		String messageDescription = "SUCCESS";
		try
		{
			Map<String, Object> headers = new HashMap<>();
			headers.put("CLIENT_ID", dunsConfig.getClientId());
			long time = System.currentTimeMillis();
			ExternalSys externalSys = new ExternalSys();
			externalSys.setEndpoint(dunsConfig.getBase_uri()+dunsConfig.getStandardizedaddress_endpoint());
			//externalSys.setSystem("SALESFORCE");
			externalSys.setService("standadizedAddress");
			String stndAddressReqString = objMapper.writeValueAsString(stndAddressReq);
			auditService.beginTransaction(stndAddressReqString, externalSys);
			String stndAddressResString = dunsApiClient.getDunsStandardizedAddress(headers, stndAddressReqString);
			response = objMapper.readValue(stndAddressResString, AddressServiceResponse.class);
			LOGGER.info("Getting StandardizedAddress from API calling took... = " + (System.currentTimeMillis() - time) + " ms");

		}
		catch(FeignException fex)
		{
			LOGGER.error("Get StandardizedAddress Error" + fex);
			messageCode = "5000";
			httpStatusCode = fex.status();
			messageDescription = fex.getMessage();
		}
		catch(Throwable ex)
		{
			httpStatusCode= 0;
			messageCode = "6000";
			LOGGER.error("Get StandardizedAddress Error" + ex);
		}
		finally
		{
			auditService.endTransaction(dunsRespJson, new ResponseDetails(httpStatusCode, messageCode, messageDescription));
			dunsResponse.put("MESSAGE_CODE", messageCode);
			dunsResponse.put("DUNS_JSON", dunsRespJson);
		}
		
		return response;
	}
	
}
