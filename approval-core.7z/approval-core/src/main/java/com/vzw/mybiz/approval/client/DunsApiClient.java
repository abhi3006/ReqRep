package com.vzw.mybiz.approval.client;

import java.util.Map;

import com.vzw.mybiz.prospect.domain.duns.AddressServiceRequest;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceResponse;
import com.vzw.mybiz.prospect.domain.duns.StandardizedAddressServiceRequest;

import feign.HeaderMap;
import feign.Headers;
import feign.RequestLine;

public interface DunsApiClient {
	@RequestLine("POST /addressmatch")
	@Headers("Content-Type: application/json")
	public String getDunsAddressMatch(@HeaderMap Map<String, Object> headerMap, String addressServiceRequest);
	
	@RequestLine("POST /standadizedAddress")
	@Headers("Content-Type: application/json")
	public String getDunsStandardizedAddress(@HeaderMap Map<String, Object> headerMap, String stndAddressServiceRequest);
}
