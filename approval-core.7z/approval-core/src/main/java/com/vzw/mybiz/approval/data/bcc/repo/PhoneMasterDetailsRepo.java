package com.vzw.mybiz.approval.data.bcc.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.vzw.mybiz.approval.data.bcc.entity.PhoneMasterDetails;

public interface PhoneMasterDetailsRepo extends CrudRepository<PhoneMasterDetails, Long>{

	
	@Query(value = "SELECT DISTINCT pmaster.phone_id, pmaster.make, pmaster.model, r.NUMBER_OF_REVIEWS, r.AVERAGE_RATING, pmaster.technology_type, pmaster.global_ready,  pmaster.Image_name, pmaster.device_type AS category, pmaster.DISPLAY_PROD_NAME, pmaster.device_master_id ,\r\n" + 
			"  pmaster.PROD_NAME, pmaster.DISPLAY_NAME_SKU, pmaster.CAMERA_INFO_TEXT, pmaster.critical_inventory_level, pmaster.sku, pmaster.imageset, pmaster.SIM_SOR_SKU, \r\n" + 
			"  NVL((\r\n" + 
			"	SELECT\r\n" + 
			"    CASE WHEN rdm.rank = 0 THEN NULL ELSE rdm.rank END\r\n" + 
			"	FROM commatg.rank_device_map rdm\r\n" + 
			"	WHERE rdm.phone_id = pmaster.phone_id\r\n" + 
			"  ),'') AS rank,\r\n" + 
			"  pmaster.display_inventory_status, pmaster.display_mbu_flag, term, percentage, upgrade_option_code, category_code, COLOR_ATTRIB_NAME, COLOR_HEX_NAME ,\r\n" + 
			"  pmaster.capacity, pmaster.NUMBER_SHARE_ELIGIBLE_FLAG, USRP_PRICE, RETAIL_1YR_PRICE, RETAIL_2YR_PRICE, EDGE_FR_PRICE AS EASYPAY_PRICE, CORP_1YR_L1_PRICE, \r\n" + 
			"  CORP_1YR_L2_PRICE, CORP_1YR_L3_PRICE, CORP_1YR_L4_PRICE, CORP_1YR_L5_PRICE, CORP_2YR_L1_PRICE, CORP_2YR_L2_PRICE, CORP_2YR_L3_PRICE,CORP_2YR_L4_PRICE, CORP_2YR_L5_PRICE,\r\n" + 
			"  CASE\r\n" + 
			"    WHEN (SIM_CLASS = 'PP' OR SIM_CLASS = 'PI')\r\n" + 
			"    AND VIRTUAL_SIM_SKU IS NOT NULL THEN VIRTUAL_SIM_SKU ELSE PREFERRED_SIM_SKU\r\n" + 
			"  END SIM_SKU\r\n" + 
			"FROM\r\n" + 
			"  (\r\n" + 
			"    SELECT * FROM commatg.phone_master pm WHERE pm.NUMBER_SHARE_ELIGIBLE_FLAG = 'N' \r\n" + 
			"    AND NOT EXISTS (SELECT epr.SOR_SKU FROM commatg.B2B_EPB_MARKET_RESTR_V epr WHERE epr.SOR_SKU = pm.sku)\r\n" + 
			"    AND EXISTS (SELECT sim.sim_sor_sku FROM commatg.b2b_epb_sim_details_v sim WHERE sim.sim_sor_sku = pm.sim_sor_sku AND active_flag <> 0)\r\n" + 
			"  ) pmaster\r\n" + 
			"  \r\n" + 
			"LEFT JOIN\r\n" + 
			"  (\r\n" + 
			"  SELECT DISTINCT SOR_id, term, percentage, upgrade_option_code, CATEGORY_Code\r\n" + 
			"  FROM commatg.DEVICE_PAYMENT_CONFIG dpc\r\n" + 
			"  WHERE active_flag = 1 AND start_date <= sysdate AND end_date >= sysdate\r\n" + 
			"  ) dpc ON pmaster.sku = dpc.sor_id\r\n" + 
			"  \r\n" + 
			"LEFT JOIN commatg.dpi_mview dpv ON pmaster.sku = dpv.item_Code \r\n" + 
			"\r\n" + 
			"left join comatg_pub.vzw_product_rating r ON pmaster.device_master_id=r.rating_id \r\n" + 
			"\r\n" + 
			"left Join COMMB2B.DMD_DEVICE_INFO b ON b.prod_name=pmaster.prod_name WHERE sku NOT LIKE 'STK%'\r\n" + 
			"\r\n" + 
			"order by rank ASC, DISPLAY_NAME_SKU", nativeQuery = true)
		List<PhoneMasterDetails> getPhoneMasterDetails();
	
}
