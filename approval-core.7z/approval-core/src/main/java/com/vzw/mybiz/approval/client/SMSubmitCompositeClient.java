package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vzw.mybiz.approval.domain.sm.onemessage.ManagerRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitResponse;
import com.vzw.mybiz.approval.domain.sm.submit.composite.SMSubmitTransactionRequest;
import com.vzw.mybiz.approval.domain.sm.submit.composite.SubmitAccountLevelTransactionRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name = "sm-submit-composite", configuration = CommonFeignConfiguration.class)
public interface SMSubmitCompositeClient {

	@RequestMapping(method = RequestMethod.POST, value = "mbt/smsubmit/submitSMTransaction", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionSubmitResponse submitCommonSMTransaction(SMSubmitTransactionRequest smSumbmitRequest);
	
	@RequestMapping(method = RequestMethod.POST, value = "mbt/smsubmit/submitSMAccountLevelTransaction", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionSubmitResponse submitCommonAccountLevelSMTransaction(SubmitAccountLevelTransactionRequest smSumbmitRequest);
	
	@RequestMapping(method = RequestMethod.POST, value = "mbt/smsubmit/notify-manager", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionSubmitResponse notifyManager(ManagerRequest request);

}
