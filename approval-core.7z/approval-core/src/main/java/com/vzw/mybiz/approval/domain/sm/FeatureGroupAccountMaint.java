/**
 * 
 */
package com.vzw.mybiz.approval.domain.sm;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

/**
 * @author kab82bq
 *
 */
@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown = true)
public class FeatureGroupAccountMaint implements Serializable {
	
	String accountNumber;

	String effectiveDate;

	List<SystemTxnInfo> addedFeaturesList;

	List<SystemTxnInfo> removedFeaturesList;

	List<SystemTxnInfo> autoAddedFeaturesList;

	List<SystemTxnInfo> autoRemovedFeaturesList;
	
	Double accountTotal;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public List<SystemTxnInfo> getAddedFeaturesList() {
		return addedFeaturesList;
	}

	public void setAddedFeaturesList(List<SystemTxnInfo> addedFeaturesList) {
		this.addedFeaturesList = addedFeaturesList;
	}

	public List<SystemTxnInfo> getRemovedFeaturesList() {
		return removedFeaturesList;
	}

	public void setRemovedFeaturesList(List<SystemTxnInfo> removedFeaturesList) {
		this.removedFeaturesList = removedFeaturesList;
	}

	public List<SystemTxnInfo> getAutoAddedFeaturesList() {
		return autoAddedFeaturesList;
	}

	public void setAutoAddedFeaturesList(List<SystemTxnInfo> autoAddedFeaturesList) {
		this.autoAddedFeaturesList = autoAddedFeaturesList;
	}

	public List<SystemTxnInfo> getAutoRemovedFeaturesList() {
		return autoRemovedFeaturesList;
	}

	public void setAutoRemovedFeaturesList(List<SystemTxnInfo> autoRemovedFeaturesList) {
		this.autoRemovedFeaturesList = autoRemovedFeaturesList;
	}

	public Double getAccountTotal() {
		return accountTotal;
	}

	public void setAccountTotal(Double accountTotal) {
		this.accountTotal = accountTotal;
	}
	
}
