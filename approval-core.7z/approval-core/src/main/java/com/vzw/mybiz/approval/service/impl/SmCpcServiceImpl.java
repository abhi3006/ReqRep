package com.vzw.mybiz.approval.service.impl;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.SmCpcClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.approval.exception.ApprovalException;
import com.vzw.mybiz.approval.service.SmCpcService;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.services.AuditService;

@Service
public class SmCpcServiceImpl implements SmCpcService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmCpcServiceImpl.class);
	@Autowired
	private SmCpcClient smCpcClient;
	
	@Autowired
    private HttpServletRequest httpServletRequest;

	@Autowired
	private AuditService auditService;

	@Override
	public OrderPDFResponse generateOrderPdfLineLevel(OrderPdfRequest request) throws ApprovalException {
		OrderPDFResponse response;
		ResponseDetails responseDetails = new ResponseDetails();
		String respString = StringUtils.EMPTY;
		Gson gson = new Gson();		
		try {
			String requestString = gson.toJson(request);
			LOGGER.debug("Request to Sm-Cpc-Composite", requestString);

			ExternalSys externalSys = new ExternalSys();
			externalSys.setSystem("Sm CPC Composite");
			externalSys.setEndpoint("/mbt/cpc/generateOrderPdf");
			externalSys.setService("generateOrderPdfLineLevel");

			auditService.beginTransaction(requestString, externalSys);
			LOGGER.debug("Calling sm-cpc-ccomposite to get MA PDF Info.");			
			
			String ecpdId = httpServletRequest.getHeader(Constant.ECPD_ID);
	        String loginUserId = httpServletRequest.getHeader(Constant.LOGIN_USER_ID);

			if (ecpdId == null || ecpdId.trim().equals("") || loginUserId == null || loginUserId.trim().equals("")) {
				LOGGER.error(Constants.HEADER_INVALID_MSG + ":: ecpdId or loginUserId is missing from Header");
				throw new ApprovalException(Constants.HEADER_INVALID_CODE, Constants.HEADER_INVALID_MSG);
			}
	        
			response = smCpcClient.generateOrderPdf(ecpdId, loginUserId, Constant.CSR_ID, request);
			LOGGER.debug("Back from sm-cpc-copmosite.");

			if (response == null) {
				LOGGER.error("Response from sm-cpc-composite is null");
				throw new ApprovalException(Constants.WS_NULL_RESP_ERROR_CODE,
						Constants.WS_NULL_RESP_ERROR_MSG + " sm-cpc");
			}

			ServiceStatus serviceStatus = response.getServiceStatus();
			if (serviceStatus != null) {
				String statusMessage = serviceStatus.getStatusMessage();
				if (!(("00".equals(statusMessage) || "0".equals(statusMessage)))) {
					LOGGER.error("generateOrderPdfLineLevel():: Failed response from sm-cpc call!");
					throw new ApprovalException(statusMessage, serviceStatus.getStatusMessage());
				}
				respString = gson.toJson(response);
			} else {
				LOGGER.error("generateOrderPdfLineLevel():: Service Status is null!");
				throw new ApprovalException(Constants.WS_NULL_RESP_ERROR_CODE, "Service Status is null! -- sm-cpc");
			}
		} catch (Exception e) {
			if (e instanceof ApprovalException) {
				throw e;
			}
			LOGGER.error("Exception occured while retrieving pdf data from sm-cpc - ", e.getMessage());
			throw new ApprovalException(Constants.EXCEPTION_CODE,
					Constants.EXCEPTION_MSG + "sm-cpc: " + e.getMessage());
		} finally {
			auditService.endTransaction(respString, responseDetails);
		}
		return response;
	}

}

	
