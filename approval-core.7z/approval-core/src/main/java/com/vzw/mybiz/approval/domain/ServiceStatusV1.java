package com.vzw.mybiz.approval.domain;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
//import org.apache.commons.httpclient.HttpStatus;

import java.io.Serializable;

import org.apache.http.HttpStatus;

@JsonDeserialize(builder=ServiceStatusV1.Builder.class)
public final class ServiceStatusV1 implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String statusMessage;
    private final String statusCode;
    private final boolean success;

    private ServiceStatusV1(Builder builder) {
        statusMessage = builder.statusMessage;
        statusCode = builder.statusCode;
        success = builder.success;
    }

    public static Builder builder() {
        return new Builder();
    }


    public static final class Builder {
        private String statusMessage = "Sucess";
        private String statusCode = String.valueOf(HttpStatus.SC_OK);
        private boolean success = true;

        private Builder() {
        }

        public Builder withStatusMessage(String statusMessage) {
            this.statusMessage = statusMessage;
            return this;
        }

        public Builder withStatusCode(String statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        public Builder withSuccess(boolean success) {
            this.success = success;
            return this;
        }

       public ServiceStatusV1 build() {
            return new ServiceStatusV1(this);
        }
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public boolean isSuccess() {
        return success;
    }

    @Override
    public String toString() {
        return "ServiceStatusV1{" +
                "statusMessage='" + statusMessage + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", success=" + success +
                '}';
    }
}
