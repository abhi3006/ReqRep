/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Setter
@Getter
public class Email {
	
	
	private String mailFrom;
	 
    private String mailTo;
 
    private String templateName;
 
    private String userEmail;
    private String orderNumber;
 
    private String mailSubject;
 
    private String mailContent;
 
    private String contentType;
 
    private String approvalUrl;
    private String reminderNumber;
    
    private Long schId;
    private String ecpdId;
    private String requester;
    
    private String myBusinessIds;
    
 
    public Email() {
        contentType = "text/plain";
    }
 
   

}
