package com.vzw.mybiz.approval.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.sm.AccountDetails;
import com.vzw.mybiz.approval.domain.sm.AccountLineItem;
import com.vzw.mybiz.approval.domain.sm.SMAccountLevelOrderResponse;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cba.BillingAddressDetails;
import com.vzw.mybiz.approval.domain.sm.ma.ui.SystemTxnInfoDisconnect;
import com.vzw.mybiz.approval.domain.sm.ma.ui.SystemTxnInfoForCBA;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

/**
 * @author KAB82BQ
 * @notes used for Ma approval screen data building
 */
public class ManagerApprovalSMOrderDetails {

	/**
	 * @param orderDetailsResponse
	 * @param smOrderResponse
	 * @notes disconnect ma screen data building method
	 */
	public static void buildDisconnectInfo(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsList = new ArrayList<AccountLineItem>();

		Map<String, List<SystemTxnInfoDisconnect>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfoDisconnect>>();

		groupAccountOrderDetails(orderDetailsResponse, accountOrderDetailsMap);

		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<LinkedHashMap<String, String>>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<String, String>();

							detailMap.put(Constant.ACC_LINE_ITEM_MTN, detailInfo.getServiceNumber());
							detailMap.put(Constant.ACC_LINE_ITEM_USER_NAME, detailInfo.getUserName());
							detailMap.put(Constant.ACC_LINE_ITEM_REASON_DISCONNECT,
									detailInfo.getReasonForDeactivate());
							detailMap.put(Constant.ACC_LINE_ITEM_DEACT_DT, detailInfo.getDeactivateDate());
							detailMap.put(Constant.ACC_LINE_ITEM_CONTRACT_DT, 
									StringUtils.isNotEmpty(detailInfo.getContractEndDate()) ? detailInfo.getContractEndDate() : "");
							detailMap.put(Constant.ACC_LINE_ITEM_ETF, 
									StringUtils.isNotEmpty(detailInfo.getEtfFee()) ? detailInfo.getEtfFee() : "");
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsList);
		}
	}

	private static void groupAccountOrderDetails(OrderDetailsResponse orderDetailsResponse,
			Map<String, List<SystemTxnInfoDisconnect>> accountOrderDetailsMap) {
		List<SystemTxnInfo> orderItemList = new ArrayList<>();

		for (SystemTxnInfo sysInfo : orderDetailsResponse.getOrderDetailsList()) {
			orderItemList.add(sysInfo);
		}
		List<String> accountNumberList = new ArrayList<>();
		Map<String, Map<String, List<SystemTxnInfo>>> accountInfoMap = new HashMap<>();
		for (SystemTxnInfo systemTxnIfo : orderItemList) {
			if (!accountNumberList.contains(systemTxnIfo.getAccountNumber())) {
				accountNumberList.add(systemTxnIfo.getAccountNumber());
				List<SystemTxnInfo> filteredInfo = orderItemList.stream().filter(feature -> {
					return feature.getAccountNumber().equalsIgnoreCase(systemTxnIfo.getAccountNumber());
				}).collect(Collectors.toList());
				Map<String, List<SystemTxnInfo>> mtnInfoMap = new HashMap<>();
				for (SystemTxnInfo mtnInfo : filteredInfo) {
					if (!mtnInfoMap.containsKey(mtnInfo.getServiceNumber())) {
						List<SystemTxnInfo> mtnInfoList = filteredInfo.stream().filter(feature -> {
							return feature.getServiceNumber().equalsIgnoreCase(mtnInfo.getServiceNumber());
						}).collect(Collectors.toList());
						mtnInfoMap.put(mtnInfo.getServiceNumber(), mtnInfoList);
					}
				}
				accountInfoMap.put(systemTxnIfo.getAccountNumber(), mtnInfoMap);
			}
		}
		if (!accountInfoMap.isEmpty()) {
			filterItemValues(accountInfoMap, accountOrderDetailsMap);
		}
	}

	private static void filterItemValues(Map<String, Map<String, List<SystemTxnInfo>>> accountInfoMap,
			Map<String, List<SystemTxnInfoDisconnect>> accountOrderDetailsMap) {
		accountInfoMap.entrySet().forEach(accountInfo -> {
			System.out.println(accountInfoMap.size());
			accountOrderDetailsMap.put(accountInfo.getKey(), new ArrayList<SystemTxnInfoDisconnect>());
			accountInfo.getValue().entrySet().forEach(mtnInfo -> {
				SystemTxnInfoDisconnect line = new SystemTxnInfoDisconnect();
				mtnInfo.getValue().stream().forEach(orderInfo -> {
					if (StringUtils.equalsIgnoreCase(Constant.DACT_DEACTIVATION_DATE, orderInfo.getDetailType())) {
						line.setDeactivateDate(orderInfo.getItemName());
					}
					if (StringUtils.equalsIgnoreCase(Constant.DACT_REASON_FOR_DEACTIVATION,
							orderInfo.getDetailType())) {
						line.setReasonForDeactivate(orderInfo.getItemName());
					}
					if (StringUtils.equalsIgnoreCase(Constant.DACT_CONTRACT_END_DATE, orderInfo.getDetailType())) {
						line.setContractEndDate(orderInfo.getItemName());
					}
					if (StringUtils.equalsIgnoreCase(Constant.DACT_ETF_FEE, orderInfo.getDetailType())) {
						line.setEtfFee(orderInfo.getItemName());
					}
					line.setServiceNumber(orderInfo.getServiceNumber());
					line.setUserName(orderInfo.getSubscriberName());
					line.setUserName(orderInfo.getSubscriberName());
				});
				accountOrderDetailsMap.get(accountInfo.getKey()).add(line);
			});
		});
	}
	
	public static void setAccountLineItemCMB(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsSMList = new ArrayList<AccountLineItem>();
		Map<String, List<SystemTxnInfo>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfo>>();
		groupAccountOrderDetailsSysInfo(orderDetailsResponse, accountOrderDetailsMap);
		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<LinkedHashMap<String, String>>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<String, String>();
							detailMap.put(Constant.ACC_LINE_ITEM_MTN, detailInfo.getServiceNumber());
							detailMap.put(Constant.ACC_LINE_ITEM_USER_NAME, detailInfo.getSubscriberName());
							detailMap.put(Constant.ACC_LINE_ITEM_CMB, detailInfo.getPlanGroup());
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsSMList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsSMList);
		}
	}
	
	private static void groupAccountOrderDetailsSysInfo(OrderDetailsResponse orderDetailsResponse,
			Map<String, List<SystemTxnInfo>> accountOrderDetailsMap) {
		orderDetailsResponse.getOrderDetailsList().forEach(orderDetail -> {
			if (orderDetail != null && orderDetail.getAccountNumber() != null) {
				if (accountOrderDetailsMap.containsKey(orderDetail.getAccountNumber())) {
					accountOrderDetailsMap.get(orderDetail.getAccountNumber()).add(orderDetail);
				} else {
					List<SystemTxnInfo> sysTxnInfoList = new ArrayList<SystemTxnInfo>();
					sysTxnInfoList.add(orderDetail);
					accountOrderDetailsMap.put(orderDetail.getAccountNumber(), sysTxnInfoList);
				}
			}
		});
	}
	
	/**
	 * method to build screen data for Change Billing Address MA Landing page
	 * @param orderDetailsResponse
	 * @param smAccountLevelOrderResponse
	 */
	public static void setAccountLineItemResponseForCBA(OrderDetailsResponse orderDetailsResponse,
			SMAccountLevelOrderResponse smAccountLevelOrderResponse) {
		List<AccountDetails> accountDetailsList = new ArrayList<AccountDetails>();
		Map<String, List<SystemTxnInfoForCBA>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfoForCBA>>();

		groupAccountOrderDetailsCBA(orderDetailsResponse, accountOrderDetailsMap);

		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountDetails accountDetails= new AccountDetails();

					SystemTxnInfoForCBA detailInfo = accountOrderDetails.getValue().get(Constant.ZERO_AS_INT);
					if (detailInfo != null) {
						accountDetails.setOldData(detailInfo.getOldBillingData());
						accountDetails.setNewData(detailInfo.getNewBillingData());
					}
					accountDetails.setAccountNumber(accountOrderDetails.getKey());
					accountDetailsList.add(accountDetails);
				}
			});
			smAccountLevelOrderResponse.setAccountDetailsList(accountDetailsList);
		}
	}

	/**
	 * method to group account details for Change Billing Address MA Landing page
	 * @param orderDetailsResponse
	 * @param accountOrderDetailsMap
	 */
	private static void groupAccountOrderDetailsCBA(OrderDetailsResponse orderDetailsResponse,
			Map<String, List<SystemTxnInfoForCBA>> accountOrderDetailsMap) {
		List<SystemTxnInfo> orderItemList = new ArrayList<>();
		
		orderItemList.addAll(orderDetailsResponse.getOrderDetailsList());
		List<String> accountNumberList = new ArrayList<>();
		Map<String, List<SystemTxnInfo>> accountMap = new HashMap<>();
		for (SystemTxnInfo systemTxnIfo : orderItemList) {
			if (!accountNumberList.contains(systemTxnIfo.getAccountNumber())) {
				accountNumberList.add(systemTxnIfo.getAccountNumber());
				List<SystemTxnInfo> filteredFeatureInfo = orderItemList.stream().filter(feature -> {
					return feature.getAccountNumber().equalsIgnoreCase(systemTxnIfo.getAccountNumber());
				}).collect(Collectors.toList());
				accountMap.put(systemTxnIfo.getAccountNumber(), filteredFeatureInfo);
			}
		}
		if (!accountMap.isEmpty()) {
			filterItemValuesCBA(accountMap,accountOrderDetailsMap);
		}
	}

	/**
	 * method to filter field values for Change Billing Address from transaction history data
	 * @param accountMap
	 * @param accountOrderDetailsMap
	 */
	private static void filterItemValuesCBA(Map<String, List<SystemTxnInfo>> accountMap,Map<String, List<SystemTxnInfoForCBA>> accountOrderDetailsMap) {	
		accountMap.entrySet().forEach(productMap -> {
			SystemTxnInfoForCBA line = new SystemTxnInfoForCBA();
			BillingAddressDetails oldBillingData = new BillingAddressDetails();
			BillingAddressDetails newBillingData = new BillingAddressDetails();
			productMap.getValue().stream().forEach(product -> {
				if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_LOCATION,product.getDetailType())) {
					oldBillingData.setLocation(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setLocation(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_ATTENTION_LINE,product.getDetailType())) {
					oldBillingData.setAttentionLine(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setAttentionLine(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_ADDRESS1,product.getDetailType())) {
					oldBillingData.setAddressLine1(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setAddressLine1(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_ADDRESS2,product.getDetailType())) {
					oldBillingData.setAddressLine2(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setAddressLine2(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_CITY,product.getDetailType())) {
					oldBillingData.setCity(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setCity(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_STATE,product.getDetailType())) {
					oldBillingData.setState(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setState(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_ZIP_CODE,product.getDetailType())) {
					oldBillingData.setZipCode(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setZipCode(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_CONTACT1,product.getDetailType())) {
					oldBillingData.setContact1(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setContact1(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_EXT1,product.getDetailType())) {
					oldBillingData.setExt1(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setExt1(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_CONTACT2,product.getDetailType())) {
					oldBillingData.setContact2(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setContact2(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_EXT2,product.getDetailType())) {
					oldBillingData.setExt2(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setExt2(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				} else if (StringUtils.equalsIgnoreCase(Constant.ACC_LINE_ITEM_PAPERLESS,product.getDetailType())) {
					oldBillingData.setPaperlessIndicator(product.getItemName() != null ? product.getItemName() : "");
					newBillingData.setPaperlessIndicator(product.getPlanGroup() != null ? product.getPlanGroup() : "");
				}
			});	
			line.setOldBillingData(oldBillingData);
			line.setNewBillingData(newBillingData);
			accountOrderDetailsMap.put(productMap.getKey(), new ArrayList<SystemTxnInfoForCBA>());			
			accountOrderDetailsMap.get(productMap.getKey()).add(line);
		});	
	}

	/**
	 * <p>
	 * Method to build the MA approval response for CBR
	 * </p>
	 * 
	 * @param orderDetailsResponse
	 * @param smOrderResponse
	 */
	public static void buildAccountAndLineResponseForCBR(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsList = new ArrayList<AccountLineItem>();

		Map<String, List<SystemTxnInfo>> accountOrderDetailsMap = new LinkedHashMap<>();

		groupAccountOrderDetailsSysInfo(orderDetailsResponse, accountOrderDetailsMap);
		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {				
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<>();

							detailMap.put(Constant.ACC_LINE_ITEM_MTN, detailInfo.getServiceNumber());
							detailMap.put(Constant.ACC_LINE_ITEM_USER_NAME, detailInfo.getSubscriberName());
							detailMap.put(Constant.ACC_LINE_ITEM_NEW_USER_NAME, detailInfo.getPlanGroup());
							detailMap.put(Constant.ACC_LINE_ITEM_NEW_USER_EMAIL, detailInfo.getItemName());
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsList);
		}
	}
}