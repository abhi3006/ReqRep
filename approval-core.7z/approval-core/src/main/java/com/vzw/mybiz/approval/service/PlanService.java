package com.vzw.mybiz.approval.service;

import java.util.List;
import java.util.Map;

import com.vzw.mybiz.approval.data.bcc.entity.PlanMasterDetails;
import com.vzw.mybiz.prospect.domain.plan.PlanRequest;

public interface PlanService {
	
	public Map<String, List<PlanMasterDetails>> fetchDeviceCompatiblePlans(PlanRequest planReq);

}
