package com.vzw.mybiz.approval.rest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.PlanResponse;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferReq;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferUiRes;
import com.vzw.mybiz.approval.exception.ApprovalException;
import com.vzw.mybiz.approval.exception.VipFeignException;
import com.vzw.mybiz.approval.rest.domain.SAPInventoryRequest;
import com.vzw.mybiz.approval.rest.domain.SAPInventoryResponse;
import com.vzw.mybiz.approval.service.DunsService;
import com.vzw.mybiz.approval.service.NpaNxxService;
import com.vzw.mybiz.approval.service.PlanService;
import com.vzw.mybiz.approval.service.SAPService;
//import com.vzw.mybiz.approval.service.EcpdService;
import com.vzw.mybiz.approval.service.VipRestService;
import com.vzw.mybiz.prospect.domain.LineInfo;
import com.vzw.mybiz.prospect.domain.Root;
import com.vzw.mybiz.prospect.domain.SelectedFeaturesList;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceRequest;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceResponse;
import com.vzw.mybiz.prospect.domain.duns.StandardizedAddressServiceRequest;
import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxRequet;
import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxResponse;
import com.vzw.mybiz.prospect.domain.plan.PlanRequest;
import com.vzw.mybiz.prospect.domain.pos.ObjectFactory;
import com.vzw.mybiz.prospect.domain.pos.POSServices;
import com.vzw.mybiz.sharedcart.domain.pos.Cart;
import com.vzw.mybiz.sharedcart.domain.pos.CartFeatureList;
import com.vzw.mybiz.sharedcart.domain.pos.CartHeader;
import com.vzw.mybiz.sharedcart.domain.pos.CartItem;
import com.vzw.mybiz.sharedcart.domain.pos.CartItemInfo;
import com.vzw.mybiz.sharedcart.domain.pos.CartItemList;
import com.vzw.mybiz.sharedcart.domain.pos.CartItemType;
import com.vzw.mybiz.sharedcart.domain.pos.CartLine;
import com.vzw.mybiz.sharedcart.domain.pos.CartOrderDetails;
import com.vzw.mybiz.sharedcart.domain.pos.CartOrderHeader;
import com.vzw.mybiz.sharedcart.domain.pos.CartServiceInfo;
import com.vzw.mybiz.sharedcart.domain.pos.EcpdInfo;
import com.vzw.mybiz.sharedcart.domain.pos.PosCartPricePlanInfoType;
import com.vzw.mybiz.sharedcart.domain.pos.PosCartPrimaryUserInfoType;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@RestController
@RequestMapping("mbt/prospect")
public class ProspectController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProspectController.class);
	
	@Autowired
	private VipRestService posService;
	
	@Autowired
	private PlanService planService;
	
	@Autowired
	private DunsService dunsService;
	
	@Autowired
	private NpaNxxService npanxxService;
	
//	@Autowired
//	private EcpdService ecpdService;
	
	@Autowired
	SAPService sapService;
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	
	@RequestMapping(value = "/getRealTimeInventoryStatus", method = RequestMethod.POST)
	public SAPInventoryResponse getRealTimeInventoryStatus(@RequestBody SAPInventoryRequest request) {
		SAPInventoryResponse inventoryResponse = sapService.getRealTimeInventoryStatus(request);
		return inventoryResponse;

	}
	
	@PostMapping(value = "/computeSedOffer", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ComputeOfferUiRes computeSedOffer(@RequestBody ComputeOfferReq computeOfferReq) {
		LOGGER.info("Calling computeSedOffer API");
		ComputeOfferUiRes res = new ComputeOfferUiRes();
		if (computeOfferReq != null) {
			res = posService.computeOffer(computeOfferReq);
		} else {
			com.vzw.mybiz.utilities.audit.domain.ServiceStatus serviceStatus = new com.vzw.mybiz.utilities.audit.domain.ServiceStatus();
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setStatusMessage(Constants.MISSING_MANDATORY_FIELDS);
			serviceStatus.setSuccess(false);
			res.setServiceStatus(serviceStatus);
		}
		LOGGER.info("Successfully retrieved ManagerApproval SM Information");
		return res;
	}
	
	@PostMapping(value = "/submit", produces = MediaType.APPLICATION_JSON_VALUE)
	public ServiceStatus prepareAndSubmit(@RequestBody Root prospectOrder) throws ApprovalException {
		LOGGER.info("Inside prepareAndSubmit of ProspectController");
		
		ServiceStatus status = null;
		boolean inventoryCheck = true;
		if (prospectOrder != null) {
			prospectOrder.getCartHeader().setUserId("c0velr3");
			
			List<LineInfo> lineInfoLst = prospectOrder.getLineDetails().getLineInfo();
			if (lineInfoLst != null) {
				for (LineInfo lineInfo : lineInfoLst) {
					lineInfo.getServiceInfo().setSelectedFeaturesList(new SelectedFeaturesList());
				}
			}
			Cart posCart = transformCartToPOSCart(prospectOrder);
			//if (posCart.getCartHeader().getEcpdInfo() == null) {
				posCart.getCartHeader().setEcpdInfo(new com.vzw.mybiz.sharedcart.domain.pos.EcpdInfo());
				posCart.getCartHeader().getEcpdInfo().setEcpdID("");
				//ecpdService.prepareAndSubmitAutomateEnroll(prospectOrder);
			//}
			//posCart.getOrderDetails().setLocationCode("W211501");
				posCart.getOrderDetails().setLocationCode("D221201");
				
			posCart.getCartHeader().setOriginatingSalesRep("EE818");
			posCart.getCartHeader().setLastAccessSalesRep("EE818");
			posCart.getLineDetails().setNumOfLines(1);
//			List<InventorySkuDetails> skuDtlsLst = new ArrayList<InventorySkuDetails>();
//			for (CartLine lineInfo: posCart.getLineDetails().getLineInfo()) {
//				for (CartItemInfo cartItmInfo: lineInfo.getItemsInfo()) {
//					for (CartItem c : cartItmInfo.getCartItems().getCartItem()) {
//						if ("DEVICE".equalsIgnoreCase(c.getCartItemType().value()) 
//								|| "ACCESSORY".equalsIgnoreCase(c.getCartItemType().value())) {
//							
//							InventorySkuDetails skuDtls = new InventorySkuDetails();
//							skuDtls.setCriticalInventoryLevel(0);
//							skuDtls.setDeviceMasterId("");
//							skuDtls.setRequestedQuantity(c.getQty()!=null?c.getQty().intValue():1);
//							skuDtls.setSku(c.getItemCode());
//							skuDtls.setSkuName(c.getItemName());
//							skuDtls.setSkuType(c.getCartItemType().value());
//							skuDtlsLst.add(skuDtls);
//							
//						}
//					}
//				}
//				
//			}
			
//			SAPInventoryRequest sapReq = new SAPInventoryRequest();
//			sapReq.setEcpdId("");
//			sapReq.setInventorySkuDetails(skuDtlsLst);
//			sapReq.setIspuLocation(null);
//			sapReq.setLocationCode("L");
//			sapReq.setRequestedSource("Prospect");
//			sapReq.setStoreSaleIndicator("L");
//			sapReq.setUserId("MyBiz-Prospect");
//			
//			SAPInventoryResponse sapResp = sapService.getRealTimeInventoryStatus(sapReq);
//			
//			if (sapResp == null || "99".equalsIgnoreCase(sapResp.getServiceStatus().getStatusCode())) {
//				inventoryCheck = false;
//			} else {
//				
//				for (CartLine lineInfo: posCart.getLineDetails().getLineInfo()) {
//					for (CartItemInfo cartItmInfo: lineInfo.getItemsInfo()) {
//						for (CartItem c : cartItmInfo.getCartItems().getCartItem()) {
//							if ("DEVICE".equalsIgnoreCase(c.getCartItemType().value()) 
//									|| "ACCESSORY".equalsIgnoreCase(c.getCartItemType().value())) {
//								for (InventorySkuResponse skuResponse : sapResp.getInventorySkuDetails()) {
//									if (skuResponse!=null && c.getItemCode().equalsIgnoreCase(skuResponse.getSku()) && skuResponse.getAvailableQuantity() <= 0) {
//										inventoryCheck = false;
//									}
//								}	
//							}
//						}
//					}
//					
//				}
//			}
//			if (!inventoryCheck) {
//				return null; //need to build
//			}
			posCart.getLineDetails().getLineInfo().stream().map(a->{
				a.setMobileNumber("mtn1");
				a.setIspuItem(false);
				a.getServiceInfo().setContractTermId("48");
				if (a.getServiceInfo().getPricePlanInfo() !=null) {
					a.getServiceInfo().getPricePlanInfo().setContractTermId("48");
					a.getServiceInfo().getPrimaryUserInfo().setIsValidAddress(false);
					String addressl1 = a.getServiceInfo().getPrimaryUserInfo().getAddress().getAddress1();
					String[] splitAddress = null;
					LOGGER.info("addressl1--->"+addressl1);
					try {
						a.getServiceInfo().getPrimaryUserInfo().setAddress(posService.validateAddress(a.getServiceInfo().getPrimaryUserInfo().getAddress()));
					} catch (VipFeignException e) {
						e.printStackTrace();
					}
					
					a.getServiceInfo().setCurrentDevice(null);
					a.getItemsInfo().stream().map(b->{
						int index = -1;
						int cnt=0;
						
						for (CartItem c : b.getCartItems().getCartItem()) {
							LOGGER.info("Info----------SIM--->"+c.getCartItemType().value());
							
							if("SIM".equalsIgnoreCase(c.getCartItemType().value())) {
								c.setItemCode("EMBDSIMTRI");
								c.setSorId("EMBDSIMTRI");
								LOGGER.info("Info----------SIM--->"+c.getItemCode());
							}
							
							
							LOGGER.info("Info----------SIM--->"+c.getItemCode());
						}
						
						
						
						for (CartItem c : b.getCartItems().getCartItem()) {
							
							if (c.getItemCode() == "" || StringUtils.isBlank(c.getItemCode())) {
								index = cnt;break;
							}
							cnt++;
						}
						if (index >= 0 && index < b.getCartItems().getCartItem().size()) {
							b.getCartItems().getCartItem().remove(index);	
						}
						
						String addressInnerl1 = b.getShipping().getAddress().getAddress1();
						LOGGER.info("addressInnerl1--->"+addressInnerl1);
						String[] splitInnerAddress = null;

						try {
							b.getShipping().setAddress(posService.validateAddress(b.getShipping().getAddress()));
						} catch (VipFeignException e) {
							e.printStackTrace();
						}
						
						
						b.setAttention("JOHN DOE");
						try {
							b.getShipping().setCBRPhone(b.getShipping().getCBRPhone().replace("-", ""));
						} catch(Exception e) {
							b.getShipping().setCBRPhone("");
						}
						b.getShipping().setIsValidAddress(false);
						return b;
					}).collect(Collectors.toList());
				}
				return a;
				}).collect(Collectors.toList());
			ObjectMapper Obj = new ObjectMapper();
			try {
				String jsonStr = Obj.writeValueAsString(posCart);
				// String base64Content = base64Encode(prospectOrder);
				LOGGER.info("jsonStr----->" + jsonStr);
				String part1 = jsonStr.substring(0, jsonStr.indexOf("\"ecpdInfo\""));
				//String part2 = jsonStr.substring(jsonStr.indexOf("\"ecpdInfo\""), jsonStr.indexOf("}"));
				String part3 = "\"ecpdInfo\": {\"ecpdID\": \"\"}";
				jsonStr = part1+part3+jsonStr.substring(jsonStr.indexOf("}")+1);
				LOGGER.info("jsonStr----->" + jsonStr);
				byte[] gZip = compress(jsonStr);
				LOGGER.info("gZip---->" + gZip);
				String base64Content = base64Encode(gZip);
				
				status = posService.submitProspectOrder(base64Content,prospectOrder);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		LOGGER.info("Exit prepareAndSubmit of ProspectController");
		return status;
	}
	
	@PostMapping(value="/npa-nxx", produces = MediaType.APPLICATION_JSON_VALUE)
	public NpaNxxResponse fetchNPANXX(@RequestBody NpaNxxRequet npanxxReq) throws ApprovalException {
		LOGGER.info("Inside fetchNPANXX of ProspectController");
		
		if (npanxxReq!=null) {
			return npanxxService.fetchNPANXX(npanxxReq);
		}
		
		LOGGER.info("Exit fetchNPANXX of ProspectController");
		return null;
	}
	
	@PostMapping(value = "/getDeviceCompatiblePlans", produces = MediaType.APPLICATION_JSON_VALUE)
	public PlanResponse getProspectPlans(@RequestBody PlanRequest planRequest) {
		LOGGER.info("Inside getProspectPlans of ProspectController");
		PlanResponse resp = new PlanResponse();
		if (planRequest != null) {
			
			resp.setResponse(planService.fetchDeviceCompatiblePlans(planRequest));
		}
		LOGGER.info("Exit getProspectPlans of ProspectController");
		return resp;
	}
	
	@PostMapping(value = "/addressMatchService", produces = MediaType.APPLICATION_JSON_VALUE)
	public AddressServiceResponse addressMatchService(@RequestBody AddressServiceRequest addMatchReq) {
		AddressServiceResponse response = new AddressServiceResponse();
		response = dunsService.getAddressMatchService(addMatchReq);
		
		return response;
	}
	
	
	@PostMapping(value = "/standardizedAddressService", produces = MediaType.APPLICATION_JSON_VALUE)
	public AddressServiceResponse standardizedAddressService(@RequestBody StandardizedAddressServiceRequest stndAddressReq) {
		AddressServiceResponse response = new AddressServiceResponse();
		response = dunsService.getStandardizedAddressService(stndAddressReq);
		
		return response;
	}
	
	
	private Cart transformCartToPOSCart(Root prospectOrder) {
		LOGGER.info("Inside transformCartToPOSCart of ProspectController");
		
		//DozerBeanMapper mapper=new DozerBeanMapper();
		MapperFactory mapperFactory=new DefaultMapperFactory.Builder().build();
		MapperFacade mapper=mapperFactory.getMapperFacade();
		Cart posCart = mapper.map(prospectOrder, Cart.class);
		CartHeader posCartHeader = mapper.map(prospectOrder.getCartHeader(), CartHeader.class);
		EcpdInfo ecpdInfo = mapper.map(prospectOrder.getCartHeader().getEcpdInfo(), EcpdInfo.class);
		posCartHeader.setEcpdInfo(ecpdInfo);
		CartOrderHeader posCartHeaderOD = mapper.map(prospectOrder.getOrderDetails(), CartOrderHeader.class);
		CartOrderDetails posOrderDetails = mapper.map(prospectOrder.getLineDetails(), CartOrderDetails.class);
		
		List<CartLine> posLineInfoLst = prospectOrder.getLineDetails().getLineInfo().stream().map(i-> {
			CartLine posLineInfo = mapper.map(i, CartLine.class);
			posLineInfo.setServiceInfo(mapper.map(i.getServiceInfo(), CartServiceInfo.class));
			posLineInfo.getServiceInfo().setPrimaryUserInfo(mapper.map(i.getServiceInfo().getPrimaryUserInfo(), PosCartPrimaryUserInfoType.class));
			posLineInfo.getServiceInfo().setPricePlanInfo(mapper.map(i.getServiceInfo().getPricePlanInfo(), PosCartPricePlanInfoType.class));
			posLineInfo.getServiceInfo().setSelectedFeaturesList(mapper.map(i.getServiceInfo().getSelectedFeaturesList(), CartFeatureList.class));
			
			List<CartItemInfo> cartItmInfoLst =  i.getItemsInfo().stream().map(j -> {
				CartItemInfo cartItemInfo = mapper.map(j, CartItemInfo.class);
				cartItemInfo.setCartItems(mapper.map(j.getCartItems(), CartItemList.class));
				List<CartItem> cartItemLstStream = j.getCartItems().getCartItem().stream().map(k -> {
					k.setCartItemType(k.getCartItemType().toUpperCase());
					CartItem cartItm = mapper.map(k, CartItem.class);
					cartItm.setCartItemType(CartItemType.fromValue(k.getCartItemType().toUpperCase()));
					return cartItm;
					}).collect(Collectors.toList());
				cartItemInfo.getCartItems().getCartItem().addAll(cartItemLstStream);
				return cartItemInfo;
				}).collect(Collectors.toList());
			posLineInfo.getItemsInfo().addAll(cartItmInfoLst);
			return posLineInfo;
			}).collect(Collectors.toList());
		posOrderDetails.getLineInfo().addAll(posLineInfoLst);
		
		
		posCart.setCartHeader(posCartHeader);
		posCart.setLineDetails(posOrderDetails);
		posCart.setOrderDetails(posCartHeaderOD);
		LOGGER.info("Exit transformCartToPOSCart of ProspectController");
		return posCart;
	}
	
	private POSServices buildPOSRequest(String base64Order) {
		LOGGER.info("Inside buildPOSRequest of ProspectController");
		
		ObjectFactory posObjectFactory = new ObjectFactory();
		POSServices service = posObjectFactory.createPOSServices();
		POSServices.ServiceHeader serviceHeader = posObjectFactory.createPOSServicesServiceHeader();
		POSServices.ServiceHeader.OrderKeyInfo serviceHeaderOrderKeyInfo = posObjectFactory.createPOSServicesServiceHeaderOrderKeyInfo();
		
		POSServices.ServiceBody serviceBody = posObjectFactory.createPOSServicesServiceBody();
		
		POSServices.ServiceBody.SaveCommonCartMS saveCommonCartMS = posObjectFactory.createPOSServicesServiceBodySaveCommonCartMS();
		POSServices.ServiceBody.SaveCommonCartMS.Request saveCommonCartMSRequest =  posObjectFactory.createPOSServicesServiceBodySaveCommonCartMSRequest();
		
		saveCommonCartMSRequest.setStatus("A");
		saveCommonCartMSRequest.setCartInfo(base64Order);
		
		saveCommonCartMS.setRequest(saveCommonCartMSRequest);
		serviceBody.setSaveCommonCartMS(saveCommonCartMS);
		
		serviceHeader.setClientAppName("MYBUSINESS");
		serviceHeader.setClientAppUserName("PROSPECT-USER");
		serviceHeader.setEncryptionIndicator("T");
		//serviceHeader.setOrderKeyInfo(serviceHeaderOrderKeyInfo);
		serviceHeader.setServiceAction("saveCommonCart");
		serviceHeader.setServiceName("cartMicroService");
		//serviceHeader.setSessionID("");
		//serviceHeader.setTimeStamp("");
		//serviceHeader.setTransactionId("");
		
		service.setServiceHeader(serviceHeader);
		service.setServiceBody(serviceBody);
		
		
		LOGGER.info("Exit buildPOSRequest of ProspectController");
		return service;
	}
	
	public String base64Encode(byte[] order) {
		LOGGER.info("Inside base64Encode of ProspectController"+order);
		
		
        String base64encodedString = null;
		try {
			LOGGER.info("order.getBytes('utf-8'):::"+order);
			//LOGGER.info("order.getBytes():::"+order.getBytes());
			base64encodedString = Base64.getEncoder().encodeToString(order);
		} catch (Exception e) {
			LOGGER.error("Errro--->"+ e);
		}
		LOGGER.info("Exit base64Encode of ProspectController");
		return base64encodedString;
	}
	
	public byte[] compress(String str) throws IOException {
	    if (str == null || str.length() == 0) {
	        return null;
	    }
	    ByteArrayOutputStream out = new ByteArrayOutputStream();
	    GZIPOutputStream gzip = new GZIPOutputStream(out);
	    gzip.write(str.getBytes(StandardCharsets.UTF_8));
	    gzip.close();
	    return out.toByteArray();
	 }

}
