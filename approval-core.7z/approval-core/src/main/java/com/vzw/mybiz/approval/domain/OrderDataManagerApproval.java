package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderDataManagerApproval implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	EcpdProfileInfo commerceInfo;
	EcpdProfileInfo accountMaintenanceInfo;;
	private String[] domainEntry;
	public EcpdProfileInfo getCommerceInfo() {
		return commerceInfo;
	}
	public void setCommerceInfo(EcpdProfileInfo commerceInfo) {
		this.commerceInfo = commerceInfo;
	}
	public String[] getDomainEntry() {
		return domainEntry;
	}
	public void setDomainEntry(String[] domainEntry) {
		this.domainEntry = domainEntry;
	}
	public EcpdProfileInfo getAccountMaintenanceInfo() {
		return accountMaintenanceInfo;
	}
	public void setAccountMaintenanceInfo(EcpdProfileInfo accountMaintenanceInfo) {
		this.accountMaintenanceInfo = accountMaintenanceInfo;
	}
	
	
}
