package com.vzw.mybiz.approval.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.NotificationClient;
import com.vzw.mybiz.approval.client.WfmCoreClient;
import com.vzw.mybiz.approval.client.WorkFlowClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AutoNotificationRequest;
import com.vzw.mybiz.approval.domain.AutoNotificationResponse;
import com.vzw.mybiz.approval.domain.Email;
import com.vzw.mybiz.approval.domain.FailOverWfmRequest;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.UpdateRequest;
import com.vzw.mybiz.approval.domain.notification.ClassicSubmitOrder;
import com.vzw.mybiz.approval.domain.notification.MBTSubmitOrder;
import com.vzw.mybiz.approval.domain.notification.ProfileEligibilityResponse;
import com.vzw.mybiz.approval.domain.notification.ProfileParameterRequest;
import com.vzw.mybiz.approval.entity.EmailScheduleDetailsLog;
import com.vzw.mybiz.approval.entity.EmailScheduleLog;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.repo.EmailScheduleDetailsLogRepo;
import com.vzw.mybiz.approval.repo.EmailScheduleLogRepo;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.BatchService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

import io.jsonwebtoken.lang.Collections;

@Component
public class BatchServiceImpl implements BatchService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BatchServiceImpl.class);

	@Autowired
	private WorkFlowClient workFlowClient;

	@Autowired
	private WfmCoreClient wfmClient;

	@Autowired
	private ManagerApprovalRepo managerApprovalRepo;

	@Autowired
	EmailScheduleLogRepo emailScheduleLogRepo;

	@Autowired
	EmailScheduleDetailsLogRepo emailScheduleDetailsLogRepo;

	@Autowired
	NotificationClient notificationClient;

	@Autowired
	CloudPropertiesConfig cloudPropertiesConfig;

	@Autowired
	CompanyClient companyClient;

	private Gson gson = new Gson();

	private DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	/* second, minute, hour, day of month, month, day(s) of week */
	@Scheduled(cron = "${spring.batch.schedule.timer}") // cron=0/60+*+*+*+*+?
	public void makeManagerApprovalTasks() {
		System.out.println("Cron Task :: Execution Time - {}" + dateTimeFormatter.format(LocalDateTime.now()));
		if (!"true".equalsIgnoreCase(cloudPropertiesConfig.getBatchEnabled())) {
			LOGGER.info("Batch is not enabled for execution...");
			return;
		}

		boolean initialReminderFlag = false;
		boolean finalReminderFlag = false;
		boolean autoExpireReminderFlag = false;

		Long initialReminderSchId = null;
		Long finalReminderSchId = null;
		Long autoExpireReminderSchId = null;

		AutoNotificationRequest maRequest = new AutoNotificationRequest();

		List<EmailScheduleLog> emailScheduleLogs = emailScheduleLogRepo.getEmailScheduleLogList(new Date());

		if (Collections.isEmpty(emailScheduleLogs)) {
			initialReminderFlag = true;
			finalReminderFlag = true;
			autoExpireReminderFlag = true;
		} else {
			for (EmailScheduleLog emailScheduleLog : emailScheduleLogs) {
				if (Constants.TRAN_SUB_STATUS_REMINDER1.equals(emailScheduleLog.getSchSubStatus())
						&& Constants.TRAN_STATUS_FAILED.equals(emailScheduleLog.getSchStatus())
						&& emailScheduleLog.getTotalRecCount() == 0) {
					initialReminderFlag = true;
					initialReminderSchId = emailScheduleLog.getId();
				}

				if (Constants.TRAN_SUB_STATUS_REMINDER2.equals(emailScheduleLog.getSchSubStatus())
						&& Constants.TRAN_STATUS_FAILED.equals(emailScheduleLog.getSchStatus())
						&& emailScheduleLog.getTotalRecCount() == 0) {
					finalReminderFlag = true;
					finalReminderSchId = emailScheduleLog.getId();
				}

				if (Constants.TRAN_SUB_STATUS_EXPIRED.equals(emailScheduleLog.getSchSubStatus())
						&& Constants.TRAN_STATUS_FAILED.equals(emailScheduleLog.getSchStatus())
						&& emailScheduleLog.getTotalRecCount() == 0) {
					autoExpireReminderFlag = true;
					autoExpireReminderSchId = emailScheduleLog.getId();
				}

			}
		}
		if (initialReminderFlag) {
			try {
				LOGGER.info("InitialNotification batch job execution start");
				maRequest = createAutonotificationRequest(Constants.TRAN_SUB_STATUS_REMINDER1, initialReminderSchId);
				initialReminder(maRequest);
			} catch (Exception e) {
				LOGGER.error("Error in InitialNotification batch process", e);
			}
		}

		if (finalReminderFlag) {
			try {
				LOGGER.info("finalReminder batch job execution start");
				maRequest = createAutonotificationRequest(Constants.TRAN_SUB_STATUS_REMINDER2, finalReminderSchId);
				finalReminder(maRequest);
			} catch (Exception e) {
				LOGGER.error("Error in finalReminder batch process", e);
			}
		}
		if (autoExpireReminderFlag) {
			try {
				LOGGER.info("autoCancelNotification batch job execution start");
				maRequest = createAutonotificationRequest(Constants.TRAN_SUB_STATUS_EXPIRED, autoExpireReminderSchId);
				autoCancelNotification(maRequest);
			} catch (Exception e) {
				LOGGER.error("Error in autoCancelNotification batch process", e);
			}
		}
	}

	@Override
	public AutoNotificationResponse initialReminder(AutoNotificationRequest maRequest) {

		AutoNotificationResponse response = new AutoNotificationResponse();

		List<ManagerApprovalTracker> managerApprovalTrackers = managerApprovalRepo.getInitialNotificationList();
		if (!Collections.isEmpty(managerApprovalTrackers)) {
			maRequest.setNotificationType(Constants.TRAN_SUB_STATUS_REMINDER1);
			maRequest.setNotificationTemplate(Constants.TEMPLATE_REMINDER);
			maRequest.setTemplateType(Constants.TEMPLATE_REMINDER);
			maRequest.setReminderNumber("1");

			processEmail(maRequest, managerApprovalTrackers);
		} else {
			LOGGER.info("reminderNotification " + maRequest.getReminderFromDays()
					+ " not sent as there is no pending approval for L1 or L2" + new Date());
		}
		response.setManagerApprovalTrackers(managerApprovalTrackers);
		response.setServiceStatus(
				prepareServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true, Constants.SUCCESS_MSG));
		return response;
	}

	@Override
	public AutoNotificationResponse finalReminder(AutoNotificationRequest maRequest) {

		AutoNotificationResponse response = new AutoNotificationResponse();

		List<ManagerApprovalTracker> managerApprovalTrackers = managerApprovalRepo.getFinalNotificationList();
		// Make and entry to schedule table
		if (!Collections.isEmpty(managerApprovalTrackers)) {
			maRequest.setNotificationType(Constants.TRAN_SUB_STATUS_REMINDER2);
			maRequest.setNotificationTemplate(Constants.TEMPLATE_REMINDER);
			maRequest.setTemplateType(Constants.TEMPLATE_REMINDER);
			maRequest.setReminderNumber("2");
			processEmail(maRequest, managerApprovalTrackers);
		} else {
			LOGGER.info("reminderNotification " + maRequest.getReminderFromDays()
					+ " not sent as there is no pending approval for L1 or L2" + new Date());
		}
		response.setManagerApprovalTrackers(managerApprovalTrackers);
		response.setServiceStatus(
				prepareServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true, Constants.SUCCESS_MSG));
		return response;
	}

	@Override
	public AutoNotificationResponse autoCancelNotification(AutoNotificationRequest maRequest) {
		AutoNotificationResponse response = new AutoNotificationResponse();

		List<ManagerApprovalTracker> managerApprovalTrackers = managerApprovalRepo.getAutoExpiredList();
		if (!Collections.isEmpty(managerApprovalTrackers)) {
			maRequest.setNotificationType(Constants.TRAN_SUB_STATUS_EXPIRED);
			maRequest.setNotificationTemplate(Constants.TEMPLATE_EXPIRE_MA);
			maRequest.setTemplateType(Constants.TEMPLATE_EXPIRE_MA);
			processEmail(maRequest, managerApprovalTrackers);
		} else {
			LOGGER.info("autoCancelNotification: {} {} {}" , maRequest.getReminderFromDays()
					, " not sent as there is no pending approval for L1 or L2" , new Date());
		}

		response.setManagerApprovalTrackers(managerApprovalTrackers);
		response.setServiceStatus(
				prepareServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true, Constants.SUCCESS_MSG));
		return response;
	}

	/**
	 * @param maRequest
	 * @param processMessage
	 * @param status
	 * @param managerApprovalTrackers
	 */
	private void processEmail(AutoNotificationRequest maRequest, List<ManagerApprovalTracker> managerApprovalTrackers) {

		String processMessage = Constants.TRAN_STATUS_IN_PROGRESS;
		String status = Constants.TRAN_STATUS_IN_PROGRESS;
		Long recordId = null;
		if (StringUtils.isNotBlank(maRequest.getRequester())) {
			maRequest.setRequester(Constants.USER_MANUAL);
		}
		Date createDate = new Date();

		EmailScheduleLog emailScheduleLog = prepareEmailScheduleLog(Constants.ACTION_INSERT, maRequest.getRequester(),
				createDate, deriveEnvValue(cloudPropertiesConfig.getEnv()), Constants.SCR_MBT,
				Integer.toString(managerApprovalTrackers.size()), processMessage, status,
				maRequest.getNotificationType());
		if (maRequest.getScheduleLogId() == null) {
			recordId = createOrUpdateScheduleLog(emailScheduleLog, Constants.ACTION_INSERT);
			maRequest.setScheduleLogId(recordId);
		}
		emailScheduleLog.setId(maRequest.getScheduleLogId());

		try {
			for (ManagerApprovalTracker tempMATracker : managerApprovalTrackers) {
				ProfileEligibilityResponse eligibilityResponse = getEligibilityResponse(tempMATracker.getEcpdId(),
						maRequest.getResetParamValue());
				if (eligibilityResponse != null && eligibilityResponse.getProfileEligibilityInfo() != null
						&& eligibilityResponse.getProfileEligibilityInfo().isEnableDisableFlag()) {
					String rejectionType = Constants.STR_BLANK;
					Email request = new Email();
					request.setSchId(maRequest.getScheduleLogId());
					ServiceStatus serviceStatus = prepareServiceStatus(Constants.SUCCESS_CODE,
							maRequest.getNotificationType(), true, Constants.SUCCESS_MSG);
					request.setRequester(maRequest.getRequester());
					request.setMailFrom(maRequest.getMailFrom());
					request.setMyBusinessIds(maRequest.getMyBusinessIds());

					request.setEcpdId(tempMATracker.getEcpdId());
					request.setOrderNumber(tempMATracker.getOrderNumber());
					request.setTemplateName(maRequest.getTemplateType());

					if (Constants.L2_PENDING.equals(tempMATracker.getStatus())) {
						request.setMailTo(tempMATracker.getApproverEmailL2());
						request.setApprovalUrl(tempMATracker.getLevelApproveUrl2());
						rejectionType = Constants.L2_REJECTED;
					} else {
						request.setMailTo(tempMATracker.getApproverEmailL1());
						request.setApprovalUrl(tempMATracker.getLevelApproveUrl1());

						rejectionType = Constants.L1_REJECTED;
					}
					if (Constants.NO.equals(cloudPropertiesConfig.getUsernotificationflag())) {
						request.setMyBusinessIds(maRequest.getMyBusinessIds());
						request.setMyBusinessIds(null);
					} else if (Constants.ALL.equals(cloudPropertiesConfig.getUsernotificationflag())) {
						request.setMailTo(request.getMailTo());
					}

					request.setMailTo(request.getMailTo().replaceAll(";", ","));
					if (Constants.TRAN_SUB_STATUS_EXPIRED.equals(maRequest.getNotificationType())) {
						serviceStatus = processOrderCancellation(tempMATracker.getOrderNumber(), rejectionType);
						// TODO: needs a table alter to hold this user email in
						// MA transaction table so below call can be skipped.
						String userEmail = retriveuserEmail(tempMATracker.getOrderNumber(), tempMATracker.getAppId());
						request.setUserEmail(userEmail);

						if (Constants.NO.equals(cloudPropertiesConfig.getUsernotificationflag())) {
							request.setMyBusinessIds(maRequest.getMyBusinessIds());
							request.setMyBusinessIds(null);
						} else if (Constants.ALL.equals(cloudPropertiesConfig.getUsernotificationflag())) {
							request.setUserEmail(request.getUserEmail());
						}
						request.setUserEmail(request.getUserEmail().replaceAll(";", ","));
					} else {
						request.setReminderNumber(maRequest.getReminderNumber());
					}

					processNotification(request, !serviceStatus.isSuccess());
				}
			}
			processMessage = Constants.TRAN_STATUS_COMPLETED;
			status = Constants.TRAN_STATUS_COMPLETED;
			recordId = recordId != null ? recordId : maRequest.getScheduleLogId();
		} catch (Exception e) {
			processMessage = Constants.TRAN_STATUS_FAILED;
			status = Constants.TRAN_STATUS_FAILED;
			LOGGER.error("Error on processEmail", e.getMessage());
		} finally {
			if (recordId != null) {

				emailScheduleLog = prepareEmailScheduleLog(Constants.ACTION_UPDATE, maRequest.getRequester(),
						createDate, deriveEnvValue(cloudPropertiesConfig.getEnv()), Constants.SCR_MBT,
						Integer.toString(managerApprovalTrackers != null ? managerApprovalTrackers.size() : 0),
						processMessage, status, maRequest.getNotificationType());
				emailScheduleLog.setId(recordId);
				createOrUpdateScheduleLog(emailScheduleLog, Constants.ACTION_UPDATE);
			}
		}

	}

	private ProfileEligibilityResponse getEligibilityResponse(String ecpdId, String resetParamValue) {
		ProfileEligibilityResponse response = new ProfileEligibilityResponse();

		try {
			response = companyClient.getProfileEligibilityDetails(Constants.TRANSACTION_MODE_BATCH,
					createProfileParameterRequest(ecpdId, resetParamValue));
		} catch (Exception e) {
			LOGGER.error("Error on company core eligibility call", e.getMessage());
		}
		return response;
	}

	private void processNotification(Email request, boolean changeMessageFlag) {
		EmailScheduleDetailsLog emailScheduleDetailsLog = new EmailScheduleDetailsLog();
		try {
			emailScheduleDetailsLog.setApproverEmailList(request.getMailTo());
			emailScheduleDetailsLog.setCreatedBy(request.getRequester());
			emailScheduleDetailsLog.setCreatedDate(new Date());
			emailScheduleDetailsLog.setEcpdId(request.getEcpdId());
			emailScheduleDetailsLog.setOrderNumber(request.getOrderNumber());
			emailScheduleDetailsLog.setProcessStatusMessage(Constants.TRAN_STATUS_COMPLETED);
			emailScheduleDetailsLog.setSchStatus(Constants.TRAN_STATUS_COMPLETED);
			emailScheduleDetailsLog.setScheduleLogId(request.getSchId());
			emailScheduleDetailsLog.setUserEmailList(request.getUserEmail());
			LOGGER.info("Email object of order " + request.getOrderNumber() + " :::" + gson.toJson(request));
			ServiceStatus notificationStatus = sendNotification(request);

			if (!notificationStatus.isSuccess()) {
				emailScheduleDetailsLog.setSchStatus(Constants.TRAN_STATUS_FAILED);
				emailScheduleDetailsLog.setProcessStatusMessage(Constants.ERROR_MESSAGE_EMAIL);
			}
			if (changeMessageFlag) {
				emailScheduleDetailsLog.setProcessStatusMessage(
						emailScheduleDetailsLog.getProcessStatusMessage() + ", " + Constants.ERROR_MESSAGE_WFM_PROCESS);
			}

		} catch (Exception e) {
			emailScheduleDetailsLog.setProcessStatusMessage(Constants.ERROR_MESSAGE_EMAIL);
			emailScheduleDetailsLog.setSchStatus(Constants.TRAN_STATUS_FAILED);
		}

		emailScheduleDetailsLog = emailScheduleDetailsLogRepo.save(emailScheduleDetailsLog);

	}

	private ServiceStatus sendNotification(Email request) {
		ServiceStatus serviceStatus = new ServiceStatus();
		try {
			serviceStatus = notificationClient.sendCustomEmail(Constants.TRANSACTION_MODE_BATCH, request);
		} catch (Exception e) {
			LOGGER.error("Error occured on notification service call", e.getMessage());
		}
		return serviceStatus;
	}

	private Long createOrUpdateScheduleLog(EmailScheduleLog emailScheduleLog, String action) {
		Long scheduleId = emailScheduleLog.getId();
		try {
			if (Constants.ACTION_INSERT.equals(action)) {
				emailScheduleLog = emailScheduleLogRepo.save(emailScheduleLog);
				scheduleId = emailScheduleLog.getId();
			} else {
				emailScheduleLogRepo.updateEmailScheduleLog(emailScheduleLog.getSchStatus(),
						emailScheduleLog.getSchProcessMessage(), emailScheduleLog.getModifiedBy(),
						emailScheduleLog.getModifiedDate(), scheduleId);
			}

		} catch (Exception e) {
			scheduleId = new Long(0);
		}
		return scheduleId;
	}

	/**
	 * 
	 */
	private EmailScheduleLog prepareEmailScheduleLog(String action, String createBy, Date createDate, String opCenter,
			String sourceChannel, String recordCount, String processMessage, String status, String subStatus) {

		EmailScheduleLog emailScheduleLog = new EmailScheduleLog();
		emailScheduleLog.setCreatedBy(createBy);
		emailScheduleLog.setCreatedDate(createDate);
		emailScheduleLog.setOpCenter(opCenter);
		emailScheduleLog.setSourceChannel(sourceChannel);
		emailScheduleLog.setTotalRecCount(Integer.parseInt(recordCount));
		emailScheduleLog.setSchProcessMessage(processMessage);
		emailScheduleLog.setSchStatus(status);
		emailScheduleLog.setSchSubStatus(subStatus);
		if (Constants.ACTION_UPDATE.equals(action)) {
			emailScheduleLog.setModifiedBy(createBy);
			emailScheduleLog.setModifiedDate(createDate);
		}

		return emailScheduleLog;
	}

	private void updateMAStatus(String status, String orderNumber, String approvedBy) {
		managerApprovalRepo.updateMAStatusAndEmail(status, approvedBy, orderNumber);
	}

	private OrderTrackingRequest buildOPTRequest(String orderNumber, String status, String transactionId, String stepId,
			String message) {
		OrderTrackingRequest request = new OrderTrackingRequest();
		request.setSource(Constants.APPROVAL_CORE);
		request.setOrderNbr(orderNumber);
		request.setOptStatus(status);
		request.setOptTransactionId(transactionId);
		request.setOptStepId(stepId);
		request.setOptMessage(message);
		request.setServerInstance(Constants.APPROVAL_CORE);
		return request;

	}

	private FailOverWfmRequest buildFailToWfm(String orderNumber, String posStatus, String transactionId,
			String locationCode, String orderStatusReason, String orderStatus) {
		FailOverWfmRequest failoverRequest = new FailOverWfmRequest();
		failoverRequest.setGroupOrderNumber(transactionId);
		failoverRequest.setCustomerReferenceNumber(orderNumber);
		failoverRequest.setLocationCode(locationCode);
		failoverRequest.setAceOrder("0000");
		failoverRequest.setOrderStatus(orderStatus);
		failoverRequest.setOrderStatusReason(orderStatusReason);
		failoverRequest.setOrderSource(Constants.APPROVAL_CORE);
		failoverRequest.setOrderMessage(posStatus);
		return failoverRequest;
	}

	public AutoNotificationResponse makeRejectionCall(String orderNumber, String approverAddress) {
		LOGGER.info("Order Rejection process started for " + orderNumber);
		AutoNotificationResponse response = new AutoNotificationResponse();
		try {
			response.setServiceStatus(
					prepareServiceStatus(Constants.SUCCESS_CODE, Constants.REJECTION_MSG, true, Constants.SUCCESS_MSG));
			workFlowClient.updateOptTrackingBatch(Constants.TRANSACTION_MODE_BATCH, buildOPTRequest(orderNumber,
					Constants.SUCCESS_MSG, "NA", Constants.SUCCESS_CODE, Constants.TRAN_SUB_STATUS_EXPIRED));
			updateMAStatus(Constants.L1_REJECTED, orderNumber, approverAddress);
			updateOrderMaster(orderNumber, Constants.ORDER_MASTER_STATUS_REJECTED);
			wfmClient.updateOrderConfirmationToWFMBatch(Constants.TRANSACTION_MODE_BATCH,
					buildUpdateReqeust(orderNumber, approverAddress, false));
		} catch (Exception e) {
			response.setServiceStatus(
					prepareServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false, Constants.FAIL_STATUS));
			LOGGER.error("Exception on Order Rejection process: {} " , e);
		}
		return response;
	}

	private UpdateRequest buildUpdateReqeust(String orderNumber, String approverAddress, boolean approvalStatus) {
		UpdateRequest updateReqeust = new UpdateRequest();
		updateReqeust.setApprovalStatus(approvalStatus);
		updateReqeust.setOrderNumber(orderNumber);
		updateReqeust.setApproverAddress(approverAddress);
		return updateReqeust;
	}

	private void updateOrderMaster(String orderNumber, String orderStatus) {
		LOGGER.info("::: Update to order master on approval/rejection cases");
		OrderMaster orderMasterData = new OrderMaster();
		orderMasterData.setOrderNbr(orderNumber);
		orderMasterData.setModifiedBy(Constants.APPROVAL_CORE);
		orderMasterData.setModifiedDt(new Date());
		orderMasterData.setOrderStatus(orderStatus);
		workFlowClient.updateOrderMasterBatch(Constants.TRANSACTION_MODE_BATCH, orderMasterData);
	}

	private ServiceStatus processOrderCancellation(String orderNumber, String rejectionType) {
		LOGGER.info("processOrderCancellation  : {}" , orderNumber);
		ServiceStatus serviceStatus = prepareServiceStatus(Constants.SUCCESS_CODE, Constants.REJECTION_MSG, true,
				Constants.SUCCESS_MSG);
		try {
			LOGGER.info("processOrderCancellation 1");
			updateOrderMaster(orderNumber, Constants.URL_EXPIRED);
			LOGGER.info("processOrderCancellation 2");
			workFlowClient.updateOptTrackingBatch(Constants.TRANSACTION_MODE_BATCH, buildOPTRequest(orderNumber,
					Constants.SUCCESS_MSG, "NA", Constants.SUCCESS_CODE, Constants.TRAN_SUB_STATUS_EXPIRED));
			LOGGER.info("processOrderCancellation 3");
			wfmClient.updateOrderStatusToWFMBatch(Constants.TRANSACTION_MODE_BATCH, buildFailToWfm(orderNumber,
					Constants.INVALID_CODE, "00", "00", Constants.URL_EXPIRY_MSG, Constants.CANCELLED));
			LOGGER.info("processOrderCancellation 4");
			updateMAStatus(rejectionType, orderNumber, Constants.USER_AUTO_BATCH);
			LOGGER.info("processOrderCancellation 5");
		} catch (Exception e) {
			serviceStatus = prepareServiceStatus(Constants.FAIL_STATUS, Constants.FAIL_STATUS, false,
					Constants.FAIL_STATUS);
			LOGGER.error("Autocan Cancellation processOrderCancellation have exception: {}", e.getMessage());
		}

		return serviceStatus;

	}

	/**
	 * To get the Order data and from that get the user notification email's to
	 * send user email for cancellation.
	 * 
	 * @param orderNumber
	 * @param sourceSystem
	 * @return
	 */
	private String retriveuserEmail(String orderNumber, String sourceSystem) {
		LOGGER.info("Retrival user email from order json for order number : {}", orderNumber);
		String userEmailList = Constants.STR_BLANK;
		try {
			String tempOrderJson = workFlowClient.getOrderJsonBatch(Constants.TRANSACTION_MODE_BATCH, orderNumber);
			if (Constants.SCR_MBT.equals(sourceSystem)) {
				MBTSubmitOrder mbtSubmitOrder = new MBTSubmitOrder();
				mbtSubmitOrder = gson.fromJson(tempOrderJson, MBTSubmitOrder.class);

				userEmailList = mbtSubmitOrder != null && mbtSubmitOrder.getOrder() != null
						&& mbtSubmitOrder.getOrder().getConfirmationAndShipNotification() != null
								? mbtSubmitOrder.getOrder().getConfirmationAndShipNotification().getEmail()
								: Constants.STR_BLANK;
			} else {
				ClassicSubmitOrder classicSubmitOrder = new ClassicSubmitOrder();
				classicSubmitOrder = gson.fromJson(tempOrderJson, ClassicSubmitOrder.class);

				userEmailList = classicSubmitOrder != null && classicSubmitOrder.getService() != null
						&& classicSubmitOrder.getService().getServiceBody() != null
						&& classicSubmitOrder.getService().getServiceBody().getServiceRequest() != null
						&& classicSubmitOrder.getService().getServiceBody().getServiceRequest().getOrder() != null
						&& classicSubmitOrder.getService().getServiceBody().getServiceRequest().getOrder()
								.getContact() != null
										? classicSubmitOrder.getService().getServiceBody().getServiceRequest()
												.getOrder().getContact().getEmail()
										: Constants.STR_BLANK;

			}

		} catch (Exception e) {
			LOGGER.error("Retrival user email have exception.", e.getMessage());
		}

		LOGGER.info("userEmailListr from order: {} " , userEmailList);
		return userEmailList;
	}

	/**
	 * 
	 * @param statusCode
	 * @param statusMessage
	 * @param statusFlag
	 * @param message
	 * @return
	 */
	private ServiceStatus prepareServiceStatus(String statusCode, String statusMessage, boolean statusFlag,
			String message) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setSuccess(statusFlag);
		serviceStatus.setMessage(message);
		;
		return serviceStatus;
	}

	private String deriveEnvValue(String envValue) {
		if (StringUtils.isNotBlank(envValue)) {
			if (envValue.toUpperCase().contains("TDC")) {
				envValue = Constants.OP_CENTER_TDC;
			} else if (envValue.toUpperCase().contains("SDC")) {
				envValue = Constants.OP_CENTER_SDC;
			} else {
				envValue = envValue.toUpperCase().replace("PCF", Constants.STR_BLANK);
			}
		} else {
			envValue = Constants.OP_CENTER_SDC;
		}
		return envValue;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	private ProfileParameterRequest createProfileParameterRequest(String ecpdId, String resetParamValue) {
		ProfileParameterRequest parameterRequest = new ProfileParameterRequest();

		parameterRequest.setEcpdId(ecpdId);
		parameterRequest.setRuleType(Constants.SCR_MBT);

		parameterRequest.setParamType(Constants.PARAM_TYPE_EMAIL_REMINDER);
		parameterRequest.setParamName(Constants.PARAM_NAME_EMAIL_REMINDER_NOTIFICATION);

		parameterRequest.setDisabledForId(Constants.USER_CASE_ID_DISABLE_EMAIL_REMINDER);
		parameterRequest.setEnabledForId(Constants.USER_CASE_ID_ENABLE_EMAIL_REMINDER);

		parameterRequest.setResetParamValue(resetParamValue);

		return parameterRequest;
	}

	private AutoNotificationRequest createAutonotificationRequest(String reminderType, Long scheduleLogId) {

		AutoNotificationRequest request = new AutoNotificationRequest();
		request.setMailFrom(cloudPropertiesConfig.getFrom());
		request.setUsernotificationflag(cloudPropertiesConfig.getUsernotificationflag());
		request.setRequester(Constants.USER_AUTO_BATCH);
		request.setMyBusinessIds(cloudPropertiesConfig.getMyBusinessIds());
		request.setScheduleLogId(scheduleLogId);

		if (Constants.TRAN_SUB_STATUS_REMINDER1.equals(reminderType)) {
			request.setReminderFromDays(cloudPropertiesConfig.getInitialnotification());
			request.setReminderToDays(cloudPropertiesConfig.getInitialnotification());
			request.setReminderNumber("1");

		} else if (Constants.TRAN_SUB_STATUS_REMINDER2.equals(reminderType)) {
			request.setReminderFromDays(cloudPropertiesConfig.getFinalnotification());
			request.setReminderToDays(cloudPropertiesConfig.getFinalnotification());
			request.setReminderNumber("2");

		}
		if (Constants.TRAN_SUB_STATUS_EXPIRED.equals(reminderType)) {
			request.setReminderFromDays(cloudPropertiesConfig.getAutoexpiredaysfrom());
			request.setReminderToDays(cloudPropertiesConfig.getAutoexpiredaysto());

		}

		return request;

	}

}