package com.vzw.mybiz.approval.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.sm.AccountLineItem;
import com.vzw.mybiz.approval.domain.sm.FeatureGroupAccountMaint;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.onemessage.MtnInfo;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

public class GenerateOrderDataSM {

	private static final String ADD = "ADD";
	private static final String AUTOADD = "AUTOADD";
	private static final String DELETE = "DELETE";
	private static final String AUTODELETE = "AUTODELETE";
	

	private static final Logger LOGGER = LoggerFactory.getLogger(GenerateOrderDataSM.class);

	public static void generateOrderDataLineLevel(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		if (orderDetailsResponse.getOrderDetailsList() != null
				&& !orderDetailsResponse.getOrderDetailsList().isEmpty()) {
			matchMtnstoAccounts(orderDetailsResponse, smOrderResponse);
		} else {
			setEmptyOrderData(orderDetailsResponse,smOrderResponse);
		}
	}
	
	public static void generateOrderDataAccountLevel(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		if (orderDetailsResponse.getOrderDetailsList() != null
				&& !orderDetailsResponse.getOrderDetailsList().isEmpty()) {
			groupAccountDetails(orderDetailsResponse, smOrderResponse);
		} else {
			setEmptyOrderData(orderDetailsResponse,smOrderResponse);
		}

	}
	
	private static void filterDuplicateProducts(SystemTxnInfo product, List<SystemTxnInfo> addedList) {
		Long filteredSize = addedList.stream().filter(productInfo -> {
			return productInfo.getItemName().equalsIgnoreCase(product.getItemName()) && productInfo.getBillingCode().equalsIgnoreCase(product.getBillingCode());	
		}).collect(Collectors.counting());
		MtnInfo mtn = new MtnInfo();
		if(filteredSize == 0) {
			product.setMtnCount(1);
			List<MtnInfo> mtnList = new ArrayList<MtnInfo>();
			mtn.setMtn(product.getServiceNumber());
			mtn.setUserName(product.getSubscriberName());
			mtnList.add(mtn);
			product.setMtnList(mtnList);
			product.setTotal(Double.parseDouble(product.getFinalPrice()));
			addedList.add(product);
		} else {
			addedList.stream().filter(productInfo -> 
			productInfo.getItemName().equalsIgnoreCase(product.getItemName()) 
				&& productInfo.getBillingCode().equalsIgnoreCase(product.getBillingCode())).map(item -> {
				mtn.setMtn(product.getServiceNumber());
				mtn.setUserName(product.getSubscriberName());
				item.getMtnList().add(mtn);
				int mtnCount =  item.getMtnCount();
				mtnCount++;
				item.setMtnCount(mtnCount);
				return item;
			}).collect(Collectors.toList());
		}
	}

	private static void setEmptyOrderData(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		smOrderResponse.setConfirmationNumber(orderDetailsResponse.getConfirmationNumber());
	}
	
	public static void generatePDFResponseForAccountLevel(Map<String, List<SystemTxnInfo>> accountProductMap, SMOrderResponse smOrderResponse,
			String effectiveDate, String confirmationNumber) {
		List<FeatureGroupAccountMaint> accountProductList = new ArrayList<>();
		LOGGER.debug("accountMap length is :" +accountProductMap.size());
		accountProductMap.entrySet().forEach(productMap -> {
			FeatureGroupAccountMaint featureGroup = new FeatureGroupAccountMaint();
			List<SystemTxnInfo> addedList = new ArrayList<>();
			List<SystemTxnInfo> removedList = new ArrayList<>();
			List<SystemTxnInfo> autoAddedList = new ArrayList<>();
			List<SystemTxnInfo> autoRemovedList = new ArrayList<>();
			productMap.getValue().stream().forEach(product -> {
				if (ADD.equalsIgnoreCase(product.getAction())) {
					filterDuplicateProducts(product,addedList);
				} else if (AUTOADD.equalsIgnoreCase(product.getAction())) {
					filterDuplicateProducts(product,autoAddedList);
				} else if (DELETE.equalsIgnoreCase(product.getAction())) {
					filterDuplicateProducts(product,removedList);
				} else if (AUTODELETE.equalsIgnoreCase(product.getAction())) {
					filterDuplicateProducts(product,autoRemovedList);
				}
			});
			featureGroup.setAccountNumber(productMap.getKey());
			featureGroup.setAddedFeaturesList(addedList);
			featureGroup.setAutoAddedFeaturesList(autoAddedList);
			featureGroup.setRemovedFeaturesList(removedList);
			featureGroup.setAutoRemovedFeaturesList(autoRemovedList);
			featureGroup.setEffectiveDate(effectiveDate);
			featureGroup.setAccountTotal(getAccountTotal(featureGroup));
			accountProductList.add(featureGroup);
		});
		smOrderResponse.setAccountFeatureList(accountProductList);
		smOrderResponse.setConfirmationNumber(confirmationNumber);
		smOrderResponse.setEffectiveDate(effectiveDate);
		LOGGER.info("PDF print response :: AccountList details are :::" +smOrderResponse);
	}

	public static void groupAccountDetails(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<SystemTxnInfo> productList = new ArrayList<>();
		for(SystemTxnInfo sysInfo : orderDetailsResponse.getOrderDetailsList()) {
			productList.add(sysInfo);
		}
		productList = productList.stream().filter(product -> "SPO".equalsIgnoreCase(product.getItemType())).collect(Collectors.toList());
		List<String> accountNumberList = new ArrayList<>();
		Map<String, List<SystemTxnInfo>> accountFeatureMap = new HashMap<>();
		for (SystemTxnInfo featureInfo : productList) {
			if (!accountNumberList.contains(featureInfo.getAccountNumber())) {
				accountNumberList.add(featureInfo.getAccountNumber());
				List<SystemTxnInfo> filteredFeatureInfo = productList.stream().filter(feature -> {
					return feature.getAccountNumber().equalsIgnoreCase(featureInfo.getAccountNumber());
				}).collect(Collectors.toList());
				accountFeatureMap.put(featureInfo.getAccountNumber(), filteredFeatureInfo);
			}
		}
		if (!accountFeatureMap.isEmpty()) {
			generatePDFResponseForAccountLevel(accountFeatureMap, smOrderResponse,orderDetailsResponse.getEffectiveDate(),orderDetailsResponse.getConfirmationNumber());
		};
	}

	private static void filterDuplicateFeatures(SystemTxnInfo feature, List<SystemTxnInfo> addedList) {
		Long filteredSize = addedList.stream().filter(featureInfo -> {
			return featureInfo.getItemName().equalsIgnoreCase(feature.getItemName()) && featureInfo.getBillingCode().equalsIgnoreCase(feature.getBillingCode());	
		}).collect(Collectors.counting());
		MtnInfo mtn = new MtnInfo();
		if (filteredSize == 0) {
			feature.setMtnCount(1);
			feature.setFinalPrice(feature.getFinalPrice());
			feature.setTotal(Double.parseDouble(feature.getFinalPrice()));
			feature.setListPrice(feature.getListPrice());
			
			List<MtnInfo> mtnList = new ArrayList<MtnInfo>();
			mtn.setMtn(feature.getServiceNumber());
			mtn.setUserName(feature.getSubscriberName());
			mtnList.add(mtn);
			
			feature.setMtnList(mtnList);
			addedList.add(feature);
		} else {
			addedList.stream().filter(featureInfo -> 
				featureInfo.getItemName().equalsIgnoreCase(feature.getItemName()) 
				&& featureInfo.getBillingCode().equalsIgnoreCase(feature.getBillingCode())).map(item -> {
				int mtnCount =  item.getMtnCount();
				mtnCount++;
				item.setTotal(item.getTotal() + Double.parseDouble(feature.getFinalPrice()));
				item.setMtnCount(mtnCount);
				mtn.setMtn(feature.getServiceNumber());
				mtn.setUserName(feature.getSubscriberName());
				item.getMtnList().add(mtn);
				return item;
			}).collect(Collectors.toList());
		}
	}

	private static void assignFeatures(List<SystemTxnInfo> list, List<SystemTxnInfo> addedList, List<SystemTxnInfo> removedList, List<SystemTxnInfo> autoAddedList, List<SystemTxnInfo> autoRemovedList) {
		list.stream().forEach(feature -> {
			if (ADD.equalsIgnoreCase(feature.getAction())) {
				filterDuplicateFeatures(feature, addedList);
			} else if (AUTOADD.equalsIgnoreCase(feature.getAction())) {
				filterDuplicateFeatures(feature, autoAddedList);
			} else if (DELETE.equalsIgnoreCase(feature.getAction())) {
				filterDuplicateFeatures(feature, removedList);
			} else if (AUTODELETE.equalsIgnoreCase(feature.getAction())) {
				filterDuplicateFeatures(feature, autoRemovedList);
			}
		});
	}
	
	
	private static Double getAccountTotal(FeatureGroupAccountMaint accountInfo) {
		Double[] pricing = {0d};
		accountInfo.getAddedFeaturesList().stream().forEach(item -> {pricing[0] = Double.sum(pricing[0] ,Double.parseDouble(item.getFinalPrice()));});
		accountInfo.getAutoAddedFeaturesList().stream().forEach(item -> {pricing[0] = Double.sum(pricing[0] ,Double.parseDouble(item.getFinalPrice()));});
		accountInfo.getRemovedFeaturesList().stream().forEach(item -> {pricing[0] = Double.sum(pricing[0] ,-Double.parseDouble(item.getFinalPrice()));});
		accountInfo.getAutoRemovedFeaturesList().stream().forEach(item -> {pricing[0] = Double.sum(pricing[0] ,-Double.parseDouble(item.getFinalPrice()));});
		return pricing[0];
	}
	
	private static void makePDFResponse(Map<String, List<SystemTxnInfo>> accountFeatureMap, SMOrderResponse smOrderResponse, String effectiveDate, String confirmationNumber) {
		List<FeatureGroupAccountMaint> accountFeatureList = new ArrayList<>();
		System.out.println(accountFeatureMap.size());
		accountFeatureMap.entrySet().forEach(featureMap -> {
			FeatureGroupAccountMaint featureGroup = new FeatureGroupAccountMaint();
			List<SystemTxnInfo> addedList = new ArrayList<>();
			List<SystemTxnInfo> removedList = new ArrayList<>();
			List<SystemTxnInfo> autoAddedList = new ArrayList<>();
			List<SystemTxnInfo> autoRemovedList = new ArrayList<>();
			featureGroup.setAccountNumber(featureMap.getKey());
			if(featureMap.getValue().get(0).getEffectiveDate() != null) {
				smOrderResponse.setEffectiveDate(featureMap.getValue().get(0).getEffectiveDate());
				featureGroup.setEffectiveDate(featureMap.getValue().get(0).getEffectiveDate());				
			} else {
				featureGroup.setEffectiveDate(effectiveDate);
				smOrderResponse.setEffectiveDate(effectiveDate);
			}
			assignFeatures(featureMap.getValue(),addedList,removedList,autoAddedList,autoRemovedList);
			featureGroup.setAddedFeaturesList(addedList);
			featureGroup.setAutoAddedFeaturesList(autoAddedList);
			featureGroup.setRemovedFeaturesList(removedList);
			featureGroup.setAutoRemovedFeaturesList(autoRemovedList);
			accountFeatureList.add(featureGroup);
			featureGroup.setAccountTotal(getAccountTotal(featureGroup));
		});
		smOrderResponse.setAccountFeatureList(accountFeatureList);
		smOrderResponse.setConfirmationNumber(confirmationNumber);
	}

	private static void matchMtnstoAccounts(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		List<SystemTxnInfo> featuresList = new ArrayList<>();
		for(SystemTxnInfo sysInfo: orderDetailsResponse.getOrderDetailsList()) {
			featuresList.add(sysInfo);
		}
		List<String> accountNumberList = new ArrayList<>();
		Map<String, List<SystemTxnInfo>> accountFeatureMap = new HashMap<>();
		for (SystemTxnInfo featureInfo : featuresList) {
			if (!accountNumberList.contains(featureInfo.getAccountNumber())) {
				accountNumberList.add(featureInfo.getAccountNumber());
				List<SystemTxnInfo> filteredFeatureInfo = featuresList.stream().filter(feature -> {
					return feature.getAccountNumber().equalsIgnoreCase(featureInfo.getAccountNumber());
				}).collect(Collectors.toList());
				accountFeatureMap.put(featureInfo.getAccountNumber(), filteredFeatureInfo);
			}
		}
		if (!accountFeatureMap.isEmpty()) {
			makePDFResponse(accountFeatureMap, smOrderResponse,orderDetailsResponse.getEffectiveDate(), orderDetailsResponse.getConfirmationNumber());
		}
	}

	/**
	 * @param transactionType
	 * @param orderDetailsResponse
	 * @param smOrderResponse
	 * @ notes do not over populate this class, try to use the ManagerApprovalSMOrderDetails class for the order info building
	 */
	public static void generateOrderDataAccountLineItem(String transactionType, OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {

		if (orderDetailsResponse.getOrderDetailsList() != null
				&& !orderDetailsResponse.getOrderDetailsList().isEmpty()) {
			if(Constant.CCC_TRANSACTION_TYPE.equals(transactionType)) {
				setAccountLineItemResponseForCCC(orderDetailsResponse, smOrderResponse);
			}else if(Constant.RES_TRANSACTION_TYPE.equals(transactionType)) {
				GenerateSusResOrderDetailSM.setAccountLineItemResponseForRES(orderDetailsResponse, smOrderResponse);				
			}else if(Constant.SUS_TRANSACTION_TYPE.equals(transactionType)) {
				GenerateSusResOrderDetailSM.setAccountLineItemResponseForSuspend(orderDetailsResponse, smOrderResponse);
			}else if(Constant.CMB_TRANSACTION_TYPE.equals(transactionType)) {
				ManagerApprovalSMOrderDetails.setAccountLineItemCMB(orderDetailsResponse, smOrderResponse);
			} else if(Constant.DACT_TRANSACTION_TYPE.equals(transactionType)) {
				ManagerApprovalSMOrderDetails.buildDisconnectInfo(orderDetailsResponse, smOrderResponse);
			} else if(StringUtils.equalsIgnoreCase(Constant.CBR_LANDING_TRANSACTION_TYPE, transactionType)) {
				ManagerApprovalSMOrderDetails.buildAccountAndLineResponseForCBR(orderDetailsResponse, smOrderResponse);
			} else {
				setEmptyOrderData(orderDetailsResponse, smOrderResponse);
			}
		} else {
			setEmptyOrderData(orderDetailsResponse, smOrderResponse);
		}
	}

	

	private static void setAccountLineItemResponseForCCC(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsSMList = new ArrayList<AccountLineItem>();
		Map<String, List<SystemTxnInfo>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfo>>();

		groupAccountOrderDetails(orderDetailsResponse, accountOrderDetailsMap);

		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<LinkedHashMap<String, String>>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null && Constant.ACTION_TYPE_ADD.equalsIgnoreCase(detailInfo.getAction())) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<String, String>();

							detailMap.put(Constant.ACC_LINE_ITEM_MTN, (detailInfo.getServiceNumber() +
									(detailInfo.getSubscriberName() != null ? (" <br> " + detailInfo.getSubscriberName()) : "")));
							detailMap.put(Constant.ACC_LINE_ITEM_NEW_CC, detailInfo.getItemName());

							SystemTxnInfo autoDeletedInfo = accountOrderDetails.getValue().stream()
									.filter(nextDetailInfo -> nextDetailInfo.getServiceNumber()
											.equals(detailInfo.getServiceNumber())
											&& Constant.ACTION_TYPE_AUTODELETE.equals(nextDetailInfo.getAction()))
									.findAny().get();

							detailMap.put(Constant.ACC_LINE_ITEM_OLD_CC, autoDeletedInfo.getItemName());
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsSMList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsSMList);
		}
	}

	private static void groupAccountOrderDetails(OrderDetailsResponse orderDetailsResponse,
			Map<String, List<SystemTxnInfo>> accountOrderDetailsMap) {
		orderDetailsResponse.getOrderDetailsList().forEach(orderDetail -> {
			if (orderDetail != null && orderDetail.getAccountNumber() != null) {
				if (accountOrderDetailsMap.containsKey(orderDetail.getAccountNumber())) {
					accountOrderDetailsMap.get(orderDetail.getAccountNumber()).add(orderDetail);
				} else {
					List<SystemTxnInfo> sysTxnInfoList = new ArrayList<SystemTxnInfo>();
					sysTxnInfoList.add(orderDetail);
					accountOrderDetailsMap.put(orderDetail.getAccountNumber(), sysTxnInfoList);
				}
			}
		});
	}
	
}
