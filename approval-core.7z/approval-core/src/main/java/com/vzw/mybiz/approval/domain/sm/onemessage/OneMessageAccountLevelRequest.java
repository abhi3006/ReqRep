package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneMessageAccountLevelRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String confirmationNumber;
	private String status;
	private String tranType; // line or account
	private List<AccountInfo> accountList;
	private List<String> confirmationEmail;

	private String loggedInUserId;
	private String loggedInUserFirstName;
	private String loggedInUserLastName;
	private int totalAccountsCount;
	private int totalAccountsSuccess;
	private int totalAccountsFailed;

	/**
	 * @return the totalAccountsCount
	 */
	public final int getTotalAccountsCount() {
		return totalAccountsCount;
	}

	/**
	 * @param totalAccountsCount the totalAccountsCount to set
	 */
	public final void setTotalAccountsCount(int totalAccountsCount) {
		this.totalAccountsCount = totalAccountsCount;
	}

	/**
	 * @return the totalAccountsSuccess
	 */
	public final int getTotalAccountsSuccess() {
		return totalAccountsSuccess;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @param totalAccountsSuccess the totalAccountsSuccess to set
	 */
	public final void setTotalAccountsSuccess(int totalAccountsSuccess) {
		this.totalAccountsSuccess = totalAccountsSuccess;
	}

	/**
	 * @return the totalAccountsFailed
	 */
	public final int getTotalAccountsFailed() {
		return totalAccountsFailed;
	}

	/**
	 * @param totalAccountsFailed the totalAccountsFailed to set
	 */
	public final void setTotalAccountsFailed(int totalAccountsFailed) {
		this.totalAccountsFailed = totalAccountsFailed;
	}

	public List<AccountInfo> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<AccountInfo> accountList) {
		this.accountList = accountList;
	}


	public String getLoggedInUserFirstName() {
		return loggedInUserFirstName;
	}

	public void setLoggedInUserFirstName(String loggedInUserFirstName) {
		this.loggedInUserFirstName = loggedInUserFirstName;
	}

	public String getLoggedInUserLastName() {
		return loggedInUserLastName;
	}

	public void setLoggedInUserLastName(String loggedInUserLastName) {
		this.loggedInUserLastName = loggedInUserLastName;
	}

	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	/**
	 * @return the confirmationEmail
	 */
	public final List<String> getConfirmationEmail() {
		return confirmationEmail;
	}

	/**
	 * @param confirmationEmail
	 *            the confirmationEmail to set
	 */
	public final void setConfirmationEmail(List<String> confirmationEmail) {
		this.confirmationEmail = confirmationEmail;
	}

	/**
	 * @return the confirmationNumber
	 */
	public final String getConfirmationNumber() {
		return confirmationNumber;
	}

	/**
	 * @param confirmationNumber
	 *            the confirmationNumber to set
	 */
	public final void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	/**
	 * @return the tranType
	 */
	public final String getTranType() {
		return tranType;
	}

	/**
	 * @param tranType
	 *            the tranType to set
	 */
	public final void setTranType(String tranType) {
		this.tranType = tranType;
	}
}