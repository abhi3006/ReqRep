package com.vzw.mybiz.approval.client;

import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceAuthResponse;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

public interface SalesForceAuthClient {
	
	@Headers("Content-Type: application/json")
	@RequestLine("POST ?grant_type={grant_type}&client_id={client_id}&client_secret={client_secret}&username={username}&password={password}")
	@PostMapping()
	public SalesForceAuthResponse fetchSalesForceAuth(@Param("grant_type") String grant_type,
			@Param("client_id") String client_id, @Param("client_secret") String client_secret,
			@Param("username") String username, @Param("password") String password);
}
