package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class ManageApprovalAMDto  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 569749696774282256L;
	private boolean changeUserInformation; 
	private DgfFieldShort cui;
	private boolean activationEquipment;
	private DgfFieldShort ae;
	private boolean changeCostCenter; 
	private DgfFieldShort ccc;
	private boolean callMessageBlocking;
	private DgfFieldShort cmb;
	private boolean suspendService;
	private DgfFieldShort ss;
	private boolean resumeService;
	private DgfFieldShort rs;
	private boolean changingCallPlan;
	private DgfFieldShort ccp;
	private boolean addRemoveFeatures; 
	private DgfFieldShort arf;
	private boolean changeVoiceMailPassword;
	private DgfFieldShort cvmp;
	private boolean changeWirelessNumber;
	private DgfFieldShort cwn;
	private boolean changeBillToAddress;
	private DgfFieldShort cbta;
	private boolean deactivateService;
	private DgfFieldShort ds;
	private boolean changeBillingResponsibility;
	private DgfFieldShort cbr;
	public boolean isChangeUserInformation() {
		return changeUserInformation;
	}
	public void setChangeUserInformation(boolean changeUserInformation) {
		this.changeUserInformation = changeUserInformation;
	}
	public DgfFieldShort getCui() {
		return cui;
	}
	public void setCui(DgfFieldShort cui) {
		this.cui = cui;
	}
	public boolean isActivationEquipment() {
		return activationEquipment;
	}
	public void setActivationEquipment(boolean activationEquipment) {
		this.activationEquipment = activationEquipment;
	}
	public DgfFieldShort getAe() {
		return ae;
	}
	public void setAe(DgfFieldShort ae) {
		this.ae = ae;
	}
	public boolean isChangeCostCenter() {
		return changeCostCenter;
	}
	public void setChangeCostCenter(boolean changeCostCenter) {
		this.changeCostCenter = changeCostCenter;
	}
	public DgfFieldShort getCcc() {
		return ccc;
	}
	public void setCcc(DgfFieldShort ccc) {
		this.ccc = ccc;
	}
	public boolean isCallMessageBlocking() {
		return callMessageBlocking;
	}
	public void setCallMessageBlocking(boolean callMessageBlocking) {
		this.callMessageBlocking = callMessageBlocking;
	}
	public DgfFieldShort getCmb() {
		return cmb;
	}
	public void setCmb(DgfFieldShort cmb) {
		this.cmb = cmb;
	}
	public boolean isSuspendService() {
		return suspendService;
	}
	public void setSuspendService(boolean suspendService) {
		this.suspendService = suspendService;
	}
	public DgfFieldShort getSs() {
		return ss;
	}
	public void setSs(DgfFieldShort ss) {
		this.ss = ss;
	}
	public boolean isResumeService() {
		return resumeService;
	}
	public void setResumeService(boolean resumeService) {
		this.resumeService = resumeService;
	}
	public DgfFieldShort getRs() {
		return rs;
	}
	public void setRs(DgfFieldShort rs) {
		this.rs = rs;
	}
	public boolean isChangingCallPlan() {
		return changingCallPlan;
	}
	public void setChangingCallPlan(boolean changingCallPlan) {
		this.changingCallPlan = changingCallPlan;
	}
	public DgfFieldShort getCcp() {
		return ccp;
	}
	public void setCcp(DgfFieldShort ccp) {
		this.ccp = ccp;
	}
	public boolean isAddRemoveFeatures() {
		return addRemoveFeatures;
	}
	public void setAddRemoveFeatures(boolean addRemoveFeatures) {
		this.addRemoveFeatures = addRemoveFeatures;
	}
	public DgfFieldShort getArf() {
		return arf;
	}
	public void setArf(DgfFieldShort arf) {
		this.arf = arf;
	}
	public boolean isChangeVoiceMailPassword() {
		return changeVoiceMailPassword;
	}
	public void setChangeVoiceMailPassword(boolean changeVoiceMailPassword) {
		this.changeVoiceMailPassword = changeVoiceMailPassword;
	}
	public DgfFieldShort getCvmp() {
		return cvmp;
	}
	public void setCvmp(DgfFieldShort cvmp) {
		this.cvmp = cvmp;
	}
	public boolean isChangeWirelessNumber() {
		return changeWirelessNumber;
	}
	public void setChangeWirelessNumber(boolean changeWirelessNumber) {
		this.changeWirelessNumber = changeWirelessNumber;
	}
	public DgfFieldShort getCwn() {
		return cwn;
	}
	public void setCwn(DgfFieldShort cwn) {
		this.cwn = cwn;
	}
	public boolean isChangeBillToAddress() {
		return changeBillToAddress;
	}
	public void setChangeBillToAddress(boolean changeBillToAddress) {
		this.changeBillToAddress = changeBillToAddress;
	}
	public DgfFieldShort getCbta() {
		return cbta;
	}
	public void setCbta(DgfFieldShort cbta) {
		this.cbta = cbta;
	}
	public boolean isDeactivateService() {
		return deactivateService;
	}
	public void setDeactivateService(boolean deactivateService) {
		this.deactivateService = deactivateService;
	}
	public DgfFieldShort getDs() {
		return ds;
	}
	public void setDs(DgfFieldShort ds) {
		this.ds = ds;
	}
	public boolean isChangeBillingResponsibility() {
		return changeBillingResponsibility;
	}
	public void setChangeBillingResponsibility(boolean changeBillingResponsibility) {
		this.changeBillingResponsibility = changeBillingResponsibility;
	}
	public DgfFieldShort getCbr() {
		return cbr;
	}
	public void setCbr(DgfFieldShort cbr) {
		this.cbr = cbr;
	}
	
	
	
}
