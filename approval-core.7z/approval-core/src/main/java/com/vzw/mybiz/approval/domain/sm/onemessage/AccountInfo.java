package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String accountStatus; // based on the transHistory/vision status
	private Set<String> addedProducts;
	private Set<String> deletedProducts;
	private int numberSuccess = 0;
	private int numberFailed = 0;
	/**
	 * @return the addedProducts
	 */
	public final Set<String> getAddedProducts() {
		return addedProducts;
	}

	/**
	 * @param addedProducts the addedProducts to set
	 */
	public final void setAddedProducts(Set<String> addedProducts) {
		this.addedProducts = addedProducts;
	}

	/**
	 * @return the deletedProducts
	 */
	public final Set<String> getDeletedProducts() {
		return deletedProducts;
	}

	/**
	 * @param deletedProducts the deletedProducts to set
	 */
	public final void setDeletedProducts(Set<String> deletedProducts) {
		this.deletedProducts = deletedProducts;
	}

	/**
	 * @return the numberSuccess
	 */
	public final int getNumberSuccess() {
		return numberSuccess;
	}

	/**
	 * @param numberSuccess the numberSuccess to set
	 */
	public final void setNumberSuccess(int numberSuccess) {
		this.numberSuccess = numberSuccess;
	}

	/**
	 * @return the numberFailed
	 */
	public final int getNumberFailed() {
		return numberFailed;
	}

	/**
	 * @param numberFailed the numberFailed to set
	 */
	public final void setNumberFailed(int numberFailed) {
		this.numberFailed = numberFailed;
	}

	public String getaccountNumber() {
		return accountNumber;
	}

	public void setaccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	
	public void addAddedProducts(String addedProduct) {
		if(addedProducts == null){
			this.addedProducts = new HashSet<String>();
		}
		this.addedProducts.add(addedProduct);
	}
	
	public void addDeletedProducts(String deletedProduct) {
		if(deletedProducts == null){
			this.deletedProducts = new HashSet<String>();
		}
		this.deletedProducts.add(deletedProduct);
	}
	


}
