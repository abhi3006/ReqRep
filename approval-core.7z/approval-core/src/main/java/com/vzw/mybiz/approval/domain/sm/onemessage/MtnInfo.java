package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MtnInfo implements Serializable{


	private static final long serialVersionUID = 1L;
	private String mtn;
	private String userAction;
	private String userName;
	private String mtnStatus; 
	/**
	 * @return the mtnStatus
	 */
	public final String getMtnStatus() {
		return mtnStatus;
	}
	/**
	 * @param mtnStatus the mtnStatus to set
	 */
	public final void setMtnStatus(String mtnStatus) {
		this.mtnStatus = mtnStatus;
	}
	/**
	 * @return the mtn
	 */
	public final String getMtn() {
		return mtn;
	}
	/**
	 * @param mtn the mtn to set
	 */
	public final void setMtn(String mtn) {
		this.mtn = mtn;
	}
	/**
	 * @return the userAction
	 */
	public final String getUserAction() {
		return userAction;
	}
	/**
	 * @param userAction the userAction to set
	 */
	public final void setUserAction(String userAction) {
		this.userAction = userAction;
	}
	/**
	 * @return the userName
	 */
	public final String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public final void setUserName(String userName) {
		this.userName = userName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mtn == null) ? 0 : mtn.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MtnInfo other = (MtnInfo) obj;
		if (mtn == null) {
			if (other.mtn != null)
				return false;
		} else if (!mtn.equals(other.mtn))
			return false;
		return true;
	}
}