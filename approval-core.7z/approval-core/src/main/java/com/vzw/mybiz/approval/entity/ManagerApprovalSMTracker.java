package com.vzw.mybiz.approval.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "EPS_MA_ACCT_MAINT_TXN", schema = "COMMB2B")
public class ManagerApprovalSMTracker implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8956948423041644597L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tx_generator")
	@SequenceGenerator(name = "tx_generator", sequenceName = "EPS_MA_ACCT_MAINT_TXN_SEQ", schema = "COMMB2B", allocationSize = 1)
	@Column(name = "MA_AM_TRANSACTION_ID", updatable = false, nullable = false)
	private Long id;

	@Column(name = "MA_AM_APP_TRANS_ID", nullable = false)
	private String orderNumber;

	@Column(name = "MA_AM_APP_ID")
	private String appId;
	
	@Column(name = "MA_AM_MANAGER_APPROVAL_LEVEL")
	private Integer level;

	@Column(name = "MA_AM_APPROVAL_URL")
	private String approveUrl;

	@Column(name = "MA_AM_RECORD_TYPE")
	private String recordType;

	@Column(name = "MA_AM_TRANSACTION_STATUS")
	private String status;

	@Column(name = "ECPD_ID")
	private String ecpdId;

	@Column(name = "MA_AM_REASON_CODE")
	private String reasonCode;

	@Column(name = "MA_AM_TRANSACTION_TYPE")
	private String transactionType;

	@Column(name = "MA_AM_APPROVER_EMAIL1")
	private String approverEmail1;

	@Column(name = "MA_AM_APPROVER_EMAIL2")
	private String approverEmail2;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_DATE")
	private Date createdDate;
	
	@Column(name = "MODIFIED_DT")
	private Date modifiedDate;
	
	@Column(name="MA_AM_TRANSACTION_JSON")
	private String maAmTransactionJson;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEcpdId() {
		return ecpdId;
	}

	public void setEcpdId(String ecpdId) {
		this.ecpdId = ecpdId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getApproveUrl() {
		return approveUrl;
	}

	public void setApproveUrl(String approveUrl) {
		this.approveUrl = approveUrl;
	}

	public String getApproverEmail1() {
		return approverEmail1;
	}

	public void setApproverEmail1(String approverEmail1) {
		this.approverEmail1 = approverEmail1;
	}

	public String getApproverEmail2() {
		return approverEmail2;
	}

	public void setApproverEmail2(String approverEmail2) {
		this.approverEmail2 = approverEmail2;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getMaAmTransactionJson() {
		return maAmTransactionJson;
	}

	public void setMaAmTransactionJson(String maAmTransactionJson) {
		this.maAmTransactionJson = maAmTransactionJson;
	}

	
}
