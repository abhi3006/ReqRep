package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductFilters implements Serializable {

	private static final long serialVersionUID = 4414564077790796989L;
	private List<Bucket> brandList;
	private List<Bucket> categoryList;
	private List<Bucket> colorList;
	private List<Bucket> priceList;
	
	public List<Bucket> getBrandList() {
		return brandList;
	}
	public void setBrandList(List<Bucket> brandList) {
		this.brandList = brandList;
	}
	public List<Bucket> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Bucket> categoryList) {
		this.categoryList = categoryList;
	}
	public List<Bucket> getColorList() {
		return colorList;
	}
	public void setColorList(List<Bucket> colorList) {
		this.colorList = colorList;
	}
	public List<Bucket> getPriceList() {
		return priceList;
	}
	public void setPriceList(List<Bucket> priceList) {
		this.priceList = priceList;
	}
	@Override
	public String toString() {
		return "ProductFilters [brandList=" + brandList + ", categoryList=" + categoryList + ", colorList="
				+ colorList + ", priceList=" + priceList + "]";
	}
	
}
