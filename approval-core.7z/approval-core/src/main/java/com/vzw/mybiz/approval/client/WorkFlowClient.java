package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.TokenRequest;
import com.vzw.mybiz.approval.domain.WorkFlowResponse;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name = "workflowmgtservice", configuration = CommonFeignConfiguration.class)
public interface WorkFlowClient {

	@PostMapping("/mbt/workflowmgt/optOrderTracking")
	public WorkFlowResponse updateOptTracking(OrderTrackingRequest orderTrackingRequest);
	
	@PostMapping("/mbt/workflowmgt/getOrderJson")
	public String getOrderJson(String orderNumber);
	
	@PostMapping("/mbt/workflowmgt/updateOrderMaster")
	public WorkFlowResponse updateOrderMaster(OrderMaster orderMaster);

	@PostMapping("/mbt/workflowmgt/optOrderTracking")
	public WorkFlowResponse updateOptTrackingBatch(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,OrderTrackingRequest orderTrackingRequest);


	@PostMapping("/mbt/workflowmgt/getOrderJson")
	public String getOrderJsonBatch(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,String orderNumber);
	
	@PostMapping("/mbt/workflowmgt/updateOrderMaster")
	public WorkFlowResponse updateOrderMasterBatch(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,OrderMaster orderMaster);
	
	@PostMapping("/mbt/workflowmgt/getCCPreOrderPayPortalToken")
	public String getCCPreOrderPayPortalToken(TokenRequest request);
}
