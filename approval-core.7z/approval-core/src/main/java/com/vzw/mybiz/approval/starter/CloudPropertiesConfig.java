package com.vzw.mybiz.approval.starter;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import com.vzw.mybiz.transformation.security.helpers.EncryptionHelper;

import lombok.Getter;
import lombok.Setter;

@Configuration
@RefreshScope
@Getter
@Setter
public class CloudPropertiesConfig implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private static final Log LOGGER = LogFactory.getLog(CloudPropertiesConfig.class);
	
	@Value("${spring.profiles.active:NA}")
	private String env;

	@Value("${spring.batch.schedule.enable:false}")
	private String batchEnabled;
	
	@Value("${spring.approval.reminder.initialnotification}")
	private int initialnotification;
	
	@Value("${spring.approval.reminder.finalnotification}")
	private int finalnotification;
	
	@Value("${spring.approval.reminder.autoexpiredaysfrom}")
	private int autoexpiredaysfrom;
	
	@Value("${spring.approval.reminder.autoexpiredaysto}")
	private int autoexpiredaysto;
	
	@Value("${spring.approval.mail.usernotificationflag:N}")
	private String usernotificationflag;
	
	@Value("${spring.approval.mail.from}")
	private String from;
	
	@Value("${spring.approval.mail.myBusinessIds}")
	private String myBusinessIds;
	
	@Value("${spring.cpc-manager-approval-url}")
	private String cpcmanagerApprovalUrl;
	
	@Value("${external.interfacing.system.vip.url}")
	private String vipUrl;

	@Value("${external.interfacing.system.vip.userId}")
	private String userId;

	@Value("${external.interfacing.system.vip.password}")
	private String password;

	@Value("${global.feign.connectTimeout:2000}")
	private int feignConnectTimeout;

	@Value("${global.feign.readTimeout:60000}")
	private int feignReadTimeout;
	
	@Value("${external.interfacing.system.etni.host}")
	private String etniHost;
	
	@Value("${external.interfacing.system.etni.npanxx}")
	private String locationSearch;
	
	@Value("${external.interfacing.system.sap.url}")
	private String sapUrl;
	
	@Value("${mbtCommonTransactions}")
	private String mbtCommonTransactions;
	
	@Value("${spring.common-manager-approval-sm-url}")
	private String commonTranManagerApprovalUrl;
	
	// For SALES FORCE
		@Value("${salesforce.uri:null}")
		private String salesForceUrl;
		
		@Value("${salesforce.auth.uri:null}")
		private String salesForceAuthUrl;
		
		
		@Value("${salesforce.auth.password:null}")
		private String salesForeceAuthPass;
		
		@Value("${salesforce.auth.username:null}")
		private String salesForeceAuthUserName;
		
		@Value("${salesforce.auth.client_id:null}")
		private String salesForeceClientId;
		
		@Value("${salesforce.auth.client_secret:null}")
		private String salesForeceClientSecret;
		
		@Value("${salesforce.proxyHost:null}")
		private String hostProxy;
		
		@Value("${salesforce.proxyPort:0}")
		private int portProxy;
		
		@Value("${consumer.host:null}")
		private String consumerHost;
		
		
		//RCWS
		@Value("${external.interfacing.system.rcws.url}")
		private String rcwsHost;
		
		@Value("${spring.cwui-manager-approval-sm-url}")
		private String cwuiManagerApprovalUrl;
		
		@Value("${spring.cba-manager-approval-sm-url}")
		private String cbaManagerApprovalUrl;


	@Autowired
	EncryptionHelper encryptionHelper;
	
	public String getNpaNxx() {
		return this.etniHost+this.locationSearch;
	}

	public String getVipUrl() {
		return vipUrl;
	}

	public void setVipUrl(String vipUrl) {
		this.vipUrl = vipUrl;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		String decryptedPassword = new String();
		try {
			LOGGER.debug("Decrypting started.");
			decryptedPassword = encryptionHelper.voltageDecrypt(password);
			LOGGER.debug("Decrypting ended.");
		} catch (Exception e) {
			LOGGER.error("Unable to decrypt the password from cloud config", e);
		}
		return decryptedPassword;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setFeignConnectTimeout(int feignConnectTimeout)
	{
		this.feignConnectTimeout = feignConnectTimeout;
	}

	public int getFeignConnectTimeout()
	{
		return feignConnectTimeout;
	}

	public void setFeignReadTimeout(int feignReadTimeout)
	{
		this.feignReadTimeout = feignReadTimeout;
	}

	public int getFeignReadTimeout()
	{
		return feignReadTimeout;
	}
	
}
