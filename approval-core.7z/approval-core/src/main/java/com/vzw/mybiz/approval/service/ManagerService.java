package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;

public interface ManagerService {

	public ManagerApprovalInfo getManagerApprovalInfo(ManagerApprovalRequest maRequest);
	
    public ManagerApprovalResponse saveManagerApprovalDetails(ManagerApprovalData maRequest);

	public ServiceStatus updateManagerApprovalInfo(ManagerApprovalRequest maRequest);
}
