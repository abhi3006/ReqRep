package com.vzw.mybiz.approval.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vzw.mybiz.approval.client.CartCore;
import com.vzw.mybiz.approval.client.CompanyClient;
import com.vzw.mybiz.approval.client.CustomizationClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.AccessoryPackage;
import com.vzw.mybiz.approval.domain.Cart;
import com.vzw.mybiz.approval.domain.CartResponse;
import com.vzw.mybiz.approval.domain.CheckoutCustomization;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.CustomizationEcpdProfileDto;
import com.vzw.mybiz.approval.domain.DgfDto;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.EcpdProfileInfo;
import com.vzw.mybiz.approval.domain.Equipment;
import com.vzw.mybiz.approval.domain.ManageApprovalMiscDto;
import com.vzw.mybiz.approval.domain.ManageApprovalOrderDto;
import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderDataManagerApproval;
import com.vzw.mybiz.approval.domain.OrderTypeDetails;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.ViewOnlyDto;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.entity.ManagerApprovalUrl;
import com.vzw.mybiz.approval.repo.MaTrackerRepo;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.ManagerService;
import com.vzw.mybiz.caching.services.cache.CacheService;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	CacheService<ManagerApprovalInfo> managerApprovalCache;

	@Autowired
	private CustomizationClient customizationClient;

	@Autowired
	private CompanyClient companyClient;

	@Autowired
	private CartCore cartCore;

	@Autowired
	private ManagerApprovalRepo managerApprovalRepo;

	@Autowired
	private MaTrackerRepo maTrackerRepo;

	public static final String MA_INFO_KEY = "CACHE_MA_";
	
	public static final Integer MA_STATE_KEY = 2;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ManagerServiceImpl.class);

	@Override
	public ManagerApprovalInfo getManagerApprovalInfo(ManagerApprovalRequest maRequest) {
		ManagerApprovalInfo serviceRes = new ManagerApprovalInfo();
		LOGGER.info("Inside getManagerApprovalInfo Service");
		try {
			ManagerApprovalInfo managerResfromCache = managerApprovalCache.getFromSession(MA_INFO_KEY+maRequest.getEcpdId(),
					ManagerApprovalInfo.class);
			if (managerResfromCache != null) {
				return managerResfromCache;
			}
			CommonRequest companyCoreReq = new CommonRequest();
			companyCoreReq.setEcpdId(maRequest.getEcpdId());
			companyCoreReq.setUserId(maRequest.getUserId());
			companyCoreReq.setZipCode(maRequest.getZipCode());
			companyCoreReq.setShoppingPath(maRequest.getTransactionType());
			CompanyCoreResponse companyCoreResponse = companyClient.getCompanyOrderData(companyCoreReq);
			CheckoutCustomization customizationInfo = customizationClient.getCustomizationInfo(companyCoreReq);
			LOGGER.info("customizationInfo: {}",customizationInfo.toString());
			managerApprovalForOrder(companyCoreResponse.getManagerApproval(), customizationInfo, companyCoreReq,
					serviceRes);
			serviceRes.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			managerApprovalCache.setToSession(MA_INFO_KEY+maRequest.getEcpdId(), serviceRes);
		} catch (Exception e) {
			serviceRes.setServiceStatus(getServiceStatus(Constants.EXCEPTION_CODE, Constants.EXCEPTION_MSG));
			LOGGER.error("Error fetching Manager Approval Details: {}", e);
		}
		LOGGER.info("Ending getManagerApprovalInfo Service");
		return serviceRes;

	}

	private ManagerApprovalInfo managerApprovalForOrder(OrderDataManagerApproval managerApproval,
			CheckoutCustomization customizationInfo, CommonRequest companyCoreReq, ManagerApprovalInfo res) {
		LOGGER.info("Inside managerApprovalForOrder Service");
		EcpdProfileInfo ecpdProfileInfo = managerApproval.getCommerceInfo();

		ManageApprovalOrderDto manageApprovalOrderDto = null;
		boolean showManagerApproval = false;

		String[] domainList = managerApproval.getDomainEntry();
		if (ecpdProfileInfo!=null && ecpdProfileInfo.getOption() > 0) {
			setManagerApprovalLevelEmail(res, ecpdProfileInfo);

			if (customizationInfo != null && customizationInfo.getDgf() != null
					&& customizationInfo.getDgf().getManageApprovalOrder() != null) {
				LOGGER.info("Populating Customization Info:"+customizationInfo.toString());
				manageApprovalOrderDto = customizationInfo.getDgf().getManageApprovalOrder();
				showManagerApproval = showManagerApproval(ecpdProfileInfo, customizationInfo.getDgf());
				res.setManagerApprovalEnabled(showManagerApproval);
				if (showManagerApproval && manageApprovalOrderDto != null) {
					CartResponse cartResponse = cartCore.retrieveCart(companyCoreReq);
					DgfFieldShort fieldData = setManagerApproverDetails(res, ecpdProfileInfo, customizationInfo,
							cartResponse);
					if (fieldData != null) {
						setManagerApprovalFields(fieldData, res);
						if (Constants.EMAIL_DOMAIN.equalsIgnoreCase(fieldData.getDgfDataType())) {
							setDomainList(res, domainList);
						}
					}
				}
				
				if (customizationInfo.getDgf().getEcpdProfile() != null
						&& MA_STATE_KEY.equals(customizationInfo.getDgf().getEcpdProfile().getManagerApprovalState())) {
					res.setManagerApprovalEnabled(false);
				}
			} else {
				LOGGER.info("No Customization Info");
				res.setManagerApprovalEnabled(true);
			}
		} else {
			LOGGER.info("No ECPD Profile Info");
			res.setManagerApprovalEnabled(false);
		}
		LOGGER.info("Ending managerApprovalForOrder Service");
		return res;
	}

	public void setDomainList(ManagerApprovalInfo managerApprovalRes, String[] domainList) {
		if (CollectionUtils.isNotEmpty(Arrays.asList(domainList))) {
			List<String> emailDomainList = new ArrayList<>();
			for (String domain : domainList) {
				emailDomainList.add(domain);
			}
			managerApprovalRes.setEmailDomainList(emailDomainList);
		}
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		return serviceStatus;
	}

	private DgfFieldShort manageNaoType(ManageApprovalOrderDto manageApprovalOrder, OrderTypeDetails orderTypeDetails) {
		DgfFieldShort nao = manageApprovalOrder.getNao();
		Boolean naoEnabled = manageApprovalOrder.getNaoEnable();
		if (naoEnabled != null && naoEnabled && orderTypeDetails.getNaoCount() > 0) {
			if (manageApprovalOrder.isQuanttityThresholdNAO()
					&& StringUtils.isNotEmpty(manageApprovalOrder.getQuantityThresholdValueNAO())) {
				if (evaluateThresholdRules(manageApprovalOrder.getQuantityNAO(),
						manageApprovalOrder.getQuantityThresholdValueNAO(), orderTypeDetails.getNaoCount())) {
					return nao;
				}
			} else {
				return nao;
			}
		}
		return null;
	}

	private boolean evaluateThresholdRules(long thresholdValue, String thresholdRule, long value) {
		boolean threshHoldRetVal = false;
		if (thresholdRule.equals("Greater Than/Equal To")) {
			if (value >= thresholdValue) {
				threshHoldRetVal = true;
			}
		} else if (thresholdRule.equals("Less Than/Equal To")) {
			if (value <= thresholdValue) {
				threshHoldRetVal = true;
			}
		}
		return threshHoldRetVal;
	}

	private boolean showManagerApproval(EcpdProfileInfo ecpdProfileInfo, DgfDto dgfDto) {
		boolean retVal = false;
		if (ecpdProfileInfo != null && ecpdProfileInfo.getOption() != 0) {
			CustomizationEcpdProfileDto ecpdProfile = dgfDto.getEcpdProfile();
			if (ecpdProfile.getUrlStatus() == 1) {
				final int ecpdState = ecpdProfile.getManagerApprovalState();
				if (ecpdState == 0 ||ecpdState == 2|| ecpdState == 1) {
					retVal = true;
				}
			} else {
				retVal = true;
			}
		}
		return retVal;
	}

	public DgfFieldShort setManagerApproverDetails(ManagerApprovalInfo managerApprovalRes,
			EcpdProfileInfo commerApprovalInfo, CheckoutCustomization customizationInfo, CartResponse cartResponse) {
		LOGGER.info("Inside setManagerApproverDetails Service");
		DgfFieldShort dataField = null;
		ManageApprovalOrderDto manageApprovalOrder = customizationInfo.getDgf().getManageApprovalOrder();
		DgfDto dgf = customizationInfo.getDgf();
		if (manageApprovalOrder.getManagerApprovalSuppress() != null
				&& manageApprovalOrder.getManagerApprovalSuppress()) {
			managerApprovalRes.setManagerApprovalSuppress(true);
		}

		ManageApprovalMiscDto manageApprovalMisc = dgf.getManageApprovalMiscDto();
		DgfFieldShort managerApproval = null;
		managerApproval = manageApprovalOrder.getManagerApproval();

		if (manageApprovalMisc != null && manageApprovalMisc.isManageAllOrders()) {
			dataField = managerApproval;
		} else if (manageApprovalOrder.isOrderType()) {
			OrderTypeDetails orderTypeDetails = this.populateOrderTypeDetails(cartResponse);
			dataField = manageNaoType(manageApprovalOrder, orderTypeDetails);
		} else if (manageApprovalOrder.isOrderThreshold()) {
			double totalDue = cartResponse.getCart().getAccessoryPackage().getTotalDueNow();
			if (StringUtils.isNotBlank(manageApprovalOrder.getOrderThresholdRule())
					&& manageApprovalOrder.getOrderThresholdValue() > 0) {
				if ((manageApprovalOrder.getOrderThresholdRule().equals(Constants.GREATERTHNEQUALTO)
						&& totalDue >= manageApprovalOrder.getOrderThresholdValue())
						|| (manageApprovalOrder.getOrderThresholdRule().equals(Constants.LESSTHNEQUALTO)
								&& totalDue <= manageApprovalOrder.getOrderThresholdValue())) {
					dataField = manageApprovalOrder.getOt();
				}
			}
		}
		LOGGER.info("Ending setManagerApproverDetails Service");
		return dataField;
	}

	private OrderTypeDetails populateOrderTypeDetails(CartResponse cartResponse) {
		OrderTypeDetails orderTypeDetails = new OrderTypeDetails();
		Cart cart = cartResponse.getCart();
		int naoCount = 0;
		if (cart != null) {
			AccessoryPackage accessoryPackage = cart.getAccessoryPackage();
			if (CollectionUtils.isNotEmpty(accessoryPackage.getEquipmentList())) {
				for (Equipment equipment : accessoryPackage.getEquipmentList()) {
					naoCount += equipment.getQuantity();
				}
			}
		}
		orderTypeDetails.setNaoCount(naoCount);
		return orderTypeDetails;

	}

	private void setManagerApprovalFields(DgfFieldShort fieldData, ManagerApprovalInfo res) {
		res.setReadonly(fieldData.isReadonly());
		res.setRequired(fieldData.isRequired());
		res.setUserInputType(fieldData.getDgfDataType());
		res.setPrePopulateEmailID(fieldData.getPrePopulatedValue());
		if (Constants.DROPDOWN.equalsIgnoreCase(fieldData.getDgfDataType())) {
			res.setLookUp(fieldData.getLookUp());
		}
		if (Constants.INPUT_TEXT.equalsIgnoreCase(fieldData.getDgfDataType())
				|| Constants.EMAIL_DOMAIN.equalsIgnoreCase(fieldData.getDgfDataType())) {
			res.setPrePopulateEmailID(fieldData.getPrePopulatedValue());
		}
	}

	public void setManagerApprovalLevelEmail(ManagerApprovalInfo managerApprovalRes,
			EcpdProfileInfo commerApprovalInfo) {
		Set<String> levelOneApproval = new HashSet<>();
		if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail1())) {
			levelOneApproval.add(commerApprovalInfo.getApproverEmail1());
		}
		if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail2())) {
			levelOneApproval.add(commerApprovalInfo.getApproverEmail2());
		}
		if (StringUtils.isNotBlank(commerApprovalInfo.getApproverEmail3())) {
			levelOneApproval.add(commerApprovalInfo.getApproverEmail3());
		}
		managerApprovalRes.setLevel(String.valueOf(commerApprovalInfo.getOption()));
		managerApprovalRes.setApproverEmails(levelOneApproval);
	}

	@Override
	public ManagerApprovalResponse saveManagerApprovalDetails(ManagerApprovalData maRequest) {
		LOGGER.info("Inside saveManagerApproverDetails Service");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			ManagerApprovalTracker maTracker = new ManagerApprovalTracker();
			maTracker.setEcpdId(maRequest.getEcpdId());
			maTracker.setOrderNumber(maRequest.getOrderNumber());
			maTracker.setLevel(Integer.valueOf(maRequest.getLevel()));
			maTracker.setApproverEmailL1(maRequest.getApproverEmailIds());
			maTracker.setLevelApproveUrl1(maRequest.getMaApprovalUrl());
			maTracker.setAppId("MBT");
			maTracker.setStatus(Constants.L1_PENDING);
			maTracker.setTransactionType("ORDERS");
			maTracker.setRecordType("ORDERS");
			maTracker.setCreatedDate(new Date());
			maTracker.setCreatedBy(maRequest.getUserId());
			maTracker.setOrderNumber(maRequest.getOrderNumber());
			maTracker = managerApprovalRepo.save(maTracker);
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			saveManagerApprovalUrl(maRequest);
		} catch (Exception e) {
			LOGGER.error("Error in saveManagerApproverDetails Service: "+e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}

	private ManagerApprovalResponse saveManagerApprovalUrl(ManagerApprovalData maRequest) {
		LOGGER.info("Inside saveManagerApprovalUrl Service");
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			ManagerApprovalUrl maUrl = new ManagerApprovalUrl();
			maUrl.setEcpdId(Long.valueOf(maRequest.getEcpdId()));
			maUrl.setUrl(maRequest.getMaApprovalUrl());
			maUrl.setCreateDate(new Date());
			maUrl.setMaxAccessed(0);
			maUrl.setUserName(maRequest.getUserId());
			maUrl = maTrackerRepo.save(maUrl);
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
		} catch (Exception e) {
			LOGGER.error("Error saveManagerApprovalUrl Service: ",e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}
	
	@Override
	public ServiceStatus updateManagerApprovalInfo(ManagerApprovalRequest maRequest) {

		ServiceStatus serviceStatus = null;
		try {
			ManagerApprovalInfo managerApprovalInfo = managerApprovalCache.getFromSession(MA_INFO_KEY+maRequest.getEcpdId(),
					ManagerApprovalInfo.class);
			
			if (managerApprovalInfo != null) {
				LOGGER.info("Exisiting user selection: {} " , managerApprovalInfo.getUserSelectedEmail());
				managerApprovalInfo.setUserSelectedEmail(maRequest.getApproverEmailIds());
				
				managerApprovalCache.setToSession(MA_INFO_KEY+maRequest.getEcpdId(), managerApprovalInfo);
				serviceStatus = getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG);
			}
		} catch (Exception e) {
			LOGGER.error("Error while updating manager approval data :{}" , e);
			serviceStatus = getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS);
		}
		return serviceStatus;
	
	}

}
