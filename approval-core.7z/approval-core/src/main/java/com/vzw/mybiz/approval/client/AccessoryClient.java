package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.RecommendationRequest;
import com.vzw.mybiz.approval.domain.RecommendationResponse;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;



@FeignClient(name="accessory-composite", configuration=CommonFeignConfiguration.class)
public interface AccessoryClient {

	@PostMapping("/mbt/browse/getRecommendedAccessories")
	public RecommendationResponse getRecommendations(RecommendationRequest request);
	
}
