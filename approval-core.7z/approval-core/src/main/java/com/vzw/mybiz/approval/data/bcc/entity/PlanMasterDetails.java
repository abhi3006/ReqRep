package com.vzw.mybiz.approval.data.bcc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class PlanMasterDetails {
	
	
	
	@Id
	@Column(name = "plan_id")
	private String planId;
	
	@Column(name = "plan_scope")
	private String planScope;
	
	@Column(name="category_id")
	private String category_id;
	
	@Column(name = "monthly_minutes")
	private String monthlyMins;
	
	@Column(name= "monthly_fee")
	private String monthlyFee;
	
	@Column(name="plan_display_name")
	private String displayName;
	
	@Column(name = "two_year_billing_code")
	private String billingCode;
	
	@Column(name = "component_type")
	private String componentType;
	
	@Column(name="ADDITIONAL_RATE_INFO")
	private String addRateInfo;
	
	@Column(name="short_description")
	private String shortDesc;
	
	@Column(name="b2b_short_desc")
	private String b2bShortDesc;
	
	@Column(name="b2b_long_desc")
	private String b2bLongDesv;
	
	@Column(name="bgsa")
	private String bgsa;
	
	@Column(name="b2b_display_name")
	private String b2bDisplayName;
	
	@Column(name="plan_category_type")
	private String planCatType;
	
	@Column (name="type")
	private String type;
	
	@Column (name="pp_seg_code")
	private String segmentCd;
	
	@Column (name="category_code")
	private String categoryCode;
	
	@Column (name="plan_status")
	private String planStatus;
	
	@Column (name="primary_secondary_indicator")
	private String primarySecondaryId;
	
}
