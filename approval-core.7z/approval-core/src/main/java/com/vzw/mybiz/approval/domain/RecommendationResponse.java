package com.vzw.mybiz.approval.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecommendationResponse {

	private ServiceStatus serviceStatus;
	private List<ProductMaster> accessoryList;
	private ProductFilters accessoryFilters;
	private int totalHits;
	private String selectedPhoneModel;
	private String selectedPhoneBrand;
	private String selectedMtn;

	public String getSelectedPhoneModel() {
		return selectedPhoneModel;
	}

	public void setSelectedPhoneModel(String selectedPhoneModel) {
		this.selectedPhoneModel = selectedPhoneModel;
	}

	public String getSelectedPhoneBrand() {
		return selectedPhoneBrand;
	}

	public void setSelectedPhoneBrand(String selectedPhoneBrand) {
		this.selectedPhoneBrand = selectedPhoneBrand;
	}

	public String getSelectedMtn() {
		return selectedMtn;
	}

	public void setSelectedMtn(String selectedMtn) {
		this.selectedMtn = selectedMtn;
	}

	public int getTotalHits() {
		return totalHits;
	}

	public void setTotalHits(int totalHits) {
		this.totalHits = totalHits;
	}

	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public List<ProductMaster> getAccessoryList() {
		return accessoryList;
	}

	public void setAccessoryList(List<ProductMaster> accessoryList) {
		this.accessoryList = accessoryList;
	}

	public ProductFilters getAccessoryFilters() {
		return accessoryFilters;
	}

	public void setAccessoryFilters(ProductFilters accessoryFilters) {
		this.accessoryFilters = accessoryFilters;
	}

	@Override
	public String toString() {
		return "GridwallResponse [serviceStatus=" + serviceStatus + ", accessoryList=" + accessoryList
				+ ", accessoryFilters=" + accessoryFilters + ", totalHits=" + totalHits + "]";
	}

}
