package com.vzw.mybiz.approval.util;

import static java.util.stream.Collectors.groupingBy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collector;

import org.apache.commons.lang3.StringUtils;

import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.sm.AccountLineItem;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cwui.AddressInfo;
import com.vzw.mybiz.approval.domain.sm.ma.cwui.ChangeUserInfoMTNInfo;
import com.vzw.mybiz.approval.domain.sm.ma.cwui.ContactInfo;
import com.vzw.mybiz.approval.domain.sm.ma.cwui.UserInformationVO;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

public class GenerateCWUIOrderDetailSM {

	/**
	 * Method to set accountLineItemList in smOrderResponse.
	 * 
	 * @param orderDetailsResponse
	 * @return Map
	 */
	public static void setAccountLineItemResponseForCWUI(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<SystemTxnInfo> orderDetailsList = orderDetailsResponse.getOrderDetailsList();
		List<AccountLineItem> accountLineItemList = new ArrayList<>();
		Map<String, Map<String, Map<String, List<SystemTxnInfo>>>> accountNumberMap = orderDetailsList.stream()
				.collect(groupingBy(SystemTxnInfo::getAccountNumber, groupByServiceNumberAndDetailType()));
		for (String accountNumber : accountNumberMap.keySet()) {
			AccountLineItem accountLineItem = new AccountLineItem();
			accountLineItem.setAccountNumber(accountNumber);
			Map<String, Map<String, List<SystemTxnInfo>>> serviceNumberMap = accountNumberMap.get(accountNumber);
			List<ChangeUserInfoMTNInfo> serviceLines = new ArrayList<>();
			for (String serviceNumber : serviceNumberMap.keySet()) {
				Map<String, List<SystemTxnInfo>> detailTypeMap = serviceNumberMap.get(serviceNumber);
				ChangeUserInfoMTNInfo serviceLine = new ChangeUserInfoMTNInfo();
				serviceLine.setAccountNumber(accountNumber);
				serviceLine.setServiceNumber(ManagerApprovalUtil.formatMtnWithDot(serviceNumber, Constant.DOT_STRING));
				serviceLine.setOldUserInfo(populateOldUserInfo(detailTypeMap));
				serviceLine.setNewUserInfo(populateNewUserInfo(detailTypeMap));
				serviceLines.add(serviceLine);
			}
			accountLineItem.setLines(serviceLines);
			accountLineItemList.add(accountLineItem);
		}
		smOrderResponse.setAccountLineItemList(accountLineItemList);
	}

	/**
	 * Return Collector object grouped by serviceNumber and detailType
	 * 
	 * @return Collector
	 */
	private static Collector<SystemTxnInfo, ?, Map<String, Map<String, List<SystemTxnInfo>>>> groupByServiceNumberAndDetailType() {
		return groupingBy(SystemTxnInfo::getServiceNumber, groupingBy(SystemTxnInfo::getDetailType));
	}

	/**
	 * Populate old user information
	 * 
	 * @param detailTypeMap
	 * @return oldUserInfo
	 */
	private static UserInformationVO populateOldUserInfo(Map<String, List<SystemTxnInfo>> detailTypeMap) {
		UserInformationVO oldUserInfo = new UserInformationVO();
		oldUserInfo.setUserId(getOldValue(detailTypeMap, Constant.USER_ID));
		oldUserInfo.setName(StringUtils.join(getOldValue(detailTypeMap, Constant.FIRST_NAME), StringUtils.SPACE,
				getOldValue(detailTypeMap, Constant.LAST_NAME)));
		oldUserInfo.setCostCenter(getOldValue(detailTypeMap, Constant.COST_CENTER));
		oldUserInfo.setAlternateContact1(populateContactInfo(getOldValue(detailTypeMap, Constant.CONTACT_PHONE_1)));
		oldUserInfo.setAlternateContact2(populateContactInfo(getOldValue(detailTypeMap, Constant.CONTACT_PHONE_2)));
		oldUserInfo.setEmail(getOldValue(detailTypeMap, Constant.EMAIL_ADDRESS));
		oldUserInfo.setAddress(populateOldAddressInfo(detailTypeMap));
		return oldUserInfo;
	}

	/**
	 * Return blank string if the argument is null
	 * 
	 * @param str
	 * @return String
	 */
	private static String nullToEmpty(String str) {
		return Objects.toString(str, StringUtils.EMPTY);
	}

	/**
	 * Populate new user information
	 * 
	 * @param detailTypeMap
	 * @return newUserInfo
	 */
	private static UserInformationVO populateNewUserInfo(Map<String, List<SystemTxnInfo>> detailTypeMap) {
		UserInformationVO newUserInfo = new UserInformationVO();
		newUserInfo.setUserId(getNewValue(detailTypeMap, Constant.USER_ID));
		newUserInfo.setName(StringUtils.join(getNewValue(detailTypeMap, Constant.FIRST_NAME), StringUtils.SPACE,
				getNewValue(detailTypeMap, Constant.LAST_NAME)));
		newUserInfo.setCostCenter(getNewValue(detailTypeMap, Constant.COST_CENTER));
		newUserInfo.setAlternateContact1(populateContactInfo(getNewValue(detailTypeMap, Constant.CONTACT_PHONE_1)));
		newUserInfo.setAlternateContact2(populateContactInfo(getNewValue(detailTypeMap, Constant.CONTACT_PHONE_2)));
		newUserInfo.setEmail(getNewValue(detailTypeMap, Constant.EMAIL_ADDRESS));
		newUserInfo.setAddress(populateNewAddressInfo(detailTypeMap));
		return newUserInfo;
	}

	/**
	 * Get new value from detailTypeMap
	 * 
	 * @param detailTypeMap
	 * @param detailType
	 * @return String
	 */
	private static String getNewValue(Map<String, List<SystemTxnInfo>> detailTypeMap, String detailType) {
		return nullToEmpty(detailTypeMap.get(detailType).get(0).getPlanGroup());
	}

	/**
	 * Get old value from detailTypeMap
	 * 
	 * @param detailTypeMap
	 * @param detailType
	 * @return String
	 */
	private static String getOldValue(Map<String, List<SystemTxnInfo>> detailTypeMap, String detailType) {
		return nullToEmpty(detailTypeMap.get(detailType).get(0).getItemName());
	}

	/**
	 * Populate old address information
	 * 
	 * @param detailTypeMap
	 * @return oldAddressInfo
	 */
	private static AddressInfo populateOldAddressInfo(Map<String, List<SystemTxnInfo>> detailTypeMap) {
		AddressInfo oldAddressInfo = new AddressInfo();
		oldAddressInfo.setAddressLine1(getOldValue(detailTypeMap, Constant.ADDRESS_1));
		oldAddressInfo.setAddressLine2(getOldValue(detailTypeMap, Constant.ADDRESS_2));
		oldAddressInfo.setCity(getOldValue(detailTypeMap, Constant.CITY));
		oldAddressInfo.setState(getOldValue(detailTypeMap, Constant.STATE));
		oldAddressInfo.setZipCode(getOldValue(detailTypeMap, Constant.ZIP_CODE));
		return oldAddressInfo;
	}

	/**
	 * Populate new address information
	 * 
	 * @param detailTypeMap
	 * @return newAddressInfo
	 */
	private static AddressInfo populateNewAddressInfo(Map<String, List<SystemTxnInfo>> detailTypeMap) {
		AddressInfo newAddressInfo = new AddressInfo();
		newAddressInfo.setAddressLine1(getNewValue(detailTypeMap, Constant.ADDRESS_1));
		newAddressInfo.setAddressLine2(getNewValue(detailTypeMap, Constant.ADDRESS_2));
		newAddressInfo.setCity(getNewValue(detailTypeMap, Constant.CITY));
		newAddressInfo.setState(getNewValue(detailTypeMap, Constant.STATE));
		newAddressInfo.setZipCode(getNewValue(detailTypeMap, Constant.ZIP_CODE));
		return newAddressInfo;
	}

	/**
	 * Populate contact information
	 * 
	 * @param contactInfoStr
	 * @return contactInfo
	 */
	private static ContactInfo populateContactInfo(String contactInfoStr) {
		// Example value: 8765439871 Ext: 8761
		ContactInfo contactInfo = new ContactInfo();
		String[] strArray = contactInfoStr.split(Constant.EXT_STR);
		contactInfo.setPhoneNumber(strArray[Constant.ZERO_AS_INT].trim());
		if (strArray.length > Constant.ONE_AS_INT) {
			contactInfo.setExtension(strArray[Constant.ONE_AS_INT].trim());
		} else {
			contactInfo.setExtension(StringUtils.EMPTY);
		}
		return contactInfo;
	}

}
