package com.vzw.mybiz.approval.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.DgfFieldShort;
import com.vzw.mybiz.approval.domain.ManageApprovalAMDto;

public class ManagerApprovalUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(ManagerApprovalUtil.class);

	public static boolean isMaCustomizationEnabled(String transactionType, ManageApprovalAMDto amDto) {
		switch (transactionType) {
		case Constant.CPC_TRANSACTION_TYPE:
			return amDto.isChangingCallPlan();
		case Constant.ARF_TRANSACTION_TYPE:
			return amDto.isAddRemoveFeatures();
		case Constant.SUS_TRANSACTION_TYPE:
			return amDto.isSuspendService();
		case Constant.RES_TRANSACTION_TYPE:
			return amDto.isResumeService();
		case Constant.CCC_TRANSACTION_TYPE:
			return amDto.isChangeCostCenter();
		case Constant.DACT_TRANSACTION_TYPE:
			return amDto.isDeactivateService();
		case Constant.TXN_TYPE_CBA:
			return amDto.isChangeBillToAddress();
		case Constant.CBR_INFO_TRANSACTION_TYPE:
			return amDto.isChangeBillingResponsibility();
		case Constant.TXN_TYPE_CWUI:
			return amDto.isChangeUserInformation();
		default:
			return false;
		}
	}

	public static DgfFieldShort getDfgFields(String transactionType, ManageApprovalAMDto amDto) {
		switch (transactionType) {
		case Constant.ARF_TRANSACTION_TYPE:
			return amDto.getArf();
		case Constant.CPC_TRANSACTION_TYPE:
			return amDto.getCcp();
		case Constant.SUS_TRANSACTION_TYPE:
			return amDto.getSs();
		case Constant.RES_TRANSACTION_TYPE:
			return amDto.getRs();
		case Constant.CCC_TRANSACTION_TYPE:
			return amDto.getCcc();
		case Constant.DACT_TRANSACTION_TYPE:
			return amDto.getDs();
		case Constant.CBA_TRANSACTION_TYPE:
			return amDto.getCbta();
		case Constant.CBR_INFO_TRANSACTION_TYPE:
			return amDto.getCbr();
		case Constant.TXN_TYPE_CWUI:
			return amDto.getCui();
		default:
			return new DgfFieldShort();
		}
	}
	
	/**
	 * <p>
	 * This method is used to format MTN where DOT separator is used to format the
	 * MTN
	 * </p>
	 * 
	 * @param input
	 * @return String
	 */
	public static String formatMtnWithDot(String input, String separator) {
		String mtn = formatNumber(input);
		if (StringUtils.length(mtn) > Constant.SIX_AS_INT) {
			mtn = StringUtils.join(mtn.substring(Constant.ZERO_AS_INT, Constant.THREE_AS_INT), separator,
					mtn.substring(Constant.THREE_AS_INT, Constant.SIX_AS_INT), separator,
					mtn.substring(Constant.SIX_AS_INT));
		}
		return mtn;
	}
	
	/**
	 * Method to remove all characters except numeric values.
	 * 
	 * @param input
	 * @return String
	 */
	public static String formatNumber(String input) {
		return StringUtils.replaceAll(StringUtils.trim(input), Constant.NUMBER_REGEX, StringUtils.EMPTY);
	}

}
