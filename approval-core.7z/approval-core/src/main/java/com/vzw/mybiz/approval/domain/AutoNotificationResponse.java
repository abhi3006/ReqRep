/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;

import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */

@Getter
@Setter
public class AutoNotificationResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String notificationType; 
	
	private int totalNumberofOrders; 
	private int successCount;
	private int failuerCount;
	private int batchProcessMasterId;
	private ServiceStatus serviceStatus;
	
	 private List<ManagerApprovalTracker> managerApprovalTrackers;
	

}
