package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.CommonRequest;
import com.vzw.mybiz.approval.domain.CompanyCoreResponse;
import com.vzw.mybiz.approval.domain.notification.ProfileEligibilityResponse;
import com.vzw.mybiz.approval.domain.notification.ProfileParameterRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;


@FeignClient(name="company-core", configuration=CommonFeignConfiguration.class)
public interface CompanyClient {

	@PostMapping("/mbt/companycore/getOrderData")
	public CompanyCoreResponse getCompanyOrderData(CommonRequest request);
	
	@PostMapping("/mbt/companycore/getProfileEligibilityDetails")
	ProfileEligibilityResponse getProfileEligibilityDetails(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,ProfileParameterRequest  request);
	
}
