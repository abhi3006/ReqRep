package com.vzw.mybiz.approval.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.SAPCoreClient;
import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckRequest;
import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckRequest.ItemStockCheckRequest;
import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckResponse;
import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckResponse.ItemStockCheckResponse;
import com.vzw.mybiz.approval.rest.domain.InventorySkuDetails;
import com.vzw.mybiz.approval.rest.domain.InventorySkuResponse;
import com.vzw.mybiz.approval.rest.domain.SAPInventoryRequest;
import com.vzw.mybiz.approval.rest.domain.SAPInventoryResponse;
import com.vzw.mybiz.approval.service.SAPService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.Feign;
import feign.Logger.Level;
import feign.Request;
import feign.jaxb.JAXBContextFactory;
import feign.jaxb.JAXBDecoder;
import feign.jaxb.JAXBEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;

@Service
public class SAPServiceImpl implements SAPService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SAPServiceImpl.class);

	SAPCoreClient sapCoreClient;
	
	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;

	@Autowired
	private AuditService auditService;

	Gson gson = new Gson();
	
	JAXBContextFactory jaxbFactory = new JAXBContextFactory.Builder().withMarshallerJAXBEncoding("UTF-8")
			.withMarshallerSchemaLocation("http://apihost http://apihost/schema.xsd").build();

	@Override
	public SAPInventoryResponse getRealTimeInventoryStatus(SAPInventoryRequest request) {
		LOGGER.info("Inside getRealTimeInventoryStatus ");

		SAPInventoryResponse inventoryResponse = new SAPInventoryResponse();
		inventoryResponse.setEcpdId(request.getEcpdId());
		inventoryResponse.setUserId(request.getUserId());
		inventoryResponse.setRequestedSource(request.getRequestedSource());
		inventoryResponse.setLocationCode(request.getLocationCode());
		inventoryResponse.setOutofStockFlag(false);
		inventoryResponse.setServiceStatus(
				populateStatus(true, "Successful", "Successful", "200"));
		try {
			
			
			sapCoreClient = Feign.builder().client(new OkHttpClient())
			.options(new Request.Options(cloudPropertiesConfig.getFeignReadTimeout(), cloudPropertiesConfig.getFeignConnectTimeout()))
			.logger(new Slf4jLogger(SAPCoreClient.class))
			.encoder(new JAXBEncoder(jaxbFactory)).decoder(new JAXBDecoder(jaxbFactory))
			.logger(new Slf4jLogger(SAPCoreClient.class)).logLevel(Level.FULL)
			.target(SAPCoreClient.class, cloudPropertiesConfig.getSapUrl());
			
			AtpCheckRequest atpCheckRequest = buildAtpCheckRequest(request);

			auditService.beginTransaction(atpCheckRequest,
					new ExternalSys("VIP", cloudPropertiesConfig.getSapUrl() + "sig/rest/atpCheck?xmlreqdoc="));
			LOGGER.info(" : atpCheckRequest :" + gson.toJson(atpCheckRequest));
			LOGGER.info(" : atpCheckRequest :" + atpCheckRequest.toString());
			AtpCheckResponse atpCheckResponse = sapCoreClient.getRealTimeInventoryStatus(atpCheckRequest);
			auditService.endTransaction(atpCheckResponse, new ResponseDetails("Message", "StatusCode"));
			LOGGER.info(":: atpCheckRequest  ::" + gson.toJson(atpCheckResponse));
			if (atpCheckResponse != null) {
				prepareInventoryResponse(inventoryResponse, atpCheckResponse, request);
			}

		} catch (Exception e) {
			LOGGER.error(" Error in live SAP end point sig/rest/atpCheck ApI call ", e.getMessage());
			inventoryResponse.setServiceStatus(
					populateStatus(false, "FAILURE","FAILURE","99"));
		}
		return inventoryResponse;
	}

	private void prepareInventoryResponse(SAPInventoryResponse inventoryResponse, AtpCheckResponse atpCheckResponse,
			SAPInventoryRequest request) {
		List<InventorySkuResponse> inventorySkuDetails = new ArrayList<InventorySkuResponse>();
		boolean outofStockFlag = false;
		boolean deviceOutofStockFlag = false;
		boolean accessoryOutofStockFlag = false;

		for (InventorySkuDetails tempSku : request.getInventorySkuDetails()) {

			ItemStockCheckResponse tempItemStockCheckResponse = atpCheckResponse.getItemStockCheckResponse().stream()
					.filter(itemStockCheckResponse -> itemStockCheckResponse != null
							&& StringUtils.equals(tempSku.getSku(), itemStockCheckResponse.getSku())
							&& (Integer.parseInt(itemStockCheckResponse.getAvailableQuantity()) == 0
									|| tempSku.getRequestedQuantity() > Integer
											.parseInt(itemStockCheckResponse.getAvailableQuantity())))
					.findFirst().orElse(null);
			LOGGER.info("For Sku " + tempSku.getSku() + " : tempItemStockCheckResponse "
					+ tempItemStockCheckResponse != null ? gson.toJson(tempItemStockCheckResponse) : "null");
			if (tempItemStockCheckResponse != null) {
				LOGGER.info(" tempItemStockCheckResponse " + gson.toJson(tempItemStockCheckResponse));
				InventorySkuResponse skuDetails = new InventorySkuResponse();
				skuDetails.setSku(tempSku.getSku());
				skuDetails.setSkuName(tempSku.getSkuName());
				skuDetails.setSkuType(tempSku.getSkuType());
				skuDetails.setDeviceMasterId(tempSku.getDeviceMasterId());
				skuDetails.setRequestedQuantity(tempSku.getRequestedQuantity());
				skuDetails.setAvailableQuantity(Integer.parseInt(tempItemStockCheckResponse.getAvailableQuantity()));
				skuDetails.setOutofStockQuantity(skuDetails.getRequestedQuantity() - skuDetails.getAvailableQuantity());
				skuDetails.setContract(tempItemStockCheckResponse.getContract());
				skuDetails.setErrorMessage(tempItemStockCheckResponse.getErrorMessage());
				inventorySkuDetails.add(skuDetails);
				if (!outofStockFlag) {
					outofStockFlag = true;
				}
				if (!deviceOutofStockFlag && "DEVICE".equals(tempSku.getSkuType())) {
					deviceOutofStockFlag = true;
				}
				if (!accessoryOutofStockFlag && "ACCESSORY".equals(tempSku.getSkuType())) {
					accessoryOutofStockFlag = true;
				}
			}
		}
		inventoryResponse.setOutofStockFlag(outofStockFlag);
		inventoryResponse.setDeviceOutofStockFlag(deviceOutofStockFlag);
		inventoryResponse.setAccessoryOutofStockFlag(accessoryOutofStockFlag);
		inventoryResponse.setInventorySkuDetails(inventorySkuDetails);
	}

	/**
	 * Prepare the request object for API call
	 * 
	 * @param request
	 * @return
	 */
	private AtpCheckRequest buildAtpCheckRequest(SAPInventoryRequest request) {
		AtpCheckRequest atpCheckRequest = new AtpCheckRequest();
		ItemStockCheckRequest itemStockCheckRequest = null;
		for (InventorySkuDetails inventorySkuDetails : request.getInventorySkuDetails()) {
			if (inventorySkuDetails.getCriticalInventoryLevel() >= 0) {
				itemStockCheckRequest = new ItemStockCheckRequest();
				if(request.getLocationCode() != null){
					itemStockCheckRequest.setLocationCode(request.getLocationCode());
				}
				//Populating the ispuLocation for store details api
				if(request.getIspuLocation() != null){
					itemStockCheckRequest.setIspuLocation(request.getIspuLocation());
				}
				itemStockCheckRequest
						.setRequestedQuantity(Integer.toString(inventorySkuDetails.getRequestedQuantity()));
				itemStockCheckRequest.setSku(inventorySkuDetails.getSku());
				if(request.getStoreSaleIndicator().equalsIgnoreCase("L")){
					itemStockCheckRequest.setStoreSaleIndicator("L");
				}else {
					itemStockCheckRequest.setStoreSaleIndicator("F");
				}
				atpCheckRequest.getItemStockCheckRequest().add(itemStockCheckRequest);
			

			} else {
				LOGGER.info(inventorySkuDetails.getSku() + " :: " + inventorySkuDetails.getSkuName()
						+ ". Not included in lifr SAP call as critical inventory value "
						+ inventorySkuDetails.getCriticalInventoryLevel());
			}
		}

		return atpCheckRequest;
	}

	/**
	 * Prepare Service status
	 * 
	 * @param statusFlag
	 * @param status
	 * @param statusMessage
	 * @param statusCode
	 * @return
	 */
	private ServiceStatus populateStatus(boolean statusFlag, String status, String statusMessage, String statusCode) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setMessage(status);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setSuccess(statusFlag);
		return serviceStatus;
	}

}