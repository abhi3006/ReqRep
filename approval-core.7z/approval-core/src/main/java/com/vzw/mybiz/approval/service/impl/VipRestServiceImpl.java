package com.vzw.mybiz.approval.service.impl;

import java.io.IOException;
import java.lang.reflect.Type;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.mybiz.approval.client.VipClient;
import com.vzw.mybiz.approval.client.WfmCoreClient;
import com.vzw.mybiz.approval.client.WorkFlowClient;
import com.vzw.mybiz.approval.domain.TokenRequest;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.BilingAddress;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.DeviceSkuDetails;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.Line;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.OrderDetails;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsRequest;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferReq;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferUiRes;
import com.vzw.mybiz.approval.domain.sed.SedVipHelper;
import com.vzw.mybiz.approval.exception.VipFeignException;
import com.vzw.mybiz.approval.service.VipRestService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.domain.pos.retrieveorder.AddressType;
import com.vzw.mybiz.domain.pos.retrieveorder.BussBillingAddress;
import com.vzw.mybiz.domain.pos.retrieveorder.ItemOrderItem;
import com.vzw.mybiz.domain.pos.retrieveorder.ReadOrder;
import com.vzw.mybiz.domain.pos.retrieveorder.ServiceBody;
import com.vzw.mybiz.domain.pos.retrieveorder.ServiceHeader.OrderKeyInfo;
import com.vzw.mybiz.prospect.domain.Root;
import com.vzw.mybiz.prospect.domain.pos.ObjectFactory;
import com.vzw.mybiz.prospect.domain.pos.POSServices;
import com.vzw.mybiz.sharedcart.domain.pos.PosCartAddressType;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.Feign;
import feign.FeignException;
import feign.Logger.Level;
import feign.Request;
import feign.RequestTemplate;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;
import feign.codec.Decoder;
import feign.codec.EncodeException;
import feign.codec.Encoder;
import feign.jaxb.JAXBContextFactory;
import feign.jaxb.JAXBDecoder;
import feign.jaxb.JAXBEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
public class VipRestServiceImpl implements VipRestService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VipRestServiceImpl.class);

	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;

	ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
	@Autowired
	private AuditService auditService;
	
	@Autowired
	private WorkFlowClient workFlowClient;
	
	private JAXBContextFactory jaxbFactory = new JAXBContextFactory.Builder().withMarshallerJAXBEncoding("UTF-8")
			.withMarshallerSchemaLocation("http://apihost http://apihost/schema.xsd").build();
	@Override
	public ComputeOfferUiRes computeOffer(ComputeOfferReq computeOfferReq) {		
		ServiceStatus status = null;
		com.vzw.mybiz.prospect.domain.sed.vip.POSServices response = null;
		ComputeOfferUiRes uiRes = null;
		String dunsRespJson = "NA";
		int httpStatusCode = 200;
		String messageCode = "0";
		String messageDescription = "SUCCESS";
		com.vzw.mybiz.prospect.domain.sed.vip.POSServices posOrder = SedVipHelper.buildComputeOfferRequest(computeOfferReq);
		posOrder.getServiceHeader().setUserName(cloudPropertiesConfig.getUserId());
		posOrder.getServiceHeader().setPassword(cloudPropertiesConfig.getPassword());
		try {
			long time = System.currentTimeMillis();
			VipClient submitProspectOrder = Feign.builder().client(new OkHttpClient())
			        .options(new Request.Options(cloudPropertiesConfig.getFeignConnectTimeout(), cloudPropertiesConfig.getFeignReadTimeout()))
					.encoder(SedVipHelper.getEncoder(posOrder)).decoder(getCustomDecoder(com.vzw.mybiz.prospect.domain.sed.vip.POSServices.class))
					.logger(new Slf4jLogger(VipClient.class)).logLevel(Level.FULL)
					.target(VipClient.class, cloudPropertiesConfig.getVipUrl());
			auditService.beginTransaction(posOrder, new ExternalSys("POS", cloudPropertiesConfig.getVipUrl()));
			response = submitProspectOrder.offerManagement(posOrder);
			//response = objMapper.readValue(responseString, com.vzw.mybiz.prospect.domain.sed.vip.POSServices.class);
			LOGGER.info("Getting computeOffer from API calling took... = " + (System.currentTimeMillis() - time) + " ms");			
			LOGGER.info("Return Code --->"+response);
			
			uiRes= SedVipHelper.mapToUiRes(response);						

		}catch(FeignException fex)
		{
			LOGGER.error("computeOffer Error" + fex);
			messageCode = "5000";
			httpStatusCode = fex.status();
			messageDescription = fex.getMessage();
			status = new ServiceStatus();
        	status.setStatusCode("1");
        	status.setStatusMessage("Failure");
        	status.setSuccess(false);
        	uiRes.setServiceStatus(status);
		}
		catch(Throwable ex)
		{
			httpStatusCode= 0;
			messageCode = "6000";
			LOGGER.error("computeOffer Error" + ex);
			status = new ServiceStatus();
        	status.setStatusCode("1");
        	status.setStatusMessage("Failure");
        	status.setSuccess(false);
        	uiRes.setServiceStatus(status);
		}
		finally
		{
			auditService.endTransaction(dunsRespJson, new ResponseDetails(httpStatusCode, messageCode, messageDescription));			
		}

		return uiRes;
	}
	
	

	@Override
	public ServiceStatus submitProspectOrder(String cartString, Root cartObj) throws VipFeignException {
		ResponseDetails respDetails = null;
		ServiceStatus status = null;
		String responseXml = null;
		//com.vzw.mybiz.prospect.domain.pos.cpqcart.POSServices posOrder = buildPOSRequestNew(cartString);
		POSServices posOrder = buildPOSRequest(cartString);
		posOrder.getServiceHeader().setUserName(cloudPropertiesConfig.getUserId());
		posOrder.getServiceHeader().setPassword(cloudPropertiesConfig.getPassword());
		try {
			VipClient submitProspectOrder = Feign.builder().client(new OkHttpClient())
			        .options(new Request.Options(cloudPropertiesConfig.getFeignConnectTimeout(), cloudPropertiesConfig.getFeignReadTimeout()))
					.encoder(getCustomEncoder(posOrder)).decoder(getCustomDecoder(null))
					.logger(new Slf4jLogger(VipClient.class)).logLevel(Level.FULL)
					.target(VipClient.class, cloudPropertiesConfig.getVipUrl());
			auditService.beginTransaction(posOrder, new ExternalSys("POS", cloudPropertiesConfig.getVipUrl()));
			responseXml = submitProspectOrder.submitOrder(posOrder);
			String tmp1 = responseXml.substring(0,responseXml.indexOf("</applicationResponseCode>"));
			String returnCode = tmp1.substring(responseXml.indexOf("<applicationResponseCode>")+25, tmp1.length());
			LOGGER.info("Return Code --->"+returnCode);
			
			tmp1 = responseXml.substring(0,responseXml.indexOf("</applicationResponseMessage>"));
			String returnMsg = tmp1.substring(responseXml.indexOf("<applicationResponseMessage>")+28, tmp1.length());
			LOGGER.info("returnMsg --->"+returnMsg);
			
			respDetails = new ResponseDetails(returnCode,returnMsg);
			if (responseXml!=null && responseXml.contains("99000") && responseXml.contains("cartId")) {
				tmp1 = responseXml.substring(0,responseXml.indexOf("</cartId>"));
				String cartid = tmp1.substring(responseXml.indexOf("<cartId>")+8, tmp1.length());
				LOGGER.info("cartid --->"+cartid);
				
				status = new ServiceStatus();
            	status.setStatusCode("0");
            	status.setStatusMessage("SUCCESS");
            	status.setSuccess(true);
            	status.setMessage(cartid);
            	
			} else {
				status = new ServiceStatus();
            	status.setStatusCode("1");
            	status.setStatusMessage("Failure");
            	status.setSuccess(false);
			}
//			respDetails = new ResponseDetails(String.valueOf(posAddressResponse.getServiceHeader().getApplicationResponseCode()),
//					  posAddressResponse.getServiceHeader().getApplicationResponseClass());
//			if ("99000".equalsIgnoreCase(String.valueOf(posAddressResponse.getServiceHeader().getApplicationResponseCode()))) {
//            	status = new ServiceStatus();
//            	status.setStatusCode("0");
//            	status.setStatusMessage("SUCCESS");
//            	status.setSuccess(true);
//            	//status.setMessage(message);
//            } else {
//            	status = new ServiceStatus();
//            	status.setStatusCode("1");
//            	status.setStatusMessage("Failure");
//            	status.setSuccess(false);
//            }
			

		}catch (Exception e) {
			LOGGER.error("Exception while calling POS address validation service", e);
			respDetails = new ResponseDetails("POS_GENERAL_ERROR", "General Error!");
			status = new ServiceStatus();
        	status.setStatusCode("1");
        	status.setStatusMessage("Failure");
        	status.setSuccess(false);
		}
		finally
		{
			auditService.endTransaction(responseXml, respDetails);
		}

		return status;
	}

	

	public Encoder getCustomEncoder(POSServices posOrder) {
		return new Encoder() {
			@Override
			public void encode(Object object, Type bodyType, RequestTemplate template) throws EncodeException {
				JAXBContextFactory jaxbContextFactory = new JAXBContextFactory.Builder()
						.withMarshallerFormattedOutput(true).build();
				Encoder encoder = new JAXBEncoder(jaxbContextFactory);
				encoder.encode(posOrder, POSServices.class, template);
			}
		};
	}
	


	public Decoder getCustomDecoder(Class className) {
		return new Decoder() {
			@Override
			public Object decode(Response response, Type type) throws IOException, DecodeException, FeignException {
				LOGGER.info("decode====>getCustomDecoder::"+response);
				JAXBContextFactory jaxbContextFactory = new JAXBContextFactory.Builder()
						.withMarshallerFormattedOutput(true).build();
				if (response.status() == 404 || response.body() == null) {
					return getResponseValue(response, type);
				}
				/*if (!(type instanceof Class)) {
					throw new UnsupportedOperationException("JAXB only supports decoding raw types. Found " + type);
				}*/
				try {
					LOGGER.info("type---->"+type);
					//@SuppressWarnings("rawtypes")
					//Unmarshaller unmarshaller = jaxbContextFactory.createUnmarshaller((Class) type);
					//LOGGER.info("unmarshaller---->"+unmarshaller);
					LOGGER.info("response.body()---->"+response.body().toString());
					if(className != null) {
						Decoder decoder = new JAXBDecoder(jaxbContextFactory);
						return decoder.decode(response, type);
					}
					else {						
						String responseLocal = IOUtils.toString(response.body().asInputStream(), "UTF-8");
						LOGGER.info("responseLocal---->"+responseLocal);						
						return responseLocal; 
					}
					// LOGGER.info("response.body()---->"+response.body().toString());
					//String responseLocal = IOUtils.toString(response.body().asInputStream(), "UTF-8");
					//LOGGER.info("responseLocal---->"+responseLocal);
				//	unmarshaller.unmarshal(new ByteArrayInputStream(responseLocal.getBytes()));
					//return responseLocal; 
				//} catch (Exception e) {
					//throw new DecodeException(e.toString(), e);
				//	LOGGER.error("Error-->"+e);
				} finally {
					if (response.body() != null) {
						response.body().close();
					}
				}
			}

			private Object getResponseValue(Response response, Type type){
				if (response.status() == 404) {
					return Util.emptyValueOf(type);
				}else if (response.body() == null) {
					return null;
				}
				return null;
			}

		};
	}
	
	private POSServices buildPOSRequest(String base64Order) {
		LOGGER.info("Inside buildPOSRequest of ProspectController");

		ObjectFactory posObjectFactory = new ObjectFactory();
		POSServices service = posObjectFactory.createPOSServices();
		POSServices.ServiceHeader serviceHeader = posObjectFactory.createPOSServicesServiceHeader();
		POSServices.ServiceHeader.OrderKeyInfo serviceHeaderOrderKeyInfo = posObjectFactory
				.createPOSServicesServiceHeaderOrderKeyInfo();

		POSServices.ServiceBody serviceBody = posObjectFactory.createPOSServicesServiceBody();

		POSServices.ServiceBody.SaveCommonCartMS saveCommonCartMS = posObjectFactory
				.createPOSServicesServiceBodySaveCommonCartMS();
		POSServices.ServiceBody.SaveCommonCartMS.Request saveCommonCartMSRequest = posObjectFactory
				.createPOSServicesServiceBodySaveCommonCartMSRequest();

		saveCommonCartMSRequest.setStatus("A");
		saveCommonCartMSRequest.setCartInfo(base64Order);

		saveCommonCartMS.setRequest(saveCommonCartMSRequest);
		serviceBody.setSaveCommonCartMS(saveCommonCartMS);

		serviceHeader.setClientAppName("MYBUSINESS");
		serviceHeader.setClientAppUserName("PROSPECT-USER");
		serviceHeader.setEncryptionIndicator("T");
		// serviceHeader.setOrderKeyInfo(serviceHeaderOrderKeyInfo);
		serviceHeader.setServiceAction("saveCommonCart");
		serviceHeader.setServiceName("cartMicroService");
		// serviceHeader.setSessionID("");
		// serviceHeader.setTimeStamp("");
		// serviceHeader.setTransactionId("");

		service.setServiceHeader(serviceHeader);
		service.setServiceBody(serviceBody);

		LOGGER.info("Exit buildPOSRequest of ProspectController");
		return service;
	}



	@Override
	public PosCartAddressType validateAddress(PosCartAddressType address) throws VipFeignException {
		LOGGER.info("Inside validateAddress");
		PosCartAddressType newaddress = null;
		ResponseDetails respDetails = null;
		ServiceStatus status = null;
		if (address.getAddress1() == null) {
			address.setAddress1(address.getStreetName());
		}
		address.setAptNum(null);
		address.setStreetName(null);
		address.setStreetNum(null);
		com.vzw.mybiz.approval.domain.jaxb.POSServices posOrder = buildAddressValidationReq(address);
		posOrder.getServiceHeader().setUserName(cloudPropertiesConfig.getUserId());
		posOrder.getServiceHeader().setPassword(cloudPropertiesConfig.getPassword());
		try {
			VipClient validateAddress = Feign.builder().client(new OkHttpClient())
			        .options(new Request.Options(cloudPropertiesConfig.getFeignConnectTimeout(), cloudPropertiesConfig.getFeignReadTimeout()))
			        .encoder(new JAXBEncoder(jaxbFactory)).decoder(new JAXBDecoder(jaxbFactory))
					.logger(new Slf4jLogger(VipClient.class)).logLevel(Level.FULL)
					.target(VipClient.class, cloudPropertiesConfig.getVipUrl());
			
			auditService.beginTransaction(posOrder, new ExternalSys("POS", cloudPropertiesConfig.getVipUrl()));
			posOrder = validateAddress.validateAddress(posOrder);
			LOGGER.info("AfterCall"+posOrder);
			String returnCode = null, returnMsg = null;
			returnCode = posOrder.getServiceHeader().getApplicationResponseCode();
			returnMsg = posOrder.getServiceHeader().getApplicationResponseMessage();
			if("99000".equalsIgnoreCase(posOrder.getServiceHeader().getApplicationResponseCode())) {
				LOGGER.info("AfterCall:::Success"+posOrder);
				//DozerBeanMapper mapper=new DozerBeanMapper();
				MapperFactory mapperFactory=new DefaultMapperFactory.Builder().build();
				MapperFacade mapper=mapperFactory.getMapperFacade();
				newaddress = mapper.map(posOrder.getServiceBody().getAddressSplit().getResponse().getAddress(), PosCartAddressType.class);
				status = new ServiceStatus();
            	status.setStatusCode("0");
            	status.setStatusMessage("SUCCESS");
            	status.setSuccess(true);
			} else {
				status = new ServiceStatus();
            	status.setStatusCode("1");
            	status.setStatusMessage("Failure");
            	status.setSuccess(false);
			}
			
			respDetails = new ResponseDetails(returnCode,returnMsg);
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			auditService.endTransaction(newaddress, respDetails);
		}
		
		LOGGER.info("Exit validateAddress");
		return newaddress;
	}

	public com.vzw.mybiz.approval.domain.jaxb.POSServices buildAddressValidationReq(PosCartAddressType address) {
		
		com.vzw.mybiz.approval.domain.jaxb.ObjectFactory posObjectFactory = new com.vzw.mybiz.approval.domain.jaxb.ObjectFactory();
		com.vzw.mybiz.approval.domain.jaxb.POSServices service = posObjectFactory.createPOSServices();
		com.vzw.mybiz.approval.domain.jaxb.ServiceHeaderType serviceHeader = posObjectFactory.createServiceHeaderType();
		com.vzw.mybiz.approval.domain.jaxb.POSServices.ServiceBody serviceBody = posObjectFactory.createPOSServicesServiceBody();
		com.vzw.mybiz.approval.domain.jaxb.AddressSplit addressSplit = posObjectFactory.createAddressSplit();
		com.vzw.mybiz.approval.domain.jaxb.AddressSplit.Request addressRequest = posObjectFactory.createAddressSplitRequest();
		com.vzw.mybiz.approval.domain.jaxb.AddressSplit.Request.AddressLineBased addressLinebased = posObjectFactory.createAddressSplitRequestAddressLineBased();
		
		service.setServiceHeader(serviceHeader);
		service.setServiceBody(serviceBody);
		
		serviceHeader.setClientAppName("MYBUSINESS");
		serviceHeader.setClientAppUserName("PROSPECT-USER");
		serviceHeader.setServiceAction("splitAddress");
		serviceHeader.setServiceName("addressService");
		
		addressLinebased.setAddressLine1(address.getAddress1());
		if (address.getAddressLine2() != null) {
			addressLinebased.setAddressLine2(address.getAddressLine2());
		} else {
			addressLinebased.setAddressLine2(" ");
		}

		addressLinebased.setCity(address.getCity());
		addressLinebased.setState(address.getState());
		addressLinebased.setZipCode(address.getZipCode());
		
		addressRequest.setCallZipPrsServerFlag("Y");
		addressRequest.setFourCharStreetTypeFlag("true");
		
		addressRequest.setAddressLineBased(addressLinebased);
		
		addressSplit.setRequest(addressRequest);
		
		serviceBody.setAddressSplit(addressSplit);
		
		return service;
		
	}

	@Override
	public RetrieveOrderDetailsResponse retrieveOrderDetails(RetrieveOrderDetailsRequest request) {
		RetrieveOrderDetailsResponse response = null;
		ResponseDetails respDetails = null;
		com.vzw.mybiz.domain.pos.retrieveorder.POSServices posRes = null;
		LOGGER.info("Request to retrieveOrderDetails  --->"+request);	
		try {
			if(request != null && StringUtils.isNotBlank(request.getOrderNum()) && StringUtils.isNotBlank(request.getToken())) {				
				TokenRequest tokenReq = new TokenRequest();
				tokenReq.setEcpdId(request.getEcpdId());
				tokenReq.setOrderNum(request.getOrderNum());
				tokenReq.setUserId(request.getUserId());
				String token = workFlowClient.getCCPreOrderPayPortalToken(tokenReq);
				if(request.getToken().equalsIgnoreCase(token)) {
					com.vzw.mybiz.domain.pos.retrieveorder.POSServices posOrder = buildRetOrderRequest(request);
					if(posOrder != null && posOrder.getServiceBody() != null) {	
						VipClient posClient = Feign.builder().client(new OkHttpClient())					        
						        .encoder(new JAXBEncoder(jaxbFactory)).decoder(new JAXBDecoder(jaxbFactory))
								.logger(new Slf4jLogger(VipClient.class)).logLevel(Level.FULL)
								.target(VipClient.class, cloudPropertiesConfig.getVipUrl());					
						auditService.beginTransaction(posOrder, new ExternalSys("POS", cloudPropertiesConfig.getVipUrl()));
						posRes = posClient.retrieveOrder(posOrder);	
						LOGGER.info("retrieveOrderDetails response --->"+posRes);	
						if(posRes != null && posRes.getServiceHeader() != null) {
							LOGGER.info("retrieveOrderDetails Response Code --->"+posRes.getServiceHeader().getApplicationResponseCode());			
							LOGGER.info("retrieveOrderDetails Response Message --->"+posRes.getServiceHeader().getApplicationResponseMessage());
							LOGGER.info("retrieveOrderDetails Response Class --->"+posRes.getServiceHeader().getApplicationResponseClass());
							respDetails = new ResponseDetails(posRes.getServiceHeader().getApplicationResponseCode(), posRes.getServiceHeader().getApplicationResponseMessage());
						}					
						if (posRes != null && posRes.getServiceHeader() != null && "99000".equalsIgnoreCase(posRes.getServiceHeader().getApplicationResponseCode()) && "SUCCESS".equalsIgnoreCase(posRes.getServiceHeader().getApplicationResponseClass())) {									
							response = new RetrieveOrderDetailsResponse();
							populateResponse(response, posRes);
							ServiceStatus status = new ServiceStatus();						
				        	status.setStatusCode("0");
				        	status.setStatusMessage("SUCCESS");
				        	status.setSuccess(true);	
				        	response.setStatus(status);
						} else {
							if(respDetails == null) {
								respDetails = new ResponseDetails("POS_SERVICE_ERROR", "Service Response Error!"); 
							}
							response = new RetrieveOrderDetailsResponse();
							ServiceStatus status = new ServiceStatus();
				        	status.setStatusCode("1");
				        	status.setStatusMessage("Service Response Error!");
				        	status.setSuccess(false);
				        	response.setStatus(status);
						}									
					}
				}	
				else {
					response = new RetrieveOrderDetailsResponse();
					ServiceStatus status = new ServiceStatus();
			    	status.setStatusCode("1");
			    	status.setStatusMessage("INVALID_ORDER");
			    	status.setSuccess(false);
			    	response.setStatus(status);
				}
			}
		}catch (Exception e) {
			LOGGER.error("Exception while calling retrieveOrderDetails service", e);
			respDetails = new ResponseDetails("SERVICE_CALL_EXCEPTION", "Exception in response method!");
			response = new RetrieveOrderDetailsResponse();
			ServiceStatus status = new ServiceStatus();
	    	status.setStatusCode("1");
	    	status.setStatusMessage("Service Exception!");
	    	status.setSuccess(false);
	    	response.setStatus(status);
		}
		finally
		{
			auditService.endTransaction(posRes, respDetails);
		}
		if(response == null) {
			response = new RetrieveOrderDetailsResponse();
			ServiceStatus status = new ServiceStatus();
	    	status.setStatusCode("1");
	    	status.setStatusMessage("Incorrect Request!");
	    	status.setSuccess(false);
	    	response.setStatus(status);
		}			
		return response;
	}		
	
	private void populateResponse(RetrieveOrderDetailsResponse response,
			com.vzw.mybiz.domain.pos.retrieveorder.POSServices posRes) {
		OrderDetails orderDetails = new OrderDetails();
		Map<String, Line> items = new HashMap<>();
		if( posRes.getServiceHeader().getOrderKeyInfo() != null) {
			OrderKeyInfo  orderKeyInfo  = posRes.getServiceHeader().getOrderKeyInfo();
			orderDetails.setClusterInfo(orderKeyInfo.getClusterInfo());
			orderDetails.setCreditApplicationNum(orderKeyInfo.getCreditApplicationNum());
			orderDetails.setLocation(orderKeyInfo.getLocation());
			orderDetails.setOrderNumber(orderKeyInfo.getOrderNum());
			orderDetails.setOutletId(orderKeyInfo.getOutletId());
			orderDetails.setSalesForceId(orderKeyInfo.getSalesForceId());
		}
		
		
		if(posRes.getServiceBody() != null && posRes.getServiceBody().getReadOrder() != null && posRes.getServiceBody().getReadOrder().getResponse() != null && 
				posRes.getServiceBody().getReadOrder().getResponse().getOrderDetails() != null) {
			ReadOrder.Response.OrderDetails orderDetailsPos = posRes.getServiceBody().getReadOrder().getResponse().getOrderDetails();
			if(orderDetailsPos.getPaymentDetails() != null) {
				orderDetails.setIsManagerWait(orderDetailsPos.getPaymentDetails().getIsManagerWait());
				orderDetails.setOrderDueTodayTotal(StringUtils.isNotBlank(orderDetailsPos.getPaymentDetails().getOrderTotal())? 
						Double.valueOf(orderDetailsPos.getPaymentDetails().getOrderTotal()):0);
				
			}
			
			if(orderDetailsPos.getCreditOrderDetails() != null && orderDetailsPos.getCreditOrderDetails().getBussCustomer() != null 
					&& orderDetailsPos.getCreditOrderDetails().getBussCustomer().getBussBillingAddress() != null) {
				BussBillingAddress  bbAddress  =orderDetailsPos.getCreditOrderDetails().getBussCustomer().getBussBillingAddress();
				BilingAddress address = new BilingAddress();
				address.setAptNum(bbAddress.getAptNum());
				address.setStreetNum(bbAddress.getStreetNum());
				address.setStreetName(bbAddress.getStreetName());
				address.setType(bbAddress.getType());
				address.setDir(bbAddress.getDir());
				address.setPobox(bbAddress.getPobox());
				address.setCity(bbAddress.getCity());
				address.setState(bbAddress.getState());
				address.setZipCode(bbAddress.getZipCode());
				address.setZipCode4(bbAddress.getZipCode4());
				address.setCountry(bbAddress.getCountry());
				response.setBilingAddress(address);
			}
			
			if(orderDetailsPos.getServiceLine() != null && orderDetailsPos.getServiceLine().size() > 0) {
				orderDetailsPos.getServiceLine().forEach(line->{
					if(line.getItemOrderDetails() != null) {
						orderDetails.setOrderType(line.getItemOrderDetails().getOrderType());
						Line lineObj = new Line();
						lineObj.setDueToday(StringUtils.isNotBlank(line.getItemOrderDetails().getOrderTotal())?
								Double.valueOf(line.getItemOrderDetails().getOrderTotal()):0);
						if(line.getItemOrderDetails().getShipping().getAddress() != null) {
							AddressType address = line.getItemOrderDetails().getShipping().getAddress();
							String ShippingAddress = address.getAptNum() + " " + address.getStreetNum() + " " + address.getStreetName() + " " + address.getType() + " " +
									address.getCity() + " "+ address.getState() + " " + address.getZipCode();
							lineObj.setShippingAddress(ShippingAddress);
						}	
						if(line.getItemOrderDetails().getItems() != null && line.getItemOrderDetails().getItems().getItem() != null ) {
							lineObj.setDeviceSkuDetails(line.getItemOrderDetails().getItems().getItem()
														.stream()
														.filter(item-> Double.valueOf(item.getItemPrice()) > 0  || (item.getItemCode() != null && item.getItemCode().contains("SHP")))
														.map(VipRestServiceImpl::mapItem)
														.collect(Collectors.toList()));
							if(lineObj.getDeviceSkuDetails() != null && lineObj.getDeviceSkuDetails().size() > 0) {
								double totalTax = lineObj.getDeviceSkuDetails().stream().mapToDouble(DeviceSkuDetails::getTax).sum();
								orderDetails.setTotalTax(orderDetails.getTotalTax() + totalTax);								
							}
						}
						if(line.getCustServiceOrderDetail() != null) {
							items.put(line.getCustServiceOrderDetail().getMobileIdNumber(), lineObj);
						}											
					}
				});
			}
		}		
		response.setOrderDetails(orderDetails);	
		response.setItems(items);
	}

	private static DeviceSkuDetails mapItem(ItemOrderItem item ) {
		DeviceSkuDetails itemObj = new DeviceSkuDetails();
		itemObj.setDescription(item.getDescription());
		itemObj.setDueToday(StringUtils.isNotBlank(item.getItemPrice()) ? Double.valueOf(item.getItemPrice()):0);
		itemObj.setItemCode(item.getItemCode());
		itemObj.setQuantity(item.getQty() != null ? item.getQty().intValue(): 1);
		if(StringUtils.isNotBlank(item.getTaxAmount())) {
			itemObj.setTax(Double.valueOf(item.getTaxAmount()) * itemObj.getQuantity());
		}		
		return itemObj;
	}


	private com.vzw.mybiz.domain.pos.retrieveorder.POSServices buildRetOrderRequest(RetrieveOrderDetailsRequest request) {
		com.vzw.mybiz.domain.pos.retrieveorder.ServiceHeader header = new com.vzw.mybiz.domain.pos.retrieveorder.ServiceHeader();		
		header.setUserName(cloudPropertiesConfig.getUserId());
		header.setPassword(cloudPropertiesConfig.getPassword());
		header.setClientAppName("MYBUSINESS");
		header.setClientAppUserName("MYBUSINESS");
		header.setServiceAction("retrieveOrderDetails");
		header.setServiceName("orderProcessingComposite");
		header.setTransactionId(request.getGon());
		header.setClientReferenceNumber(request.getGon());
		header.setResponseFormat("XML");		
		header.setEncryptionIndicator("T");
		try {
			Date date = new Date();				
		    XMLGregorianCalendar xmlDate ;
		    GregorianCalendar gc = new GregorianCalendar();
		    gc.setTime(date);
		    xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
			header.setTimeStamp(xmlDate.toString());
		} catch (DatatypeConfigurationException e) {
			LOGGER.error("Date validation failed. with exception {}", e);
		}		
		com.vzw.mybiz.domain.pos.retrieveorder.ServiceHeader.ClientOrderInfo orderInfo = new com.vzw.mybiz.domain.pos.retrieveorder.ServiceHeader.ClientOrderInfo();
		orderInfo.setChannelId("MB");
		orderInfo.setVendorId("MYBUSINESS");
		orderInfo.setClientOrderType("");
		header.setClientOrderInfo(orderInfo);	
		com.vzw.mybiz.domain.pos.retrieveorder.POSServices req = new com.vzw.mybiz.domain.pos.retrieveorder.POSServices();
		req.setServiceHeader(header);
		
		ServiceBody serviceBody = new ServiceBody();
		ReadOrder readOrder = new ReadOrder();
		ReadOrder.Request readOrderRequest = new ReadOrder.Request();
		readOrderRequest.setLocationCode(request.getLocationCode());
		if(StringUtils.isNotBlank(request.getOrderNum())) {
			String orderNum = request.getOrderNum();
			orderNum = orderNum.contains("MB") && orderNum.startsWith("MB") ? orderNum.split("MB")[1] : orderNum;
			readOrderRequest.setOrderNum(new BigInteger(orderNum));
		}
		else {
			readOrderRequest.setOrderNum(BigInteger.valueOf(0));
		}
		readOrderRequest.setRetrieveFraudStatus(Boolean.TRUE);
		readOrderRequest.setRetrieveDeviceRecycleInfo(Boolean.TRUE);
		readOrder.setRequest(readOrderRequest);
		serviceBody.setReadOrder(readOrder);
		req.setServiceBody(serviceBody);
		return req;		
	}
}
