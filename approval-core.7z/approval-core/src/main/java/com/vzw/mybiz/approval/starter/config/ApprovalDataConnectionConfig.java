package com.vzw.mybiz.approval.starter.config;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.vzw.mybiz.transformation.security.helpers.EncryptionHelper;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableConfigurationProperties(ApprovalDataSourceConfig.class)
@EnableJpaRepositories(basePackages = { "com.vzw.mybiz.approval.repo" }, entityManagerFactoryRef = "entityManager")
@EntityScan(basePackages = { "com.vzw.mybiz.approval.entity" })
public class ApprovalDataConnectionConfig {
	
	@Autowired
	EncryptionHelper encryptionHelper;

	@Autowired
	ApprovalDataSourceConfig dataSourceConfig;
	
	
	@Bean
	@Primary
	public DataSource dataSource() {
		HikariDataSource hikariDataSource = new HikariDataSource();
		hikariDataSource.setDriverClassName(dataSourceConfig.getDriverClassName());
		hikariDataSource.setJdbcUrl(dataSourceConfig.getUrl());
		hikariDataSource.setUsername(dataSourceConfig.getUserName());
		hikariDataSource.setPassword(encryptionHelper.voltageDecrypt(dataSourceConfig.getEncryptedPassword()));
		hikariDataSource.setMaximumPoolSize(dataSourceConfig.getHikari().getMaximumPoolSize());
		hikariDataSource.setPoolName(dataSourceConfig.getHikari().getPoolName());
		hikariDataSource.setMinimumIdle(dataSourceConfig.getHikari().getMinimumIdle());
		hikariDataSource.setAutoCommit(dataSourceConfig.getHikari().isAutoCommit());
		hikariDataSource.setMaxLifetime(dataSourceConfig.getHikari().getMaxLifetime());
		hikariDataSource.setConnectionTimeout(dataSourceConfig.getHikari().getConnectionTimeout());

		return hikariDataSource;
	}
	
	
	@Bean
	@Primary
    public LocalContainerEntityManagerFactoryBean entityManager() {
		
       LocalContainerEntityManagerFactoryBean em
         = new LocalContainerEntityManagerFactoryBean();
       em.setDataSource(dataSource());
       em.setPackagesToScan(
         new String[] { "com.vzw.mybiz.approval.entity" });

       HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
       em.setJpaVendorAdapter(vendorAdapter);
       em.setPersistenceUnitName("datasourcembtapp");
       HashMap<String, Object> properties = new HashMap<>();
       properties.put("hibernate.dialect","org.hibernate.dialect.Oracle12cDialect");
       em.setJpaPropertyMap(properties);

       return em;
   }
	
}
