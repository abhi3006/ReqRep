package com.vzw.mybiz.approval.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
@Entity
@Table(name = "EMAIL_AUDIT_SCHEDULE_LOG", schema = "COMMB2B")
public class EmailScheduleLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
	@SequenceGenerator(name = "seq_generator", sequenceName = "EMAIL_AUDIT_SCHEDULE_LOG_SEQ", schema = "COMMB2B", allocationSize = 1)
	@Column(name = "SCH_ID", updatable = false, nullable = false)
	private Long id;

	@Column(name = "SCH_STATUS", nullable = false)
	private String schStatus;
	// SCH_STATUS VARCHAR2 (15) NOT NULL,

	@Column(name = "SCH_SUB_STATUS", nullable = false)
	private String schSubStatus;
	// SCH_SUB_STATUS VARCHAR2 (15) NOT NULL,

	@Column(name = "OP_CENTER", nullable = false)
	private String opCenter;
	// OP_CENTER VARCHAR2 (10) NOT NULL,

	@Column(name = "SCR_CHANNEL", nullable = false)
	private String sourceChannel;
	// SCR_CHANNEL VARCHAR2 (10) NOT NULL,

	@Column(name = "SCH_MESSAGE")
	private String schProcessMessage;
	// SCH_MESSAGE VARCHAR2 (50) NOT NULL,

	@Column(name = "PROCESS_REC_COUNT")
	private int totalRecCount;
	// PROCESS_REC_COUNT NUMBER,

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;
	// CREATED_BY VARCHAR2 (50) NOT NULL,

	@Column(name = "CREATED_DT", nullable = false)
	private Date createdDate;
	// CREATED_DT TIMESTAMP (6)NOT NULL,

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;
	// MODIFIED_BY VARCHAR2 (50),

	@Column(name = "MODIFIED_DT", nullable = false)
	private Date modifiedDate;
	// MODIFIED_DT TIMESTAMP (6),
}
