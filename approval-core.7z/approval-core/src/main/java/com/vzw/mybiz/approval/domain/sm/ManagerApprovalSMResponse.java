package com.vzw.mybiz.approval.domain.sm;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.vzw.mybiz.approval.domain.sm.promotion.PromotionInfo;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ManagerApprovalSMResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private SMOrderResponse orderResponse;
	private String orderNumber;
	private String orderType;
	private ServiceStatus serviceStatus;
	private boolean isNextLevelApproval;
	private String level;
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public SMOrderResponse getOrderResponse() {
		return orderResponse;
	}
	public void setOrderResponse(SMOrderResponse orderResponse) {
		this.orderResponse = orderResponse;
	}
	public boolean isNextLevelApproval() {
		return isNextLevelApproval;
	}
	public void setNextLevelApproval(boolean isNextLevelApproval) {
		this.isNextLevelApproval = isNextLevelApproval;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}

}
