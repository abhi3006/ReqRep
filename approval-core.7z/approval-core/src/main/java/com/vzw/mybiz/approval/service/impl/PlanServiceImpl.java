package com.vzw.mybiz.approval.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vzw.mybiz.approval.data.bcc.entity.PlanMasterDetails;
import com.vzw.mybiz.approval.data.bcc.repo.PlanMasterDetailsRepo;
import com.vzw.mybiz.approval.service.PlanService;
import com.vzw.mybiz.prospect.domain.plan.PlanRequest;

@Service
public class PlanServiceImpl implements PlanService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PlanServiceImpl.class);

	@Autowired
	PlanMasterDetailsRepo planRepo;

	@Override
	public Map<String, List<PlanMasterDetails>> fetchDeviceCompatiblePlans(PlanRequest planReq) {
		LOGGER.info("Inside fetchDeviceCompatibleIndividualPlans of PlanServiceImpl");
		Map<String, List<PlanMasterDetails>> response= new HashMap<String, List<PlanMasterDetails>>();
		String marketId = "153";
		if (planReq!= null) {
			try{marketId = planRepo.fetchMarket(planReq.getAddress().getZipCode());}catch(Exception e){}
			
			String acctInd = "N";
			if ("AccountSharePlan".equalsIgnoreCase(planReq.getPlanCatagoryType())) {
				acctInd = "Y";
			}
			List<String> billingCds = planRepo.fetchBillingCds(planReq.getDeviceSku(), planReq.getSimSku(), acctInd);
			int limit = 700;
			int start = 1;
			LOGGER.info("billingCds--->"+billingCds.size());
			if (billingCds!=null && billingCds.size()>0) {
				List<PlanMasterDetails> plnMasterDtlsLst = null;
				int listSize=billingCds.size(), chunkSize=billingCds.size()%limit;
				List<List<String>> list2= null;
				list2 = splitList(listSize, chunkSize, billingCds);
				plnMasterDtlsLst = planRepo.fetchCompatiblePlans("N", "N", planReq.getEcpd(),
						marketId, list2.get(0),list2.get(1), list2.get(2), list2.get(3), list2.get(4), list2.get(5));
				organizeCompatiblePlans(response, plnMasterDtlsLst);
			}
			
			
			
		}
		
		LOGGER.info("Exit fetchDeviceCompatibleIndividualPlans of PlanServiceImpl");
		return response;
	}
	
	
	public List<List<String>> splitList(int listSize, int chunkSize, List<String> billingCds) {
		
		if (chunkSize > 0) {
			return IntStream.range(0, (listSize-1)/chunkSize+1)
		             .mapToObj(i->billingCds.subList(i*=chunkSize,
		                                       listSize-chunkSize>=i? i+chunkSize: listSize))
		             .collect(Collectors.toList());	
		}
		
		return null;
	}
	
	public void organizeCompatiblePlans(Map<String, List<PlanMasterDetails>> response, List<PlanMasterDetails> plnMasterDtlsLst) {
		LOGGER.info("Inside organizeCompatiblePlans of PlanServiceImpl");
		if (plnMasterDtlsLst!=null) {
			
			for (PlanMasterDetails planMasterDetails : plnMasterDtlsLst) {
				List<PlanMasterDetails> list = null;
				String key = planMasterDetails.getCategoryCode();
				if (response.containsKey(key)) {
					list = 	response.get(key);
				}
				if (list==null) {
					list = new ArrayList<PlanMasterDetails>();
				}
				list.add(planMasterDetails);
				response.put(key, list);
//				for (PlanMasterDetails planMasterDetail : plnMasterDtlsLst) {
//					if (key.equalsIgnoreCase(planMasterDetail.getCategoryCode())) {
//						if (response.containsKey(key)) {
//							list = 	response.get(key);
//						}
//						if (list==null) {
//							list = new ArrayList<PlanMasterDetails>();
//						}
//						list.add(planMasterDetail);
//						response.put(key, list);
//					}
//				}
				LOGGER.info("Current Key===>"+key);
				
			}	
		}
		
		
		
		LOGGER.info("Exit organizeCompatiblePlans of PlanServiceImpl");
	}

}
