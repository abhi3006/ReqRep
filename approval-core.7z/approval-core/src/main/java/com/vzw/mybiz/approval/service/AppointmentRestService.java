package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentDetail;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentRequest;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentResponse;

public interface AppointmentRestService {
	
	public AppointmentResponse saveAndSchedule(AppointmentDetail appointmentDetail);

	public StoreAppointmentResponse getStoreById(StoreAppointmentRequest request);

}
