package com.vzw.mybiz.approval.starter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "spring.datasourcembtapp")
public class ApprovalDataSourceConfig {

	private String driverClassName;

	private String url;

	private String userName;

	private String encryptedPassword;

	private final Hikari hikari = new Hikari();

	public Hikari getHikari() {
		return hikari;
	}

	public static class Hikari {
		private int minimumIdle;

		private int maximumPoolSize;

		private int idleTimeout;

		private String poolName;

		private boolean autoCommit;

		private int maxLifetime;

		private int connectionTimeout;

		public int getMinimumIdle() {
			return minimumIdle;
		}

		public void setMinimumIdle(int minimumIdle) {
			this.minimumIdle = minimumIdle;
		}

		public int getMaximumPoolSize() {
			return maximumPoolSize;
		}

		public void setMaximumPoolSize(int maximumPoolSize) {
			this.maximumPoolSize = maximumPoolSize;
		}

		public int getIdleTimeout() {
			return idleTimeout;
		}

		public void setIdleTimeout(int idleTimeout) {
			this.idleTimeout = idleTimeout;
		}

		public String getPoolName() {
			return poolName;
		}

		public void setPoolName(String poolName) {
			this.poolName = poolName;
		}

		public boolean isAutoCommit() {
			return autoCommit;
		}

		public void setAutoCommit(boolean autoCommit) {
			this.autoCommit = autoCommit;
		}

		public int getMaxLifetime() {
			return maxLifetime;
		}

		public void setMaxLifetime(int maxLifetime) {
			this.maxLifetime = maxLifetime;
		}

		public int getConnectionTimeout() {
			return connectionTimeout;
		}

		public void setConnectionTimeout(int connectionTimeout) {
			this.connectionTimeout = connectionTimeout;
		}

	}

	public String getDriverClassName() {
		return driverClassName;
	}

	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

}
