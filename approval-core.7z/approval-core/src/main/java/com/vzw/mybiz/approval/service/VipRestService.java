/**
 * 
 */
package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsRequest;
import com.vzw.mybiz.approval.domain.pos.retrieveorder.RetrieveOrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferReq;
import com.vzw.mybiz.approval.domain.sed.ComputeOfferUiRes;
import com.vzw.mybiz.approval.exception.VipFeignException;
import com.vzw.mybiz.prospect.domain.Root;
import com.vzw.mybiz.sharedcart.domain.pos.PosCartAddressType;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

/**
 * @author v142861
 *
 */
public interface VipRestService {
	
	public ServiceStatus submitProspectOrder(String cartString, Root cart) throws VipFeignException;
	
	public PosCartAddressType validateAddress(PosCartAddressType address) throws VipFeignException;
	
	public ComputeOfferUiRes computeOffer(ComputeOfferReq req);

	public RetrieveOrderDetailsResponse retrieveOrderDetails(RetrieveOrderDetailsRequest request);
	
}
