package com.vzw.mybiz.approval.service.impl;

import java.math.BigInteger;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;

import com.vzw.mybiz.approval.client.EtniClient;
import com.vzw.mybiz.approval.domain.ServiceStatusV1;
import com.vzw.mybiz.approval.service.NpaNxxService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.prospect.domain.etni.npanxx.Msgresponse;
import com.vzw.mybiz.prospect.domain.etni.npanxx.Msgresponse.Field;
import com.vzw.mybiz.prospect.domain.etni.npanxx.Msgresponse.Table;
import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxRequet;
import com.vzw.mybiz.prospect.domain.npanxx.NpaNxxResponse;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.Feign;
import feign.Logger.Level;
import feign.jaxb.JAXBContextFactory;
import feign.jaxb.JAXBDecoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;

@Service
public class NpaNxxServiceImpl implements NpaNxxService{

	private static final Logger LOGGER = LoggerFactory.getLogger(NpaNxxServiceImpl.class);
	
    private EtniClient etniClient;
	
	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;
	
	@Autowired
    private AuditService auditService;
	
//	@Autowired
//	private CommonFeignConfiguration feignConfiguration;
	
	@Override
	public NpaNxxResponse fetchNPANXX(NpaNxxRequet request) {
		LOGGER.info("Inside fetchNPANXX");
		Optional<Field> errorMsg = Optional.empty();
        String query = buildEtniQuery(request);
        Msgresponse msgRsp = null;
        try {
            URI uri = new URI(query);
           // beginTransaction(uri, "NPA-NXX");
            LOGGER.info("NpaNxxListByLocation uri :" + uri);
            
            etniClient =  Feign.builder().client(new OkHttpClient())
			.decoder(new JAXBDecoder(jaxBContextFactory()))
			//.options(feignConfiguration.options())
			.logger(new Slf4jLogger(EtniClient.class)).logLevel(Level.FULL)
			.target(EtniClient.class, cloudPropertiesConfig.getEtniHost());
            
            msgRsp =  etniClient.npanxxSearch(uri);
            LOGGER.info("msgRsp ---> :" + msgRsp);
            if(msgRsp != null ) {
                Optional<Field> errorCode = getFieldValue(msgRsp, "errorCode");
                LOGGER.info("if condition 1 ---> :" + msgRsp);
                errorMsg = getFieldValue(msgRsp, "errorMsg");
                LOGGER.info("if condition 2 ---> :" + msgRsp);
                if (errorCode.isPresent() && errorCode.get().getValue().equalsIgnoreCase("0")
                        && msgRsp.getTable() != null && msgRsp.getTable().getCount() > 0) {
                	LOGGER.info("if condition 3 ---> :" + msgRsp);
                    List<String> npaNxx = processEtniResponse(msgRsp.getTable());
                    LOGGER.info("if condition 4 -npaNxx--> :" + npaNxx);
                    if (npaNxx.size() > 0) {
                    	LOGGER.info("if condition 5 -npaNxx--> :" + npaNxx.size());
                        return NpaNxxResponse.builder().withNpaNxx(npaNxx).build();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("An error occurred with ETNI service" + e);
            return NpaNxxResponse.builder().withServiceStatus(buildEtniConnectionErr(e.getMessage())).build();
        } finally {
        //    endTransaction(msgRsp);
        }
        //throw new EtniServiceException("Etni service returned the error :" + getErrorMsg(errorMsg));
        return null;
		
	}
	
	private JAXBContextFactory jaxBContextFactory() {
		return new JAXBContextFactory.Builder()
				.withMarshallerJAXBEncoding("UTF-8")
				.build();
	}
	
	private ServiceStatusV1 buildEtniConnectionErr (String msg) {
        return ServiceStatusV1.builder()
                .withStatusCode("Failure")
                .withSuccess(false).withStatusMessage(msg).build();
    }
	
	 private void beginTransaction(URI uri, String subService) {
	        String url = cloudPropertiesConfig.getNpaNxx() +  uri.toString();
	        ExternalSys extSystem = new ExternalSys("ETNI", url);
	        extSystem.setService("ETNI");
	        extSystem.setSubService(subService);
	        auditService.beginTransaction(url, extSystem);
	    }

	    private void endTransaction(Msgresponse msgRsp) {
	        if(msgRsp != null) {
	            Optional<Field> errorCode = msgRsp.getField().stream().filter(x -> x.getName().equalsIgnoreCase("errorCode")).findAny();
	            Optional<Field> errorMsG = msgRsp.getField().stream().filter(x -> x.getName().equalsIgnoreCase("errorMsg")).findAny();
	            if(errorCode.isPresent() && errorMsG.isPresent()) {
	                auditService.endTransaction(msgRsp, new ResponseDetails(errorCode.get().getValue(), errorMsG.get().getValue()));
	            }
	        }
	    }
	
	private String buildEtniQuery(NpaNxxRequet request) {
		LOGGER.info("Inside buildEtniQuery");
        StringBuilder etniQuery = new StringBuilder(cloudPropertiesConfig.getNpaNxx());
        //search with zipcode if available
        if (StringUtils.isNotBlank(request.getAddress().getZipCode())) {
            etniQuery.append("&zip=");
            etniQuery.append(request.getAddress().getZipCode());
            LOGGER.info(etniQuery.toString());
            return etniQuery.toString();
        }
        //search with state and city if available
        if (StringUtils.isNotBlank(request.getAddress().getState()) && StringUtils.isNotBlank(request.getAddress().getCity())) {
            etniQuery.append("&state=");
            etniQuery.append(request.getAddress().getState());
            etniQuery.append("&city=");
            etniQuery.append(request.getAddress().getCity());
            return etniQuery.toString();
        }
        throw new IllegalArgumentException("Can't Perform npa/nxx search for a given request. One of these city/state or zipcode must be present: " + request);

    }
	
	private Optional<Field> getFieldValue(Msgresponse msgRsp, String key) {
		LOGGER.info("Inside getFieldValue");
        return msgRsp.getField().stream().filter(x -> x.getName().equalsIgnoreCase(key)).findAny();
    }
	
	private List<String> processEtniResponse(Table table) {

        Map<BigInteger, String> npaMap = new HashMap<>();
        Map<BigInteger, String> nxxMap = new HashMap<>();
        table.getRow().forEach(x -> {
            x.getField().forEach(y -> {
                if (y.getName().equalsIgnoreCase("npa")) {
                    npaMap.put(BigInteger.valueOf(x.getId()), y.getValue());
                }
                if (y.getName().equalsIgnoreCase("nxx")) {
                    nxxMap.put(BigInteger.valueOf(x.getId()), y.getValue());
                }
            });
        });
        Set<BigInteger> keys = npaMap.keySet();
        List<String> npanxxList = keys.stream()
                .filter(x -> npaMap.get(x) != null && nxxMap.get(x) != null)
                .map(x -> npaMap.get(x) + "-" + nxxMap.get(x))
                .collect(Collectors.toList());

        return npanxxList;
    }

	
	

}
