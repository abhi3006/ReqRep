package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonAutoDetect
@JsonIgnoreProperties(ignoreUnknown=true)
public class ManageApprovalMiscDto implements Serializable{
	
	@Override
	public String toString() {
		return "ManageApprovalMiscDto [manageAllOrders=" + manageAllOrders + ", manageDeviceType=" + manageDeviceType
				+ ", manageAccessoryCategory=" + manageAccessoryCategory + ", multiOrderEmailAccessory="
				+ multiOrderEmailAccessory + "]";
	}

	/**
	 * @author kab82bq
	 */
	private static final long serialVersionUID = 7906145189533181135L;
	private boolean manageAllOrders;
	private boolean manageDeviceType;
	private boolean manageAccessoryCategory;
	private String multiOrderEmailAccessory;

    public boolean isManageAllOrders() {
		return manageAllOrders;
	}

	public void setManageAllOrders(boolean manageAllOrders) {
		this.manageAllOrders = manageAllOrders;
	}

	public boolean isManageDeviceType() {
		return manageDeviceType;
	}

	public void setManageDeviceType(boolean manageDeviceType) {
		this.manageDeviceType = manageDeviceType;
	}

	public boolean isManageAccessoryCategory() {
		return manageAccessoryCategory;
	}

	public void setManageAccessoryCategory(boolean manageAccessoryCategory) {
		this.manageAccessoryCategory = manageAccessoryCategory;
	}

	public String getMultiOrderEmailAccessory() {
		return multiOrderEmailAccessory;
	}

	public void setMultiOrderEmailAccessory(String multiOrderEmailAccessory) {
		this.multiOrderEmailAccessory = multiOrderEmailAccessory;
	}

}
