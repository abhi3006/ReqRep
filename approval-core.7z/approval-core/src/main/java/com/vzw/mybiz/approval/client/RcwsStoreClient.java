package com.vzw.mybiz.approval.client;

import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Request;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Response;

import feign.Headers;
import feign.RequestLine;

public interface RcwsStoreClient {
	@RequestLine("POST /rcws/Process")
	@Headers({"Content-Type: text/xml"})
	@PostMapping()
	public Response getStore(Request storeRequest);

}
