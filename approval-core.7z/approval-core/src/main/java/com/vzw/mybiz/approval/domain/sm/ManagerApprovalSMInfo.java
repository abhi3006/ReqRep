package com.vzw.mybiz.approval.domain.sm;

import java.io.Serializable;
import java.util.List;

import com.vzw.mybiz.approval.domain.DgfFieldShortLookup;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;


public class ManagerApprovalSMInfo implements Serializable{


/* comments on business logic */
 /*
  *  l1 ecpd email + mba email(not mandatory for user to enter/he can skip) setVariableDisplayInUI/isRequired  (true/false) 
  *  l1 ecpd email + mba email(mandatory) setVariableDisplayInUI/isRequired  (true/true)
  *  l2 epcd '2' email + mba (mba customization appears - user input will be appended to l1 emails) setVariableDisplayInUI(false) 
  *  l2 ecpd '1' email + mba (required) setVariableDisplayInUI/isRequired (mandatory)
  *
  */
	/**
	 * 
	 * @author kab82bq 
	 */
	private static final long serialVersionUID = -1363868526301253210L;
	/**
	 * 
	 */
	
	private ServiceStatus serviceStatus;
	
	private List<String> approverEmails; // ecpd  emails
	private boolean isManagerApprovalEnabled; // ma enabled
	private boolean managerApprovalSuppress;
	private String prePopulateEmailID; // mba provided email 
	private boolean isRequired; // customization input property
	private boolean isReadonly; //customization input property
	private String userInputType; //customization input property
	private List<DgfFieldShortLookup> lookUp; //customization input property
	private List<String> emailDomainList; //customization input property
	private String level; // ecpd ma level(level 1 or level 2 )
	private String userSelectedEmail; 
	private boolean variableDisplayInUI; // helps UI to understand if mba inputs are needed to be mandated   
	
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public List<String> getEmailDomainList() {
		return emailDomainList;
	}

	public void setEmailDomainList(List<String> emailDomainList) {
		this.emailDomainList = emailDomainList;
	}

	public String getPrePopulateEmailID() {
		return prePopulateEmailID;
	}

	public void setPrePopulateEmailID(String prePopulateEmailID) {
		this.prePopulateEmailID = prePopulateEmailID;
	}

	public boolean isRequired() {
		return isRequired;
	}

	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}

	public boolean isReadonly() {
		return isReadonly;
	}

	public void setReadonly(boolean isReadonly) {
		this.isReadonly = isReadonly;
	}

	public String getUserInputType() {
		return userInputType;
	}

	public void setUserInputType(String userInputType) {
		this.userInputType = userInputType;
	}

	public List<DgfFieldShortLookup> getLookUp() {
		return lookUp;
	}

	public void setLookUp(List<DgfFieldShortLookup> lookUp) {
		this.lookUp = lookUp;
	}

	public List<String> getApproverEmails() {
		return approverEmails;
	}

	public void setApproverEmails(List<String> approvalEmails) {
		this.approverEmails = approvalEmails;
	}

	public boolean isManagerApprovalSuppress() {
		return managerApprovalSuppress;
	}

	public void setManagerApprovalSuppress(boolean managerApprovalSuppress) {
		this.managerApprovalSuppress = managerApprovalSuppress;
	}

	public boolean isManagerApprovalEnabled() {
		return isManagerApprovalEnabled;
	}

	public void setManagerApprovalEnabled(boolean isManagerApprovalEnabled) {
		this.isManagerApprovalEnabled = isManagerApprovalEnabled;
	}
	public String getUserSelectedEmail() {
		return userSelectedEmail;
	}
	public void setUserSelectedEmail(String userSelectedEmail) {
		this.userSelectedEmail = userSelectedEmail;
	}
	public boolean isVariableDisplayInUI() {
		return variableDisplayInUI;
	}
	public void setVariableDisplayInUI(boolean variableDisplayInUI) {
		this.variableDisplayInUI = variableDisplayInUI;
	}
	

}
