package com.vzw.mybiz.approval.service.impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vzw.mybiz.approval.client.AccessoryClient;
import com.vzw.mybiz.approval.client.SubmitClient;
import com.vzw.mybiz.approval.client.WfmCoreClient;
import com.vzw.mybiz.approval.client.WorkFlowClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.Credentials;
import com.vzw.mybiz.approval.domain.FailOverWfmRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.OrderMaster;
import com.vzw.mybiz.approval.domain.OrderTrackingRequest;
import com.vzw.mybiz.approval.domain.RecommendationRequest;
import com.vzw.mybiz.approval.domain.RecommendationResponse;
import com.vzw.mybiz.approval.domain.ServiceStatus;
import com.vzw.mybiz.approval.domain.SubmitCoreResponse;
import com.vzw.mybiz.approval.domain.UpdateRequest;
import com.vzw.mybiz.approval.entity.ManagerApprovalTracker;
import com.vzw.mybiz.approval.repo.ManagerApprovalRepo;
import com.vzw.mybiz.approval.service.ApprovalService;

@Component
public class ApprovalServiceImpl implements ApprovalService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApprovalServiceImpl.class);

	@Autowired
	private WorkFlowClient workFlowClient;

	@Autowired
	private SubmitClient submitClient;

	@Autowired
	private WfmCoreClient wfmClient;

	@Autowired
	private ManagerApprovalRepo managerApprovalRepo;
	
	@Autowired
	private Credentials credentials;
	
	@Autowired
	private AccessoryClient accessoryClient;
	
	private Map<String, Boolean> statusMap;
	
	@PostConstruct
	public void init(){
		statusMap = new HashMap<>();
		statusMap.put(Constants.URL_EXPIRED, false);
		statusMap.put(Constants.L1_APPROVED, false);
		statusMap.put(Constants.L1_REJECTED, false);
	}

	@Override
	public ManagerApprovalResponse getOrderInformation(ManagerApprovalRequest maRequest) {
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			credentials.setEncryptedText(maRequest.getCreds());
			Map<String, String> infoMap = decryptCreds(credentials);
			if (isValid(infoMap)) {
				String orderJson = retriveOrderJson(infoMap.get("orderId"));
				response.setOrderJson(orderJson);
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG));
			} else {
				if(statusMap.get(Constants.L1_APPROVED)){
					response.setServiceStatus(getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_APPROVED_MSG));
				}else if(statusMap.get(Constants.L1_REJECTED)){
					response.setServiceStatus(getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_REJECTED_MSG));
				}else if(statusMap.get(Constants.URL_EXPIRED)){
					processOrderCancellation(infoMap.get("orderId"));
					response.setServiceStatus(getServiceStatus(Constants.INVALID_CODE, Constants.URL_EXPIRY_MSG));
				}
			}
			response.setOrderNumber(infoMap.get("orderId"));
			response.setApproverAddress(infoMap.get("emailId"));
			response.setOrderType(infoMap.get("orderType"));
			

		} catch (Exception e) {
			LOGGER.error("Exception while retriving order information : {}" , e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		return response;
	}

	@Override
	public ManagerApprovalResponse makeApprovalCall(ManagerApprovalRequest maRequest) {
		LOGGER.info("Order Approval process started for: {} " , maRequest.getOrderNumber());
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			wfmClient.updateOrderConfirmationToWFM(
					buildUpdateReqeust(maRequest.getOrderNumber(), maRequest.getApproverAddress(), true));
			SubmitCoreResponse submitCoreResponse = submitClient.submitOrderToPos(maRequest.getOrderNumber());
			if (submitCoreResponse.getServiceStatus().getStatusCode().equalsIgnoreCase(Constants.SUCCESS_CODE)) {
				updateMAStatus(Constants.L1_APPROVED, maRequest.getOrderNumber(), maRequest.getApproverAddress());
				workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.SUCCESS_MSG, "NA",
						Constants.SUCCESS_CODE, Constants.MA_ORDER_SUBMISSION_SUCCESS_MSG));
				updateOrderMaster(maRequest.getOrderNumber(), Constants.ORDER_MASTER_STATUS_APPROVED);
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.APPROVAL_MSG));
			} else {
				workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.FAIL_STATUS, "NA",
						Constants.FAILURE_CODE, Constants.MA_ORDER_SUBMISSION_FAILURE_MSG));
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Order Approval process : {}" , e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
		}
		getRecommendations(maRequest, response);
		return response;
	}

	private void getRecommendations(ManagerApprovalRequest maRequest, ManagerApprovalResponse response) {
		try {
			RecommendationRequest recommendationRequest = new RecommendationRequest();
			recommendationRequest.setUserId(maRequest.getUserId());
			recommendationRequest.setEcpdId(maRequest.getEcpdId());
			recommendationRequest.setRecommendedSize(5);
			recommendationRequest.setSkuList(maRequest.getProductCodes());
			recommendationRequest.setCartList(maRequest.getProductCodes());
			LOGGER.info("Received product codes for recommendations :{}" , recommendationRequest.toString());
			RecommendationResponse recommendationResponse = accessoryClient.getRecommendations(recommendationRequest);
			response.setRecommendations(recommendationResponse);
		} catch (Exception e) {
			LOGGER.error("Exception received while calling recommendations : {}" , e.getMessage());
		}
	}

	private OrderTrackingRequest buildOPTRequest(String orderNumber, String status, String transactionId, String stepId,
			String message) {
		OrderTrackingRequest request = new OrderTrackingRequest();
		request.setSource(Constants.APPROVAL_CORE);
		request.setOrderNbr(orderNumber);
		request.setOptStatus(status);
		request.setOptTransactionId(transactionId);
		request.setOptStepId(stepId);
		request.setOptMessage(message);
		request.setServerInstance(Constants.APPROVAL_CORE);
		return request;

	}

	private FailOverWfmRequest buildFailToWfm(String orderNumber, String posStatus, String transactionId,
			String locationCode, String orderStatusReason, String orderStatus) {
		FailOverWfmRequest failoverRequest = new FailOverWfmRequest();
		failoverRequest.setGroupOrderNumber(transactionId);
		failoverRequest.setCustomerReferenceNumber(orderNumber);
		failoverRequest.setLocationCode(locationCode);
		failoverRequest.setAceOrder("0000");
		failoverRequest.setOrderStatus(orderStatus);
		failoverRequest.setOrderStatusReason(orderStatusReason);
		failoverRequest.setOrderSource(Constants.APPROVAL_CORE);
		failoverRequest.setOrderMessage(posStatus);
		return failoverRequest;
	}

	@Override
	public ManagerApprovalResponse makeRejectionCall(ManagerApprovalRequest maRequest) {
		LOGGER.info("Order Rejection process started for :{} " , maRequest.getOrderNumber());
		ManagerApprovalResponse response = new ManagerApprovalResponse();
		try {
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.REJECTION_MSG));
			workFlowClient.updateOptTracking(buildOPTRequest(maRequest.getOrderNumber(), Constants.SUCCESS_MSG, "NA",
					Constants.SUCCESS_CODE, Constants.MA_ORDER_SUBMISSION_REJECTED_MSG));
			updateMAStatus(Constants.L1_REJECTED, maRequest.getOrderNumber(), maRequest.getApproverAddress());
			updateOrderMaster(maRequest.getOrderNumber(), Constants.ORDER_MASTER_STATUS_REJECTED);
			wfmClient.updateOrderConfirmationToWFM(
					buildUpdateReqeust(maRequest.getOrderNumber(), maRequest.getApproverAddress(), false));
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS));
			LOGGER.error("Exception on Order Rejection process : {}" , e);
		}
		return response;
	}

	private UpdateRequest buildUpdateReqeust(String orderNumber, String approverAddress, boolean approvalStatus) {
		UpdateRequest updateReqeust = new UpdateRequest();
		updateReqeust.setApprovalStatus(approvalStatus);
		updateReqeust.setOrderNumber(orderNumber);
		updateReqeust.setApproverAddress(approverAddress);
		return updateReqeust;
	}

	private void updateOrderMaster(String orderNumber, String orderStatus) {
		LOGGER.info("::: Update to order master on approval/rejection cases");
		OrderMaster orderMasterData = new OrderMaster();
		orderMasterData.setOrderNbr(orderNumber);
		orderMasterData.setModifiedBy(Constants.APPROVAL_CORE);
		orderMasterData.setModifiedDt(new Date());
		orderMasterData.setOrderStatus(orderStatus);
		workFlowClient.updateOrderMaster(orderMasterData);
	}

	private void processOrderCancellation(String orderNumber) {
		LOGGER.info("Process order cancellation on URL Expired scenario : {}", orderNumber);
		updateOrderMaster(orderNumber, Constants.URL_EXPIRED);
		wfmClient.updateOrderStatusToWFM(buildFailToWfm(orderNumber, Constants.INVALID_CODE, "00", "00",
				Constants.URL_EXPIRY_MSG, Constants.CANCELLED));
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		return serviceStatus;
	}

	private boolean isValid(Map<String, String> infoMap) {
		String[] transactionStatus = {Constants.L1_APPROVED, Constants.L1_REJECTED};
		ManagerApprovalTracker managerApprovalTracker = managerApprovalRepo.findOneByOrderNumber(infoMap.get("orderId"));
		if(managerApprovalTracker!=null){
			String orderStatus = managerApprovalTracker.getStatus();
			if(Constants.URL_EXPIRED.equalsIgnoreCase(orderStatus) || isURLExpired(managerApprovalTracker)) {
				statusMap.put(Constants.URL_EXPIRED, true);
				return false;
			} 
			if(ArrayUtils.contains(transactionStatus, managerApprovalTracker.getStatus())){
				statusMap.put(Constants.L1_APPROVED, managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L1_APPROVED));
				statusMap.put(Constants.L1_REJECTED, managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L1_REJECTED));
				return false;
			}
			return true;
		}
		return false;
	}

	private boolean isURLExpired(ManagerApprovalTracker managerApprovalTracker) {
		Date orderCreatedDate = managerApprovalTracker.getCreatedDate();
		LOGGER.info("Order Created Date : {}" , orderCreatedDate);
		if (orderCreatedDate != null) {
			LocalDate createdDate = orderCreatedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LOGGER.info("Order Created Date :{}" , createdDate);
			LocalDate seventhDay = createdDate.plusWeeks(1L);
			LOGGER.info("seventh day of Order Created Date : {} ", seventhDay);
			LocalDate currentDate = LocalDate.now(ZoneId.systemDefault());
			int compareResult = currentDate.compareTo(seventhDay);
			LOGGER.info("Date comparision result : {}" , compareResult);
			if (compareResult < 0 || compareResult == 0) {
				return false;
			} else {
				return true;
			}
		}
		return true;
	}

	private String retriveOrderJson(String orderNumber) {
		LOGGER.info("Retrival of order json for order number : {}" , orderNumber);
		return workFlowClient.getOrderJson(orderNumber);
	}

	private Map<String, String> decryptCreds(Credentials creds) {
		Map<String, String> infoMap = new HashMap<String, String>();
		String decrptedCreds = creds.getDecryptedText();
		if (StringUtils.isNotEmpty(decrptedCreds)) {
			String[] decryptedValues = decrptedCreds.split("&");
			for (String parameter : decryptedValues) {
				String[] keyValues = parameter.split("=");
				LOGGER.info("Values Received :{} {} {} " , keyValues[0] , " = " , keyValues[1]);
				infoMap.put(keyValues[0].trim(), keyValues[1].trim());
			}
		}
		return infoMap;
	}

	private void updateMAStatus(String status, String orderNumber, String approvedBy) {
		managerApprovalRepo.updateMAStatusAndEmail(status, approvedBy, orderNumber);
	}

}