package com.vzw.mybiz.approval.exception;

public class StoreAppointmentException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public StoreAppointmentException(Exception exception) {
		super(exception);
	}

}
