package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
public class InventorySkuResponse extends InventorySkuDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private int availableQuantity;
	private int outofStockQuantity;
	private String contract;
	private String errorMessage;
}