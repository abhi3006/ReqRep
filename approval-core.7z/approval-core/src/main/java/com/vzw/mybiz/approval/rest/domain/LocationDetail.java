/**
 * 
 */
package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;

/**
 * @author nandbi6
 *
 */
public class LocationDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4221967844034759169L;
	private int currentInventoryLevel;
	private String locationCode;

	public int getCurrentInventoryLevel() {
		return currentInventoryLevel;
	}

	public void setCurrentInventoryLevel(int currentInventoryLevel) {
		this.currentInventoryLevel = currentInventoryLevel;
	}

	/**
	 * @return the locationCode
	 */
	public String getLocationCode() {
		return locationCode;
	}

	/**
	 * @param locationCode
	 *            the locationCode to set
	 */
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

}
