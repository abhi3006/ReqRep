package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vzw.mybiz.approval.domain.sm.onemessage.FinalNotificationRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitResponse;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name = "smtran-submit-core", configuration = CommonFeignConfiguration.class)
public interface SMTransactionSubmitClient {
		
	@RequestMapping(method = RequestMethod.POST, value = "mbt/smtran/submitMLMOTransaction", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionSubmitResponse submitTransactionARF(TransactionSubmitRequest request);
	
	@RequestMapping(method = RequestMethod.POST, value = "mbt/smtran/triggerNotification", consumes = MediaType.APPLICATION_JSON_VALUE)
	public TransactionSubmitResponse sendConfirmationEmail(FinalNotificationRequest confirmRequest);

}
