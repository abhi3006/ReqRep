package com.vzw.mybiz.approval.starter.config;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import com.vzw.mybiz.transformation.security.helpers.EncryptionHelper;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableConfigurationProperties(ApprovalDataSourceConfig.class)
@EnableJpaRepositories(basePackages = { "com.vzw.mybiz.approval.data.bcc.repo" }, entityManagerFactoryRef = "bccEntityManager")
@EntityScan(basePackages = { "com.vzw.mybiz.approval.bcc.entity" })
public class ApprovalBccDataConnectionConfig {
	
	@Autowired
	EncryptionHelper encryptionHelper;
	
	@Autowired
	ApprovalBccDataSourceConfig bccDataSourceConfig;
	
	
	@Bean
    public LocalContainerEntityManagerFactoryBean bccEntityManager() {
		
       LocalContainerEntityManagerFactoryBean em
         = new LocalContainerEntityManagerFactoryBean();
       em.setDataSource(bccDataSource());
       em.setPackagesToScan(
         new String[] { "com.vzw.mybiz.approval.data.bcc.entity" });

       HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
       em.setJpaVendorAdapter(vendorAdapter);
       em.setPersistenceUnitName("datasourcembtbatch");
       HashMap<String, Object> properties = new HashMap<>();
       properties.put("hibernate.dialect","org.hibernate.dialect.Oracle12cDialect");
       em.setJpaPropertyMap(properties);

       return em;
   }
	
	@Bean
	public DataSource bccDataSource() {
		HikariDataSource hikariDataSource = new HikariDataSource();
		hikariDataSource.setDriverClassName(bccDataSourceConfig.getDriverClassName());
		hikariDataSource.setJdbcUrl(bccDataSourceConfig.getUrl());
		hikariDataSource.setUsername(bccDataSourceConfig.getUserName());
		hikariDataSource.setPassword(encryptionHelper.voltageDecrypt(bccDataSourceConfig.getEncryptedPassword()));
		hikariDataSource.setMaximumPoolSize(bccDataSourceConfig.getHikari().getMaximumPoolSize());
		hikariDataSource.setPoolName(bccDataSourceConfig.getHikari().getPoolName());
		hikariDataSource.setMinimumIdle(bccDataSourceConfig.getHikari().getMinimumIdle());
		hikariDataSource.setAutoCommit(bccDataSourceConfig.getHikari().isAutoCommit());
		hikariDataSource.setMaxLifetime(bccDataSourceConfig.getHikari().getMaxLifetime());
		hikariDataSource.setConnectionTimeout(bccDataSourceConfig.getHikari().getConnectionTimeout());

		return hikariDataSource;
	}
	
}
