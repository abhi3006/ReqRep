package com.vzw.mybiz.approval.rest.domain;

public class SEDOfferResponse {

}
