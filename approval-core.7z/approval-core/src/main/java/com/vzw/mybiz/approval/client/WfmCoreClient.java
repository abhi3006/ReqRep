package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.FailOverWfmRequest;
import com.vzw.mybiz.approval.domain.UpdateRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;

@FeignClient(name="wfm-core", configuration = CommonFeignConfiguration.class)
public interface WfmCoreClient {

	@PostMapping("/mbt/wfm/updateWfmOrderStatus")
	public String updateOrderStatusToWFM(FailOverWfmRequest failOverWfmRequest);
	
	@PostMapping("/mbt/wfm/updateMaStatus")
	public String updateOrderConfirmationToWFM(UpdateRequest updateRequest);
	
	
	@PostMapping("/mbt/wfm/updateWfmOrderStatus")
	public String updateOrderStatusToWFMBatch(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,FailOverWfmRequest failOverWfmRequest);
	
	@PostMapping("/mbt/wfm/updateMaStatus")
	public String updateOrderConfirmationToWFMBatch(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode,UpdateRequest updateRequest);
}
