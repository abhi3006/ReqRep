package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPDFResponse;
import com.vzw.mybiz.approval.domain.sm.ma.cpc.OrderPdfRequest;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;



@FeignClient(name = "sm-cpc-composite", configuration = CommonFeignConfiguration.class)
public interface SmCpcClient {
		
	@RequestMapping(method = RequestMethod.POST, value = "mbt/cpc/generateOrderPdf", consumes = MediaType.APPLICATION_JSON_VALUE)
	public OrderPDFResponse generateOrderPdf(@RequestHeader("Am_ecpd_id") String ecpdId,@RequestHeader ("AM_UID") String loginUderId ,
			 @RequestHeader("CSR_ID") String csrid, OrderPdfRequest request);	
	
}
