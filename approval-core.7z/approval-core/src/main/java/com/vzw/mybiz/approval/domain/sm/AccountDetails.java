package com.vzw.mybiz.approval.domain.sm;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

/**
 * @author gulanso
 */

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String accountNumber;
	private Object oldData;
	private Object newData;
		
}
