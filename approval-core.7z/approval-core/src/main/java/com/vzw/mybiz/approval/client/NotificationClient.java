package com.vzw.mybiz.approval.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.Email;
import com.vzw.mybiz.approval.domain.sm.jms.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.sm.onemessage.ManagerRequest;
import com.vzw.mybiz.approval.domain.sm.onemessage.NotificationResponse;
import com.vzw.mybiz.security.overrides.CommonFeignConfiguration;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

@Component
@FeignClient(name = "notification-core", configuration = CommonFeignConfiguration.class )
public interface NotificationClient {
	
	
	@PostMapping(value = "/mbt/notify/manager", consumes = MediaType.APPLICATION_JSON_VALUE)
	public NotificationResponse sendMailToManger(@RequestBody ManagerRequest  oneMessageWrapper);
	
	
	@PostMapping(value = "/mbt/custom/sendCustomEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ServiceStatus sendCustomEmail(@RequestHeader(Constants.TRANSACTION_MODE_HEADER) String tranMode, @RequestBody Email  request);
	
	@PostMapping(value = "/mbt/custom/sendCustomEmail", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ServiceStatus sendCustomStoreAppointmentEmail(@RequestBody com.vzw.mybiz.approval.domain.storeAppointment.Email request);
	
	@PostMapping(value = "/mbt/jms/notify/manager", consumes = MediaType.APPLICATION_JSON_VALUE)
	public NotificationResponse sendMailToManagerUsingJMS(@RequestBody ManagerApprovalRequest  jmsWrapper);



}
