package com.vzw.mybiz.approval.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.vzw.mybiz.approval.domain.sm.ma.cpc.*;
import com.vzw.mybiz.approval.domain.sm.promotion.OrderLineItem;
import com.vzw.mybiz.approval.domain.sm.promotion.PDFPlanDetails;
import com.vzw.mybiz.approval.domain.sm.promotion.PromotionInfo;
import net.bytebuddy.matcher.FilterableList;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

import static com.vzw.mybiz.approval.constant.Constant.*;

public class GenerateCPCOrderDetailSM {

	private OrderDetailsResponse orderDetailsResponse;
	private static final Logger LOGGER = LoggerFactory.getLogger(GenerateCPCOrderDetailSM.class);

	public  void processCPCTransactionDetailForMA(OrderDetailsResponse orderDetailsResponse, SMOrderResponse smOrderResponse) {
		this.orderDetailsResponse = orderDetailsResponse;
		try {
			List<SystemTxnInfo> lineItems = orderDetailsResponse.getOrderDetailsList();
			Order order = null;
			if (lineItems != null && lineItems.size() > 0) {
				SystemTxnInfo lineItem = lineItems.get(0);
				order = new Order();
				order.setOrderLineItems(lineItems);
				order.setAccountNumber(lineItem.getAccountNumber());
				order.setEffectiveDate(orderDetailsResponse.getEffectiveDate());
				double addedMonthlyAccessFee = 0D;
				HashMap<String, Double> monthlyAccessFeeAddedPlanMap = new HashMap<String, Double>();
				HashMap<String, Double> monthlyAccessFeeDeletedPlanMap = new HashMap<String, Double>();
				for (SystemTxnInfo orderLineItem : order.getOrderLineItems()) {
					if (Constant.AUTOADD.equalsIgnoreCase(orderLineItem.getAction())
							&& Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(orderLineItem.getPlanGroup())) {
						monthlyAccessFeeAddedPlanMap.put(orderLineItem.getServiceNumber(),
								Double.valueOf(orderLineItem.getFinalPrice()));
						addedMonthlyAccessFee = addedMonthlyAccessFee + Double.valueOf(orderLineItem.getFinalPrice());
					} else if (Constant.AUTODELETE.equalsIgnoreCase(orderLineItem.getAction())
							&& Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(orderLineItem.getPlanGroup())) {

						monthlyAccessFeeDeletedPlanMap.put(orderLineItem.getServiceNumber(),
								Double.valueOf(orderLineItem.getFinalPrice()));
					}
				}
				if (monthlyAccessFeeAddedPlanMap.isEmpty()) {
					for (SystemTxnInfo orderLineItem : order.getOrderLineItems()) {
						if (Constant.DATA_CHANGE.equalsIgnoreCase(orderLineItem.getItemType())) {
							monthlyAccessFeeAddedPlanMap.put(orderLineItem.getServiceNumber(),
									Double.valueOf(orderLineItem.getPlanGroup().substring(16, 20)));
							monthlyAccessFeeDeletedPlanMap.put(orderLineItem.getServiceNumber(),
									Double.valueOf(orderLineItem.getPlanGroup().substring(16, 20)));
						}
					}
				}
				order = preparePlanInfo(order);
				order = prepareCurrentPlanInfo(order);
				order = prepareFeatureInfo(order);
				order = preparePromoInfo(order);

				List<PlanGroup> planGroupList = new ArrayList<PlanGroup>();

				double totalCurrentCost = 0;
				for (Map.Entry<String, CPCPlanDetails> entry : order.getPlans().entrySet()) {
					CPCPlanDetails cpcPlanDetails = entry.getValue();

					PlanGroup planGroup = new PlanGroup();
					PlanData planData = getPlanData(cpcPlanDetails, entry.getKey());
					List<MtnDetail> mtnList = planData.getMtnDetails();
					planGroup.setNewPlanInfo(planData);

					PlanData currentPlanData = getCurrentPlanData(order, cpcPlanDetails.getBillingCode(), mtnList);
					List<PlanData> currentPlanList = new ArrayList<PlanData>();
					currentPlanList.add(currentPlanData);
					planGroup.setCurrentPlanInfoList(currentPlanList);

					List<PromotionInfo> newPromoList = getPromoList(order,Constant.ADD,AUTOADD, mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setNewPromoList(newPromoList);

					List<PromotionInfo> removedPromoList = getPromoList(order, DELETE, AUTODELETE,mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setRemovedPromoList(removedPromoList);

					List<FeatureData> addFeatureList = getFeatureList(order, Constant.ADD, mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setAddFeatureList(addFeatureList);

					List<FeatureData> deleteFeatureList = getFeatureList(order, Constant.DELETE, mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setDeleteFeatureList(deleteFeatureList);

					List<FeatureData> autoAddFeatureList = getFeatureList(order, Constant.AUTOADD, mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setAutoAddFeatureList(autoAddFeatureList);
					double addFeatureTotal = getFeatureTotal(autoAddFeatureList);
					planGroup.setAddedFeatureTotal(addFeatureTotal);

					List<FeatureData> autoDeleteFeatureList = getFeatureList(order, Constant.AUTODELETE, mtnList,
							monthlyAccessFeeAddedPlanMap);
					planGroup.setAutoDeleteFeatureList(autoDeleteFeatureList);
					double deleteFeatureTotal = getFeatureTotal(autoDeleteFeatureList);
					planGroup.setDeletedFeatureTotal(deleteFeatureTotal);
					// newPlan total for shared
					if (cpcPlanDetails.isSharedPlan()) {
						double newPlanTotal = getNewplanTotalForShared(order, mtnList, true,
								monthlyAccessFeeAddedPlanMap);
						newPlanTotal = Math.floor(newPlanTotal * 100) / 100;
						planGroup.setNewPlanTotal(newPlanTotal);
					} else {
						double addFeaturePrice = getFeaturePrice(addFeatureList);
						double autoAddFeaturePrice = getFeaturePrice(autoAddFeatureList);
						double newPlanTotal = planData.getFinalMonthlyFee() * planData.getMtnDetails().size()
								+ addFeaturePrice + autoAddFeaturePrice;
						newPlanTotal = Math.floor(newPlanTotal * 100) / 100;
						planGroup.setNewPlanTotal(newPlanTotal);
					}
					// currentplan total for shared
					if (Constant.SHARED.equalsIgnoreCase(currentPlanData.getGroupType())) {
						double currentPlanTotal = getCurrentPlanTotalForShared(order, mtnList, true,
								monthlyAccessFeeDeletedPlanMap, currentPlanData);
						currentPlanTotal = Math.floor(currentPlanTotal * 100) / 100;
						planGroup.setCurrentPlanTotal(currentPlanTotal);
						// getting total current cost
						totalCurrentCost += currentPlanTotal;
					} else {

						double currentPlanTotal = currentPlanData.getFinalMonthlyFee()
								* currentPlanData.getMtnDetails().size();
						currentPlanTotal = Math.floor(currentPlanTotal * 100) / 100;
						planGroup.setCurrentPlanTotal(currentPlanTotal);
						// getting total current cost
						totalCurrentCost += currentPlanTotal;
					}
					planGroupList.add(planGroup);
				}
				CPCPlanAndFeatureDetails cpcPlanAndFeature = new CPCPlanAndFeatureDetails();
				cpcPlanAndFeature.setPlanGroupList(planGroupList);
				cpcPlanAndFeature.setAccountNumber(order.getAccountNumber());

				double estimatedCost = getEstimatedCost(order, monthlyAccessFeeAddedPlanMap,
						monthlyAccessFeeDeletedPlanMap);
				estimatedCost = Math.floor(estimatedCost * 100) / 100;
				cpcPlanAndFeature.setCostDifference(estimatedCost);

				double totalNewCost = getMonthlyCost(order, monthlyAccessFeeAddedPlanMap) - addedMonthlyAccessFee;
				totalNewCost = Math.floor(totalNewCost * 100) / 100;
				cpcPlanAndFeature.setTotalNewCost(totalNewCost);

				// double totalCurrentCost = getTotalCurrentCost(totalNewCost, estimatedCost);
				totalCurrentCost = Math.floor(totalCurrentCost * 100) / 100;
				cpcPlanAndFeature.setTotalCurrentCost(totalCurrentCost);
				smOrderResponse.setCpcPlanAndFeature(cpcPlanAndFeature);
				smOrderResponse.setConfirmationNumber(orderDetailsResponse.getConfirmationNumber());
				smOrderResponse.setEffectiveDate(orderDetailsResponse.getEffectiveDate());
				smOrderResponse.setEcpdId(orderDetailsResponse.getEcpdId());
				smOrderResponse.setLoginUserId(orderDetailsResponse.getLoggedInUserId());

				LOGGER.debug("SMOrderResponse in  GenerateCPCOrderDataSM is succeessful ");
			}
			generatePlanCostComprison(smOrderResponse);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM: ", e.getMessage());
		}
	}

	private List<PromotionInfo> getPromoList(Order order, String action,String autoAction, List<MtnDetail> mtnList, HashMap<String, Double> monthlyAccessFeeAddedPlanMap) {
		List<PromotionInfo> response = new ArrayList<>();
		PromotionInfo promoInfo = null;
			for (String planId : order.getPromos().keySet()) {
				CPCPlanDetails plan = order.getPromos().get(planId);
				if (null != plan && null != plan.getFeatureTypeLineItems()) {
					for (String promoType : plan.getFeatureTypeLineItems().keySet()) {
						if (promoType.equalsIgnoreCase(action) || promoType.equalsIgnoreCase(autoAction) ) {
							Map<String, List<SystemTxnInfo>> promoMap = plan.getFeatureTypeLineItems()
									.get(promoType);
							for (String promos : promoMap.keySet()) {
								promoInfo = new PromotionInfo();
								List<SystemTxnInfo> list = promoMap.get(promos);
								SystemTxnInfo item = list.get(0);
								promoInfo = buildPromoObject(item,mtnList,action);
								response.add(promoInfo);
							}
						}
					}
				}
			}
			return response;
	}

	private PromotionInfo buildPromoObject(SystemTxnInfo item, List<MtnDetail> mtnList, String action) {
		PromotionInfo promotionInfo = new PromotionInfo();
		promotionInfo.setMtnDetails(mtnList);
		promotionInfo.setPromoDollarAmountOff(item.getFinalPrice());
		promotionInfo.setPromoStatusCode(action);
		promotionInfo.setPromotionDescription(item.getItemName());
		return promotionInfo;
	}


	private void generatePlanCostComprison(SMOrderResponse smOrderResponse) {
		PlanCostComparison planCostComparison = new PlanCostComparison();
		List<PlanDetails> planDetailsList = new ArrayList<>();
		List<PlanGroup> planGroupList = smOrderResponse.getCpcPlanAndFeature().getPlanGroupList();

		planGroupList.forEach(planGroup -> {
			PlanDetails planDetails = new PlanDetails();

			if (planGroup.getCurrentPlanInfoList() != null && planGroup.getCurrentPlanInfoList().get(0) != null) {
				planDetails.setCurrentPlanName(planGroup.getCurrentPlanInfoList().get(0).getPlanDisplayName());
				planDetails.setCurrentPlanCost(planGroup.getCurrentPlanTotal());
				planDetails.setCurrentPlanType(planGroup.getCurrentPlanInfoList().get(0).getGroupType());

				if(planGroup.getCurrentPlanInfoList().get(0).getMtnDetails() != null) {
					int totalLines = planGroup.getCurrentPlanInfoList().get(0).getMtnDetails().size();
					planDetails.setCurrrentPlanLines(totalLines>1? String.valueOf(totalLines) + " Lines" : String.valueOf(totalLines) + " Line");
				}
			}

			if (planGroup.getNewPlanInfo() != null) {
				planDetails.setNewPlanCost(planGroup.getNewPlanTotal());
				planDetails.setNewPlanName(planGroup.getNewPlanInfo().getPlanDisplayName());
				planDetails.setNewPlanType(planGroup.getNewPlanInfo().getGroupType());

				if(planGroup.getNewPlanInfo().getMtnDetails() != null) {
					int totalNewLines = planGroup.getNewPlanInfo().getMtnDetails().size();
					planDetails.setNewPlanLines(totalNewLines + totalNewLines > 1? String.valueOf(totalNewLines) +" Lines" : String.valueOf(totalNewLines) +" Line");
				}
			}

			planDetails.setTotaladdedFeatures(createFeatureDetailsForCostComparison(planGroup.getAddFeatureList(),
					planGroup.getAutoAddFeatureList()));
			planDetails.setTotalRemovedFeartures(createFeatureDetailsForCostComparison(planGroup.getDeleteFeatureList
					(), planGroup.getAutoDeleteFeatureList()));


			planDetailsList.add(planDetails);
		});
		planCostComparison.setPlanDetailList(planDetailsList);
		smOrderResponse.getCpcPlanAndFeature().setPlanCostComparison(planCostComparison);
	}

	private List<FeatureDetails> createFeatureDetailsForCostComparison(List<FeatureData> featureDataList,
																	   List<FeatureData> autoAddedRemovedFeatureList) {
		List<FeatureDetails> featureDetailsList = new ArrayList<>();
		featureDataList.forEach(featureData -> {
			FeatureDetails featureDetails = new FeatureDetails();
			featureDetails.setFeatureName(featureData.getName());
			featureDetails.setCurrentPrice(featureData.getFeaturePrice());
			featureDetailsList.add(featureDetails);
		});

		autoAddedRemovedFeatureList.forEach(autoAddedRemovedFeature -> {
			FeatureDetails featureDetails = new FeatureDetails();
			featureDetails.setFeatureName(autoAddedRemovedFeature.getName());
			featureDetails.setNewPrice(autoAddedRemovedFeature.getFeaturePrice());
			featureDetailsList.add(featureDetails);
		});
		return featureDetailsList;
	}

	private double getNewplanTotalForShared(Order order, List<MtnDetail> mtnList, boolean sharedPlan,
			HashMap<String, Double> monthlyAccessFeeMap) throws Exception {
		double sharedPlanPrice = 0;
		try {
			sharedPlanPrice = getSharedPlanPrice(order);
			for (int i = 0; i < mtnList.size(); i++) {
				MtnDetail item = mtnList.get(i);
				String mdn = item.getMtn();
				double finalPrice = 0;
				if (sharedPlan) {
					if (monthlyAccessFeeMap.get(item.getMtn()) != null) {
						finalPrice = monthlyAccessFeeMap.get(item.getMtn());
						item.setLineAccessFee(String.valueOf(finalPrice));
					}
				}
				sharedPlanPrice += finalPrice;
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getNewplanTotalForShared(): ", e.getMessage());
		}
		return sharedPlanPrice;
	}

	private double getCurrentPlanTotalForShared(Order order, List<MtnDetail> mtnList, boolean sharedPlan,
			HashMap<String, Double> monthlyAccessFeeMap, PlanData currentPlanData) throws Exception {
		double sharedPlanPrice = 0;
		try {
			List<MtnDetail> newMtnList = new ArrayList<MtnDetail>();
			sharedPlanPrice = getCurrentSharedPlanPrice(order);
			for (int i = 0; i < mtnList.size(); i++) {
				MtnDetail item = mtnList.get(i);
				String mdn = item.getMtn();
				double finalPrice = 0;
				if (sharedPlan) {
					if (monthlyAccessFeeMap.get(item.getMtn()) != null) {
						finalPrice = monthlyAccessFeeMap.get(item.getMtn());
						MtnDetail mtnDetail = new MtnDetail();
						mtnDetail.setMtn(item.getMtn());
						mtnDetail.setEquipmentModel(item.getEquipmentModel());
						mtnDetail.setUserName(item.getUserName());
						mtnDetail.setLineAccessFee(String.valueOf(finalPrice));
						mtnDetail.setDeviceType(item.getDeviceType());
						newMtnList.add(mtnDetail);
					}
				}
				sharedPlanPrice += finalPrice;
			}
			currentPlanData.setMtnDetails(newMtnList);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getCurrentPlanTotalForShared(): ", e.getMessage());
		}
		return sharedPlanPrice;
	}

	private double getFeaturePrice(List<FeatureData> list) {
		double featurePrice = 0;
		try {
			for (FeatureData featureData : list) {
				if(!featureData.isNoBillImpact())
				{
					featurePrice += featureData.getFinalPrice();					
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getFeaturePrice(): ", e.getMessage());
		}
		return featurePrice;
	}

	private PlanData getPlanData(CPCPlanDetails cpcPlanDetails, String billingCode) {
		PlanData planData = null;
		try {
			List<SystemTxnInfo> list = cpcPlanDetails.getLineItems();
			SystemTxnInfo item = list.get(0);
			planData = new PlanData();
			planData.setFinalMonthlyFee(Double.valueOf(item.getFinalPrice()));
			planData.setMonthlyFee(Double.valueOf(formattedVisionMtn(item.getListPrice())));
			planData.setGroupType(cpcPlanDetails.getPlanGroup());
			planData.setMtnDetails(getMtnDetailsList(cpcPlanDetails.getLineItems()));
			planData.setTwoYearBillingCode(billingCode);
			planData.setPlanDisplayName(cpcPlanDetails.getPlanName());
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getPlanData(): ", e.getMessage());
		}
		return planData;

	}

	private String formattedVisionMtn(String mtn) {
		mtn = StringUtils.trim(mtn);
		return mtn.replaceAll("[-|\\.|\\s()]?,", "");
	}

	private PlanData getCurrentPlanData(Order order, String billingCode, List<MtnDetail> mtnList) throws Exception {
		PlanData planData = new PlanData();
		try {
			List<PlanData> currentPlanList = new ArrayList<PlanData>();
			CPCPlanDetails cpcPlanDetails = null;
			for (Map.Entry<String, CPCPlanDetails> entry : order.getCurrentPlans().entrySet()) {
				cpcPlanDetails = entry.getValue();
				planData = getPlanData(cpcPlanDetails, entry.getKey());
				currentPlanList.add(planData);
			}

			List<SystemTxnInfo> list = cpcPlanDetails.getLineItems();

			List<SystemTxnInfo> filterList = new ArrayList<SystemTxnInfo>();
			for (MtnDetail detail : mtnList) {
				SystemTxnInfo result = list.stream().filter(x -> x.getServiceNumber().equals(detail.getMtn())).findAny()
						.orElse(null);
				if (result != null) {
					filterList.add(result);
				}
			}
			if (filterList.size() > 0) {
				SystemTxnInfo item = filterList.get(0);
				planData.setFinalMonthlyFee(Double.valueOf(item.getFinalPrice()));
				planData.setMonthlyFee(Double.valueOf(item.getListPrice()));
				planData.setGroupType(cpcPlanDetails.getPlanGroup());
				planData.setMtnDetails(getMtnDetailsList(filterList));
				planData.setTwoYearBillingCode(billingCode);
				planData.setPlanDisplayName(cpcPlanDetails.getPlanName());
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getCurrentPlanData(): ", e.getMessage());
		}
		return planData;
	}

	private List<FeatureData> getFeatureList(Order order, String feature, List<MtnDetail> mtnList,
			HashMap<String, Double> monthlyAccessFeeAddedPlanMap) throws Exception {
		List<FeatureData> featureList = new ArrayList<FeatureData>();
		try {
			List<SystemTxnInfo> filterList = new ArrayList<SystemTxnInfo>();
			double totalPrice = 0;
			Map<String, SystemTxnInfo> filterfeatureMap = new HashMap<String, SystemTxnInfo>();

			for (String planId : order.getFeatures().keySet()) {
				CPCPlanDetails plan = order.getFeatures().get(planId);
				if (null != plan && null != plan.getFeatureTypeLineItems()) {
					for (String featureType : plan.getFeatureTypeLineItems().keySet()) {
						if (featureType.equalsIgnoreCase(feature)) {
							FeatureData featureData = null;
							filterfeatureMap.clear();
							filterList.clear();
							Map<String, List<SystemTxnInfo>> featureMap = plan.getFeatureTypeLineItems()
									.get(featureType);
							for (String features : featureMap.keySet()) {
								List<SystemTxnInfo> list = featureMap.get(features);
								for (MtnDetail detail : mtnList) {
									if (!filterfeatureMap.containsKey(detail.getMtn())) {
										SystemTxnInfo result = list.stream()
												.filter(x -> x.getServiceNumber().equals(detail.getMtn())).findAny()
												.orElse(null);
										if (result != null) {
											filterList.add(result);
											filterfeatureMap.put(detail.getMtn(), result);
										}
									}
								}
							}
							featureData = getFeatureData(filterList);
							if (featureData != null) {
								boolean featureElegible = isFeatureEligible(filterList, plan.isSharedPlan(),
										monthlyAccessFeeAddedPlanMap, feature);
								if (featureElegible) {
									double price = 0;
									if (filterList.size() > 0) {
										if (filterList.get(0) != null && !Constant.ACCOUNT_LEVEL_FEATURE
												.equalsIgnoreCase(filterList.get(0).getPlanGroup())) {
											price += getTotalCost(filterList, plan.isSharedPlan(),
													monthlyAccessFeeAddedPlanMap);
										} else if (filterList.get(0) != null && Constant.ACCOUNT_LEVEL_FEATURE
												.equalsIgnoreCase(filterList.get(0).getPlanGroup())) {
											price = Double.parseDouble(filterList.get(0).getFinalPrice());
										}
									}
									featureData.setFinalPrice(price);
								}
								featureList.add(featureData);
							}

						}
					}
				}
			}

		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getFeatureList(): ", e.getMessage());
		}

		return featureList;
	}

	private double getTotalCost(List<SystemTxnInfo> list, boolean sharedPlan,
			HashMap<String, Double> monthlyAccessFeeMap) {
		double price = 0;
		try {
			if (!sharedPlan) {
				for (SystemTxnInfo lineItem : list) {
					if (lineItem.getFinalPrice() != null) {
						price = price + Double.parseDouble(lineItem.getFinalPrice());
					}
				}
			} else {
				for (SystemTxnInfo lineItem : list) {
					if (monthlyAccessFeeMap.get(lineItem.getServiceNumber()) != null) {
						price = price + monthlyAccessFeeMap.get(lineItem.getServiceNumber());
					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getTotalCost(): ", e.getMessage());
		}
		return price;
	}

	private double getFeatureTotal(List<FeatureData> list) {
		double featureTotal = 0;
		try {
			for (FeatureData featuredata : list) {
				featureTotal += featuredata.getFinalPrice();
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getFeatureTotal(): ", e.getMessage());
		}
		return featureTotal;
	}

	// new method for filtering autoadd features which has monthly access fee
	private boolean isFeatureEligible(List<SystemTxnInfo> lineItemsPerDevice, boolean sharedPlan,
			HashMap<String, Double> monthlyAccessFeeMap, String feature) {
		if (Constant.AUTOADD.equalsIgnoreCase(feature)) {
			for (int i = 0; i < lineItemsPerDevice.size(); i++) {
				SystemTxnInfo item = lineItemsPerDevice.get(i);
				if ("Monthly Access Fee".equalsIgnoreCase(item.getPlanGroup())) {
					return false;
				}
			}
		}
		return true;
	}

	private FeatureData getFeatureData(List<SystemTxnInfo> lineItems) throws Exception {
		FeatureData featureData = null;
		try {
			if (lineItems != null && lineItems.size() > 0) {
				SystemTxnInfo item = lineItems.get(0);
				if (item != null) {
					String itemName = (item.getItemName() == null) ? "" : item.getItemName();
					featureData = new FeatureData();
					featureData.setName(item.getItemName());
					featureData.setMtnDetails(getMtnDetailsList(lineItems));
					if(Constant.ACCOUNT_LEVEL_FEATURE_TRUE.equalsIgnoreCase(item.getPlanGroup()))
						featureData.setNoBillImpact(true);
					if (item.getFinalPrice() != null) {
						featureData.setFeaturePrice(Double.valueOf(item.getFinalPrice()));
						Double finalPrice = featureData.getMtnDetails().size() * featureData.getFeaturePrice();
						featureData.setFinalPrice(finalPrice);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getFeatureData(): ", e.getMessage());
		}
		return featureData;
	}

	private List<MtnDetail> getMtnDetailsList(List<SystemTxnInfo> lineItems) throws Exception {
		List<MtnDetail> mtnDetailList = new ArrayList<MtnDetail>();
		try {
			for (SystemTxnInfo info : lineItems) {
				MtnDetail mtnDetail = new MtnDetail();
				mtnDetail.setMtn(info.getServiceNumber());
				mtnDetail.setDeviceType(info.getPhoneType());
				mtnDetail.setUserName(info.getSubscriberName());
				mtnDetail.setLineAccessFee(info.getFinalPrice()); // need to check
				mtnDetailList.add(mtnDetail);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getMtnDetailsList(): ", e.getMessage());
		}
		return mtnDetailList;
	}

	private double getEstimatedCost(Order order, HashMap<String, Double> monthlyAccessAddPlanFeeMap,
			HashMap<String, Double> monthlyAccessDeletePlanFeeMap) throws IOException {
		double estimatedPrice = 0;
		try {
			double addPrice = 0;
			double newSharePlanPrice = 0;
			double oldSharePlanPrice = 0;
			double deletePrice = 0;
			if (order != null) {
				if (orderDetailsResponse != null) {
					List<SystemTxnInfo> list = orderDetailsResponse.getOrderDetailsList();
					for (SystemTxnInfo lineItem : list) {

						if (ACCOUNT_LEVEL_PLAN.equalsIgnoreCase(lineItem.getItemType())) {
							if (Constant.ADD.equalsIgnoreCase(lineItem.getAction())
									&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
								if (monthlyAccessAddPlanFeeMap.containsKey(lineItem.getServiceNumber())) {
									addPrice = addPrice + monthlyAccessAddPlanFeeMap.get(lineItem.getServiceNumber());
								}
								newSharePlanPrice = Double.parseDouble(lineItem.getFinalPrice());
							} else if (Constant.DELETE.equalsIgnoreCase(lineItem.getAction())
									&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
								if (monthlyAccessDeletePlanFeeMap.containsKey(lineItem.getServiceNumber())) {
									deletePrice = deletePrice
											+ monthlyAccessDeletePlanFeeMap.get(lineItem.getServiceNumber());
								}
								oldSharePlanPrice = Double.parseDouble(lineItem.getFinalPrice());
							}
						} else if (Constant.LLP.equalsIgnoreCase(lineItem.getItemType())) {
							if (Constant.ADD.equalsIgnoreCase(lineItem.getAction())) {
								addPrice = addPrice + Double.parseDouble(lineItem.getFinalPrice());
							} else if (Constant.AUTOADD.equalsIgnoreCase(lineItem.getAction())) {
								addPrice = addPrice + Double.parseDouble(lineItem.getFinalPrice());
							} else if (Constant.DELETE.equalsIgnoreCase(lineItem.getAction())) {
								deletePrice = deletePrice + Double.parseDouble(lineItem.getFinalPrice());
							} else if (Constant.AUTODELETE.equalsIgnoreCase(lineItem.getAction())) {
								deletePrice = deletePrice + Double.parseDouble(lineItem.getFinalPrice());
							}
						}

					}
				}
				double featureCost = getEstimatedCostForFeature();
				estimatedPrice = addPrice + newSharePlanPrice - deletePrice - oldSharePlanPrice + featureCost;
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getEstimatedCost(): ", e.getMessage());
		}
		return estimatedPrice;
	}

	private double getEstimatedCostForFeature() throws Exception {
		double featureCost = 0D;
		double deletePrice = 0D;
		double addPrice = 0D;
		try {
			Set<String> addedALFBillingCodeSet = new HashSet<>();
			Set<String> deletedALFBillingCodeSet = new HashSet<>();
			if (orderDetailsResponse != null) {
				List<SystemTxnInfo> list = orderDetailsResponse.getOrderDetailsList();
				for (SystemTxnInfo info : list) {
					if (FEATURES.equalsIgnoreCase(info.getDetailType())) {
						if (!Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(info.getPlanGroup())
								&& (Constant.ADD.equalsIgnoreCase(info.getAction())
										|| Constant.AUTOADD.equalsIgnoreCase(info.getAction()))) {
							if (Constant.ACCOUNT_LEVEL_FEATURE.equalsIgnoreCase(info.getPlanGroup())) {
								addPrice = addALFPrice(addPrice, addedALFBillingCodeSet, info);
							} else {
								if (info.getFinalPrice() != null && !Constant.ACCOUNT_LEVEL_FEATURE_TRUE.equalsIgnoreCase(info.getPlanGroup())) {
									featureCost = featureCost + Double.parseDouble(info.getFinalPrice());
								}
							}
						} else if (!Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(info.getPlanGroup())
								&& (Constant.AUTODELETE.equalsIgnoreCase(info.getAction())
										|| Constant.DELETE.equalsIgnoreCase(info.getAction()))) {
							if (Constant.ACCOUNT_LEVEL_FEATURE.equalsIgnoreCase(info.getPlanGroup())) {
								deletePrice = addALFPrice(deletePrice, deletedALFBillingCodeSet, info);
							} else {
								if (info.getFinalPrice() != null) {
									featureCost = featureCost - Double.parseDouble(info.getFinalPrice());
								}
							}
						}

					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getEstimatedCostForFeature(): ", e.getMessage());
		}
		return featureCost + addPrice - deletePrice;
	}

	private double addALFPrice(double price, Set<String> alpBillingCodeSet, SystemTxnInfo info) {
		if (!alpBillingCodeSet.contains(info.getBillingCode())) {
			alpBillingCodeSet.add(info.getBillingCode());
			price = price + Double.valueOf(info.getFinalPrice());
		}
		return price;
	}

	// monthly cost for plan
	private double getMonthlyCost(Order order, HashMap<String, Double> monthlyAccessFeeMap) throws Exception {
		double monthlyCost = 0;
		try {
			// monthly cost for smartphone ,tablet and other
			for (String planId : order.getPlans().keySet()) {
				CPCPlanDetails plan = order.getPlans().get(planId);
				if (null != plan && null != plan.getDeviceTypeLineItems()) {
					for (String deviceCategory : plan.getDeviceTypeLineItems().keySet()) {
						monthlyCost += getMonthlyTotalCost(plan.getDeviceTypeLineItems().get(deviceCategory),
								plan.isSharedPlan(), monthlyAccessFeeMap);
					}
				}
			}
			// monthly cost for features
			for (String planId : order.getFeatures().keySet()) {
				CPCPlanDetails plan = order.getFeatures().get(planId);
				if (null != plan && null != plan.getFeatureTypeLineItems()) {
					for (String featureType : plan.getFeatureTypeLineItems().keySet()) {
						Map<String, List<SystemTxnInfo>> featureMap = plan.getFeatureTypeLineItems().get(featureType);
						for (String feature : featureMap.keySet()) {
							List<SystemTxnInfo> list = featureMap.get(feature);
							if (list.get(0) != null
									&& Constant.ACCOUNT_LEVEL_FEATURE.equalsIgnoreCase(list.get(0).getPlanGroup())
									&& (Constant.AUTOADD.equalsIgnoreCase(list.get(0).getAction())
											|| Constant.ADD.equalsIgnoreCase(list.get(0).getAction()))) {
								monthlyCost += Double.valueOf(list.get(0).getFinalPrice());
							} else if(!Constant.ACCOUNT_LEVEL_FEATURE_TRUE.equalsIgnoreCase(list.get(0).getPlanGroup())){
								monthlyCost += getMonthlyTotalCost(list, plan.isSharedPlan(), monthlyAccessFeeMap);
							}
						}
					}
				}
			}
			monthlyCost += getSharedPlanPrice(order);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getMonthlyCost(): ", e.getMessage());
		}
		return monthlyCost;
	}

	private double getMonthlyTotalCost(List<SystemTxnInfo> list, boolean sharedPlan,
			HashMap<String, Double> monthlyAccessFeeMap) throws Exception {
		double price = 0;
		try {
			if (!sharedPlan) {
				for (SystemTxnInfo lineItem : list) {
					if (lineItem.getFinalPrice() != null) {
						if (Constant.AUTOADD.equalsIgnoreCase(lineItem.getAction())
								|| (Constant.ADD.equalsIgnoreCase(lineItem.getAction())))
							price = price + Double.parseDouble(lineItem.getFinalPrice());
					}
				}
			} else {
				for (SystemTxnInfo lineItem : list) {
					if (monthlyAccessFeeMap.get(lineItem.getServiceNumber()) != null) {
						if (Constant.AUTOADD.equalsIgnoreCase(lineItem.getAction())
								|| (Constant.ADD.equalsIgnoreCase(lineItem.getAction())))
							price = price + monthlyAccessFeeMap.get(lineItem.getServiceNumber());
					}
				}
			}

		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getMonthlyTotalCost(): ", e.getMessage());
		}
		return price;
	}

	private double getSharedPlanPrice(Order order) {
		double sharedPlanPrice = 0;
		try {
			for (String planId : order.getPlans().keySet()) {
				CPCPlanDetails plan = order.getPlans().get(planId);
				if (null != plan && null != plan.getDeviceTypeLineItems()) {
					for (String deviceCategory : plan.getDeviceTypeLineItems().keySet()) {
						if (plan.isSharedPlan()) {
							sharedPlanPrice = Double
									.valueOf(plan.getDeviceTypeLineItems().get(deviceCategory).get(0).getFinalPrice());
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getSharedPlanPrice(): ", e.getMessage());
		}
		return sharedPlanPrice;
	}

	private double getCurrentSharedPlanPrice(Order order) throws Exception {
		double sharedPlanPrice = 0;
		try {
			for (String planId : order.getCurrentPlans().keySet()) {
				CPCPlanDetails plan = order.getCurrentPlans().get(planId);
				if (null != plan && null != plan.getDeviceTypeLineItems()) {
					for (String deviceCategory : plan.getDeviceTypeLineItems().keySet()) {
						if (plan.isSharedPlan()) {
							sharedPlanPrice = Double
									.valueOf(plan.getDeviceTypeLineItems().get(deviceCategory).get(0).getFinalPrice());
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getCurrentSharedPlanPrice(): ", e.getMessage());
		}
		return sharedPlanPrice;
	}

	// prepare plan info
	private Order preparePlanInfo(Order order) throws Exception {
		try {
			if (null != orderDetailsResponse) {
				Map<String, CPCPlanDetails> plans = new HashMap<>();
				List<SystemTxnInfo> lineItems = orderDetailsResponse.getOrderDetailsList();
				for (SystemTxnInfo lineItem : lineItems) {
					if (Constant.ADD.equalsIgnoreCase(lineItem.getAction())
							&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
						String planGroup = lineItem.getPlanGroup();
						if (null != lineItem.getBillingCode() && !plans.containsKey(lineItem.getBillingCode())) {
							CPCPlanDetails planDetails = new CPCPlanDetails();
							boolean isShared = lineItem.getItemType().isEmpty() ? false
									: lineItem.getItemType().equalsIgnoreCase(ACCOUNT_LEVEL_PLAN);
							planDetails.setSharedPlan(isShared);
							planDetails.setPlanName(lineItem.getItemName());
							planDetails.setPlanGroup(planGroup);
							planDetails = mapLineItemsToDeviceType(order, lineItem.getBillingCode(), planDetails);
							planDetails = getMonthlyCostForPlan(planDetails);
							plans.put(lineItem.getBillingCode(), planDetails);
						}
					}
				}
				order.setPlans(plans);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM preparePlanInfo(): ", e.getMessage());
		}
		return order;
	}

	private Order prepareCurrentPlanInfo(Order order) throws Exception {
		try {
			if (null != orderDetailsResponse) {
				Map<String, CPCPlanDetails> plans = new HashMap<>();
				List<SystemTxnInfo> lineItems = orderDetailsResponse.getOrderDetailsList();
				for (SystemTxnInfo lineItem : lineItems) {
					if (Constant.DELETE.equalsIgnoreCase(lineItem.getAction())
							&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
						String planGroup = lineItem.getPlanGroup();
						if (null != lineItem.getBillingCode() && !plans.containsKey(lineItem.getBillingCode())) {
							CPCPlanDetails planDetails = new CPCPlanDetails();
							boolean isShared = lineItem.getItemType().isEmpty() ? false
									: lineItem.getItemType().equalsIgnoreCase(ACCOUNT_LEVEL_PLAN);
							planDetails.setSharedPlan(isShared);
							planDetails.setPlanName(lineItem.getItemName());
							planDetails.setPlanGroup(planGroup);
							planDetails = mapLineItemsToDeviceType(order, lineItem.getBillingCode(), planDetails);
							planDetails = getMonthlyCostForCurrentPlan(planDetails);
							plans.put(lineItem.getBillingCode(), planDetails);
						}
					}
				}
				order.setCurrentPlans(plans);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM prepareCurrentPlanInfo(): ", e.getMessage());
		}

		return order;
	}

	private CPCPlanDetails mapLineItemsToDeviceType(Order order, String planId, CPCPlanDetails plan) throws Exception {
		try {
			if (StringUtils.isNotBlank(planId)) {
				plan = getItemsForPlanAndDeviceType(order, planId, plan);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM mapLineItemsToDeviceType(): ", e.getMessage());
		}
		return plan;
	}

	private CPCPlanDetails getItemsForPlanAndDeviceType(Order order, String planId, CPCPlanDetails plan)
			throws Exception {
		try {
			List<SystemTxnInfo> lineItems = order.getOrderLineItems();
			Map<String, List<SystemTxnInfo>> deviceTypeLineItems = new HashMap<>();

			List<SystemTxnInfo> planLineItems = lineItems.stream().filter(lineItem -> {
				if (StringUtils.isNotBlank(lineItem.getBillingCode())) {
					return lineItem.getBillingCode().equalsIgnoreCase(planId);
				} else {
					return false;
				}
			}).collect(Collectors.toList());

			plan.setLineItems(planLineItems);

			for (SystemTxnInfo item : planLineItems) {
				String deviceCategory = StringUtils.isBlank(item.getPhoneType()) ? Constant.OTHER : item.getPhoneType();
				List<SystemTxnInfo> items = deviceTypeLineItems.getOrDefault(deviceCategory,
						new ArrayList<SystemTxnInfo>());
				items.add(item);
				deviceTypeLineItems.put(deviceCategory, items);

			}
			plan.setDeviceTypeLineItems(deviceTypeLineItems);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM mapLineItemsToDeviceType(): ", e.getMessage());
		}
		return plan;
	}

	private CPCPlanDetails getMonthlyCostForPlan(CPCPlanDetails plan) throws Exception {
		try {
			double planPrice = 0;
			for (SystemTxnInfo lineItem : plan.getLineItems()) {
				if (Constant.ADD.equalsIgnoreCase(lineItem.getAction())
						&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())
						&& Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(lineItem.getPlanGroup())) {
					planPrice += Double.parseDouble(lineItem.getFinalPrice());
				} else if (Constant.ADD.equalsIgnoreCase(lineItem.getAction())
						&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
					planPrice += Double.parseDouble(lineItem.getFinalPrice());
				}
			}
			plan.setTotalFinalPrice(planPrice);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getMonthlyCostForPlan(): ", e.getMessage());
		}
		return plan;
	}

	private CPCPlanDetails getMonthlyCostForCurrentPlan(CPCPlanDetails plan) throws Exception {
		try {
			double planPrice = 0;
			for (SystemTxnInfo lineItem : plan.getLineItems()) {
				if (Constant.DELETE.equalsIgnoreCase(lineItem.getAction())
						&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())
						&& Constant.MONTHLY_ACCESS_FEE.equalsIgnoreCase(lineItem.getPlanGroup())) {
					planPrice += Double.parseDouble(lineItem.getFinalPrice());
				} else if (Constant.DELETE.equalsIgnoreCase(lineItem.getAction())
						&& Constant.CALLING_PLAN.equalsIgnoreCase(lineItem.getDetailType())) {
					planPrice += Double.parseDouble(lineItem.getFinalPrice());
				}
			}
			plan.setTotalFinalPrice(planPrice);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM getMonthlyCostForCurrentPlan(): ", e.getMessage());
		}
		return plan;
	}

	// prepare feature info
	private Order prepareFeatureInfo(Order order) throws Exception {
		try {
			if (null != orderDetailsResponse) {
				Map<String, CPCPlanDetails> plans = new HashMap<>();
				List<SystemTxnInfo> lineItems = orderDetailsResponse.getOrderDetailsList();
				for (SystemTxnInfo lineItem : lineItems) {
					if (FEATURES.equalsIgnoreCase(lineItem.getDetailType())) {
						String planGroup = lineItem.getPlanGroup();
						if (null != lineItem.getBillingCode() && !plans.containsKey(lineItem.getBillingCode())) {
							CPCPlanDetails planDetails = new CPCPlanDetails();
							boolean isShared = lineItem.getItemType().isEmpty() ? false
									: lineItem.getItemType().equalsIgnoreCase(ACCOUNT_LEVEL_PLAN);
							planDetails.setSharedPlan(isShared);
							planDetails.setPlanName(lineItem.getItemName());
							planDetails.setPlanGroup(planGroup);
							planDetails = mapLineItemsToFeatureType(order, lineItem.getBillingCode(), planDetails,FEATURES);
							planDetails = getMonthlyCostForPlan(planDetails);
							plans.put(lineItem.getBillingCode(), planDetails);
						}
					}
				}
				order.setFeatures(plans);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM prepareFeatureInfo(): ", e.getMessage());
		}
		return order;
	}

	//prepare promo information
	private Order preparePromoInfo(Order order) throws Exception {
		if (null != orderDetailsResponse) {
			Map<String, CPCPlanDetails> plans = new HashMap<>();
			List<SystemTxnInfo> lineItems = orderDetailsResponse.getOrderDetailsList();
			for (SystemTxnInfo lineItem : lineItems) {
				if (Constant.PROMO.equalsIgnoreCase(lineItem.getDetailType())) {
					String planGroup = lineItem.getPlanGroup();
					if (null != lineItem.getBillingCode() && !plans.containsKey(lineItem.getBillingCode())) {
						CPCPlanDetails planDetails = new CPCPlanDetails();
						boolean isShared = lineItem.getItemType().isEmpty() ? false
								: lineItem.getItemType().equalsIgnoreCase(ACCOUNT_LEVEL_PLAN);
						planDetails.setSharedPlan(isShared);
						planDetails.setPlanName(lineItem.getItemName());
						planDetails.setPlanGroup(planGroup);
						planDetails = mapLineItemsToFeatureType(order, lineItem.getBillingCode(), planDetails,PROMO);
						planDetails = getMonthlyCostForPlan(planDetails);
						plans.put(lineItem.getBillingCode(), planDetails);
					}
				}
			}
			order.setPromos(plans);
		}
		return order;
	}


	// feature grouping
	private CPCPlanDetails mapLineItemsToFeatureType(Order order, String planId, CPCPlanDetails plan, String detailType) throws Exception {
		try {
			Map<String, Map<String, List<SystemTxnInfo>>> featureTypeLineItems = new HashMap<String, Map<String, List<SystemTxnInfo>>>();
			List<SystemTxnInfo> lineItems = order.getOrderLineItems();
			List<SystemTxnInfo> planLineItems = lineItems.stream().filter(lineItem -> {
				if (lineItem.getBillingCode() != null) {
					return lineItem.getBillingCode().equalsIgnoreCase(planId)
							&& FEATURES.equalsIgnoreCase(lineItem.getDetailType());
				}
				return false;
			}).collect(Collectors.toList());
			if(FEATURES.equalsIgnoreCase(detailType)){
				planLineItems = lineItems.stream().filter(lineItem -> {
					if (lineItem.getBillingCode() != null) {
						return lineItem.getBillingCode().equalsIgnoreCase(planId)
								&& FEATURES.equalsIgnoreCase(lineItem.getDetailType());
					}
					return false;
				}).collect(Collectors.toList());
			}else {
				planLineItems = lineItems.stream().filter(lineItem -> {
					if (lineItem.getBillingCode() != null) {
						return lineItem.getBillingCode().equalsIgnoreCase(planId)
								&& Constant.PROMO.equalsIgnoreCase(lineItem.getDetailType());
					}
					return false;
				}).collect(Collectors.toList());
			}


			plan.setLineItems(planLineItems);

			for (SystemTxnInfo item : planLineItems) {
				String itemName = StringUtils.isBlank(item.getItemName()) ? Constant.OTHER : item.getItemName();
				if (Constant.ADD.equalsIgnoreCase(item.getAction())) {

					Map<String, List<SystemTxnInfo>> map = featureTypeLineItems.getOrDefault(Constant.ADD,
							new HashMap<String, List<SystemTxnInfo>>());
					List<SystemTxnInfo> items = map.getOrDefault(itemName, new ArrayList<SystemTxnInfo>());
					items.add(item);
					map.put(itemName, items);
					featureTypeLineItems.put(Constant.ADD, map);
				} else if (Constant.DELETE.equalsIgnoreCase(item.getAction())) {
					Map<String, List<SystemTxnInfo>> map = featureTypeLineItems.getOrDefault(Constant.DELETE,
							new HashMap<String, List<SystemTxnInfo>>());

					List<SystemTxnInfo> items = map.getOrDefault(itemName, new ArrayList<SystemTxnInfo>());
					items.add(item);
					map.put(itemName, items);
					featureTypeLineItems.put(Constant.DELETE, map);
				} else if (Constant.AUTOADD.equalsIgnoreCase(item.getAction())) {
					Map<String, List<SystemTxnInfo>> map = featureTypeLineItems.getOrDefault(Constant.AUTOADD,
							new HashMap<String, List<SystemTxnInfo>>());

					List<SystemTxnInfo> items = map.getOrDefault(itemName, new ArrayList<SystemTxnInfo>());
					items.add(item);
					map.put(itemName, items);
					featureTypeLineItems.put(Constant.AUTOADD, map);
				} else if (Constant.AUTODELETE.equalsIgnoreCase(item.getAction())) {
					Map<String, List<SystemTxnInfo>> map = featureTypeLineItems.getOrDefault(Constant.AUTODELETE,
							new HashMap<String, List<SystemTxnInfo>>());

					List<SystemTxnInfo> items = map.getOrDefault(itemName, new ArrayList<SystemTxnInfo>());
					items.add(item);
					map.put(itemName, items);
					featureTypeLineItems.put(Constant.AUTODELETE, map);
				}
			}
			plan.setFeatureTypeLineItems(featureTypeLineItems);
		} catch (Exception e) {
			LOGGER.debug("Exception in GenerateCPCOrderDataSM mapLineItemsToFeatureType(): ", e.getMessage());
		}
		return plan;
	}

}
