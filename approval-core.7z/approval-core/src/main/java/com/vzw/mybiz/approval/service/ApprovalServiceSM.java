package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.sm.ManagerApprovalAccountLevelResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMResponse;

public interface ApprovalServiceSM {

	public ManagerApprovalSMResponse getSMInformation(ManagerApprovalSMRequest maRequest);

	public ManagerApprovalSMResponse makeApprovalCall(ManagerApprovalSMRequest maRequest);

	public ManagerApprovalSMResponse makeRejectionCall(ManagerApprovalSMRequest maRequest,boolean triggerOneMessage);

	public ManagerApprovalAccountLevelResponse getAccountLevelSMInformation(ManagerApprovalSMRequest maRequest);
	
}