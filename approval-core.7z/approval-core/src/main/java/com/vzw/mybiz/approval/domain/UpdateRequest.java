package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class UpdateRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String orderNumber;
	private boolean approvalStatus;
	private String approverAddress;

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public boolean isApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(boolean approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getApproverAddress() {
		return approverAddress;
	}

	public void setApproverAddress(String approverAddress) {
		this.approverAddress = approverAddress;
	}

}
