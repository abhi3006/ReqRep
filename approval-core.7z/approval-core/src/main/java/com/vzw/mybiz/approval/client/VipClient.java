package com.vzw.mybiz.approval.client;

import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.exception.VipFeignException;
import com.vzw.mybiz.prospect.domain.pos.POSServices;

import feign.Headers;
import feign.RequestLine;

public interface VipClient {

	@RequestLine("POST /eai/netace/POSWSAdapter")
	@Headers("Content-Type: text/xml")
	public String submitOrder(POSServices posOrder) throws VipFeignException;
	
	@RequestLine("POST /eai/netace/POSWSAdapter?xmlreqdoc=")
	@Headers({"Content-Type: text/xml", "auditType: B"})
	public com.vzw.mybiz.approval.domain.jaxb.POSServices validateAddress(com.vzw.mybiz.approval.domain.jaxb.POSServices posAddressRequest);
	
	@RequestLine("POST /eai/netace/POSWSAdapter")
	@Headers({"Content-Type: text/xml", "auditType: B"})
	@PostMapping("/eai/netace/POSWSAdapter")		
	public com.vzw.mybiz.prospect.domain.sed.vip.POSServices offerManagement(com.vzw.mybiz.prospect.domain.sed.vip.POSServices pOSServices);

	@RequestLine("POST /eai/netace/POSWSAdapter")
	@Headers({"Content-Type: text/xml", "auditType: B"})
	@PostMapping("/eai/netace/POSWSAdapter")		
	public com.vzw.mybiz.domain.pos.retrieveorder.POSServices retrieveOrder(com.vzw.mybiz.domain.pos.retrieveorder.POSServices pOSServices);

	
}
