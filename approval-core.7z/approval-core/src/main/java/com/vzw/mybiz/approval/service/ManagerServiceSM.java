package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.domain.ManagerApprovalData;
import com.vzw.mybiz.approval.domain.ManagerApprovalInfo;
import com.vzw.mybiz.approval.domain.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.ManagerApprovalResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMInfo;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;

public interface ManagerServiceSM {

	public ManagerApprovalSMInfo getManagerApprovalSMInfo(ManagerApprovalSMRequest maAmRequest);

}
