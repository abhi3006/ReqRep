package com.vzw.mybiz.approval.domain.sm.onemessage;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FinalNotificationRequest {

	private String confirmNbr;
	private String status; 

	public String getConfirmNbr() {
		return confirmNbr;
	}

	public void setConfirmNbr(String confirmNbr) {
		this.confirmNbr = confirmNbr;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
