package com.vzw.mybiz.approval.service.impl;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.vzw.mybiz.approval.data.bcc.entity.PhoneMasterDetails;
import com.vzw.mybiz.approval.data.bcc.repo.PhoneMasterDetailsRepo;
import com.vzw.mybiz.approval.domain.accessory.AccessoryGridwallResponse;
import com.vzw.mybiz.approval.domain.devices.DeviceDetails;
import com.vzw.mybiz.approval.domain.devices.DeviceSkuDetails;

@Service
public class DeviceServiceImpl {

	@Autowired
	PhoneMasterDetailsRepo phoneMasterDetailsRepo;
	
	public List<DeviceDetails> getDeviceInformation() {
		
		List<DeviceDetails> deviceList = new LinkedList<>();
		
		List<PhoneMasterDetails> phones = phoneMasterDetailsRepo.getPhoneMasterDetails();
		if(CollectionUtils.isNotEmpty(phones)) {
			Map<String, List<PhoneMasterDetails>> parentMapping = phones.stream()
                    .collect(Collectors.groupingBy(PhoneMasterDetails::getDeviceId));
			
			parentMapping.forEach((deviceId, phoneDetails) -> {
				
				DeviceDetails device = new DeviceDetails();
				
				PhoneMasterDetails details = phoneDetails.get(0);				
				device.setBrandName(details.getBrandName());
				device.setCategory(details.getCategory());
				device.setDeviceId(deviceId);
				device.setName(details.getDisplayProductName());
				
				phoneDetails.stream().map(detail -> {
					DeviceSkuDetails sku = new DeviceSkuDetails();
					sku.setSimSku(detail.getSimSku());
					sku.setSku(detail.getSku());
					sku.setCapacity(detail.getCapacity());
					sku.setColor(detail.getColor());
					sku.setCssColor(detail.getCssColor());
					sku.setPhoneId(detail.getPhoneId());
					sku.setImageSet(detail.getImageSet());
					sku.setCriticalInventoryLevel(detail.getCriticalInventoryLevel() != null ? detail.getCriticalInventoryLevel() : 0);
					sku.setRetailPrice(detail.getRetailPrice() != null ? detail.getRetailPrice() : 0F);
					return sku;
				}).collect(Collectors.toCollection(() -> device.getSkulist()));
				
				deviceList.add(device);
				
			});
			
		}
		
		return deviceList;
		
	}
	
	public AccessoryGridwallResponse getAccessoryInformation() throws IOException {
		String data = IOUtils.toString(getClass().getClassLoader().getResource("accessoryJson.json"));
		Gson gson = new Gson();
		AccessoryGridwallResponse response = gson.fromJson(data, AccessoryGridwallResponse.class);
		return response;
	}
	
}
