package com.vzw.mybiz.approval.rest.domain;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
public class SAPInventoryRequest implements Serializable {

	private static final long serialVersionUID = -6127149834580428255L;
	
	private String ecpdId;
	private String userId;
	private String requestedSource;
	private String locationCode;
	private String ispuLocation;
	private String storeSaleIndicator;
	List<InventorySkuDetails> inventorySkuDetails;
}
