package com.vzw.mybiz.approval.client;

import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckRequest;
import com.vzw.mybiz.approval.jaxb.domain.sap.AtpCheckResponse;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

public interface SAPCoreClient {
	
	@RequestLine("POST /sig/rest/atpCheck?xmlreqdoc=")
	@Headers("Content-Type: text/xml")
	public AtpCheckResponse getRealTimeInventoryStatus(AtpCheckRequest request);
	
	
}
