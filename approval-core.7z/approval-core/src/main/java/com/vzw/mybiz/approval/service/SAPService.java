package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.approval.rest.domain.SAPInventoryRequest;
import com.vzw.mybiz.approval.rest.domain.SAPInventoryResponse;

public interface SAPService {
	
	public SAPInventoryResponse getRealTimeInventoryStatus(SAPInventoryRequest request);
}
