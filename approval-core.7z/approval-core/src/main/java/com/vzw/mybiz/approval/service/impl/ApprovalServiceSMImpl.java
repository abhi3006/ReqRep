package com.vzw.mybiz.approval.service.impl;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.vzw.mybiz.approval.client.NotificationClient;
import com.vzw.mybiz.approval.client.SMSubmitCompositeClient;
import com.vzw.mybiz.approval.client.SMTransactionSubmitClient;
import com.vzw.mybiz.approval.client.TransHistoryCoreClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.Credentials;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalAccountLevelResponse;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMRequest;
import com.vzw.mybiz.approval.domain.sm.ManagerApprovalSMResponse;
import com.vzw.mybiz.approval.domain.sm.SMAccountLevelOrderResponse;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.jms.ManagerApprovalRequest;
import com.vzw.mybiz.approval.domain.sm.onemessage.FinalNotificationRequest;
import com.vzw.mybiz.approval.domain.sm.onemessage.ManagerRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitRequest;
import com.vzw.mybiz.approval.domain.sm.submit.TransactionSubmitResponse;
import com.vzw.mybiz.approval.domain.sm.submit.composite.SMSubmitTransactionRequest;
import com.vzw.mybiz.approval.domain.sm.submit.composite.SubmitAccountLevelTransactionRequest;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsRequest;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;
import com.vzw.mybiz.approval.domain.sm.transorder.UpdateTransactionHistoryRequest;
import com.vzw.mybiz.approval.entity.ManagerApprovalSMTracker;
import com.vzw.mybiz.approval.repo.ManagerApprovalSMRepo;
import com.vzw.mybiz.approval.service.ApprovalServiceSM;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.approval.util.GenerateCPCOrderDetailSM;
import com.vzw.mybiz.approval.util.GenerateCWUIOrderDetailSM;
import com.vzw.mybiz.approval.util.GenerateOrderDataSM;
import com.vzw.mybiz.approval.util.ManagerApprovalSMOrderDetails;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

@Component
public class ApprovalServiceSMImpl implements ApprovalServiceSM {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApprovalServiceSMImpl.class);

	@Value("${global.ui.mbthosturl}")
	private String mbtHostUrl;

	@Autowired
	private ManagerApprovalSMRepo managerApprovalSMRepo;

	@Autowired
	private TransHistoryCoreClient transHistoryCoreClient;

	@Autowired
	private Credentials credentials;

	@Autowired
	private SMTransactionSubmitClient smTransactionSubmitClient;

	@Autowired
	private SMSubmitCompositeClient smSubmitCompositeClient;
	
	@Autowired
	private NotificationClient notificationClient;

	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;

	private Map<String, Boolean> statusMap;
	private Map<String, String> levelMap;

	@PostConstruct
	public void init() {
		statusMap = new HashMap<>();
		levelMap = new HashMap<>();
		levelMap.put("1_R", "L1REJECTED");
		levelMap.put("2_R", "L2REJECTED");
		levelMap.put("1_A", "L1APPROVED");
		levelMap.put("2_A", "L2APPROVED");
		levelMap.put("2_P", "L2PENDING");
		levelMap.put("0_R", "EXPIRED");
	}

	@Override
	public ManagerApprovalSMResponse getSMInformation(ManagerApprovalSMRequest maRequest) {
		ManagerApprovalSMResponse response = new ManagerApprovalSMResponse();
		try {		
			credentials.setEncryptedText(maRequest.getCreds());
			Map<String, String> infoMap = decryptCreds(credentials);
			statusMap.put(Constants.URL_EXPIRED_AM, false);
			statusMap.put(Constants.L1_APPROVED, false);
			statusMap.put(Constants.L1_REJECTED, false);
			statusMap.put(Constants.L2_REJECTED, false);
			statusMap.put(Constants.L2_APPROVED, false);
			if (isValid(infoMap)) {
				transLevelOrderDetails(response, infoMap);
			} else {
				LOGGER.info("the transaction return valid as false, statusMap is {} " ,statusMap);
				if (statusMap.keySet().stream().filter(item -> item.endsWith("APPROVED"))
						.filter(item -> statusMap.get(item) == true).count() > 0) {
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_APPROVED_MSG, false));
					LOGGER.info("the transaction has already been approved");
				} else if (statusMap.keySet().stream().filter(item -> item.endsWith("REJECTED"))
						.filter(item -> statusMap.get(item) == true).count() > 0) {
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_REJECTED_MSG, false));
					LOGGER.info("the transaction has been rejected");
				} else if (statusMap.get(Constants.URL_EXPIRED_AM)) {
					// process MA and trans table update
					maRequest.setLevel("0");
					maRequest.setOrderNumber(infoMap.get("orderId"));
					makeRejectionCall(maRequest, false);
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.URL_EXPIRY_MSG, false));
					LOGGER.info("the transaction has expired");
				}
			}
			response.setLevel(infoMap.get("level"));
			response.setOrderNumber(infoMap.get("orderId"));
			response.setOrderType(infoMap.get("transactionType"));
		} catch (Exception e) {
			LOGGER.error("Exception while retriving order information : {}" , e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
		}
		return response;
	}
	
	/**
	 * <p>
	 * This method is used to get transaction details to be displayed
	 * on manager approval landing page for account level transactions
	 * </p>
	 * 
	 * @param ManagerApprovalSMRequest
	 * @return ManagerApprovalAccountLevelResponse
	 */
	@Override
	public ManagerApprovalAccountLevelResponse getAccountLevelSMInformation(ManagerApprovalSMRequest maRequest) {
		ManagerApprovalAccountLevelResponse response = new ManagerApprovalAccountLevelResponse();
		try {		
			credentials.setEncryptedText(maRequest.getCreds());
			Map<String, String> infoMap = decryptCreds(credentials);
			statusMap.put(Constants.URL_EXPIRED_AM, false);
			statusMap.put(Constants.L1_APPROVED, false);
			statusMap.put(Constants.L1_REJECTED, false);
			statusMap.put(Constants.L2_REJECTED, false);
			statusMap.put(Constants.L2_APPROVED, false);
			if (isValid(infoMap)) {
				accountLevelOrderDetails(response, infoMap);
			} else {
				LOGGER.info("the transaction return valid as false, statusMap is {} " ,statusMap);
				if (statusMap.keySet().stream().filter(item -> item.endsWith("APPROVED"))
						.filter(item -> statusMap.get(item) == true).count() > 0) {
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_APPROVED_MSG, false));
					LOGGER.info("the transaction has already been approved");
				} else if (statusMap.keySet().stream().filter(item -> item.endsWith("REJECTED"))
						.filter(item -> statusMap.get(item) == true).count() > 0) {
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.ORDER_REJECTED_MSG, false));
					LOGGER.info("the transaction has been rejected");
				} else if (statusMap.get(Constants.URL_EXPIRED_AM)) {
					// process MA and trans table update
					maRequest.setLevel("0");
					maRequest.setOrderNumber(infoMap.get("orderId"));
					makeRejectionCall(maRequest, false);
					response.setServiceStatus(
							getServiceStatus(Constants.INVALID_CODE, Constants.URL_EXPIRY_MSG, false));
					LOGGER.info("the transaction has expired");
				}
			}
			response.setLevel(infoMap.get("level"));
			response.setOrderNumber(infoMap.get("orderId"));
			response.setOrderType(infoMap.get("transactionType"));
		} catch (Exception e) {
			LOGGER.error("Exception while retriving order information : {}" , e);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
		}
		return response;
	}

	private OrderDetailsResponse retrieveOrderDetails(String orderConfirmation) {
		LOGGER.info("inside calling trans core api");
		OrderDetailsRequest request = new OrderDetailsRequest();
		request.setConfirmationNumber(orderConfirmation);
		OrderDetailsResponse orderDetailsResponse = transHistoryCoreClient.retrieveOrderDetails(request);
		LOGGER.info("transCore response for MA page landing... {}", new Gson().toJson(orderDetailsResponse));
		return orderDetailsResponse;
	}
	
	/**
	 * @param response
	 * @param infoMap
	 */
	private void accountLevelOrderDetails(ManagerApprovalAccountLevelResponse response, Map<String, String> infoMap) {
		try {
			OrderDetailsResponse orderDetailsResponse = retrieveOrderDetails(infoMap.get("orderId"));
			LOGGER.info("end calling trans core api");
			SMAccountLevelOrderResponse smOrderResponse = new SMAccountLevelOrderResponse();
			if(Constant.CBA_TRANSACTION_TYPE.equalsIgnoreCase(infoMap.get("transactionType"))) {
				ManagerApprovalSMOrderDetails.setAccountLineItemResponseForCBA(orderDetailsResponse, smOrderResponse);
			}
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true));
			response.setOrderResponse(smOrderResponse);
		} catch (Exception e1) {
			LOGGER.error("Exception while trying to fetch data from trans core:{} " , e1);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
		}
	}

	private void transLevelOrderDetails(ManagerApprovalSMResponse response, Map<String, String> infoMap) {
		try {
			OrderDetailsResponse orderDetailsResponse = retrieveOrderDetails(infoMap.get("orderId"));
			LOGGER.info("end calling trans core api");
			SMOrderResponse smOrderResponse = new SMOrderResponse();
			if ("ARFACCOUNTLEVEL".equalsIgnoreCase(infoMap.get("transactionType"))) {
				GenerateOrderDataSM.generateOrderDataAccountLevel(orderDetailsResponse, smOrderResponse);
			} else if ("CPCLINELEVEL".equalsIgnoreCase(infoMap.get("transactionType")) || "callingPlanChg".equalsIgnoreCase(infoMap.get("transactionType")) ) {
				generateOrderDataCPCLineLevel(orderDetailsResponse, smOrderResponse);
			} else if (Constant.ARFLINELEVEL_TRANSACTION_TYPE.equalsIgnoreCase(infoMap.get("transactionType"))) {
				GenerateOrderDataSM.generateOrderDataLineLevel(orderDetailsResponse, smOrderResponse);
			} else if (Constant.CWUI_MA_TRANSACTION_TYPE.equals(infoMap.get("transactionType"))) {
				GenerateCWUIOrderDetailSM.setAccountLineItemResponseForCWUI(orderDetailsResponse, smOrderResponse);
			} else if (checkForCommonTransaction(infoMap.get("transactionType"))){
				GenerateOrderDataSM.generateOrderDataAccountLineItem(infoMap.get("transactionType"), orderDetailsResponse, smOrderResponse);
			}
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true));
			response.setOrderResponse(smOrderResponse);
		} catch (Exception e1) {
			LOGGER.error("Exception while trying to fetch data from trans core:{} " , e1);
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
		}
	}

	public boolean checkForCommonTransaction(String tranType) {
		if(cloudPropertiesConfig != null && 
				!StringUtils.isEmpty(cloudPropertiesConfig.getMbtCommonTransactions())) {
			List<String> commonTransactionTypesList = Arrays.asList(cloudPropertiesConfig.getMbtCommonTransactions().trim().split("\\s*,\\s*"));
			if(commonTransactionTypesList.contains(tranType))
				return true;			
		}
		return false;
	}

	private void generateOrderDataCPCLineLevel(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		if (orderDetailsResponse.getOrderDetailsList() != null
				&& !orderDetailsResponse.getOrderDetailsList().isEmpty()) {
			GenerateCPCOrderDetailSM generateCPCOrderDataSM = new GenerateCPCOrderDetailSM();
			generateCPCOrderDataSM.processCPCTransactionDetailForMA(orderDetailsResponse, smOrderResponse);		
		} else {
			smOrderResponse.setConfirmationNumber(orderDetailsResponse.getConfirmationNumber());
		}
	}

	private boolean checkIfAnotherLevelExists(ManagerApprovalSMTracker managerApprovalTracker) {
		String[] approverEmail2 = managerApprovalTracker.getApproverEmail2() != null
				? managerApprovalTracker.getApproverEmail2().split(";")
				: new String[] {};
		if (ArrayUtils.isNotEmpty(approverEmail2)
				&& !managerApprovalTracker.getStatus().equalsIgnoreCase("L2PENDING")) {
			return true;
		}
		return false;
	}

	@Override
	public ManagerApprovalSMResponse makeApprovalCall(ManagerApprovalSMRequest maRequest) {
		LOGGER.info("Order Approval process started for SM :{}" , maRequest.getOrderNumber());
		ManagerApprovalSMResponse response = new ManagerApprovalSMResponse();
		TransactionSubmitResponse transServiceResponse = new TransactionSubmitResponse();
		try {
			ManagerApprovalSMTracker managerApprovalTracker = managerApprovalSMRepo
					.findOneByOrderNumber(maRequest.getOrderNumber());
			if (checkIfAnotherLevelExists(managerApprovalTracker)) {
				// trigger the next level approval
				LOGGER.info("updating MA transaction");
				String url = getApprovalURL(managerApprovalTracker.getEcpdId(), 2,
						managerApprovalTracker.getOrderNumber(), managerApprovalTracker.getTransactionType());
				
				updateMATransactionStatus(levelMap.get((managerApprovalTracker.getLevel()) + "_P"),
						maRequest.getOrderNumber());
				updateMAApprovalUrl(url, maRequest.getOrderNumber());
				updateTransactionHistory(maRequest.getOrderNumber(), Constants.TRAN_STATUS_L2PENDING);
				LOGGER.info("trigger email for level 2 approval");
				if(Constant.transactionsWithCustomEmailTemplate.contains(managerApprovalTracker.getTransactionType())){
					customMANotification(buildMACustomEmailRequest(managerApprovalTracker));
				} else {
					oneMessageMANotification(managerApprovalTracker, maRequest,
							levelMap.get((managerApprovalTracker.getLevel()) + "_P")); // send email to level 2 manager
				}
				response.setNextLevelApproval(true);
				response.setLevel(levelMap.get((managerApprovalTracker.getLevel()) + "_P"));
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true));
			} else {
				if (checkForCommonTransaction(managerApprovalTracker.getTransactionType())
						|| Constant.CWUI_MA_TRANSACTION_TYPE.equals(managerApprovalTracker.getTransactionType())) {
					transServiceResponse = processSMSubmit(managerApprovalTracker, maRequest.getOrderNumber());
				} else if (Constant.ACCOUNT_LEVEL_TRANSACTIONS.contains(managerApprovalTracker.getTransactionType())) {
					transServiceResponse = processAccountLevelSMSubmit(managerApprovalTracker, maRequest.getOrderNumber());
				} else {
					transServiceResponse = processMLMOSubmit(managerApprovalTracker, maRequest.getOrderNumber());
				}
				response.setNextLevelApproval(false);
				response.setLevel(managerApprovalTracker.getLevel().toString());
				submitPostProcessing(transServiceResponse, response);
				updateMATransactionStatus(levelMap.get(managerApprovalTracker.getLevel() + "_A"),
						maRequest.getOrderNumber());
				// transaction table update is done in respective submit micro
			}
		} catch (Exception e) {
			LOGGER.error("Exception on Order Approval process for SM : {}" , e);
			response.setServiceStatus(getServiceStatus(Constants.EXCEPTION_CODE, Constants.EXCEPTION_MSG, false));
		}		
		return response;
	}

	private TransactionSubmitResponse processSMSubmit(ManagerApprovalSMTracker managerApprovalTracker,
			String confirmationNumber) throws IOException {
		// Process SMSubmit call
		TransactionSubmitResponse transServiceResponse = new TransactionSubmitResponse();
		ObjectMapper OM = new ObjectMapper();
		try {
			SMSubmitTransactionRequest smSumbmitRequest = OM.readValue(managerApprovalTracker.getMaAmTransactionJson(),
					SMSubmitTransactionRequest.class);

			smSumbmitRequest.setManagerApproved(true);
			smSumbmitRequest.setConfirmationNumber(confirmationNumber);
			transServiceResponse = smSubmitCompositeClient.submitCommonSMTransaction(smSumbmitRequest);
		} catch (IOException e) {
			throw e;
		}
		return transServiceResponse;
	}
	
	private TransactionSubmitResponse processAccountLevelSMSubmit(ManagerApprovalSMTracker managerApprovalTracker,
			String confirmationNumber) throws IOException {
		// Process SMSubmit call
		TransactionSubmitResponse transServiceResponse = new TransactionSubmitResponse();
		ObjectMapper OM = new ObjectMapper();
		try {
			SubmitAccountLevelTransactionRequest smSumbmitRequest = OM.readValue(managerApprovalTracker.getMaAmTransactionJson(),
					SubmitAccountLevelTransactionRequest.class);

			smSumbmitRequest.setManagerApproved(true);
			smSumbmitRequest.setConfirmationNumber(confirmationNumber);
			transServiceResponse = smSubmitCompositeClient.submitCommonAccountLevelSMTransaction(smSumbmitRequest);
		} catch (IOException e) {
			throw e;
		}
		return transServiceResponse;
	}

	private TransactionSubmitResponse processMLMOSubmit(ManagerApprovalSMTracker managerApprovalTracker,
			String confirmationNumber) {
		// process MLMO submit call
		TransactionSubmitResponse transServiceResponse ;
		TransactionSubmitRequest transactionSubmitRequest = new Gson()
				.fromJson(managerApprovalTracker.getMaAmTransactionJson(), TransactionSubmitRequest.class);
		transactionSubmitRequest.setManagerApproved(true);
		transactionSubmitRequest.setConfirmationNumber(confirmationNumber);
		transServiceResponse = smTransactionSubmitClient.submitTransactionARF(transactionSubmitRequest);
		return transServiceResponse;
	}

	private void submitPostProcessing(TransactionSubmitResponse transSubmitResponse,
			ManagerApprovalSMResponse response) {
				if (null != transSubmitResponse && StringUtils.isNotEmpty(transSubmitResponse.getConfirmNbr())) {
			if (null != transSubmitResponse.getServiceStatus() && transSubmitResponse.getServiceStatus().isSuccess()) {
				response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true));
			} else {
				response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
			}
		} else {
			response.setServiceStatus(getServiceStatus(Constants.EXCEPTION_CODE, Constants.EXCEPTION_MSG, false));
		}
	}

	private String getApprovalURL(String ecpdId, Integer level, String orderNumber, String transactionType) {
		LOGGER.info("Construct Manager approval URL for confirmation number in MS : {}" , orderNumber);
		String plainText = "orderId=" + orderNumber + "&ecpdId=" + ecpdId + "&level=" + level + "&transactionType="
				+ transactionType;
		credentials.setPlainText(plainText);
		
		if(checkForCommonTransaction(transactionType))
			return mbtHostUrl + cloudPropertiesConfig.getCommonTranManagerApprovalUrl() + credentials.getEncryptedText();
		else if ("callingPlanChg".equalsIgnoreCase(transactionType)) 
			return mbtHostUrl + cloudPropertiesConfig.getCpcmanagerApprovalUrl() + credentials.getEncryptedText();
		else if (Constant.CWUI_MA_TRANSACTION_TYPE.equalsIgnoreCase(transactionType))
			return mbtHostUrl + cloudPropertiesConfig.getCwuiManagerApprovalUrl() + credentials.getEncryptedText();
		else if (Constant.CBA_MA_TRANSACTION_TYPE.equalsIgnoreCase(transactionType))
			return mbtHostUrl + cloudPropertiesConfig.getCbaManagerApprovalUrl() + credentials.getEncryptedText();
		else 
			return mbtHostUrl + "/mbt/managerapproval?appName=epam#/arf/manager-approval/" + credentials.getEncryptedText();
	}

	private void oneMessageMANotification(ManagerApprovalSMTracker managerApprovalTracker,
			ManagerApprovalSMRequest maReqeust, String managerApprovalStatus) {		
		ManagerRequest managerRequest = buildManagerRequest(managerApprovalTracker, managerApprovalStatus);
		managerRequest.setReminderFlag5Day(false);
		managerRequest.setReminderFlag7Day(false);
		sendLevel2ManagerNotificationMail(managerRequest);
	}

	/**
	 * @param managerRequest
	 */
	private void sendLevel2ManagerNotificationMail(ManagerRequest managerRequest) {
		LOGGER.info("call to send L2 Email for transactionType: {}, confirmationNumber: {}",
				managerRequest.getTranType(), managerRequest.getConfirmationNumber());
		if (Constant.CWUI_MA_TRANSACTION_TYPE.equals(managerRequest.getTranType())) {
			smSubmitCompositeClient.notifyManager(managerRequest);
		} else {
			notificationClient.sendMailToManger(managerRequest);
		}
	}

	private ManagerRequest buildManagerRequest(ManagerApprovalSMTracker managerApprovalTracker, String managerApprovalStatus) {
		String url = getApprovalURL(managerApprovalTracker.getEcpdId(), 2, managerApprovalTracker.getOrderNumber(),
				managerApprovalTracker.getTransactionType());
		ManagerRequest managerRequest = new ManagerRequest();
		managerRequest.setConfirmationNumber(managerApprovalTracker.getOrderNumber());
		managerRequest.setApprovalUrl(url);
		managerRequest.setTranType(managerApprovalTracker.getTransactionType());
		managerRequest.setApproverEmailIds(
				Stream.of(managerApprovalTracker.getApproverEmail2()).collect(Collectors.toList()));
		managerRequest.setStatus(Constants.TRAN_STATUS_PENDING); // batchprocess=false; "pending"
		managerRequest.setManagerApprovalStatus(managerApprovalStatus);
		managerRequest.setEcpdId(managerApprovalTracker.getEcpdId());
		return managerRequest;
	}

	@Override
	public ManagerApprovalSMResponse makeRejectionCall(ManagerApprovalSMRequest maRequest, boolean triggerOneMessage) {
		LOGGER.info("Order Rejection process started for SM : {}" , maRequest.getOrderNumber());
		ManagerApprovalSMResponse response = new ManagerApprovalSMResponse();
		FinalNotificationRequest confRequest = new FinalNotificationRequest();
		try {
			updateTransactionHistory(maRequest.getOrderNumber(), Constants.TRAN_STATUS_REJECTED);
			response.setServiceStatus(getServiceStatus(Constants.SUCCESS_CODE, Constants.SUCCESS_MSG, true));
			response.setLevel(levelMap.get(maRequest.getLevel() + "_R"));
			if (triggerOneMessage) {
				updateMATransactionStatus(levelMap.get(maRequest.getLevel() + "_R"), maRequest.getOrderNumber());
				confRequest.setConfirmNbr(maRequest.getOrderNumber());
				smTransactionSubmitClient.sendConfirmationEmail(confRequest);
			} else {
				updateMATransactionStatus(levelMap.get(maRequest.getLevel() + "_R"), maRequest.getOrderNumber());
			}
		} catch (Exception e) {
			response.setServiceStatus(getServiceStatus(Constants.FAILURE_CODE, Constants.FAIL_STATUS, false));
			LOGGER.error("Exception on Order Rejection process for SM :{}" , e);
		}
		return response;
	}

	private void updateTransactionHistory(String orderNumber, String status) {
		UpdateTransactionHistoryRequest request = new UpdateTransactionHistoryRequest();
		request.setConfirmNumber(orderNumber);
		request.setTransactionStatus(status);
		transHistoryCoreClient.updateTransactionStatus(request);
	}

	private void updateMATransactionStatus(String STATUS, String orderNumber) {
		managerApprovalSMRepo.updateMAStatus(STATUS, orderNumber);
	}

	private void updateMAApprovalUrl(String approvalUrl, String orderNumber) {
		managerApprovalSMRepo.updateMAApprovalUrl(approvalUrl, orderNumber);
	}

	private ServiceStatus getServiceStatus(String statusCode, String statusMessage, boolean isSuccess) {
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setStatusCode(statusCode);
		serviceStatus.setStatusMessage(statusMessage);
		serviceStatus.setSuccess(isSuccess);
		return serviceStatus;
	}

	private boolean isValid(Map<String, String> infoMap) {
		String[] transactionStatus = { Constants.L1_APPROVED, Constants.L2_APPROVED, Constants.L1_REJECTED,
				Constants.L2_REJECTED };
		ManagerApprovalSMTracker managerApprovalTracker = managerApprovalSMRepo
				.findOneByOrderNumber(infoMap.get("orderId"));
		if (managerApprovalTracker != null) {
			LOGGER.info("manager approval record retireved :{} " , new Gson().toJson(managerApprovalTracker));
			if (isURLExpired(managerApprovalTracker)) {
				statusMap.put(Constants.URL_EXPIRED_AM, true);
				return false;
			}
			if (Integer.parseInt(infoMap.get("level")) == 1 && managerApprovalTracker.getStatus().contains("L2")) {
				statusMap.put(Constants.L1_APPROVED, true);
				return false;
			}
			if (ArrayUtils.contains(transactionStatus, managerApprovalTracker.getStatus())) {
				statusMap.put(Constants.L1_APPROVED,
						managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L1_APPROVED));
				statusMap.put(Constants.L2_APPROVED,
						managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L2_APPROVED));
				statusMap.put(Constants.L1_REJECTED,
						managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L1_REJECTED));
				statusMap.put(Constants.L2_REJECTED,
						managerApprovalTracker.getStatus().equalsIgnoreCase(Constants.L2_REJECTED));
				return false;
			}
			return true;
		}
		return false;
	}

	private boolean isURLExpired(ManagerApprovalSMTracker managerApprovalTracker) {
		Date orderCreatedDate = managerApprovalTracker.getCreatedDate();
		LOGGER.info("Order Created Date : {} " , orderCreatedDate);
		if (orderCreatedDate != null) {
			LocalDate createdDate = orderCreatedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
			LOGGER.info("Order Created Date :{}" , createdDate);
			LocalDate eighthDay = createdDate.plusDays(8);
			LOGGER.info("seventh day of Order Created Date : {}" , eighthDay);
			LocalDate currentDate = LocalDate.now(ZoneId.systemDefault());
			int compareResult = currentDate.compareTo(eighthDay);
			LOGGER.info("Date comparision result : {}" , compareResult);
			if (compareResult <= 0) {
				return false;
			} else {
				return true;
			}
		}
		return true;
	}

	private Map<String, String> decryptCreds(Credentials creds) {
		Map<String, String> infoMap = new HashMap<String, String>();
		String decrptedCreds = creds.getDecryptedText();
		if (StringUtils.isNotEmpty(decrptedCreds)) {
			String[] decryptedValues = decrptedCreds.split("&");
			for (String parameter : decryptedValues) {
				String[] keyValues = parameter.split("=");
				LOGGER.info("Values Received :{} {} {}" , keyValues[0] , " = " , keyValues[1]);
				infoMap.put(keyValues[0].trim(), keyValues[1].trim());
			}
		}
		return infoMap;
	}
	
	/**
	 * <p>
	 * This method is used to send L2 manager approval email
	 * by calling /jms/notify/manager endpoint in notification-core
	 * </p>
	 * 
	 * @param managerRequest
	 */
	private void customMANotification(ManagerApprovalRequest managerRequest) {
		managerRequest.setReminderFlag5Day(false);
		managerRequest.setReminderFlag7Day(false);
		LOGGER.info("caling notification core to send L2 Email ");
		notificationClient.sendMailToManagerUsingJMS(managerRequest);
	}
	
	/**
	 * <p>
	 * This method is used to create request object 
	 * for /jms/notify/manager endpoint in notification-core
	 * </p>
	 * 
	 * @param managerApprovalTracker
	 * @return ManagerApprovalRequest
	 */
	private ManagerApprovalRequest buildMACustomEmailRequest(ManagerApprovalSMTracker managerApprovalTracker) {
		OrderDetailsResponse orderDetailsResponse = retrieveOrderDetails(managerApprovalTracker.getOrderNumber());
		String username = StringUtils.EMPTY;
		if(orderDetailsResponse!=null){
			List<SystemTxnInfo> orderDetailsList = orderDetailsResponse.getOrderDetailsList();

			if(orderDetailsList!=null && !orderDetailsList.isEmpty()){
				username = orderDetailsList.get(Constant.ZERO_AS_INT).getSubscriberName();
			}
		}
		String url = getApprovalURL(managerApprovalTracker.getEcpdId(), Constant.TWO_AS_INT, managerApprovalTracker.getOrderNumber(),
				managerApprovalTracker.getTransactionType());
		
		ManagerApprovalRequest managerRequest = new ManagerApprovalRequest();
		managerRequest.setConfirmationNumber(managerApprovalTracker.getOrderNumber());
		managerRequest.setApprovalUrl(url);
		managerRequest.setTranType(managerApprovalTracker.getTransactionType());
		managerRequest.setApproverEmailIds(
				Stream.of(managerApprovalTracker.getApproverEmail2()).collect(Collectors.toList()));
		managerRequest.setStatus(Constants.TRAN_STATUS_PENDING);
		managerRequest.setUsername(username);
		return managerRequest;
	}
}