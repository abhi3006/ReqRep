package com.vzw.mybiz.approval.constant;

import java.util.Arrays;
import java.util.List;

public interface Constant {
	
	public static final String CPC_TRANSACTION_TYPE = "callingPlanChg";	
	public static final String ARF_TRANSACTION_TYPE = "ARF";
	public static final String SUS_TRANSACTION_TYPE = "suspend";
	public static final String RES_TRANSACTION_TYPE = "resume";
	public static final String CCC_TRANSACTION_TYPE = "changeCostCenter";
	public static final String DACT_TRANSACTION_TYPE = "disconnect";
	public static final String CMB_TRANSACTION_TYPE = "callMessageBlocking";
	public static final String CBA_TRANSACTION_TYPE = "chgBillingAddress";
	public static final String ARFLINELEVEL_TRANSACTION_TYPE = "ARFLINELEVEL";
	public static final String ADD = "ADD";
	public static final String AUTOADD = "AUTOADD";
	public static final String DELETE = "DELETE";
	public static final String AUTODELETE = "AUTODELETE";
	public static final String ACCOUNT_LEVEL_PLAN = "ALP";
	public static final String CALLING_PLAN = "calling plan";
	public static final String LLP = "LLP";
	public static final String MONTHLY_ACCESS_FEE = "monthly access fee";
	public static final String DATA_CHANGE = "Data change";
	public static final String FEATURES = "Features";
	public static final String PROMO = "PROMO";
	public static final String OTHER = "Other";
	public static final String SHARED = "Shared";
	public static final String CSR_ID = "MBT_CPC_MA_PDF";
	public static final String ECPD_ID = "Am_ecpd_id";
	public static final String LOGIN_USER_ID = "AM_UID";
	public static final String ACCOUNT_LEVEL_FEATURE = "Account Level Feature";
	public static final String ACCOUNT_LEVEL_FEATURE_TRUE = "Account Level Feature_true";

	public static final String ACTION_TYPE_ADD = "ADD";
	public static final String ACTION_TYPE_AUTODELETE = "AUTODELETE";
	public static final String ACTION_TYPE_BILLING = "Billing";
	public static final String ACTION_TYPE_REASON = "Reason";
	public static final String ACTION_TYPE_RECONNECT_DATE = "Reconnect Date";

	
	public static final String ACC_LINE_ITEM_MTN = "Wireless number";
	public static final String ACC_LINE_ITEM_USER_NAME = "User name";
	public static final String ACC_LINE_ITEM_OLD_CC= "Current cost center";
	public static final String ACC_LINE_ITEM_NEW_CC = "New cost center";
	
	public static final String ACC_LINE_ITEM_REASON = "Suspend Status";
	public static final String ACC_LINE_ITEM_SUS_BILLING = "Suspended Billing";
	public static final String ACC_LINE_ITEM_RECONNECT_DATE = "Reconnect Date";
	public static final String ACC_LINE_ITEM_BILLING = "Billing";
	
	public static final String ACC_LINE_ITEM_CMB = "Call Message Blocking";
	public static final String TXN_TYPE_CCC = "CCC";
	public static final String TXN_TYPE_SUSPEND = "SUS";
	public static final String TXN_TYPE_RESUME = "RES";

	// disconnect types
	public static final String DACT_REASON_FOR_DEACTIVATION = "Reason For Deactivation";
	public static final String DACT_DEACTIVATION_DATE = "Deactivation Date";
	public static final String DACT_CONTRACT_END_DATE= "Contract End Date";
	public static final String DACT_ETF_FEE= "Etf Fee";
	public static final String ACC_LINE_ITEM_REASON_DISCONNECT= "Reason for Disconnect";
	public static final String ACC_LINE_ITEM_CONTRACT_DT= "Contract End Date";
	public static final String ACC_LINE_ITEM_DEACT_DT= "Deactivate Date";
	public static final String ACC_LINE_ITEM_ETF= "Early Termination Fee";
	public static final String TXN_TYPE_DISCONNECT = "DACT";
	
	public static final String CWUI_MA_TRANSACTION_TYPE = "ChangeUserInformation";
	public static final String TXN_TYPE_CWUI = "CWUI";
	public static final String USER_ID = "User Id";
	public static final String FIRST_NAME = "First Name";
	public static final String LAST_NAME = "Last Name";
	public static final String COST_CENTER = "Cost center";
	public static final String CONTACT_PHONE_1 = "Contact Phone 1";
	public static final String CONTACT_PHONE_2 = "Contact Phone 2";
	public static final String EMAIL_ADDRESS = "Email Address";
	public static final String ADDRESS_1 = "Address 1";
	public static final String ADDRESS_2 = "Address 2";
	public static final String CITY = "City";
	public static final String STATE = "State";
	public static final String ZIP_CODE = "Zip Code";
	public static final String EXT_STR = "Ext:";
	public static final int ZERO_AS_INT = 0;
	public static final int ONE_AS_INT = 1;
	public static final int THREE_AS_INT = 3;
	public static final int SIX_AS_INT = 6;
	public static final String DOT_STRING = ".";
	public static final String NUMBER_REGEX = "[^0-9]";
	
	public static final String ACC_LINE_ITEM_LOCATION = "Location";
	public static final String ACC_LINE_ITEM_ATTENTION_LINE = "Attention Line";
	public static final String ACC_LINE_ITEM_ADDRESS1 = "Address 1";
	public static final String ACC_LINE_ITEM_ADDRESS2 = "Address 2";
	public static final String ACC_LINE_ITEM_CITY = "City";
	public static final String ACC_LINE_ITEM_STATE = "State";
	public static final String ACC_LINE_ITEM_ZIP_CODE = "Zip Code";
	public static final String ACC_LINE_ITEM_CONTACT1 = "Contact 1";
	public static final String ACC_LINE_ITEM_CONTACT2 = "Contact 2";
	public static final String ACC_LINE_ITEM_EXT1 = "Ext 1";
	public static final String ACC_LINE_ITEM_EXT2 = "Ext 2";
	public static final String ACC_LINE_ITEM_PAPERLESS = "Paperless Billing";
	public static final String TXN_TYPE_CBA = "CBA";
	public static final List<String> ACCOUNT_LEVEL_TRANSACTIONS = Arrays.asList("chgBillingAddress");
	public static final String CBA_MA_TRANSACTION_TYPE = "chgBillingAddress";
	
	public static final String CBR_LANDING_TRANSACTION_TYPE = "ChangeBillingResponsibility";
	public static final String ACC_LINE_ITEM_NEW_USER_NAME = "Name of the new customer";
	public static final String ACC_LINE_ITEM_NEW_USER_EMAIL = "E-mail of the new customer";
	public static final String CBR_INFO_TRANSACTION_TYPE = "CBR";
	
	public static final int TWO_AS_INT = 2;
	public static final String CMB_LANDING_TRANSACTION_TYPE = "callMessageBlocking";
	public static final List<String> transactionsWithCustomEmailTemplate = Arrays.asList(Constant.CBA_MA_TRANSACTION_TYPE, CBR_LANDING_TRANSACTION_TYPE, CMB_LANDING_TRANSACTION_TYPE);
}

