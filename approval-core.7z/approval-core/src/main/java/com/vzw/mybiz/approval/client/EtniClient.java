package com.vzw.mybiz.approval.client;

import java.net.URI;

import com.vzw.mybiz.prospect.domain.etni.npanxx.Msgresponse;

import feign.RequestLine;

public interface EtniClient {

    @RequestLine("POST")
    public Msgresponse npanxxSearch(URI uri);

}
