package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

public class ViewOnlyDto  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean viewOnlyOn;
	private String state;
	private String defaultMessage;
	private String customOverrideMessage;
	
	public boolean isViewOnlyOn() {
		return viewOnlyOn;
	}
	public void setViewOnlyOn(boolean viewOnlyOn) {
		this.viewOnlyOn = viewOnlyOn;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDefaultMessage() {
		return defaultMessage;
	}
	public void setDefaultMessage(String defaultMessage) {
		this.defaultMessage = defaultMessage;
	}
	public String getCustomOverrideMessage() {
		return customOverrideMessage;
	}
	public void setCustomOverrideMessage(String customOverrideMessage) {
		this.customOverrideMessage = customOverrideMessage;
	}
}
