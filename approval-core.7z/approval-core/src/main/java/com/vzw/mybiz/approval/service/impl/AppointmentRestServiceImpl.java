package com.vzw.mybiz.approval.service.impl;


import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.vzw.mybiz.approval.client.NotificationClient;
import com.vzw.mybiz.approval.client.RcwsStoreClient;
import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentDetail;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentInfo;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.CustomerDetails;
import com.vzw.mybiz.approval.domain.storeAppointment.Email;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.StoreDetails;
import com.vzw.mybiz.approval.domain.storeAppointment.VisitPurposeDetails;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Response;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.ServiceType;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Store;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentRequest;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreDetailsR;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreType;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.TransactionType;
import com.vzw.mybiz.approval.service.AppointmentRestService;
import com.vzw.mybiz.approval.service.SalesForceService;
import com.vzw.mybiz.approval.starter.CloudPropertiesConfig;
import com.vzw.mybiz.utilities.audit.domain.ExternalSys;
import com.vzw.mybiz.utilities.audit.domain.ResponseDetails;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;
import com.vzw.mybiz.utilities.audit.services.AuditService;

import feign.Feign;
import feign.Logger.Level;
import feign.Request;
import feign.jaxb.JAXBContextFactory;
import feign.jaxb.JAXBDecoder;
import feign.jaxb.JAXBEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;



@Service
public class AppointmentRestServiceImpl implements AppointmentRestService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AppointmentRestServiceImpl.class);

	@Autowired
	private NotificationClient notficationClient;
	
	@Autowired
	private SalesForceService sfService;
	
	@Autowired
	private CloudPropertiesConfig cloudPropertiesConfig;
	
	@Autowired
	AuditService auditService;
	
	private RcwsStoreClient storeClient;
	
	JAXBContextFactory jaxbFactory = new JAXBContextFactory.Builder().withMarshallerJAXBEncoding("UTF-8")
			.withMarshallerSchemaLocation("http://apihost http://apihost/schema.xsd").build();
	
	
	@PostConstruct
	public void init() {
		storeClient  = Feign.builder().client(new OkHttpClient())
				.options(new Request.Options(cloudPropertiesConfig.getFeignConnectTimeout(),cloudPropertiesConfig.getFeignReadTimeout()))
				.encoder(new JAXBEncoder(jaxbFactory))
				.decoder(new JAXBDecoder(jaxbFactory))
				.logger(new Slf4jLogger(RcwsStoreClient.class)).logLevel(Level.FULL)
				.target(RcwsStoreClient.class,cloudPropertiesConfig.getRcwsHost());
		
	}


	
	@Override
	public AppointmentResponse saveAndSchedule(AppointmentDetail appointmentDetail) {
		CompletableFuture<SalesForceResponse> salesForceFuture = new CompletableFuture<>();
		SalesForceResponse sfResponse = new SalesForceResponse();
		String appointmentId=null;
		
		if(null != appointmentDetail) {
			salesForceFuture = sfService.initiateSfCall(appointmentDetail);
			CompletableFuture.allOf(salesForceFuture).join();
		}
		
		AppointmentResponse response = new AppointmentResponse();
		AppointmentInfo appointmentInfo ;
		appointmentInfo = setDetailsFromRequest(appointmentDetail);	

		if(null != appointmentInfo.getAppointmentType()) {			
			response.setAppointmentInfo(appointmentInfo);			
			LOGGER.info("AFTER SETTING RESPONSE :{}" , response);
			ServiceStatus serviceStatus = new ServiceStatus();			
			try {
				sfResponse = salesForceFuture.get();
			} catch (InterruptedException e) {
				LOGGER.info("InterruptedException :{}" , e.getMessage());
			} catch (ExecutionException e) {				
				LOGGER.info("ExecutionException :{}" , e.getMessage());
			}		
			
			if(sfResponse != null && null != sfResponse.getGleadId() && null !=sfResponse.getMsg() &&sfResponse.getMsg().equalsIgnoreCase("Success!!")) {
				
				appointmentId = sfResponse.getGleadId();
				response.getAppointmentInfo().setAppointmentId(appointmentId);
				serviceStatus = sendNotification(appointmentDetail,appointmentId);
				response.setServiceStatus(serviceStatus);
				LOGGER.info("AFTER GETTING RESPONSE FROM NOTIFICATION :{}", response);
			}
			else {
				LOGGER.info("FAILED SALESFORCE RESPONSE :{}" , response);
				ServiceStatus serviceStatusSf = new ServiceStatus();
				serviceStatusSf.setSuccess(false);
				serviceStatusSf.setStatusMessage("Failed in SF call ");
				serviceStatusSf.setStatusCode("909");
				response.setServiceStatus(serviceStatusSf);
				return response;
			}
		
		}
		else {
		LOGGER.info("FAILED RESPONSE :{}" , response);
		ServiceStatus serviceStatus = new ServiceStatus();
		serviceStatus.setSuccess(false);
		serviceStatus.setStatusMessage("FAiled");
		serviceStatus.setStatusCode("99000");
		response.setServiceStatus(serviceStatus);
		
		return response;
		}

		
		return response;
	}
	private ServiceStatus sendNotification(AppointmentDetail appointmentDetail,String appointmentId) {
		ServiceStatus status = new ServiceStatus();
		Email request = new Email(); 
		
		request.setTemplateName(Constants.TEMPLATE_StoreAppointment);
		request.setMailTo(appointmentDetail.getCustomerDetails().getEmail());
		request.setUserEmail("string");
		if(null != appointmentDetail.getStoreDetails()) {
		request.setApprovalUrl(appointmentDetail.getStoreDetails().getStoreName()+", "+appointmentDetail.getStoreDetails().getAddress1()+", "+appointmentDetail.getStoreDetails().getCity()+", "
				+appointmentDetail.getStoreDetails().getState()+", "+appointmentDetail.getStoreDetails().getZip()+", "+appointmentDetail.getStoreDetails().getPhoneNumber());
		}
		if(null !=appointmentDetail.getPurposeDetails() ) {
		
		request.setMailContent("Selected Slot : "+appointmentDetail.getPurposeDetails().getAppointmentDate()+" "+appointmentDetail.getPurposeDetails().getSlotGrouping()+" "+appointmentDetail.getPurposeDetails().getSlotTime());
		
		}
		request.setMailFrom("string");
		request.setMyBusinessIds("string");
		request.setOrderNumber(appointmentId);
		if(null != appointmentDetail.getPurposeDetails()) {
		request.setReminderNumber(appointmentDetail.getPurposeDetails().getPurpose()+".   Additional Comments : "+appointmentDetail.getPurposeDetails().getAdditionalComments());
		}
		request.setContentType("string");
		request.setMailSubject(Constants.EMAIL_SUBJECT);
		
		try {
			status = notficationClient.sendCustomStoreAppointmentEmail(request);
		} catch(Exception e) {
			LOGGER.info("Error in notification : {}", request);
		}
		return status;
	}

	private AppointmentInfo setDetailsFromRequest(AppointmentDetail appointmentDetail) {
		AppointmentInfo response = new AppointmentInfo();
		VisitPurposeDetails purposeDetails = new VisitPurposeDetails();
		StoreDetails storeDetails = new StoreDetails();
		CustomerDetails customerDetails = new CustomerDetails();
		
		if(StringUtils.isNotEmpty(appointmentDetail.getSubmittedDate())) {
			response.setSubmittedDate(appointmentDetail.getSubmittedDate());
		}
		
		if (null != appointmentDetail && !ObjectUtils.isEmpty(appointmentDetail.getPurposeDetails())) {
			LOGGER.info("POPULATING Purpose Details : {}" , appointmentDetail.getPurposeDetails());
			purposeDetails.setPurpose(appointmentDetail.getPurposeDetails().getPurpose());
			purposeDetails.setAdditionalComments(appointmentDetail.getPurposeDetails().getAdditionalComments());
			purposeDetails.setSlotGrouping(appointmentDetail.getPurposeDetails().getSlotGrouping());
			purposeDetails.setSlotTime(appointmentDetail.getPurposeDetails().getSlotTime());
			purposeDetails.setAppointmentDate(appointmentDetail.getPurposeDetails().getAppointmentDate());

			response.setPurposeDetails(purposeDetails);
		}


		if (null != appointmentDetail && !ObjectUtils.isEmpty(appointmentDetail.getStoreDetails())) {

			LOGGER.info("POPULATING STORE DETAILS :{}" , appointmentDetail.getStoreDetails());
			storeDetails.setStoreId(appointmentDetail.getStoreDetails().getStoreId());
			storeDetails.setStoreName(appointmentDetail.getStoreDetails().getStoreName());
			storeDetails.setAddress1(appointmentDetail.getStoreDetails().getAddress1());
			storeDetails.setCity(appointmentDetail.getStoreDetails().getCity());
			storeDetails.setState(appointmentDetail.getStoreDetails().getState());
			storeDetails.setZip(appointmentDetail.getStoreDetails().getZip());
			storeDetails.setPhoneNumber(appointmentDetail.getStoreDetails().getPhoneNumber());
			storeDetails.setNetAceLocation(appointmentDetail.getStoreDetails().getNetAceLocation());
			storeDetails.setOutletId(appointmentDetail.getStoreDetails().getOutletId());

			response.setStoreDetails(storeDetails);

		}
		if (null != appointmentDetail && !ObjectUtils.isEmpty(appointmentDetail.getCustomerDetails())) {
			LOGGER.info("POPULATING CUSTOMER DETAILS : {}" , appointmentDetail.getCustomerDetails());
			customerDetails.setBusinessName(appointmentDetail.getCustomerDetails().getBusinessName());
			customerDetails.setFirstName(appointmentDetail.getCustomerDetails().getFirstName());
			customerDetails.setLastName(appointmentDetail.getCustomerDetails().getLastName());
			customerDetails.setEmail(appointmentDetail.getCustomerDetails().getEmail());
			customerDetails.setPhoneNumber(appointmentDetail.getCustomerDetails().getPhoneNumber());
			customerDetails.setAddress1(appointmentDetail.getCustomerDetails().getAddress1());
			customerDetails.setAddress2(appointmentDetail.getCustomerDetails().getAddress2());
			customerDetails.setCity(appointmentDetail.getCustomerDetails().getCity());
			customerDetails.setState(appointmentDetail.getCustomerDetails().getState());
			customerDetails.setZip(appointmentDetail.getCustomerDetails().getZip());

			response.setCustomerDetails(customerDetails);
		}
		if(StringUtils.isNotEmpty(appointmentDetail.getAppointmentType())) {
			response.setAppointmentType(appointmentDetail.getAppointmentType());
			response.setAppointmentStatus(appointmentDetail.getAppointmentStatus());
		}
		
		
		return response;

	}
	

@Override	
public StoreAppointmentResponse getStoreById(StoreAppointmentRequest request) {
		
		StoreAppointmentResponse appointmentResponse = new StoreAppointmentResponse();
		
		com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Request rcwsRequest = new com.vzw.mybiz.approval.domain.storeAppointment.RCWS.Request();
		
		ServiceType service = new ServiceType();
		StoreType storeType = new StoreType();
		TransactionType transactionType = new TransactionType();
		StoreResponse resp = new StoreResponse();
		
		transactionType.setConsumerid("1000");
		storeType.setStoreNumber(request.getStoreId());
		service.setName("StoreService");
		rcwsRequest.setSourceSystem("MYBIZ");
		service.setAction("GetStoreDetailProcess");
		service.setStore(storeType);
		service.setTransaction(transactionType);
		
		
		rcwsRequest.setService(service);
		Response tempResponse= new Response();
		
		try {
		
		
		
		ExternalSys externalSys = new ExternalSys("RCWS", cloudPropertiesConfig.getRcwsHost());
		externalSys.setService(rcwsRequest.getService().getName());
		externalSys.setSubService(rcwsRequest.getService().getAction());
		
		auditService.beginTransaction(rcwsRequest, externalSys);
		tempResponse = storeClient.getStore(rcwsRequest);
		LOGGER.info("RESPONSE FROM RCWS : {}",tempResponse);
		resp.setResponse(tempResponse);
		auditService.endTransaction(tempResponse,new ResponseDetails(resp.toString(),"SUCCESS"));
		}catch(Exception e) {
			LOGGER.error("Error in POS end point to get store details :{}", e.getMessage());
		}
		if(resp == null || resp.getResponse().getService().getStatus().equalsIgnoreCase("Failure")) {
			LOGGER.info("No stores returned by POS for the provided ZIP");
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setMessage("No stores returned by POS for the provided ZIP");
			appointmentResponse.setServiceStatus(serviceStatus);
			return appointmentResponse;
		}
		
		Store storeDetails = new Store();
		
		if(resp.getResponse() != null && resp.getResponse().getService().getStore() != null) {
			storeDetails = resp.getResponse().getService().getStore();
		}else{
			LOGGER.info("No Stores found in POS");
		}
		LOGGER.info("Stores found : ");
		
		StoreDetailsR detail = new StoreDetailsR();
		
		
		detail.setOutletId(storeDetails.getStoreDetails().getOutletId());
		detail.setStoreName(storeDetails.getStoreDetails().getStoreName());
		detail.setStoreId(storeDetails.getStoreDetails().getStoreNumber());
		detail.setAddress1(storeDetails.getStoreDetails().getAddress1());
		detail.setPhoneNumber(storeDetails.getStoreDetails().getPhoneNumber());
		detail.setState(storeDetails.getStoreDetails().getState());
		detail.setCity(storeDetails.getStoreDetails().getCity());
		detail.setZip(storeDetails.getStoreDetails().getZip());
		detail.setNetAceLocation(storeDetails.getStoreDetails().getNetaceLocationCode());
		detail.setConsumerHost(cloudPropertiesConfig.getConsumerHost());
		
		detail.setTimings(storeDetails.getStoreHours());
		
		appointmentResponse.setStoreDetail(detail);
		ServiceStatus status = new ServiceStatus();
		status.setStatusCode(Constants.SUCCESS_CODE);
		status.setStatusMessage("SUCCESS");
		status.setSuccess(true);
		status.setMessage("Store Details Fetched Successfully");
		appointmentResponse.setServiceStatus(status);
		

		return appointmentResponse;
	}


	
	
}
