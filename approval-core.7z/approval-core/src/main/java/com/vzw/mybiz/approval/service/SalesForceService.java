package com.vzw.mybiz.approval.service;

import java.util.concurrent.CompletableFuture;

import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentDetail;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceResponse;


public interface SalesForceService {
	
	CompletableFuture<SalesForceResponse> initiateSfCall(AppointmentDetail appointmentDetail);

}
