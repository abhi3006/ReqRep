package com.vzw.mybiz.approval.domain.sm;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.vzw.mybiz.approval.domain.sm.ma.cwui.ChangeUserInfoMTNInfo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountLineItem implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String accountNumber;
	private List<LinkedHashMap<String, String>> mtnDetailsSMList;
	private List<ChangeUserInfoMTNInfo> lines;
		
}
