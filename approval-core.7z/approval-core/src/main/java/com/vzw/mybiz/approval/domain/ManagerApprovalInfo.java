package com.vzw.mybiz.approval.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Set;


public class ManagerApprovalInfo implements Serializable{

	/**
	 * 
	 * @author kab82bq 
	 */
	private static final long serialVersionUID = -1363868526301253210L;
	/**
	 * 
	 */
	
	private ServiceStatus serviceStatus;
	
	private boolean isManagerApprovalEnabled;
	private boolean managerApprovalSuppress;
	private Set<String> approverEmails;
	private String prePopulateEmailID;
	private boolean isRequired;
	private boolean isReadonly;
	private String userInputType;
	private List<DgfFieldShortLookup> lookUp;
	private List<String> emailDomainList;
	private String level; 
	private String userSelectedEmail;
	
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	public List<String> getEmailDomainList() {
		return emailDomainList;
	}

	public void setEmailDomainList(List<String> emailDomainList) {
		this.emailDomainList = emailDomainList;
	}

	public String getPrePopulateEmailID() {
		return prePopulateEmailID;
	}

	public void setPrePopulateEmailID(String prePopulateEmailID) {
		this.prePopulateEmailID = prePopulateEmailID;
	}

	public boolean isRequired() {
		return isRequired;
	}

	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}

	public boolean isReadonly() {
		return isReadonly;
	}

	public void setReadonly(boolean isReadonly) {
		this.isReadonly = isReadonly;
	}

	public String getUserInputType() {
		return userInputType;
	}

	public void setUserInputType(String userInputType) {
		this.userInputType = userInputType;
	}

	public List<DgfFieldShortLookup> getLookUp() {
		return lookUp;
	}

	public void setLookUp(List<DgfFieldShortLookup> lookUp) {
		this.lookUp = lookUp;
	}

	public Set<String> getApproverEmails() {
		return approverEmails;
	}

	public void setApproverEmails(Set<String> approverEmails) {
		this.approverEmails = approverEmails;
	}

	public boolean isManagerApprovalSuppress() {
		return managerApprovalSuppress;
	}

	public void setManagerApprovalSuppress(boolean managerApprovalSuppress) {
		this.managerApprovalSuppress = managerApprovalSuppress;
	}

	public boolean isManagerApprovalEnabled() {
		return isManagerApprovalEnabled;
	}

	public void setManagerApprovalEnabled(boolean isManagerApprovalEnabled) {
		this.isManagerApprovalEnabled = isManagerApprovalEnabled;
	}
	public String getUserSelectedEmail() {
		return userSelectedEmail;
	}
	public void setUserSelectedEmail(String userSelectedEmail) {
		this.userSelectedEmail = userSelectedEmail;
	}

	/*private boolean displayMgrAprvl;
	// true if send to mgr approval to etm
	private boolean mgrAprvlToEtm;
	private boolean managerApprovalSuppress;
	

	// true if:
	//   level 1 and no variable setup in dgf
	//   or level 2 and 1 email from ecpd and no variable setup in dgf
	private boolean faultySetupDisplay = false;
	// true if:
	//   level 1 always show / true
	//   level 2 only 1 email from ecpd and variable setup in dgf
	private boolean variableEmailDisplay = false;
	private List<String> mgrAprvlL1Email;
	private List<String> mgrAprvlL2Email;
	private List<String> mgrAprvlL3Email;
	
	// stores the variable setup from user if enabled
	// or stores faulty setup email address
	private String varEmailAddress;

	public boolean isDisplayMgrAprvl() {
		return displayMgrAprvl;
	}

	public void setDisplayMgrAprvl(boolean displayMgrAprvl) {
		this.displayMgrAprvl = displayMgrAprvl;
	}

	public boolean isMgrAprvlToEtm() {
		return mgrAprvlToEtm;
	}

	public void setMgrAprvlToEtm(boolean mgrAprvlToEtm) {
		this.mgrAprvlToEtm = mgrAprvlToEtm;
	}

	public boolean isManagerApprovalSuppress() {
		return managerApprovalSuppress;
	}

	public void setManagerApprovalSuppress(boolean managerApprovalSuppress) {
		this.managerApprovalSuppress = managerApprovalSuppress;
	}

	public boolean isFaultySetupDisplay() {
		return faultySetupDisplay;
	}

	public void setFaultySetupDisplay(boolean faultySetupDisplay) {
		this.faultySetupDisplay = faultySetupDisplay;
	}

	public boolean isVariableEmailDisplay() {
		return variableEmailDisplay;
	}

	public void setVariableEmailDisplay(boolean variableEmailDisplay) {
		this.variableEmailDisplay = variableEmailDisplay;
	}

	public List<String> getMgrAprvlL1Email() {
		return mgrAprvlL1Email;
	}

	public void setMgrAprvlL1Email(List<String> mgrAprvlL1Email) {
		this.mgrAprvlL1Email = mgrAprvlL1Email;
	}

	public List<String> getMgrAprvlL2Email() {
		return mgrAprvlL2Email;
	}

	public void setMgrAprvlL2Email(List<String> mgrAprvlL2Email) {
		this.mgrAprvlL2Email = mgrAprvlL2Email;
	}

	public List<String> getMgrAprvlL3Email() {
		return mgrAprvlL3Email;
	}

	public void setMgrAprvlL3Email(List<String> mgrAprvlL3Email) {
		this.mgrAprvlL3Email = mgrAprvlL3Email;
	}

	public String getVarEmailAddress() {
		return varEmailAddress;
	}

	public void setVarEmailAddress(String varEmailAddress) {
		this.varEmailAddress = varEmailAddress;
	}
	
	private DgfFieldShort variableEmailAddress;


	public DgfFieldShort getVariableEmailAddress() {
		return variableEmailAddress;
	}

	public void setVariableEmailAddress(DgfFieldShort variableEmailAddress) {
		if(isVariableEmailSetInDgfField(variableEmailAddress)){
			this.variableEmailAddress = variableEmailAddress;
		}
	}
	
	private boolean isVariableEmailSetInDgfField(DgfFieldShort managerApproval) {
		String dgfDataType = null;
		if (managerApproval != null) {
			dgfDataType = managerApproval.getDgfDataType();
		}
		if(dgfDataType !=null && !StringUtils.isBlank(dgfDataType) 
				&& (Constants.INPUT_TEXT.equals(dgfDataType)
				|| Constants.EMAIL_DOMAIN.equals(dgfDataType)
				|| Constants.DROPDOWN.equals(dgfDataType)
				|| Constants.NONE.equals(dgfDataType))){
			return true;
		}
		return false;
	}*/
}
