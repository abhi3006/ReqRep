package com.vzw.mybiz.approval.service;

import com.vzw.mybiz.prospect.domain.duns.AddressServiceRequest;
import com.vzw.mybiz.prospect.domain.duns.AddressServiceResponse;
import com.vzw.mybiz.prospect.domain.duns.StandardizedAddressServiceRequest;

public interface DunsService {

	AddressServiceResponse getAddressMatchService(AddressServiceRequest addMatchReq);

	AddressServiceResponse getStandardizedAddressService(StandardizedAddressServiceRequest stndAddressReq);

}
