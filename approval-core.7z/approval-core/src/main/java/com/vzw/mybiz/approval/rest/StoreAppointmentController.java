package com.vzw.mybiz.approval.rest;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vzw.mybiz.approval.common.Constants;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentDetail;
import com.vzw.mybiz.approval.domain.storeAppointment.AppointmentResponse;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentRequest;
import com.vzw.mybiz.approval.domain.storeAppointment.RCWS.StoreAppointmentResponse;
import com.vzw.mybiz.approval.exception.StoreAppointmentException;
import com.vzw.mybiz.approval.service.AppointmentRestService;
import com.vzw.mybiz.utilities.audit.domain.ServiceStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

@RestController
@RequestMapping("mbt/appointments")
public class StoreAppointmentController {

	@Autowired
	AppointmentRestService appointmentRestService;

	private static final Logger LOGGER = LoggerFactory.getLogger(StoreAppointmentController.class);

	@PostMapping(value = "/scheduleAppointment", produces = MediaType.APPLICATION_JSON_VALUE)
	public AppointmentResponse saveAndSchedule(@RequestBody AppointmentDetail appointmentDetail)
			throws StoreAppointmentException {
		LOGGER.info("INSIDE scheduleApointment of Controller");
		AppointmentResponse appointmentResponse = appointmentRestService.saveAndSchedule(appointmentDetail);
		if(appointmentResponse == null) {
			LOGGER.info("INSIDE scheduleApointment of Controller : Failed to schedule appointment");
			appointmentResponse = new AppointmentResponse();
			ServiceStatus serviceStatus = new ServiceStatus();
			serviceStatus.setStatusMessage(Constants.FAIL_STATUS);
			serviceStatus.setStatusCode(Constants.FAILURE_CODE);
			serviceStatus.setSuccess(false);
			serviceStatus.setMessage(Constants.SCHEDULE_APPOINTMENT_FAIL);
			
			appointmentResponse.setServiceStatus(serviceStatus);
		}
		return appointmentResponse;

	}
	
	@PostMapping(value = "/loadStore",produces =  MediaType.APPLICATION_JSON_VALUE)
	public StoreAppointmentResponse getStoreForAppointment(@RequestBody StoreAppointmentRequest request) {
		StoreAppointmentResponse response = new StoreAppointmentResponse();
		ServiceStatus serviceStatus = new ServiceStatus();
		
		try {
			response = appointmentRestService.getStoreById(request);
		}catch(Exception e) {
			serviceStatus = populateStatus("FAILED TO GET STORE", "200", "FAILED", false);
			response.setServiceStatus(serviceStatus);
		}
		LOGGER.debug("OUTSIDE loadAppointmentDetails");
		
		
		
		return response;
		
	}

	private ServiceStatus populateStatus(String message, String statusCore, String statusMessage, boolean statusFlag) {
	ServiceStatus serviceStatus = new ServiceStatus();
	serviceStatus.setMessage(message);//Constants.STR_STATUS_MESSAGE
	serviceStatus.setStatusCode(statusCore);// Constants.STATUS_CODE_200
	serviceStatus.setStatusMessage(statusMessage);// Constants.STATUS_SUCCESS
	serviceStatus.setSuccess(statusFlag);
	return serviceStatus;
}


}
