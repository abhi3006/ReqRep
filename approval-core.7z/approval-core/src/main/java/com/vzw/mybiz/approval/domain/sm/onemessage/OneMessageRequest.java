package com.vzw.mybiz.approval.domain.sm.onemessage;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonAutoDetect
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OneMessageRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	private String confirmationNumber;
	private String Status;
	private String tranType; // line or account
	private List<FeatureInfo> addedFeaturesList;
	private List<FeatureInfo> removedFeaturesList;
	private List<String> confirmationEmail; // csv string

	private String loggedInUserId;
	//sent it from UI
	private String loggedInUserFirstName;
	private String loggedInUserLastName;
	private int totalLinesCount;
	private int totalLinesSuccess;
	private int totalLinesFailed;
	
	
	public final void setTotalLinesCount(int totalLinesCount) {
		this.totalLinesCount = totalLinesCount;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}


	public String getLoggedInUserId() {
		return loggedInUserId;
	}

	public void setLoggedInUserId(String loggedInUserId) {
		this.loggedInUserId = loggedInUserId;
	}

	public String getLoggedInUserFirstName() {
		return loggedInUserFirstName;
	}

	public void setLoggedInUserFirstName(String loggedInUserFirstName) {
		this.loggedInUserFirstName = loggedInUserFirstName;
	}

	public String getLoggedInUserLastName() {
		return loggedInUserLastName;
	}

	public void setLoggedInUserLastName(String loggedInUserLastName) {
		this.loggedInUserLastName = loggedInUserLastName;
	}


	
	
	public List<FeatureInfo> getAddedFeaturesList() {
		return addedFeaturesList;
	}

	public void setAddedFeaturesList(List<FeatureInfo> addedFeaturesList) {
		this.addedFeaturesList = addedFeaturesList;
	}

	public List<FeatureInfo> getRemovedFeaturesList() {
		return removedFeaturesList;
	}

	public void setRemovedFeaturesList(List<FeatureInfo> removedFeaturesList) {
		this.removedFeaturesList = removedFeaturesList;
	}

	/**
	 * @return the confirmationEmail
	 */
	public final List<String> getConfirmationEmail() {
		return confirmationEmail;
	}

	/**
	 * @param confirmationEmail the confirmationEmail to set
	 */
	public final void setConfirmationEmail(List<String> confirmationEmail) {
		this.confirmationEmail = confirmationEmail;
	}

	/**
	 * @param confirmationEmail the confirmationEmail to set
	 */
	
	/**
	 * @return the totalLinesCount
	 */
	public final int getTotalLinesCount() {
		return totalLinesCount;
	}

	/**
	 * @param totalLinesCount the totalLinesCount to set
	 * 
	 * 
	 */
	/**
	 * @return the totalLinesSuccess
	 */
	public final int getTotalLinesSuccess() {
		return totalLinesSuccess;
	}

	/**
	 * @param totalLinesSuccess the totalLinesSuccess to set
	 */
	public final void setTotalLinesSuccess(int totalLinesSuccess) {
		this.totalLinesSuccess = totalLinesSuccess;
	}

	/**
	 * @return the totalLinesFailed
	 */
	public final int getTotalLinesFailed() {
		return totalLinesFailed;
	}

	/**
	 * @param totalLinesFailed the totalLinesFailed to set
	 */
	public final void setTotalLinesFailed(int totalLinesFailed) {
		this.totalLinesFailed = totalLinesFailed;
	}

}
