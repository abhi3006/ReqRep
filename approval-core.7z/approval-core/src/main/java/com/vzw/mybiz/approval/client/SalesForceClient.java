package com.vzw.mybiz.approval.client;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;

import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceRequest;
import com.vzw.mybiz.approval.domain.storeAppointment.SalesForceResponse;

import feign.HeaderMap;
import feign.RequestLine;

public interface SalesForceClient {
	
	@RequestLine("POST /services/apexrest/MybizStoreLocator")
	@PostMapping()
	public SalesForceResponse sendDetailToSf(SalesForceRequest salesForceRequest, @HeaderMap Map<String, Object> headerMap);

}
