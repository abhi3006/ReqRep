package com.vzw.mybiz.approval.exception;

public class VipFeignException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VipFeignException(Throwable exception) {
		super(exception);
	}

	public VipFeignException(String message) {
		super(message);
	}
}
