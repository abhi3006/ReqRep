/**
 * 
 */
package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * @author nandbi6
 *
 */
@Getter
@Setter
public class AutoNotificationRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int reminderFromDays;
	private int reminderToDays;
	private String templateType;
	private String requester;
	private String notificationType;
	private String notificationTemplate;
	private String reminderNumber;
	private String resetParamValue;
	private String mailFrom;
	private String usernotificationflag;
	private String myBusinessIds;
	private Long scheduleLogId;

}
