package com.vzw.mybiz.approval.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.vzw.mybiz.approval.constant.Constant;
import com.vzw.mybiz.approval.domain.sm.AccountLineItem;
import com.vzw.mybiz.approval.domain.sm.SMOrderResponse;
import com.vzw.mybiz.approval.domain.sm.ma.ui.SystemTxnInfoForResume;
import com.vzw.mybiz.approval.domain.sm.transorder.OrderDetailsResponse;
import com.vzw.mybiz.approval.domain.sm.transorder.SystemTxnInfo;

public class GenerateSusResOrderDetailSM {
	
	public static void setAccountLineItemResponseForRES(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsSMList = new ArrayList<AccountLineItem>();
		Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfoForResume>>();

		groupAccountOrderDetails(orderDetailsResponse, accountOrderDetailsMap,Constant.RES_TRANSACTION_TYPE);

		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<LinkedHashMap<String, String>>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<String, String>();

							detailMap.put(Constant.ACC_LINE_ITEM_MTN, detailInfo.getServiceNumber());
							detailMap.put(Constant.ACC_LINE_ITEM_USER_NAME, detailInfo.getSubscriberName());
							detailMap.put(Constant.ACC_LINE_ITEM_REASON, detailInfo.getReasonForSuspend());

							detailMap.put(Constant.ACC_LINE_ITEM_BILLING, detailInfo.getSuspendBilling());
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsSMList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsSMList);
		}
	}
	
	private static void groupAccountOrderDetails(OrderDetailsResponse orderDetailsResponse,
			Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap,String transactionType) {
        List<SystemTxnInfo> orderItemList = new ArrayList<>();
		
		for(SystemTxnInfo sysInfo: orderDetailsResponse.getOrderDetailsList()) {			
			orderItemList.add(sysInfo);
		}
		List<String> accountNumberList = new ArrayList<>();
		Map<String, List<SystemTxnInfo>> accountResumeMap = new HashMap<>();
		for (SystemTxnInfo systemTxnIfo : orderItemList) {
			if (!accountNumberList.contains(systemTxnIfo.getAccountNumber())) {
				accountNumberList.add(systemTxnIfo.getAccountNumber());
				List<SystemTxnInfo> filteredFeatureInfo = orderItemList.stream().filter(feature -> {
					return feature.getAccountNumber().equalsIgnoreCase(systemTxnIfo.getAccountNumber());
				}).collect(Collectors.toList());
				accountResumeMap.put(systemTxnIfo.getAccountNumber(), filteredFeatureInfo);
			}
		}
		if (!accountResumeMap.isEmpty()) {
			filterItemValues(accountResumeMap,accountOrderDetailsMap,transactionType);
		}
	}
	
private static void filterItemValues(Map<String, List<SystemTxnInfo>> accountResumeMap,Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap,String transactionType) {	
	accountResumeMap.entrySet().forEach(productMap -> {
			List<SystemTxnInfo> reasonForSuspendList = new ArrayList<>();
			List<SystemTxnInfo> suspendBillingList = new ArrayList<>();
			List<SystemTxnInfo> reconnectDateList = new ArrayList<>();
			productMap.getValue().stream().forEach(product -> {
				if (StringUtils.equalsIgnoreCase(Constant.ACTION_TYPE_REASON,product.getDetailType())) {
					reasonForSuspendList.add(product);
				} else if (StringUtils.equalsIgnoreCase(Constant.ACTION_TYPE_BILLING,product.getDetailType())) {
					suspendBillingList.add(product);
				} else if(StringUtils.equalsIgnoreCase(Constant.ACTION_TYPE_RECONNECT_DATE,product.getDetailType())) {
					reconnectDateList.add(product);
				}
			});		
			if(StringUtils.equalsIgnoreCase(Constant.RES_TRANSACTION_TYPE,transactionType)) {
				buildRESResponse(productMap.getKey(),reasonForSuspendList,suspendBillingList,accountOrderDetailsMap);
			} else if(StringUtils.equalsIgnoreCase(Constant.SUS_TRANSACTION_TYPE,transactionType)) {
				buildSUSResponse(productMap.getKey(),reconnectDateList,reasonForSuspendList,suspendBillingList,accountOrderDetailsMap);
			}
			
		});	
	}
	private static void buildRESResponse(String account,List<SystemTxnInfo> reasonForSuspendList,List<SystemTxnInfo> suspendBillingList,Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap) {
		accountOrderDetailsMap.put(account, new ArrayList<SystemTxnInfoForResume>());
		for(int i=0;i<suspendBillingList.size();i++) {			
			SystemTxnInfoForResume line = new SystemTxnInfoForResume();			
            line.setServiceNumber( suspendBillingList.get(i).getServiceNumber());
 			line.setSubscriberName(suspendBillingList.get(i).getSubscriberName());
 			line.setSuspendBilling(suspendBillingList.get(i).getItemName());
 			if(reasonForSuspendList.isEmpty()) {
 				line.setReasonForSuspend("N/A");
 			}else {
 				line.setReasonForSuspend(reasonForSuspendList.get(i).getItemName());
 			}					
 			accountOrderDetailsMap.get(account).add(line);
		}
	}

	private static void buildSUSResponse(String account,List<SystemTxnInfo> reconnectDateList,List<SystemTxnInfo> reasonForSuspendList,List<SystemTxnInfo> suspendBillingList,Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap) {
		accountOrderDetailsMap.put(account, new ArrayList<SystemTxnInfoForResume>());
		for(int i=0;i<suspendBillingList.size();i++) {			
			SystemTxnInfoForResume line = new SystemTxnInfoForResume();			
            line.setServiceNumber( suspendBillingList.get(i).getServiceNumber());
 			line.setSubscriberName(suspendBillingList.get(i).getSubscriberName());
 			line.setSuspendBilling(suspendBillingList.get(i).getItemName());
 			line.setReasonForSuspend(reasonForSuspendList.get(i).getItemName());
 			if(reconnectDateList.isEmpty()) {
 				line.setReconnectDate("N/A");
 			}else {
 				line.setReconnectDate(reconnectDateList.get(i).getItemName());
 			} 			
 			accountOrderDetailsMap.get(account).add(line);
		}
	}
	public static void setAccountLineItemResponseForSuspend(OrderDetailsResponse orderDetailsResponse,
			SMOrderResponse smOrderResponse) {
		List<AccountLineItem> mtnDetailsSMList = new ArrayList<AccountLineItem>();
		Map<String, List<SystemTxnInfoForResume>> accountOrderDetailsMap = new LinkedHashMap<String, List<SystemTxnInfoForResume>>();
		groupAccountOrderDetails(orderDetailsResponse, accountOrderDetailsMap, Constant.SUS_TRANSACTION_TYPE);
		if (!accountOrderDetailsMap.isEmpty()) {
			accountOrderDetailsMap.entrySet().forEach(accountOrderDetails -> {
				if (accountOrderDetails != null) {
					AccountLineItem accountLineItem = new AccountLineItem();
					List<LinkedHashMap<String, String>> orderDetailsList = new ArrayList<LinkedHashMap<String, String>>();

					accountOrderDetails.getValue().stream().forEach(detailInfo -> {
						if (detailInfo != null) {
							LinkedHashMap<String, String> detailMap = new LinkedHashMap<String, String>();
							detailMap.put(Constant.ACC_LINE_ITEM_MTN, detailInfo.getServiceNumber());
							detailMap.put(Constant.ACC_LINE_ITEM_USER_NAME, detailInfo.getSubscriberName());
							detailMap.put(Constant.ACC_LINE_ITEM_REASON, detailInfo.getReasonForSuspend());
							detailMap.put(Constant.ACC_LINE_ITEM_SUS_BILLING, detailInfo.getSuspendBilling());
							detailMap.put(Constant.ACC_LINE_ITEM_RECONNECT_DATE,detailInfo.getReconnectDate());
							orderDetailsList.add(detailMap);
						}
					});
					accountLineItem.setAccountNumber(accountOrderDetails.getKey());
					accountLineItem.setMtnDetailsSMList(orderDetailsList);
					mtnDetailsSMList.add(accountLineItem);
				}
			});
			smOrderResponse.setAccountLineItemList(mtnDetailsSMList);
		}
	}
}
