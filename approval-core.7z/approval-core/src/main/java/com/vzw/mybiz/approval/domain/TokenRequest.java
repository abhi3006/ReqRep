package com.vzw.mybiz.approval.domain;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class TokenRequest implements Serializable {

	private static final long serialVersionUID = 8036431950750481731L;
	private String userId;
	private String ecpdId;
	private String orderNum;

}
