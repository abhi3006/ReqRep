package com.vz.wm.controller;

import java.util.List;

import com.vz.wm.entity.ServiceRequestEntity;
import com.vz.wm.service.IServiceRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("serviceRequest")
public class ServiceRequestController {
	@Autowired
	private IServiceRequestService iServiceRequestService;

	@GetMapping(value={"article/ecpdId"}, produces={"application/json","application/xml"})
	public ResponseEntity<ServiceRequestEntity> getByEcpdId(@PathVariable("ecpdId") Integer ecpdId) {
		ServiceRequestEntity serviceRequestEntity = iServiceRequestService.getByEcpdId(ecpdId);
		return new ResponseEntity<ServiceRequestEntity>(serviceRequestEntity, HttpStatus.OK);
	}



	@GetMapping("articles")
	public ResponseEntity<List<ServiceRequestEntity>> getAllList() {
		List<ServiceRequestEntity> list = iServiceRequestService.getAllList();
		return new ResponseEntity<List<ServiceRequestEntity>>(list, HttpStatus.OK);
	}

}