package com.vz.wm.repo;

import java.util.List;

import com.vz.wm.entity.ServiceRequestEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceRequestRepository extends CrudRepository<ServiceRequestEntity, Integer> {


}
