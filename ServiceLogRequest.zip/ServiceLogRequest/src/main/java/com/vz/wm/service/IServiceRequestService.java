package com.vz.wm.service;

import java.util.List;

import com.vz.wm.entity.ServiceRequestEntity;

public interface IServiceRequestService {
     List<ServiceRequestEntity> getAllList();
     ServiceRequestEntity getByEcpdId(Integer articleId);
}
