package com.vz.wm.service;

import java.util.ArrayList;
import java.util.List;

import com.vz.wm.entity.ServiceRequestEntity;
import com.vz.wm.repo.ServiceRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceRequestService implements IServiceRequestService {
	@Autowired
	private ServiceRequestRepository requestRepository;

	@Override
	public ServiceRequestEntity getByEcpdId(Integer ecpdId) {
		ServiceRequestEntity obj = requestRepository.findById(ecpdId).get();
		return obj;
	}

	@Override
	public List<ServiceRequestEntity> getAllList() {
		List<ServiceRequestEntity> list = new ArrayList<>();
		requestRepository.findAll().forEach(e -> list.add(e));
		return list;
	}


}
