# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

Import Postman Dump

https://go.postman.co/workspace/My-Workspace~aded889f-94af-4fd6-84d9-634e6d6fa8a7/collection/17687162-039fe242-4464-472f-8df0-8814537d8e72


POST - http://127.0.0.1:8080/servicetracker/getstlist
Body input:
{
    "pageSize" : "10",
    "pageNo" : "0",
    "searchOptions":[
        {
            "columnName": "status",
            "orderBy": "asc",
            "filerValue": "SYNC_COMPLETE"
        },
        {
            "columnName": "updatedatetime",
            "orderBy": "asc",
            "filerValue": "20"
        }
    ]
}
GET - http://127.0.0.1:8080/servicetracker/getstlist



