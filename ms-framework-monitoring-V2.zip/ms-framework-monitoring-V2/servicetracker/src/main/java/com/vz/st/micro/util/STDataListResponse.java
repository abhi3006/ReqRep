package com.vz.st.micro.util;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.st.micro.domain.ServiceTrackerInfo;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class STDataListResponse {
	
	private Long totalElements;
	private Integer pageSize;
	private Integer totalPages;
	private Integer currentPageNo;
	private List<ServiceTrackerInfo> data;
	
	
	public List<ServiceTrackerInfo> getData() {
		return data;
	}
	public void setData(List<ServiceTrackerInfo> data) {
		this.data = data;
	}
	public Long getTotalElements() {
		return totalElements;
	}
	public void setTotalElements(Long total) {
		this.totalElements = total;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}
	public Integer getCurrentPageNo() {
		return currentPageNo;
	}
	public void setCurrentPageNo(Integer currentPageNo) {
		this.currentPageNo = currentPageNo;
	}
	

}
