package com.vz.st.micro.util;

import java.util.List;


public class ServiceTrackerPage {

	private List<SearchOptionsDto> searchOptions;
	private Integer pageSize;
	private Integer pageNo;

	public List<SearchOptionsDto> getSearchOptions() {
		return searchOptions;
	}

	public void setSearchOptions(List<SearchOptionsDto> searchOptions) {
		this.searchOptions = searchOptions;
	}
	
	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	

}
