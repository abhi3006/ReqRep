package com.vz.st.micro.util;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.st.micro.domain.ServiceTrackerInfo;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataList {
	private List<ServiceTrackerInfo> data;

	public List<ServiceTrackerInfo> getData() {
		return data;
	}

	public void setData(List<ServiceTrackerInfo> data) {
		this.data = data;
	}
}
