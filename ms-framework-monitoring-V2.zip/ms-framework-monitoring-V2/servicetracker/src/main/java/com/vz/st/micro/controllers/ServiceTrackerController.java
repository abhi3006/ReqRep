package com.vz.st.micro.controllers;

import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.st.micro.exception.ServiceTrackerServiceException;
import com.vz.st.micro.services.ServiceTrackerService;
import com.vz.st.micro.util.STDataListResponse;
import com.vz.st.micro.util.ServiceTrackerPage;

/**
 * Created by Adil on 10/23/21.
 */
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ServiceTrackerController {

	private static final Logger logger = LogManager.getLogger(ServiceTrackerController.class);

	private final ServiceTrackerService serviceTrackerService;
	
	private ServiceTrackerController(ServiceTrackerService service) {
		this.serviceTrackerService=service;
	}


	@RequestMapping(value = { "/getstlist" }, method = RequestMethod.GET, produces = { "application/json" })
	public ResponseEntity<STDataListResponse> getServiceTracker(
			@RequestBody(required = false) ServiceTrackerPage request) {
		if (request==null) {
			request= new ServiceTrackerPage();
			request.setPageNo(0);
			request.setPageSize(10);
		}
		return serviceTrackerService.getServiceTrackerlist(request);
	}
	
	@RequestMapping(value = { "/getstlist" }, method = RequestMethod.POST, produces = { "application/json" },consumes = { "application/json" })
	public ResponseEntity<STDataListResponse> postServiceTacker(
			@RequestBody(required = false) ServiceTrackerPage request) {
		Optional<Integer> optPn = Optional.ofNullable(request.getPageNo());
		Optional<Integer> optPs = Optional.ofNullable(request.getPageSize());
		if (!optPs.isPresent() || !optPn.isPresent()) {
			throw new ServiceTrackerServiceException("Page-number or Page-size is null or empty");
		}
		return serviceTrackerService.getServiceTrackerlist(request);
	}


}
