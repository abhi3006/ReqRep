package com.vz.st.micro.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "SERVICE_TRACKING_INFO")
public class ServiceTrackerInfo {

	@NotNull
	@Column(name = "TRACKING_ID")
	private String trackingId;

	@Id
	@Column(name = "SERVICE_ID")
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE) 
	private Long serviceId;

	@NotNull
	@Column(name = "MESSAGE_ID")
	private String messageId;

	@Column(name = "ID_NAME1")
	private String idName1;

	@Column(name = "ID_VAL1")
	private String idVal1;

	@Column(name = "ID_NAME2")
	private String idName2;

	@Column(name = "ID_VAL2")
	private String idVal2;

	@Column(name = "ID_NAME3")
	private String idName3;

	@Column(name = "ID_VAL3")
	private String idVal3;

	@Column(name = "CONSUMER")
	private String consumer;

	@NotNull
	@Column(name = "STATUS")
	private String status;

	@NotNull
	@Column(name = "REQ_RECEIVED_DATE_TIME")
	private Timestamp receiveDate;

	@Column(name = "RESP_SENT_TIME")
	private Timestamp responseDate;

	@Column(name = "TOTAL_TIME")
	private Integer tTime;

	@Column(name = "ASYNC_STATUS")
	private String asyncStatus;

	@Column(name = "TIME_TO_RESPOND")
	private Integer timeToRespond;

	@Column(name = "RESP_TIME_ALERT")
	private String rtAlert;

	@Column(name = "RESP_SIZE_ALERT")
	private String rsAlert;

	@Column(name = "EXCEPTION")
	private String exception;

	@Lob
	@Basic(fetch = FetchType.LAZY)
	@Column(name = "EXECUTION_FLOW")
	private String exectuionFlow;

	@Column(name = "COMPLETED_DATE_TIME")
	private Date compDateTime;

	@NotNull
	@Column(name = "UPDATED_DATE_TIME")
	private Date updateDateTime;

	public String getTrackingId() {
		return trackingId;
	}

	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}

	public Long getServiceId() {
		return serviceId;
	}

	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getIdName1() {
		return idName1;
	}

	public void setIdName1(String idName1) {
		this.idName1 = idName1;
	}

	public String getIdVal1() {
		return idVal1;
	}

	public void setIdVal1(String idVal1) {
		this.idVal1 = idVal1;
	}

	public String getIdName2() {
		return idName2;
	}

	public void setIdName2(String idName2) {
		this.idName2 = idName2;
	}

	public String getIdVal2() {
		return idVal2;
	}

	public void setIdVal2(String idVal2) {
		this.idVal2 = idVal2;
	}

	public String getIdName3() {
		return idName3;
	}

	public void setIdName3(String idName3) {
		this.idName3 = idName3;
	}

	public String getIdVal3() {
		return idVal3;
	}

	public void setIdVal3(String idVal3) {
		this.idVal3 = idVal3;
	}

	public String getConsumer() {
		return consumer;
	}

	public void setConsumer(String consumer) {
		this.consumer = consumer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(Timestamp receiveDate) {
		this.receiveDate = receiveDate;
	}

	public Timestamp getResponseDate() {
		return responseDate;
	}

	public void setResponseDate(Timestamp responseDate) {
		this.responseDate = responseDate;
	}

	public Integer gettTime() {
		return tTime;
	}

	public void settTime(Integer tTime) {
		this.tTime = tTime;
	}

	public String getAsyncStatus() {
		return asyncStatus;
	}

	public void setAsyncStatus(String asyncStatus) {
		this.asyncStatus = asyncStatus;
	}

	public Integer getTimeToRespond() {
		return timeToRespond;
	}

	public void setTimeToRespond(Integer timeToRespond) {
		this.timeToRespond = timeToRespond;
	}

	public String getRtAlert() {
		return rtAlert;
	}

	public void setRtAlert(String rtAlert) {
		this.rtAlert = rtAlert;
	}

	public String getRsAlert() {
		return rsAlert;
	}

	public void setRsAlert(String rsAlert) {
		this.rsAlert = rsAlert;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getExectuionFlow() {
		return exectuionFlow;
	}

	public void setExectuionFlow(String exectuionFlow) {
		this.exectuionFlow = exectuionFlow;
	}

	public Date getCompDateTime() {
		return compDateTime;
	}

	public void setCompDateTime(Date compDateTime) {
		this.compDateTime = compDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

}
