package com.vz.st.micro.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.persistence.Tuple;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.vz.st.micro.domain.ServiceTrackerInfo;
import com.vz.st.micro.repositories.ServiceTrackerInfoRepository;
import com.vz.st.micro.util.STDataListResponse;
import com.vz.st.micro.util.ServiceTrackerPage;

/**
 * Created by Adil
 */
@Service
public class ServiceTrackerServiceImpl implements ServiceTrackerService {

	private static final Logger logger = LogManager.getLogger(ServiceTrackerServiceImpl.class);

	@Autowired
	ServiceTrackerInfoRepository serviceTrackerRepo;

	@Override
	@Transactional(readOnly = true)
	public ResponseEntity getServiceTrackerlist(ServiceTrackerPage request) {
		TimeZone.setDefault( TimeZone.getTimeZone("UTC"));
		Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
		Page<ServiceTrackerInfo> pagedResult = findByCriteria(request, paging);
		List<ServiceTrackerInfo> mapList = null;
		if (pagedResult.hasContent()) {
			mapList = pagedResult.getContent();
		}
		STDataListResponse sdResponse = new STDataListResponse();
		sdResponse.setTotalElements(pagedResult.getTotalElements());
		sdResponse.setPageSize(pagedResult.getSize());
		sdResponse.setTotalPages(pagedResult.getTotalPages());
		sdResponse.setCurrentPageNo(pagedResult.getNumber());
		sdResponse.setData(mapList);
		return new ResponseEntity<>(sdResponse, HttpStatus.OK);

	}

	public Page<ServiceTrackerInfo> findByCriteria(ServiceTrackerPage request, Pageable pageable) {

		Page page = serviceTrackerRepo.findAll((Specification<ServiceTrackerInfo>) (root, query, criteriaBuilder) -> {
			List<Predicate> predicates = new ArrayList<>();
			List<Predicate> preds = createPredicate(root, criteriaBuilder, query, request);
			predicates.addAll(preds);

			return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
		}, pageable);
		return page;
	}

	private List<Predicate> createPredicate(Root<ServiceTrackerInfo> root, CriteriaBuilder criteriaBuilder,
			CriteriaQuery<?> query, ServiceTrackerPage request) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			if (!CollectionUtils.isEmpty(request.getSearchOptions())) {
				final boolean[] sorted = { false };
				request.getSearchOptions().stream().forEach(option -> {
					String colName = option.getColumnName().toLowerCase();
					String order = option.getOrderBy();
					String filterData = option.getFilerValue() != null ? option.getFilerValue().toLowerCase() : "";
					switch (colName) {
					case "exception":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("exception"))
									: criteriaBuilder.asc(root.get("exception")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("exception")), "%" + filterData + "%")));
						}
						break;
				
					case "trackingid":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("trackingId"))
									: criteriaBuilder.asc(root.get("trackingId")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("trackingId")), "%" + filterData + "%")));
						}
						break;
						
					case "serviceid":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("serviceId"))
									: criteriaBuilder.asc(root.get("serviceId")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("serviceId").as(String.class)), "%" + filterData + "%")));
						}
						break;
					case "messageid":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("messageId"))
									: criteriaBuilder.asc(root.get("messageId")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("messageId")), "%" + filterData + "%")));
						}
						break;
					case "idname1":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idName1"))
									: criteriaBuilder.asc(root.get("idName1")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idName1")), "%" + filterData + "%")));
						}
						break;
					case "idname2":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idName2"))
									: criteriaBuilder.asc(root.get("idName2")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idName2")), "%" + filterData + "%")));
						}
						break;
					case "idname3":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idName3"))
									: criteriaBuilder.asc(root.get("idName3")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idName3")), "%" + filterData + "%")));
						}
						break;
					case "idval1":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idVal1"))
									: criteriaBuilder.asc(root.get("idVal1")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idVal1")), "%" + filterData + "%")));
						}
						break;
					case "idval2":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idVal2"))
									: criteriaBuilder.asc(root.get("idVal2")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idVal2")), "%" + filterData + "%")));
						}
						break;
					case "idval3":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("idVal3"))
									: criteriaBuilder.asc(root.get("idVal3")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("idVal3")), "%" + filterData + "%")));
						}
						break;

					case "consumer":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("consumer"))
									: criteriaBuilder.asc(root.get("consumer")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("consumer")), "%" + filterData + "%")));
						}
						break;
					case "status":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("status"))
									: criteriaBuilder.asc(root.get("status")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("status")), "%" + filterData + "%")));
						}
						break;
					case "ttime":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("tTime"))
									: criteriaBuilder.asc(root.get("tTime")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("tTime")), "%" + filterData + "%")));
						}
						break;
					case "asyncstatus":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("asyncStatus"))
									: criteriaBuilder.asc(root.get("asyncStatus")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("asyncStatus")), "%" + filterData + "%")));
						}
						break;
					case "timetorespond":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(
									order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("timeToRespond"))
											: criteriaBuilder.asc(root.get("timeToRespond")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("timeToRespond")), "%" + filterData + "%")));
						}
						break;
					case "rtalert":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("rtAlert"))
									: criteriaBuilder.asc(root.get("rtAlert")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("rtAlert")), "%" + filterData + "%")));
						}
						break;
					case "rsalert":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("rsAlert"))
									: criteriaBuilder.asc(root.get("rsAlert")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("rsAlert")), "%" + filterData + "%")));
						}
						break;
					case "errordoc":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("errorDoc"))
									: criteriaBuilder.asc(root.get("errorDoc")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("errorDoc")), "%" + filterData + "%")));
						}
						break;
					case "receivedate":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(
									order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.<Date>get("receiveDate"))
											: criteriaBuilder.asc(root.<Date>get("receiveDate")));
						}
						if (filterData != null && !filterData.equals("")) {
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("receiveDate"), criteriaBuilder.literal("MM/dd/yyyy HH:MI:ss"));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					case "responsedate":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc")
									? criteriaBuilder.desc(root.<Date>get("responseDate"))
									: criteriaBuilder.asc(root.<Date>get("responseDate")));
						}
						if (filterData != null && !filterData.equals("")) {
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("responseDate"), criteriaBuilder.literal("MM/dd/yyyy "));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					case "compdatetime":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc")
									? criteriaBuilder.desc(root.<Date>get("compDateTime"))
									: criteriaBuilder.asc(root.<Date>get("compDateTime")));
						}
						if (filterData != null && !filterData.equals("")) {
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("compDateTime"), criteriaBuilder.literal("MM/dd/yyyy HH:MI:ss"));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					case "updatedatetime":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc")
									? criteriaBuilder.desc(root.<Date>get("updateDateTime"))
									: criteriaBuilder.asc(root.<Date>get("updateDateTime")));
						}
						if (filterData != null && !filterData.equals("")) { 
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("updateDateTime"), criteriaBuilder.literal("MM/dd/yyyy"));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					}
				});
			}
		} catch (Exception ex) {
			logger.info("Exception in create predicate");
		}
		return predicates;
	}

}
