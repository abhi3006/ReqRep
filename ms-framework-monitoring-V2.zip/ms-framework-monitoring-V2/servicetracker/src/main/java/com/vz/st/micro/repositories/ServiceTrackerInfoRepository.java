package com.vz.st.micro.repositories;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;

import com.vz.st.micro.domain.ServiceTrackerInfo;

/**
 * Created by Adil 10/20/2021.
 */
public interface ServiceTrackerInfoRepository extends CrudRepository<ServiceTrackerInfo,Integer>,JpaSpecificationExecutor<ServiceTrackerInfo>{
}
