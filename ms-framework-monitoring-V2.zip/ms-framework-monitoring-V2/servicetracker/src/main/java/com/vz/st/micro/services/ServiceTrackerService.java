package com.vz.st.micro.services;

import org.springframework.http.ResponseEntity;

import com.vz.st.micro.util.ServiceTrackerPage;

/**
 * Created by Adil on 10/21/2021.
 */
public interface ServiceTrackerService {

	ResponseEntity getServiceTrackerlist(ServiceTrackerPage request);
}
