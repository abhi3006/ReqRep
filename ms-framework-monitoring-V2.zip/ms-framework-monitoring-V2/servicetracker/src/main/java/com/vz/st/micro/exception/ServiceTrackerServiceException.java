package com.vz.st.micro.exception;

public class ServiceTrackerServiceException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1593566355829445772L;

	public ServiceTrackerServiceException(String message) {
		super(message);
	}

	public ServiceTrackerServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
