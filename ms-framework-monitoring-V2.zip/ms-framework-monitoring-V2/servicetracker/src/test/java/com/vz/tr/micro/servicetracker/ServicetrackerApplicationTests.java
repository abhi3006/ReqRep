package com.vz.tr.micro.servicetracker;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicetrackerApplicationTests {

	
}
