package com.vz.sd.exception;

public class ServiceRegistryDisplayServiceException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1593566355829445772L;

	public ServiceRegistryDisplayServiceException(String message) {
		super(message);
	}

	public ServiceRegistryDisplayServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
