package com.vz.sd.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.vz.sd.beans.ServiceRegistryRequest;
import com.vz.sd.entity.ServiceRegistryEntity;
import com.vz.sd.repo.ServiceRegistryRepo;
import com.vz.sd.util.SRDataListResponse;
import com.vz.sd.util.ServiceRegistryPage;

@Service
public class ServiceRegistryServiceImpl implements ServiceRegistryService {
	@Autowired
	ServiceRegistryRepo serviceRegistryRepo;

	private static final Logger log = LoggerFactory.getLogger(ServiceRegistryService.class);

	public List<ServiceRegistryEntity> listAll() {
		List<ServiceRegistryEntity> products = new ArrayList<>();
		serviceRegistryRepo.findAll().forEach(products::add); // fun with Java 8
		return products;
	}

	@Override
	@Transactional(readOnly = true)
	public ResponseEntity getServiceRegistrylist(ServiceRegistryPage request) {
		Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
		Page<ServiceRegistryEntity> pagedResult = findByCriteria(request, paging);
		List<ServiceRegistryEntity> mapList = null;
		if (pagedResult.hasContent()) {
			mapList = pagedResult.getContent();
		}
		SRDataListResponse sdResponse = new SRDataListResponse();
		sdResponse.setTotalElements(pagedResult.getTotalElements());
		sdResponse.setPageSize(pagedResult.getSize());
		sdResponse.setTotalPages(pagedResult.getTotalPages());
		sdResponse.setCurrentPageNo(pagedResult.getNumber());
		sdResponse.setData(mapList);
		return new ResponseEntity<>(sdResponse, HttpStatus.OK);

	}

	public Page<ServiceRegistryEntity> findByCriteria(ServiceRegistryPage request, Pageable pageable) {

		Page page = serviceRegistryRepo
				.findAll((Specification<ServiceRegistryEntity>) (root, query, criteriaBuilder) -> {
					List<Predicate> predicates = new ArrayList<>();
					List<Predicate> preds = createPredicate(root, criteriaBuilder, query, request);
					predicates.addAll(preds);

					return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
				}, pageable);
		return page;
	}

	private List<Predicate> createPredicate(Root<ServiceRegistryEntity> root, CriteriaBuilder criteriaBuilder,
			CriteriaQuery query, ServiceRegistryPage request) {
		List<Predicate> predicates = new ArrayList<>();
		try {
			if (!CollectionUtils.isEmpty(request.getSearchOptions())) {
				final boolean[] sorted = { false };
				request.getSearchOptions().stream().forEach(option -> {
					String colName = option.getColumnName().toLowerCase();
					String order = option.getOrderBy();
					String filterData = option.getFilerValue() != null ? option.getFilerValue().toLowerCase() : "";
					switch (colName) {
					case "serviceid":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("serviceId"))
									: criteriaBuilder.asc(root.get("serviceId")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(
									criteriaBuilder.like(criteriaBuilder.lower(root.get("serviceId").as(String.class)),
											"%" + filterData + "%")));
						}
						break;

					case "servicename":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("serviceName"))
									: criteriaBuilder.asc(root.get("serviceName")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("serviceName")), "%" + filterData + "%")));
						}
						break;
					case "version":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("version"))
									: criteriaBuilder.asc(root.get("version")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("version")), "%" + filterData + "%")));
						}
						break;
					case "org":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("org"))
									: criteriaBuilder.asc(root.get("org")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("org")), "%" + filterData + "%")));
						}
						break;
					case "domain":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("domain"))
									: criteriaBuilder.asc(root.get("domain")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("domain")), "%" + filterData + "%")));
						}
						break;
					case "subdomain":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("subDomain"))
									: criteriaBuilder.asc(root.get("subDomain")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("subDomain")), "%" + filterData + "%")));
						}
						break;
					case "isasync":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("isAsync"))
									: criteriaBuilder.asc(root.get("isAsync")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("isAsync")), "%" + filterData + "%")));
						}
						break;
					case "responsespec":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(
									order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("responseSpec"))
											: criteriaBuilder.asc(root.get("responseSpec")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("responseSpec")), "%" + filterData + "%")));
						}
						break;
					case "isactive":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("isActive"))
									: criteriaBuilder.asc(root.get("isActive")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("isActive")), "%" + filterData + "%")));
						}
						break;
					case "createdby":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("createdBy"))
									: criteriaBuilder.asc(root.get("createdBy")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("createdBy")), "%" + filterData + "%")));
						}
						break;
					case "updatedby":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("updatedby"))
									: criteriaBuilder.asc(root.get("updatedby")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("updatedby")), "%" + filterData + "%")));
						}
						break;
					case "vastid":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("vastId"))
									: criteriaBuilder.asc(root.get("vastId")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("vastId")), "%" + filterData + "%")));
						}
						break;
					case "operationname":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(
									order.equalsIgnoreCase("desc") ? criteriaBuilder.desc(root.get("operationName"))
											: criteriaBuilder.asc(root.get("operationName")));
						}
						if (filterData != null && !filterData.equals("")) {
							predicates.add(criteriaBuilder.and(criteriaBuilder
									.like(criteriaBuilder.lower(root.get("operationName")), "%" + filterData + "%")));
						}
						break;
					case "createddatetime":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc")
									? criteriaBuilder.desc(root.<Date>get("createddatetime"))
									: criteriaBuilder.asc(root.<Date>get("createddatetime")));
						}
						if (filterData != null && !filterData.equals("")) {
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("createddatetime"), criteriaBuilder.literal("MM/dd/yyyy"));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					case "updatedatetime":
						if (order != null && !order.equals("")) {
							sorted[0] = true;
							query.orderBy(order.equalsIgnoreCase("desc")
									? criteriaBuilder.desc(root.<Date>get("updatedatetime"))
									: criteriaBuilder.asc(root.<Date>get("updatedatetime")));
						}
						if (filterData != null && !filterData.equals("")) {
							Expression<String> dateStringExpr = criteriaBuilder.function("TO_CHAR", String.class,
									root.get("updatedatetime"), criteriaBuilder.literal("MM/dd/yyyy"));
							if (filterData != null && !filterData.equals("")) {
								predicates.add(criteriaBuilder.like(dateStringExpr, "%" + filterData + "%"));
							}
						}
						break;
					}
				});
			}
		} catch (Exception ex) {
			log.info("Exception in create predicate");
		}
		return predicates;
	}

	@Override
	@Transactional
	public ResponseEntity updateServiceRegistry(ServiceRegistryRequest request) {
		if (serviceRegistryRepo.existsById(request.getServiceId())) {
			Optional<ServiceRegistryEntity> entityOpt = serviceRegistryRepo.findById(request.getServiceId());
			ServiceRegistryEntity entity = entityOpt.get();
			if (entity != null) {
				Optional<String> optSD = Optional.ofNullable(request.getServiceDefinition());
				if (optSD.isPresent()) {
					if (isJSONValid(request.getServiceDefinition())) {
						entity.setServiceDefinition(request.getServiceDefinition());
					}
				}

				Optional<String> optRS = Optional.ofNullable(request.getReqSpec());
				if (optRS.isPresent()) {
					if (isJSONValid(request.getReqSpec())) {
						entity.setReqSpec(request.getReqSpec());
					}
				}

				Optional<String> optED = Optional.ofNullable(request.getErrorDoc());
				if (optED.isPresent()) {
					if (isJSONValid(request.getErrorDoc())) {
						entity.setErrorDoc(request.getErrorDoc());
					}
				}

				Optional<String> optVI = Optional.ofNullable(request.getVastId());
				if (optVI.isPresent()) {
					entity.setVastId(request.getVastId());
				}
				Optional<String> optON = Optional.ofNullable(request.getOperationName());
				if (optON.isPresent()) {
					entity.setVastId(request.getOperationName());
				}
				ServiceRegistryEntity response = serviceRegistryRepo.save(entity);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}
		return new ResponseEntity<>("Unable to update, Bad request found", HttpStatus.BAD_REQUEST);
	}

	public boolean isJSONValid(String test) {
		try {
			new JSONArray(test);
		} catch (JSONException ex) {
			try {
				new JSONObject(test);	
			} catch (JSONException ex1) {
				return false;
			}
		}
		return true;
	}

}
