package com.vz.sd.controller;

import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.sd.beans.ServiceRegistryRequest;
import com.vz.sd.exception.ServiceRegistryDisplayServiceException;
import com.vz.sd.service.ServiceRegistryService;
import com.vz.sd.util.SRDataListResponse;
import com.vz.sd.util.ServiceRegistryPage;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ServiceRegistryController {

	private final ServiceRegistryService serviceRegistryService;

	private ServiceRegistryController(ServiceRegistryService serviceRegistryServicess) {
		this.serviceRegistryService = serviceRegistryServicess;
	}

	private static final Logger logger = LogManager.getLogger(ServiceRegistryController.class);

	@RequestMapping(value = { "/getsrlist" }, method = RequestMethod.GET, produces = { "application/json" })
	public ResponseEntity<SRDataListResponse> getServiceRegistry(
			@RequestBody(required = false) ServiceRegistryPage request) {
		if (request==null) {
			request= new ServiceRegistryPage();
			request.setPageNo(0);
			request.setPageSize(10);
		}
		return serviceRegistryService.getServiceRegistrylist(request);
	}
	
	@RequestMapping(value = { "/getsrlist" }, method = RequestMethod.POST, produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity<SRDataListResponse> postServiceRegistry(
			@RequestBody(required = false) ServiceRegistryPage request) {
		Optional<Integer> optPn = Optional.ofNullable(request.getPageNo());
		Optional<Integer> optPs = Optional.ofNullable(request.getPageSize());
		if (!optPs.isPresent() || !optPn.isPresent()) {
			throw new ServiceRegistryDisplayServiceException("Page-number or Page-size is null or empty");
		}
		return serviceRegistryService.getServiceRegistrylist(request);
	}

}
