package com.vz.sd.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "SERVICE_REGISTRY")
public class ServiceRegistryEntity {
	@Id
	@Column(name = "SERVICE_ID")
	private Integer serviceId;
	
	@Column(name = "SERVICE_NAME")
	private String serviceName;
	@Column(name = "VERSION")
	private String version;
	@Column(name = "ORG")
	private String org;
	@Column(name = "DOMAIN")
	private String domain;
	@Column(name = "SUB_DOMAIN")
	private String subDomain;
	@Column(name = "IS_ASYNC")
	private String isAsync;
	@Lob
	@Column(name = "SERVICE_DEFINTION")
	private String serviceDefinition;
	

	@Lob
	@Column(name = "REQUEST_SPEC")
	private String reqSpec;
	@Column(name = "RESPONSE_SPEC")
	private String responseSpec;
	@Column(name = "IS_ACTIVE")
	private String isActive;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "UPDATED_BY")
	private String updatedby;
	
	@Lob
	@Column(name = "ERROR_DOC")
	private String errorDoc;
	
	@Column(name = "CREATED_DATE_TIME")
	private Date createddatetime;
	
	@Column(name = "UPDATED_DATE_TIME")
	private Date updatedatetime;
	
	@Column(name = "VAST_ID")
	private String vastId;
	
	@Column(name = "OPERATION_NAME")
	private String operationName;
	
	
	public String getVastId() {
		return vastId;
	}

	public void setVastId(String vastId) {
		this.vastId = vastId;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	
	
	public String getServiceDefinition() {
		return serviceDefinition;
	}

	public void setServiceDefinition(String serviceDefinition) {
		this.serviceDefinition = serviceDefinition;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public String getIsAsync() {
		return isAsync;
	}

	public void setIsAsync(String isAsync) {
		this.isAsync = isAsync;
	}

	

	public String getReqSpec() {
		return reqSpec;
	}

	public void setReqSpec(String reqSpec) {
		this.reqSpec = reqSpec;
	}

	public String getResponseSpec() {
		return responseSpec;
	}

	public void setResponseSpec(String responseSpec) {
		this.responseSpec = responseSpec;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public String getErrorDoc() {
		return errorDoc;
	}

	public void setErrorDoc(String errorDoc) {
		this.errorDoc = errorDoc;
	}

	public Date getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(Date createddatetime) {
		this.createddatetime = createddatetime;
	}

	public Date getUpdatedatetime() {
		return updatedatetime;
	}

	public void setUpdatedatetime(Date updatedatetime) {
		this.updatedatetime = updatedatetime;
	}



}
