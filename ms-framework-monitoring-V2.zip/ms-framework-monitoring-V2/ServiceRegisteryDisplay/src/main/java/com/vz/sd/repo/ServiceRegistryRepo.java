package com.vz.sd.repo;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vz.sd.entity.ServiceRegistryEntity;

@Repository
public interface ServiceRegistryRepo extends CrudRepository<ServiceRegistryEntity,Integer>,JpaSpecificationExecutor<ServiceRegistryEntity>{
	

}
