package com.vz.sd.util;

public class SearchOptionsDto {

    private String columnName;
    private String orderBy;
    private String filerValue;

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getFilerValue() {
        return filerValue;
    }

    public void setFilerValue(String filerValue) {
        this.filerValue = filerValue;
    }
}
