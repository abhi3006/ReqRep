package com.vz.sd.beans;

import java.time.LocalDateTime;

public class ServiceRegistrySearchCriteria {

	private Integer serviceId;
	private String serviceName;
	private String version;
	private String org;
	private String domain;
	private String subDomain;
	private String isAsync;
	private String serviceDefintion;
	private String reqSpec;
	private String responseSpec;
	private String isActive;
	private String createdBy;
	private String updatedby;	
	private String errorDoc;
	private String vastId;	
	private String operationName;
	private LocalDateTime createddatetime;	
	private LocalDateTime updatedatetime;
	
	
	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public String getIsAsync() {
		return isAsync;
	}

	public void setIsAsync(String isAsync) {
		this.isAsync = isAsync;
	}

	public String getServiceDefintion() {
		return serviceDefintion;
	}

	public void setServiceDefintion(String serviceDefintion) {
		this.serviceDefintion = serviceDefintion;
	}

	public String getReqSpec() {
		return reqSpec;
	}

	public void setReqSpec(String reqSpec) {
		this.reqSpec = reqSpec;
	}

	public String getResponseSpec() {
		return responseSpec;
	}

	public void setResponseSpec(String responseSpec) {
		this.responseSpec = responseSpec;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedby() {
		return updatedby;
	}

	public void setUpdatedby(String updatedby) {
		this.updatedby = updatedby;
	}

	public String getErrorDoc() {
		return errorDoc;
	}

	public void setErrorDoc(String errorDoc) {
		this.errorDoc = errorDoc;
	}

	

	public LocalDateTime getCreateddatetime() {
		return createddatetime;
	}

	public void setCreateddatetime(LocalDateTime createddatetime) {
		this.createddatetime = createddatetime;
	}

	public LocalDateTime getUpdatedatetime() {
		return updatedatetime;
	}

	public void setUpdatedatetime(LocalDateTime updatedatetime) {
		this.updatedatetime = updatedatetime;
	}

	public String getVastId() {
		return vastId;
	}

	public void setVastId(String vastId) {
		this.vastId = vastId;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

}
