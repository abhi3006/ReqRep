package com.vz.sd.service;

import org.springframework.http.ResponseEntity;

import com.vz.sd.beans.ServiceRegistryRequest;
import com.vz.sd.util.ServiceRegistryPage;

public interface ServiceRegistryService {

	ResponseEntity getServiceRegistrylist(ServiceRegistryPage request);

	ResponseEntity updateServiceRegistry(ServiceRegistryRequest request);
	
}
