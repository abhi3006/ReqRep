# Getting Started


POST- http://127.0.0.1:8080/serviceregistrydisplay/getsrlist

{
    "pageSize" : "10",
    "pageNo" : "0",
    "searchOptions":[
        {
            "columnName": "serviceName",
            "orderBy": "",
            "filerValue": ""
        },
        {
            "columnName": "org",
            "orderBy": "",
            "filerValue": ""
        },
        {
            "columnName": "updatedatetime",
            "orderBy": "asc",
            "filerValue": "29"
        }
    ]
}

GET- http://127.0.0.1:8080/serviceregistrydisplay/getsrlist