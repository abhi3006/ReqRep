package com.vz.wm.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.wm.beans.ServiceRegistryRequest;
import com.vz.wm.service.ServiceRegistryService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ServiceRegistryController {
	
	@Autowired
	ServiceRegistryService serviceRegistryService;


	private static final Logger logger = LogManager.getLogger(ServiceRegistryController.class);

	@RequestMapping(value = { "/serviceRegistry" }, method = RequestMethod.POST, produces = {
			"application/json" }, consumes = { "application/json" })
	public  Map<String, String> saveServiceRegistry(@RequestBody ServiceRegistryRequest serviceRegistryRequest, HttpServletRequest req) {
		logger.info("Entered into ServiceRegistryController, ServiceRegistry API:" + serviceRegistryService);
		return  serviceRegistryService.saveServiceRegistry(serviceRegistryRequest);
	}
	
	@RequestMapping(value = { "/update" }, method = RequestMethod.POST, produces = { "application/json" }, consumes = { "application/json" })
	public ResponseEntity updateServiceRegistry(
			@RequestBody(required = true) ServiceRegistryRequest request) {
		return serviceRegistryService.updateServiceRegistry(request);
	}

}
