package com.vz.wm.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vz.wm.beans.ServiceRegistryRequest;
import com.vz.wm.entity.ServiceRegistryEntity;
import com.vz.wm.repo.ServiceRegistryRepo;

import net.bytebuddy.build.Plugin.Engine.Source.Empty;

@Service
public class ServiceRegistryService {

	@Autowired
	ServiceRegistryRepo serviceRegistryRepo;

	private static final Logger log = LoggerFactory.getLogger(ServiceRegistryService.class);

	public Map<String, String> saveServiceRegistry(ServiceRegistryRequest request) {
		Map<String, String> response = new HashMap<>();

		ServiceRegistryEntity sre = new ServiceRegistryEntity();

		if (request.getServiceName() != null && !request.getServiceName().isEmpty() && request.getVersion() != null
				&& !request.getVersion().isEmpty() && request.getOrg() != null && !request.getOrg().isEmpty()
				&& request.getDomain() != null && !request.getDomain().isEmpty() && request.getSubDomain() != null
				&& !request.getSubDomain().isEmpty() && request.getIsAsync() != null && !request.getIsAsync().isEmpty()
				&& request.getServiceDefinition() != null && !request.getServiceDefinition().isEmpty()
				&& request.getReqSpec() != null && !request.getReqSpec().isEmpty() && request.getErrorDoc() != null
				&& !request.getErrorDoc().isEmpty() && !request.getVastId().isEmpty()
				&& !request.getOperationName().isEmpty())

		{

			log.info("ServiceID - " + request.getServiceId());
			sre.setServiceId(request.getServiceId());

			if (request.getServiceName() != null && !request.getServiceName().isEmpty()) {
				log.info("ServiceName - " + request.getServiceName());
				sre.setServiceName(request.getServiceName());
			}
			if (request.getVersion() != null && !request.getVersion().isEmpty()) {
				log.info("Version - " + request.getVersion());
				sre.setVersion(request.getVersion());
			}
			if (request.getOrg() != null && !request.getOrg().isEmpty()) {
				log.info("Org - " + request.getOrg());
				sre.setOrg(request.getOrg());
			}
			if (request.getDomain() != null && !request.getDomain().isEmpty()) {
				log.info("Domain - " + request.getDomain());
				sre.setDomain(request.getDomain());
			}
			if (request.getSubDomain() != null && !request.getSubDomain().isEmpty()) {
				log.info("SubDomain - " + request.getSubDomain());
				sre.setSubDomain(request.getSubDomain());
			}
			if (request.getIsAsync() != null && !request.getIsAsync().isEmpty()) {
				log.info("IsASync - " + request.getIsAsync());
				sre.setIsAsync(request.getIsAsync());
			}

			if (request.getServiceDefinition() != null && !request.getServiceDefinition().isEmpty()) {
				log.info("ServiceDefinition - " + request.getServiceDefinition());
				sre.setServiceDefinition(request.getServiceDefinition());
			}
			if (request.getReqSpec() != null && !request.getReqSpec().isEmpty()) {

				log.info("ReqSpec - " + request.getReqSpec());
				sre.setReqSpec(request.getReqSpec());
			}

			if (request.getErrorDoc() != null && !request.getErrorDoc().isEmpty()) {

				log.info("ErrorDoc - " + request.getErrorDoc());
				sre.setErrorDoc(request.getErrorDoc());
			}
			if (request.getVastId() != null) {
				sre.setVastId(request.getVastId());
			}
			if (request.getOperationName() != null) {
				sre.setOperationName(request.getOperationName());
			}

			/*
			 * log.info("IsActive - " + request.getIsActive()); sre.setIsActive("Yes");
			 */

			if (request.getResponseSpec() == null || request.getIsActive() == null || request.getCreatedBy() == null
					|| request.getUpdatedby() == null || request.getCreateddatetime() == null
					|| request.getUpdatedatetime() == null) {

				if (request.getServiceId() != null || request.getServiceId() == null)
					;
				if (request.getResponseSpec() != null || request.getResponseSpec() == null)
					;
				if (request.getIsActive() != null || request.getIsActive() == null)
					;
				if (request.getCreatedBy() != null || request.getCreatedBy() == null)
					;
				if (request.getUpdatedby() != null || request.getUpdatedby() == null)
					;
				if (request.getCreateddatetime() != null || request.getCreateddatetime() == null)
					;
				if (request.getUpdatedatetime() != null || request.getUpdatedatetime() == null)
					;
				log.info("ResponseSpec - " + request.getResponseSpec());
				sre.setResponseSpec("null");
				log.info("IsActive - " + request.getIsActive());
				sre.setIsActive("Yes");
				log.info("CreatedBy - " + request.getCreatedBy());
				sre.setCreatedBy("null");
				log.info("Updatedby - " + request.getUpdatedby());
				sre.setUpdatedby("null");
				log.info("Created_date_Time - " + request.getCreateddatetime());
				sre.setCreateddatetime(request.getCreateddatetime());
				log.info("Updated_date_Time - " + request.getUpdatedatetime());
				sre.setUpdatedatetime(request.getUpdatedatetime());
			}
			serviceRegistryRepo.save(sre);

			response.put("Message", "Success");

		} else {
			response.put("Message", "Failed");
		}

		return response;

	}

	@Transactional
	public ResponseEntity updateServiceRegistry(ServiceRegistryRequest request) {
		if (serviceRegistryRepo.existsById(request.getServiceId())) {
			Optional<ServiceRegistryEntity> entityOpt = serviceRegistryRepo.findById(request.getServiceId());
			ServiceRegistryEntity entity = entityOpt.get();
			if (entity != null) {
				Optional<String> optSD = Optional.ofNullable(request.getServiceDefinition());
				if (optSD.isPresent()) {
					if (isJSONValid(request.getServiceDefinition())) {
						entity.setServiceDefinition(request.getServiceDefinition());
					}
				}

				Optional<String> optRS = Optional.ofNullable(request.getReqSpec());
				if (optRS.isPresent()) {
					if (isJSONValid(request.getReqSpec())) {
						entity.setReqSpec(request.getReqSpec());
					}
				}

				Optional<String> optED = Optional.ofNullable(request.getErrorDoc());
				if (optED.isPresent()) {
					if (isJSONValid(request.getErrorDoc())) {
						entity.setErrorDoc(request.getErrorDoc());
					}
				}

				Optional<String> optVI = Optional.ofNullable(request.getVastId());
				if (optVI.isPresent()) {
					entity.setVastId(request.getVastId());
				}
				Optional<String> optON = Optional.ofNullable(request.getOperationName());
				if (optON.isPresent()) {
					entity.setOperationName(request.getOperationName());
				}

				Optional<String> optSN = Optional.ofNullable(request.getServiceName());
				if (optSN.isPresent()) {
					entity.setServiceName(request.getServiceName());
				}

				Optional<String> optIA = Optional.ofNullable(request.getIsAsync());
				if (optIA.isPresent()) {
					entity.setIsAsync(request.getIsAsync());
				}
				Optional<String> optSDO = Optional.ofNullable(request.getSubDomain());
				if (optSDO.isPresent()) {
					entity.setSubDomain(request.getSubDomain());
				}
				Optional<String> optDO = Optional.ofNullable(request.getDomain());
				if (optDO.isPresent()) {
					entity.setDomain(request.getDomain());
				}
				Optional<String> optOR = Optional.ofNullable(request.getOrg());
				if (optOR.isPresent()) {
					entity.setOrg(request.getOrg());
				}

				Optional<String> optVE = Optional.ofNullable(request.getVersion());
				if (optVE.isPresent()) {
					entity.setVersion(request.getVersion());
				}

				ServiceRegistryEntity response = serviceRegistryRepo.save(entity);
				
				return new ResponseEntity<>(response, HttpStatus.OK);
			} 
		}
		return new ResponseEntity<>("Unable to update, Bad request or ID not found", HttpStatus.BAD_REQUEST);
	}

	public boolean isJSONValid(String test) {
		try {
			new JSONArray(test);
		} catch (JSONException ex) {
			try {
				new JSONObject(test);
			} catch (JSONException ex1) {
				return false;
			}
		}
		return true;
	}

}
