package com.vz.wm.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vz.wm.entity.ServiceRegistryEntity;
@Repository
public interface ServiceRegistryRepo extends CrudRepository<ServiceRegistryEntity, Integer> {

}
