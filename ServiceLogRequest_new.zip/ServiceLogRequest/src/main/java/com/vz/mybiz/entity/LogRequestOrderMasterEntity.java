package com.vz.mybiz.entity;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ORDER_MASTER")
public class LogRequestOrderMasterEntity implements Serializable {

    @Id
    @Column(name="ID", nullable=true)
    private String id;
    @Column(name="ORDER_NBR", nullable=true, length=50)
    private String order_nbr;
    @Column(name="GROUP_ORDER_NBR", nullable=true, length=50)
    private String group_order_nbr;
    @Column(name="ORDER_TYPE", nullable=true, length=200)
    private String order_type;
    @Column(name="ORDER_STATUS", nullable=true, length=25)
    private String order_status;
    @Column(name="ORDER_COUNT", nullable=true)
    private String order_count;
    @Column(name="POS_ORDER_NR", nullable=true, length=50)
    private String pos_order_nr;
    @Column(name="NETACE_LOCATION", nullable=true, length=60)
    private String netace_location;
    @Column(name="ECPD_ID", nullable=true)
    private String ecpd_id;
    @Column(name="OP_CENTER", nullable=true, length=16)
    private String op_center;
    @Column(name="IS_MANAGER_APPROVAL", nullable=true, length=10)
    private String is_manager_approval;
    @Column(name="ORDER_CHANNEL", nullable=true, length=10)
    private String order_channel;
    @Column(name="ORDER_REQUEST", nullable=true)
    private String order_request;
    @Column(name="ORDER_RESPONSE", nullable=true)
    private String order_response;
    @Column(name="CREATED_BY", nullable=true, length=100)
    private String created_by;
    @Column(name="CREATED_DT", nullable=true)
    private String created_dt;
    @Column(name="MODIFIED_BY", nullable=true, length=100)
    private String modified_by;
    @Column(name="MODIFIED_DT", nullable=true)
    private String modified_dt;
    @Column(name="SERVER_INSTANCE", nullable=true, length=100)
    private String server_instance;
    @Column(name="PRE_ORDER_NBR", nullable=true, length=50)
    private String pre_order_nbr;
    @Column(name="CREDIT_APP_NBR", nullable=true, length=50)
    private String credit_app_nbr;
    @Column(name="MULTILINE_SEQ_NBR", nullable=true, length=50)
    private String multiline_seq_nbr;
    @Column(name="NEW_PO_NBR", nullable=true, length=100)
    private String new_po_nbr;
    @Column(name="IP_ADDRESS", nullable=true, length=15)
    private String ip_address;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public String getOrder_nbr() {
        return order_nbr;
    }
    public void setOrder_nbr(String order_nbr) {
        this.order_nbr = order_nbr;
    }


    public String getGroup_order_nbr() {
        return group_order_nbr;
    }
    public void setGroup_order_nbr(String group_order_nbr) {
        this.group_order_nbr = group_order_nbr;
    }


    public String getOrder_type() {
        return order_type;
    }
    public void setOrder_type(String order_type) {
        this.order_type = order_type;
    }


    public String getOrder_status() {
        return order_status;
    }
    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }


    public String getOrder_count() {
        return order_count;
    }
    public void setOrder_count(String order_count) {
        this.order_count = order_count;
    }


    public String getPos_order_nr() {
        return pos_order_nr;
    }
    public void setPos_order_nr(String pos_order_nr) {
        this.pos_order_nr = pos_order_nr;
    }


    public String getNetace_location() {
        return netace_location;
    }
    public void setNetace_location(String netace_location) {
        this.netace_location = netace_location;
    }


    public String getEcpd_id() {
        return ecpd_id;
    }
    public void setEcpd_id(String ecpd_id) {
        this.ecpd_id = ecpd_id;
    }


    public String getOp_center() {
        return op_center;
    }
    public void setOp_center(String op_center) {
        this.op_center = op_center;
    }


    public String getIs_manager_approval() {
        return is_manager_approval;
    }
    public void setIs_manager_approval(String is_manager_approval) {
        this.is_manager_approval = is_manager_approval;
    }


    public String getOrder_channel() {
        return order_channel;
    }
    public void setOrder_channel(String order_channel) {
        this.order_channel = order_channel;
    }


    public String getOrder_request() {
        return order_request;
    }
    public void setOrder_request(String order_request) {
        this.order_request = order_request;
    }


    public String getOrder_response() {
        return order_response;
    }
    public void setOrder_response(String order_response) {
        this.order_response = order_response;
    }


    public String getCreated_by() {
        return created_by;
    }
    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }


    public String getCreated_dt() {
        return created_dt;
    }
    public void setCreated_dt(String created_dt) {
        this.created_dt = created_dt;
    }


    public String getModified_by() {
        return modified_by;
    }
    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }


    public String getModified_dt() {
        return modified_dt;
    }
    public void setModified_dt(String modified_dt) {
        this.modified_dt = modified_dt;
    }


    public String getServer_instance() {
        return server_instance;
    }
    public void setServer_instance(String server_instance) {
        this.server_instance = server_instance;
    }


    public String getPre_order_nbr() {
        return pre_order_nbr;
    }
    public void setPre_order_nbr(String pre_order_nbr) {
        this.pre_order_nbr = pre_order_nbr;
    }


    public String getCredit_app_nbr() {
        return credit_app_nbr;
    }
    public void setCredit_app_nbr(String credit_app_nbr) {
        this.credit_app_nbr = credit_app_nbr;
    }


    public String getMultiline_seq_nbr() {
        return multiline_seq_nbr;
    }
    public void setMultiline_seq_nbr(String multiline_seq_nbr) {
        this.multiline_seq_nbr = multiline_seq_nbr;
    }


    public String getNew_po_nbr() {
        return new_po_nbr;
    }
    public void setNew_po_nbr(String new_po_nbr) {
        this.new_po_nbr = new_po_nbr;
    }


    public String getIp_address() {
        return ip_address;
    }
    public void setIp_address(String ip_address) {
        this.ip_address = ip_address;
    }


}

