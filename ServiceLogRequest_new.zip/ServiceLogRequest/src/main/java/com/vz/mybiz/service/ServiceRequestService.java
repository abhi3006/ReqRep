package com.vz.mybiz.service;

import com.vz.mybiz.entity.ServiceRequestEntity;
import com.vz.mybiz.repository.ServiceRequestRepository;
import com.vz.mybiz.util.LogRequestDto;
import com.vz.mybiz.util.SRDataListResponse;
import com.vz.mybiz.util.ServiceRegistryPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Service
public class ServiceRequestService implements IServiceRequestService {
	@Autowired
	private ServiceRequestRepository serviceRequestRepository;
	@Override
	@Transactional(readOnly = true)
	public ResponseEntity getServiceRegistryEcpdIdList(ServiceRegistryPage request, Long id) {
		Pageable paging = PageRequest.of(request.getPageNo(), request.getPageSize());
		Page<ServiceRequestEntity> pagedResult =  findByECPDIDCriteria(request, paging,id);
		List<ServiceRequestEntity> mapList = null;
		if (pagedResult.hasContent()) {
			mapList = pagedResult.getContent();
		}
		SRDataListResponse sdResponse = new SRDataListResponse();
		sdResponse.setTotalElements(pagedResult.getTotalElements());
		sdResponse.setPageSize(pagedResult.getSize());
		sdResponse.setTotalPages(pagedResult.getTotalPages());
		sdResponse.setCurrentPageNo(pagedResult.getNumber());
		sdResponse.setData(mapList);
		return new ResponseEntity<>(sdResponse, HttpStatus.OK);

	}

	public Page<ServiceRequestEntity> findByECPDIDCriteria(ServiceRegistryPage request, Pageable pageable, Long ecpdId) {
		Page<ServiceRequestEntity> EcpdIdList = serviceRequestRepository.findByEcpdId(ecpdId, pageable);
		return EcpdIdList;
	}

	public LogRequestDto logRequestList(ServiceRegistryPage request, Long id) {
		return null;
	}
}
