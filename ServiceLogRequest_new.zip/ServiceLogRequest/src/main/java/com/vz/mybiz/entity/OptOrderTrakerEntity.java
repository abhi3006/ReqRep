package com.vz.mybiz.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "OPT_ORDER_TRACKING")
public class OptOrderTrakerEntity implements Serializable {
    @Id
    @Column(name="ID", nullable=true)
    private String id;
    @Column(name="ORDER_NBR", nullable=true, length=50)
    private String order_nbr;
    @Column(name="OPT_TRANSACTION_ID", nullable=true, length=50)
    private String opt_transaction_id;
    @Column(name="OPT_STATUS", nullable=true, length=25)
    private String opt_status;
    @Column(name="OPT_STEP_ID", nullable=true, length=50)
    private String opt_step_id;
    @Column(name="OPT_MESSAGE", nullable=true, length=1000)
    private String opt_message;
    @Column(name="CREATED_BY", nullable=true, length=100)
    private String created_by;
    @Column(name="CREATED_DT", nullable=true)
    private String created_dt;
    @Column(name="MODIFIED_BY", nullable=true, length=100)
    private String modified_by;
    @Column(name="MODIFIED_DT", nullable=true)
    private String modified_dt;
    @Column(name="SERVER_INSTANCE", nullable=true, length=100)
    private String server_instance;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }


    public String getOrder_nbr() {
        return order_nbr;
    }
    public void setOrder_nbr(String order_nbr) {
        this.order_nbr = order_nbr;
    }


    public String getOpt_transaction_id() {
        return opt_transaction_id;
    }
    public void setOpt_transaction_id(String opt_transaction_id) {
        this.opt_transaction_id = opt_transaction_id;
    }


    public String getOpt_status() {
        return opt_status;
    }
    public void setOpt_status(String opt_status) {
        this.opt_status = opt_status;
    }


    public String getOpt_step_id() {
        return opt_step_id;
    }
    public void setOpt_step_id(String opt_step_id) {
        this.opt_step_id = opt_step_id;
    }


    public String getOpt_message() {
        return opt_message;
    }
    public void setOpt_message(String opt_message) {
        this.opt_message = opt_message;
    }


    public String getCreated_by() {
        return created_by;
    }
    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }


    public String getCreated_dt() {
        return created_dt;
    }
    public void setCreated_dt(String created_dt) {
        this.created_dt = created_dt;
    }


    public String getModified_by() {
        return modified_by;
    }
    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }


    public String getModified_dt() {
        return modified_dt;
    }
    public void setModified_dt(String modified_dt) {
        this.modified_dt = modified_dt;
    }


    public String getServer_instance() {
        return server_instance;
    }
    public void setServer_instance(String server_instance) {
        this.server_instance = server_instance;
    }


}