package com.vz.mybiz.util;

public class SubmitWorkFlowDto {
    public String optStepId;
    public String optMessage;
    public String optStatus;
    public String createdBy;
    public String serverInstance;
    public String createdDate;

    public String getOptStepId() {
        return optStepId;
    }

    public void setOptStepId(String optStepId) {
        this.optStepId = optStepId;
    }

    public String getOptMessage() {
        return optMessage;
    }

    public void setOptMessage(String optMessage) {
        this.optMessage = optMessage;
    }

    public String getOptStatus() {
        return optStatus;
    }

    public void setOptStatus(String optStatus) {
        this.optStatus = optStatus;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getServerInstance() {
        return serverInstance;
    }

    public void setServerInstance(String serverInstance) {
        this.serverInstance = serverInstance;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
