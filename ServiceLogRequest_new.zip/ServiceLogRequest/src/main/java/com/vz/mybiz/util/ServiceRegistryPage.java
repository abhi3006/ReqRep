package com.vz.mybiz.util;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.List;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceRegistryPage {

	private List<SearchOptionsDto> searchOptions;
	private Integer pageSize;
	private Integer pageNo;

	public List<SearchOptionsDto> getSearchOptions() {
		return searchOptions;
	}

	public void setSearchOptions(List<SearchOptionsDto> searchOptions) {
		this.searchOptions = searchOptions;
	}
	
	
	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	

}
